import { translateStatus, translateUi } from './language';

// Only system-owned enums/messages are localized. Counterparty names, document
// identifiers, payment purposes and references must retain their original text.
const translatedFields = new Set(['kind', 'type', 'glEntry', 'side', 'category', 'confidence', 'rule', 'reason', 'clientAssignment', 'availability']);
export function reconciliationValueText(field: string, value: string): string {
  if (field === 'status') return translateStatus(value);
  if (field === 'glEntry') {
    return translateUi(value).replace(/: (Debit|Credit)(?= · |$)/g, (_match, side: string) => `: ${translateUi(side)}`);
  }
  return translatedFields.has(field) ? translateUi(value) : value;
}
