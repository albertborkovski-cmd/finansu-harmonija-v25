import { documentActionSnapshot } from './documentRowActions';
import { stornoPeriodError, testStornoOriginalDate, type StornoDocument, type StornoPeriodPolicy } from './documentStorno';

export type CancelDocumentApprovalCommand = { expectedSnapshot: string; reason: string };
export type ApprovalCancellationEvent = {
  id: string; at: string; actor: string; action: 'Approval cancelled'; reason: string;
  fromStatus: string; fromAccountingStatus?: string; toStatus: 'Draft';
};
type ApprovalContext = { allowed: boolean; today: string; period: StornoPeriodPolicy; hasCorrections: boolean };
const normalized = (value: unknown) => String(value ?? '').trim().toLowerCase();

/** Cancellation returns an unposted, untransferred approval to Draft. It never
 * reverses accounting entries or recalls a document from an external system. */
export function cancelDocumentApprovalBlocker(document: StornoDocument, context: ApprovalContext): string {
  if (!context.allowed) return 'You need View and Edit access to this company’s documents.';
  if (document.document_deletion || document.inactive || document.active === false || document.is_active === false)
    return 'This document is no longer active.';
  const states = [normalized(document.status), normalized(document.accounting_note_status)];
  if (!['approved', 'confirmed'].includes(states[0] || states[1])) return 'Only an approved or confirmed document can be returned for correction.';
  if (document.accounting_posting || document.accounting_storno || document.document_storno)
    return 'This document has accounting or reversal entries. Its approval cannot be cancelled.';
  if (context.hasCorrections || document.corrected_by_document_id) return 'A corrective document already exists. Review the correction before cancelling approval.';
  if (states.some(state => ['transferred', 'exported', 'posted', 'paid', 'processing'].includes(state))
    || Object.entries(document).some(([key, value]) => /^(exported|transferred|external_posting|external_document)(_|$)/i.test(key) && Boolean(value))
    || [document.accounting_transfer_status, document.export_status, document.transfer_status, document.integration_status]
      .some(value => value != null && !['', 'not sent', 'not exported', 'not transferred', 'none'].includes(normalized(value))))
    return 'The document has been sent to accounting or its transfer is not verified as unsent.';
  if (Array.isArray(document.digitization_issues) && document.digitization_issues.some(issue => issue.status === 'Awaiting OCR'))
    return 'Wait for OCR reprocessing before cancelling approval.';
  const date = testStornoOriginalDate(document);
  if (!date) return 'A valid accounting date is required to check the period.';
  const periodError = stornoPeriodError(date, date, context.today, context.period);
  if (periodError) return 'Approval cannot be cancelled: the document date is outside an open accounting period.';
  return '';
}

export function prepareDocumentApprovalCancellation(document: StornoDocument, command: CancelDocumentApprovalCommand,
  context: ApprovalContext & { id: string; actor: string; now: string }) {
  const blocker = cancelDocumentApprovalBlocker(document, context);
  if (blocker) throw new Error(blocker);
  if (command.expectedSnapshot !== documentActionSnapshot(document)) throw new Error('The document changed. Reopen Cancel approval before continuing.');
  if (command.reason.length > 2000) throw new Error('The reason must not exceed 2,000 characters.');
  const event: ApprovalCancellationEvent = { id: context.id, at: context.now, actor: context.actor,
    action: 'Approval cancelled', reason: command.reason.trim(), fromStatus: String(document.status ?? ''),
    ...('accounting_note_status' in document ? { fromAccountingStatus: String(document.accounting_note_status ?? '') } : {}), toStatus: 'Draft' };
  return { event, patch: { status: 'Draft', ...('accounting_note_status' in document ? { accounting_note_status: 'Draft' } : {}) } };
}
