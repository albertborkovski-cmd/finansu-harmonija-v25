import type { DbDocument } from './supabase';
import { isRecordLinked } from './recordLifecycle';
import { uploadedDocumentDisplayStatus } from './ocrDocumentStatusPresentation';
import { OCR_STATUS_SETTINGS_KEY } from './ocrStatuses';

/** Inspect current document states, computed OCR stages and persisted references/history.
 * The status catalogue's own descriptions/audit are not document usage. */
export function isOcrStatusLinked(status: string, documents: readonly DbDocument[], storage: Storage): boolean {
  const normalized = status.trim().toLocaleLowerCase();
  if (documents.some(document => document.status?.trim().toLocaleLowerCase() === normalized
    || uploadedDocumentDisplayStatus(document).toLocaleLowerCase() === normalized)) return true;
  const referenceStorage = {
    get length() { return storage.length; },
    key: (index: number) => storage.key(index),
    getItem: (key: string) => key === OCR_STATUS_SETTINGS_KEY ? null : storage.getItem(key),
  } as Storage;
  return isRecordLinked({ id: `ocr-status:${status}`, name: status }, OCR_STATUS_SETTINGS_KEY, referenceStorage);
}
