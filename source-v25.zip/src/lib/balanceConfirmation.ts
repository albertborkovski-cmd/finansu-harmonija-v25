import type { Company } from './supabase';
import type { DebtRow } from './companyRelatedObjectData';
import { debtAmountInCents, debtDirection } from './debtActions';
import { debtPayments } from './debtDetails';
import type { ReconciliationState } from './reconciliation';

export type BalanceParty = { name: string; code: string; vatCode: string; address: string; email: string };
export type BalanceLine = { id: string; date: string; document: string; description: string; debit: number; credit: number; balance: number };
export type BalanceStatement = {
  id: string; companyId: string; sender: BalanceParty; recipient: BalanceParty; debtIds: string[];
  date: string; from: string; to: string; currency: string; opening: number; closing: number; lines: BalanceLine[];
  language: 'EN' | 'LT'; createdAt: string;
};
export const BALANCE_PREVIEW_KEY = 'finansu-harmonija:v25:balance-confirmation-previews';
export const BALANCE_RESPONSES_KEY = 'finansu-harmonija:v25:balance-confirmation-responses';

export function balanceParty(company?: Partial<Company>, fallback = ''): BalanceParty {
  return { name: company?.name || fallback, code: company?.company_code || '', vatCode: company?.vat_code || '', address: company?.address || '', email: company?.email || '' };
}
export function balanceDate(value: string) {
  const result = /^\d{2}\.\d{2}\.\d{4}$/.test(value) ? value.split('.').reverse().join('-') : value.slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(result) || !Number.isFinite(Date.parse(result)) || new Date(result).toISOString().slice(0, 10) !== result) throw new Error('Enter valid confirmation dates.');
  return result;
}
export function validateBalancePeriod(date: string, from: string, to: string) {
  [date, from, to].forEach(balanceDate);
  if (from > to || to > date) throw new Error('The period must end on or before the confirmation date.');
}
export function balanceRecipientKey(row: DebtRow) {
  return JSON.stringify([row.counterpartyCode.trim() || row.counterpartyName.trim().toLowerCase(), row.currency]);
}

/** Signed balances from the sender's perspective; currencies never share a statement. */
export function buildBalanceStatements(rows: readonly DebtRow[], company: Company, contacts: readonly Company[], period: { date: string; from: string; to: string; language: 'EN' | 'LT' }, state?: ReconciliationState | null): BalanceStatement[] {
  validateBalancePeriod(period.date, period.from, period.to);
  if (!rows.length) throw new Error('Select at least one counterparty.');
  const grouped = new Map<string, DebtRow[]>();
  for (const row of rows) {
    if (!debtDirection(row) || debtAmountInCents(row.outstandingAmount, true) === null || !/^[A-Z]{3}$/.test(row.currency)) throw new Error('Invalid debt balance or currency.');
    const key = balanceRecipientKey(row), group = grouped.get(key) || [];
    if (!group.some(item => item.id === row.id)) group.push(row);
    grouped.set(key, group);
  }
  return [...grouped.entries()].map(([key, group]) => {
    const first = group[0];
    const matches = contacts.filter(contact => first.counterpartyCode ? [contact.company_code, contact.accounting_system_code].includes(first.counterpartyCode) : contact.name.trim().toLowerCase() === first.counterpartyName.trim().toLowerCase());
    const recipient = balanceParty(matches.length === 1 ? matches[0] : undefined, first.counterpartyName);
    if (!recipient.code) recipient.code = first.counterpartyCode;
    const entries: Omit<BalanceLine, 'balance'>[] = [];
    for (const row of group) {
      const total = debtAmountInCents(row.totalAmount, true), paid = debtAmountInCents(row.paidAmount, true);
      if (total === null || paid === null) throw new Error('Invalid document amount.');
      const payments = debtPayments(row, company.id, state);
      if (payments.reduce((sum, payment) => sum + payment.matchedMinor, 0) !== paid) throw new Error('Payment dates are missing. Review the payment history before creating a statement.');
      const receivable = debtDirection(row) === 'receivable';
      entries.push({ id: row.id, date: balanceDate(row.issueDate), document: row.documentReference, description: period.language === 'LT' ? 'Sąskaita faktūra' : 'Invoice', debit: receivable ? total : 0, credit: receivable ? 0 : total });
      payments.forEach(payment => entries.push({ id: payment.id, date: balanceDate(payment.date), document: payment.reference, description: `${period.language === 'LT' ? 'Mokėjimas' : 'Payment'}: ${row.documentReference}`, debit: receivable ? 0 : payment.matchedMinor, credit: receivable ? payment.matchedMinor : 0 }));
    }
    entries.sort((a, b) => a.date.localeCompare(b.date) || a.id.localeCompare(b.id));
    const opening = entries.filter(line => line.date < period.from).reduce((sum, line) => sum + line.debit - line.credit, 0);
    let running = opening;
    const lines = entries.filter(line => line.date >= period.from && line.date <= period.to).map(line => ({ ...line, balance: (running += line.debit - line.credit) }));
    return { id: key, companyId: company.id, sender: balanceParty(company), recipient, debtIds: group.map(row => row.id), ...period, currency: first.currency, opening, closing: running, lines, createdAt: new Date().toISOString() };
  });
}
export function balancePortalUrl(id: string, upload = false) {
  return `${window.location.origin}${import.meta.env.BASE_URL}balance-confirmation/${encodeURIComponent(id)}${upload ? '#upload' : ''}`;
}
export function saveBalancePreview(statement: BalanceStatement, storage: Storage = localStorage) {
  const current = JSON.parse(storage.getItem(BALANCE_PREVIEW_KEY) || '{}');
  storage.setItem(BALANCE_PREVIEW_KEY, JSON.stringify({ ...current, [statement.id]: statement }));
}
export function loadBalancePreview(id: string, storage: Storage = localStorage): BalanceStatement | null {
  try { return JSON.parse(storage.getItem(BALANCE_PREVIEW_KEY) || '{}')[id] || null; } catch { return null; }
}
export function saveBalanceResponse(id: string, decision: 'confirm' | 'disagree', comment: string, storage: Storage = localStorage) {
  if (!loadBalancePreview(id, storage)) throw new Error('This confirmation link is not available in this browser.');
  if (decision === 'disagree' && !comment.trim()) throw new Error('Describe the discrepancy before submitting.');
  if (!['confirm', 'disagree'].includes(decision)) throw new Error('Choose a response.');
  const responses = JSON.parse(storage.getItem(BALANCE_RESPONSES_KEY) || '{}');
  if (responses[id]) throw new Error('A response has already been saved.');
  responses[id] = { decision, comment: comment.trim(), at: new Date().toISOString() };
  storage.setItem(BALANCE_RESPONSES_KEY, JSON.stringify(responses));
  return responses[id];
}
export function validateBalanceFiles(files: readonly File[]) {
  if (files.length > 20) throw new Error('Choose up to 20 files.');
  if (files.some(file => !/\.(pdf|jpe?g|png|tiff?|docx|xlsx)$/i.test(file.name) || file.size <= 0 || file.size > 50 * 1024 * 1024)) throw new Error('Use PDF, JPG, PNG, TIFF, DOCX or XLSX files up to 50 MB each.');
}
/** Local preview intake stores file bytes, not merely successful-looking file names. */
export async function saveBalanceFiles(statement: BalanceStatement, files: readonly File[]) {
  validateBalanceFiles(files);
  if (!files.length) throw new Error('Select files first.');
  const db = await new Promise<IDBDatabase>((resolve, reject) => {
    const request = indexedDB.open('fh-balance-confirmation-intake', 1);
    request.onupgradeneeded = () => request.result.createObjectStore('files', { keyPath: 'id' });
    request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error);
  });
  try {
    await new Promise<void>((resolve, reject) => {
      const transaction = db.transaction('files', 'readwrite');
      files.forEach(file => transaction.objectStore('files').put({ id: crypto.randomUUID(), statementId: statement.id, companyId: statement.companyId, counterparty: statement.recipient.name, file, name: file.name, at: new Date().toISOString() }));
      transaction.oncomplete = () => resolve(); transaction.onerror = () => reject(transaction.error); transaction.onabort = () => reject(transaction.error);
    });
  } finally { db.close(); }
}
