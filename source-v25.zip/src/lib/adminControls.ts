import { isSystemAdministratorRole, type AppSession } from './accessControl';
import { normalizeWorkspaceMode, workspaceModeStorageKey, type WorkspaceMode } from './workspaceMode';

export const ADMIN_CONTROLS_KEY = 'finansu-harmonija:v18:admin-controls';
export const ADMIN_CONTROLS_EVENT = 'fh-admin-controls-changed';
export type Maintenance = { id: string; start: number; end: number; reminderMinutes: number; message: string };
export type AdminControlPolicy = {
  maintenance: Maintenance | null;
  revokedBefore: Record<string, number>;
  blocks: Record<string, { until: number; reason: string }>;
};
export type AdminControls = AdminControlPolicy & {
  scopes?: Partial<Record<'ocr' | 'fh', AdminControlPolicy>>;
  history: { id: string; at: number; actor: string; action: string; scope?: WorkspaceMode }[];
};
const emptyPolicy = (): AdminControlPolicy => ({ maintenance: null, revokedBefore: {}, blocks: {} });
export function loadAdminControls(): AdminControls {
  const raw = window.localStorage.getItem(ADMIN_CONTROLS_KEY);
  return raw ? JSON.parse(raw) : { maintenance: null, revokedBefore: {}, blocks: {}, history: [] };
}
export const isControlAdmin = (session: AppSession) => !session.roleNames.includes('Inactive') && session.roleNames.some(isSystemAdministratorRole);
/** Legacy policies remain shared. Product policies are independent additions. */
export function adminControlsForScope(policy: AdminControls, scope: WorkspaceMode): AdminControls {
  return scope === 'combined' ? policy : { ...(policy.scopes?.[scope] || emptyPolicy()), history: policy.history };
}
export function updateAdminControls(session: AppSession, action: string, change: (current: AdminControls) => AdminControls, scope: WorkspaceMode = 'combined') {
  if (!isControlAdmin(session)) throw new Error('Only Meso Administrator can manage these settings.');
  if (!['ocr', 'fh', 'combined'].includes(scope)) throw new Error('Select an administration scope.');
  const current = loadAdminControls();
  const changed = change(structuredClone(adminControlsForScope(current, scope)));
  const { maintenance, revokedBefore, blocks } = changed;
  const next: AdminControls = scope === 'combined'
    ? { ...current, maintenance, revokedBefore, blocks }
    : { ...current, scopes: { ...current.scopes, [scope]: { maintenance, revokedBefore, blocks } } };
  next.history = [{ id: crypto.randomUUID(), at: Date.now(), actor: session.email, action, scope }, ...current.history];
  window.localStorage.setItem(ADMIN_CONTROLS_KEY, JSON.stringify(next));
  window.dispatchEvent(new Event(ADMIN_CONTROLS_EVENT));
  return next;
}
function applicablePolicies(policy: AdminControls, scope: WorkspaceMode): AdminControlPolicy[] {
  return [policy, ...(scope === 'combined' ? [policy.scopes?.ocr, policy.scopes?.fh] : [policy.scopes?.[scope]])].filter((item): item is AdminControlPolicy => Boolean(item));
}
export function loginRestriction(policy: AdminControls, session: AppSession, now: number, scope: WorkspaceMode = 'combined'): string | null {
  if (isControlAdmin(session)) return null;
  for (const item of applicablePolicies(policy, scope)) {
    const maintenance = item.maintenance;
    if (maintenance && now >= maintenance.start && now < maintenance.end) return `${maintenance.message} Access resumes ${new Date(maintenance.end).toLocaleString()}.`;
    const block = item.blocks[session.email.toLowerCase()];
    if (block && now < block.until) return `${block.reason} Access resumes ${new Date(block.until).toLocaleString()}.`;
  }
  return null;
}
export function sessionRevoked(policy: AdminControls, session: AppSession, startedAt: number, now = Date.now(), scope: WorkspaceMode = 'combined') {
  return !isControlAdmin(session) && applicablePolicies(policy, scope).some(item => {
    const scheduledCutoff = item.maintenance && item.maintenance.start <= now ? item.maintenance.start : 0;
    return Math.max(scheduledCutoff, item.revokedBefore['*'] || 0, item.revokedBefore[session.email.toLowerCase()] || 0) >= startedAt;
  });
}
export function upcomingAdminMaintenance(policy: AdminControls, now: number, scope: WorkspaceMode = 'combined'): Maintenance | null {
  return applicablePolicies(policy, scope).map(item => item.maintenance)
    .filter((plan): plan is Maintenance => Boolean(plan && now >= plan.start - plan.reminderMinutes * 60_000 && now < plan.start))
    .sort((a, b) => a.start - b.start)[0] || null;
}
export function adminSessionWorkspace(email: string): WorkspaceMode {
  try { return normalizeWorkspaceMode(JSON.parse(window.localStorage.getItem(workspaceModeStorageKey(email)) || 'null')); }
  catch { return 'combined'; }
}
