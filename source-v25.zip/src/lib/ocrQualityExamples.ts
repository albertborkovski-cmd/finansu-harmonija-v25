import { createOcrFormExamples as baseExamples, OCR_FORM_EXAMPLE_CONFIGS, OCR_FORM_EXAMPLE_TYPES } from './ocrTaskTabExamples';
export { OCR_FORM_EXAMPLE_CONFIGS, OCR_FORM_EXAMPLE_TYPES };
export const OCR_FORM_EXAMPLES_BATCH = 'v25-ocr-quality-warnings-v1';

export function createOcrFormExamples(companyId: string, organization: string, owner: { email: string; fullName: string }, at: string) {
  const base = baseExamples(companyId, organization, owner, at);
  const original = base.documents[2], saved = base.tasks[original.id];
  const documents = ['POOR', 'REVIEW', 'MULTIPLE'].map((scenario, index) => ({
    ...original, id: `${companyId}:${OCR_FORM_EXAMPLES_BATCH}:${scenario}`, file_case: `OCR-QUALITY-${scenario}.svg`,
    status: 'Worker review', ocr_poor_quality: scenario !== 'REVIEW', ocr_quality_review_required: scenario !== 'POOR',
    ocr_handwriting: index === 2 ? 'partial' as const : 'none' as const,
    number: index === 1 ? original.number : '',
    notes: `SYNTHETIC QUALITY WARNING TEST: ${scenario}. Not for accounting. Quality flags are test metadata, not a live OCR result.`,
  }));
  const tasks = Object.fromEntries(documents.map(document => [document.id, {
    ...saved, id: document.id, name: document.file_case, sourceRunId: OCR_FORM_EXAMPLES_BATCH,
    status: 'Available' as const, trainingStatus: undefined, savedAt: undefined, editStartedAt: undefined,
    fields: { ...saved.fields, invoiceNumber: document.number },
    accounting: { ...saved.accounting!, documentId: document.id, documentName: document.file_case },
  }]));
  return { documents, tasks };
}
