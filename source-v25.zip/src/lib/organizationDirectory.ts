import type { Company } from './supabase';
import { NO_BUYER_FILTER } from './documentOrganizationAssignment';

export const GLOBAL_COUNTERPARTIES_KEY = 'finansu-harmonija:v7:settings:counterparties';
export const companyCounterpartiesKey = (id: string) => `finansu-harmonija:v18:company-counterparties:${id}`;
export type CounterpartyReference = { storageKey: string; recordId: string; ownerCompanyId: string };
export type DirectoryCounterparty = { company: Company; source: CounterpartyReference };
export interface OrganizationDirectoryEntry extends Company {
  organizationId?: string;
  isOrganizationClient: boolean;
  counterpartyReferences: CounterpartyReference[];
}
const text = (value: unknown) => typeof value === 'string' ? value.trim() : '';
const code = (value: unknown) => text(value).replace(/\s/g, '').toLocaleLowerCase();
const country = (value: unknown) => {
  const normalized = code(value);
  return ['lt', 'lithuania', 'lietuva'].includes(normalized) ? 'lt' : normalized;
};
export const counterpartyDirectoryId = (source: CounterpartyReference) => `counterparty:${encodeURIComponent(source.storageKey)}:${encodeURIComponent(source.recordId)}`;

/** Only legal identifiers merge entities; similar display names are not proof of identity. */
export function sameDirectoryEntity(a: Company, b: Company) {
  const aCode = code(a.company_code), bCode = code(b.company_code);
  const aCountry = country(a.country || a.tax_country || a.counterparty_country);
  const bCountry = country(b.country || b.tax_country || b.counterparty_country);
  if (aCountry && bCountry && aCountry !== bCountry) return false;
  if (aCode && bCode && aCode !== '—' && bCode !== '—') return aCode === bCode;
  const aVat = code(a.vat_code), bVat = code(b.vat_code);
  return Boolean(aVat && aVat !== '—' && aVat === bVat);
}

export function loadDirectoryCounterparties(companies: Company[], includeGlobal: boolean, storage: Pick<Storage, 'getItem'> = window.localStorage): DirectoryCounterparty[] {
  const sources = [
    ...(includeGlobal ? [{ storageKey: GLOBAL_COUNTERPARTIES_KEY, ownerCompanyId: '' }] : []),
    ...companies.map(company => ({ storageKey: companyCounterpartiesKey(company.id), ownerCompanyId: company.id })),
  ];
  return sources.flatMap(source => {
    let rows: unknown;
    try { rows = JSON.parse(storage.getItem(source.storageKey) || '[]'); } catch { return []; }
    if (!Array.isArray(rows)) return [];
    return rows.filter((row): row is Company => row && typeof row.id === 'string' && typeof row.name === 'string')
      .map(company => ({ company, source: { ...source, recordId: company.id } }));
  });
}

export function buildOrganizationDirectory(companies: Company[], counterparties: DirectoryCounterparty[]): OrganizationDirectoryEntry[] {
  const result: OrganizationDirectoryEntry[] = companies.map(company => ({ ...company, organizationId: company.id,
    isOrganizationClient: company.is_organization_client !== false, counterpartyReferences: [] }));
  for (const { company, source } of counterparties) {
    const sourceId = counterpartyDirectoryId(source);
    const existing = result.find(entry => entry.organization_client_source === sourceId || sameDirectoryEntity(entry, company));
    if (existing) existing.counterpartyReferences.push(source);
    else result.push({ ...company, id: sourceId, isOrganizationClient: false, counterpartyReferences: [source] });
  }
  return result.sort((a, b) => Number(b.isOrganizationClient) - Number(a.isOrganizationClient)
    || a.name.localeCompare(b.name, undefined, { sensitivity: 'base', numeric: true }));
}

export function directoryEntriesForDisplay(entries: OrganizationDirectoryEntry[], query: string, clientsOnly: boolean) {
  const needle = query.trim().toLocaleLowerCase();
  return entries.filter(entry => (!clientsOnly || entry.isOrganizationClient)
    && (!needle || `${entry.name} ${entry.company_code} ${entry.vat_code}`.toLocaleLowerCase().includes(needle)));
}

export function matchesOrganizationDirectoryDocument(document: { companyId: string; counterpartyId: string; counterpartyCode: string; clientCounterparty: string }, selection: readonly string[] | null, entries: OrganizationDirectoryEntry[]) {
  if (selection === null) return true;
  if (!document.companyId && selection.includes(NO_BUYER_FILTER)) return true;
  return entries.some(entry => selection.includes(entry.id) && (
    entry.organizationId ? entry.organizationId === document.companyId
      : entry.counterpartyReferences.some(source => (!document.companyId || !source.ownerCompanyId || source.ownerCompanyId === document.companyId)
        && (document.counterpartyId ? source.recordId === document.counterpartyId
          : code(document.counterpartyCode) && code(document.counterpartyCode) !== '—'
            ? code(document.counterpartyCode) === code(entry.company_code)
            : text(document.clientCounterparty).toLocaleLowerCase() === text(entry.name).toLocaleLowerCase()))
  ));
}

/** A promotion creates only company master data, never copies access, documents or integrations. */
export function companyFromCounterparty(entry: OrganizationDirectoryEntry, id: string): Company {
  return { id, name: entry.name, company_code: entry.company_code || '', vat_code: entry.vat_code || '',
    client_since: new Date().getFullYear(), action_required: 0, company_status: 'Active',
    country: entry.country || entry.counterparty_country || entry.tax_country || '',
    tax_country: entry.tax_country || entry.country || entry.counterparty_country || '',
    legal_form: entry.legal_form || entry.counterparty_legal_status || '',
    address: entry.address || '', email: entry.email || '', phone: entry.phone || '',
    base_currency: entry.base_currency || 'EUR', is_organization_client: true, organization_client_source: entry.id };
}
