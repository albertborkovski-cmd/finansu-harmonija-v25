import type { DbDocument } from './supabase';
import type { WorkspaceTask } from '../components/WorkspaceView';
import type { OcrFieldValidationRule } from './ocrFieldValidation';
import { isOcrInternalSupplierField } from './ocrAccountingFields';
import { normalizeOcrFormRule, OCR_WORKSPACE_FIELD_KEYS } from './ocrFormSchema';
import { ocrDocumentFieldValue } from './ocrRequiredFields';
import { documentFieldText, OCR_SHARED_FIELDS, ocrFieldOverrides, preserveOcrAssignments } from './documentSharedFields';
import { evaluateAutomationRules, type AutomationContext, type AutomationRule, type AutomationResult } from './ocrAutomationRules';
import { ocrRoutingTypeCodes, type OcrDocumentType } from './ocrApprovalRouting';
import { documentTypeCatalogOptions } from './documentTypeCatalog';

const columns: Record<string, keyof DbDocument> = {
  number: 'number', documentDate: 'document_date', dueEndDate: 'due_end_date', clientCounterparty: 'client_counterparty',
  documentPurpose: 'document_purpose', operationDate: 'operation_date', amountWithoutVat: 'amount_without_vat',
  vat: 'vat', vatPercent: 'vat_percent', totalAmount: 'total_amount', currency: 'currency', validFrom: 'valid_form',
  orderNo: 'order_no', departmentCode: 'department_code', objectProject: 'object_project', series: 'series',
  costCenter: 'cost_center', accountablePerson: 'accountable_responsible', productGroup: 'product_group',
  glAccount: 'expense_account', expenseAccount: 'expense_account', vatClassifier: 'vat_classifier', notes: 'notes',
};
const excluded = new Set(['documentType', 'documentPurpose', 'invoice', 'type', 'subtype', 'status', 'source', 'fileCase', 'receiveDate',
  'approvedBy', 'advanceEmployee', 'id', 'company_id', 'counterparty_id', '__proto__', 'prototype', 'constructor']);

/** Resolve catalog renames at read time without rewriting stored rules/history.
 * The routing helper falls back to raw input; require a real active catalog code. */
export function automationRulesForDocumentTypes(rules: readonly AutomationRule[], catalog: readonly OcrDocumentType[]): AutomationRule[] {
  const activeCodes = new Set(documentTypeCatalogOptions(catalog.map(type => ({ ...type, status: type.status || 'Active', parentCode: type.parentCode || '' }))).map(type => type.value));
  return rules.map(rule => {
    const code = ocrRoutingTypeCodes({ document_type: rule.documentType }, catalog)[0];
    const configured = catalog.find(type => type.code === code && activeCodes.has(type.code));
    return configured ? { ...rule, documentType: configured.code } : { ...rule, enabled: false };
  });
}

/** One target list shared by the rule form, preview and processing boundary. */
export function automationDocumentFields(rules: readonly OcrFieldValidationRule[]): OcrFieldValidationRule[] {
  return rules.map(normalizeOcrFormRule).filter(rule => rule.enabled !== false && !rule.inactive
    && !excluded.has(rule.key) && !isOcrInternalSupplierField(rule) && rule.group !== 'parties' && rule.group !== 'lines');
}

/** Validate against the CURRENT field schema, not only the schema at rule creation. */
export function automationRuleValueError(rule: AutomationRule, fields: readonly OcrFieldValidationRule[]): string | null {
  const field = automationDocumentFields(fields).find(candidate => candidate.key === rule.fieldKey);
  if (!field) return 'This field is no longer available for document rules.';
  if (rule.action === 'required') return null;
  const value = rule.value.trim();
  if (!value) return 'Value is required.';
  if (field.inputType === 'number' && (!/^-?(?:\d+(?:[.,]\d+)?|[.,]\d+)$/.test(value) || !Number.isFinite(Number(value.replace(',', '.')))))
    return 'Enter a valid numeric value.';
  if (field.inputType === 'date') {
    const date = /^\d{4}-\d{2}-\d{2}$/.test(value) ? new Date(`${value}T00:00:00Z`) : undefined;
    if (!date || !Number.isFinite(date.getTime()) || date.toISOString().slice(0, 10) !== value) return 'Enter a valid date in YYYY-MM-DD format.';
  }
  if (field.inputType === 'boolean' && !['true', 'false'].includes(value)) return 'Choose true or false for this field.';
  if (field.inputType === 'select' && !field.options?.includes(value)) return 'Choose a value from the configured field options.';
  if (field.inputType === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) return 'Enter a valid email address.';
  if (field.key === 'documentPurpose' && !['Purchase', 'Sale'].includes(value)) return 'Choose Purchase or Sale.';
  return null;
}

export function evaluateConfiguredAutomationRules(rules: readonly AutomationRule[], context: AutomationContext,
  fields: readonly OcrFieldValidationRule[]): AutomationResult {
  const configured = automationDocumentFields(fields), allowed = new Set(configured.map(field => field.key));
  const safeContext = { ...context, values: Object.fromEntries(Object.entries(context.values).filter(([key]) => allowed.has(key))) };
  const invalid = new Map(rules.map(rule => [rule.id, automationRuleValueError(rule, configured)]).filter((entry): entry is [string, string] => Boolean(entry[1])));
  const evaluated = evaluateAutomationRules(rules.filter(rule => !invalid.has(rule.id)), safeContext);
  if (invalid.size) {
    const matched = evaluateAutomationRules(rules.filter(rule => invalid.has(rule.id)), safeContext).matchedRuleIds;
    for (const id of matched) {
      const rule = rules.find(candidate => candidate.id === id)!;
      evaluated.warnings.push({ fieldKey: rule.fieldKey, ruleId: id, message: invalid.get(id)! });
      evaluated.matchedRuleIds.push(id);
    }
  }
  return evaluated;
}

export type DocumentAutomationResult = AutomationResult & { document: DbDocument; patch: Partial<DbDocument> };

/** Read-only list explanation; existing task/escalation reasons take precedence at the caller. */
export function ocrAutomationIssueReason(document: DbDocument, fields: readonly OcrFieldValidationRule[], documentTypeCodes: string[],
  rules: readonly AutomationRule[], translate: (value: string) => string = value => value): string {
  const warnings = evaluateOcrDocumentAutomation(document, fields, documentTypeCodes, rules).warnings;
  return [...new Set(warnings.map(warning => {
    const label = translate(fields.find(field => field.key === warning.fieldKey)?.label || warning.fieldKey);
    const message = warning.message.startsWith('Expected value: ')
      ? `${translate('Expected value')}: ${warning.message.slice('Expected value: '.length)}` : translate(warning.message);
    return `${label}: ${message}`;
  }))].join('; ');
}

/** Uses recognized source text only. File names, notes, rendered HTML and OCR drafts
 * are never passed off as source text. Validation mode cannot replace human edits. */
export function evaluateOcrDocumentAutomation(document: DbDocument, fields: readonly OcrFieldValidationRule[],
  documentTypeCodes: string[], rules: readonly AutomationRule[], applyAssignments = false): DocumentAutomationResult {
  const configured = automationDocumentFields(fields);
  const values = Object.fromEntries(configured.map(field => [field.key, documentFieldText(ocrDocumentFieldValue(document, field.key))]));
  const overrides = ocrFieldOverrides(document);
  const protectedFields = configured.filter(field => {
    if (!applyAssignments) return true;
    const column = columns[field.key];
    if (column && Object.hasOwn(overrides, column)) return true;
    const lineKey = column && OCR_SHARED_FIELDS[column as keyof typeof OCR_SHARED_FIELDS];
    const lines = document.summary_line_items;
    if (!lineKey) return false;
    if (lines?.length && new Set(lines.map(line => documentFieldText(line[lineKey]))).size > 1) return true;
    // A detailed per-line allocation is not one document-level value. Do not
    // flatten explicit/mixed line codes, even if the document header is empty.
    const detailValues = (document.line_items || []).map(line => documentFieldText(line[lineKey]));
    const header = documentFieldText(column && document[column]);
    return new Set(detailValues).size > 1 || detailValues.some(value => value && value !== header);
  }).map(field => field.key);
  const context = { documentTypeCodes, organizationId: document.company_id || '',
    text: typeof document.ocr_text === 'string' ? document.ocr_text : '', values, protectedFields };
  const evaluated = evaluateConfiguredAutomationRules(rules, context, configured);
  const patch: Partial<DbDocument> = {};
  const extracted: Record<string, string> = { ...document.ocr_values };
  for (const assignment of evaluated.assignments) {
    extracted[assignment.fieldKey] = assignment.value;
    const column = columns[assignment.fieldKey];
    if (column) {
      Object.assign(patch, { [column]: assignment.value });
      const lineKey = OCR_SHARED_FIELDS[column as keyof typeof OCR_SHARED_FIELDS];
      if (lineKey && document.line_items?.length) patch.line_items = (patch.line_items || document.line_items)
        .map(line => ({ ...line, [lineKey]: assignment.value }));
    }
  }
  if (evaluated.assignments.length) patch.ocr_values = extracted;
  const safePatch = preserveOcrAssignments(document, patch);
  return { ...evaluated, patch: safePatch, document: { ...document, ...safePatch } };
}

/** Seeded/unopened task snapshots must not mask newly recognized assignments.
 * Never synchronize into an opened or saved human draft. */
export function synchronizeOcrAutomationTask(task: WorkspaceTask, assignments: AutomationResult['assignments']): WorkspaceTask {
  if (!assignments.length || task.savedAt || task.lastCorrectedAt || task.editStartedAt || task.ocrRunRequest
    || task.status === 'Completed' || task.trainingStatus === 'Confirmed') return task;
  const next = { ...task, fields: { ...task.fields }, ocrFieldValues: { ...task.ocrFieldValues } };
  for (const assignment of assignments) {
    next.ocrFieldValues[assignment.fieldKey] = assignment.value;
    const field = OCR_WORKSPACE_FIELD_KEYS[assignment.fieldKey as keyof typeof OCR_WORKSPACE_FIELD_KEYS];
    if (field) next.fields[field] = assignment.value;
    if (next.accounting && assignment.fieldKey === 'vatClassifier') next.accounting = { ...next.accounting, vatClassifier: assignment.value };
    if (next.accounting && ['glAccount', 'expenseAccount'].includes(assignment.fieldKey)) next.accounting = { ...next.accounting, expenseAccount: assignment.value };
  }
  return next;
}
