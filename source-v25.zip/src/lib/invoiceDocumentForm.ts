import { invoiceCreditCounterparty, newInvoiceDraft, newInvoiceLine, type InvoiceDraft, type InvoiceLineDraft, type InvoiceAttachment } from './invoiceCreation';
import { documentEditStateError, type InlineDocumentSource } from './documentInlineEditing';
import { documentLineNumber } from './documentDetailEditing';
import type { Company } from './supabase';

export type InvoiceRecord = Record<string, unknown>;
const text = (value: unknown) => value == null ? '' : String(value);
const records = (value: unknown): InvoiceRecord[] => Array.isArray(value) ? value.filter(row => row && typeof row === 'object') : [];
const amount = (value: unknown) => String(Math.abs(documentLineNumber(text(value))));

/** Origin is independent of status and file attachments. An uploaded document
 * marked "Manual" for processing still uses the imported-document form. */
export function usesManualInvoiceForm(document: InvoiceRecord): boolean {
  const origin = text(document.entry_method || document.source).trim().toLowerCase();
  return origin === 'manual' && /^(invoices?|sales?[\s_-]*invoices?|purchase[\s_-]*invoices?|vat[\s_-]*invoice)$/i.test(text(document.document_type));
}

export function invoiceDocumentSnapshot(document: InvoiceRecord) {
  return JSON.stringify(document);
}

/** Files attached before the invoice form existed remain available as the
 * original document, separately from the form's editable attachment list. */
export function invoiceSourceAttachment(document?: InvoiceRecord): InvoiceAttachment | null {
  if (!document?.image_url || records(document.invoice_attachments).some(file => file.url === document.image_url)) return null;
  const url = text(document.image_url), name = text(document.file_case) || `${text(document.number) || 'Document'}.pdf`;
  const type = /^data:(application\/pdf|image\/(?:png|jpeg));/.exec(url)?.[1]
    || (/\.png$/i.test(name) ? 'image/png' : /\.jpe?g$/i.test(name) ? 'image/jpeg' : 'application/pdf');
  return { name, url, type, size: 0 };
}

/** A legacy document may reference a counterparty no longer in the active
 * directory. Keep its saved identity visible without creating a master record. */
export function invoiceFormCounterparties(document: InvoiceRecord | undefined, parties: Company[]): Company[] {
  if (!document) return parties;
  const match = invoiceCreditCounterparty(document as never, parties);
  if (match || !text(document.client_counterparty)) return parties;
  return [...parties, { id: text(document.counterparty_id) || `document-party:${text(document.id)}`,
    name: text(document.client_counterparty), company_code: text(document.counterparty_code),
    vat_code: text(document.counterparty_vat_code), address: text(document.counterparty_address),
  } as Company];
}

function hydrateLine(row: InvoiceRecord, index: number, draft: InvoiceDraft, prefix: string): InvoiceLineDraft {
  const quantity = amount(row.qty ?? 1);
  const price = row.price == null || row.price === ''
    ? String((Math.abs(documentLineNumber(text(row.subtotal))) + Math.abs(documentLineNumber(text(row.discount)))) / (Number(quantity) || 1)) : amount(row.price);
  return { ...newInvoiceLine(text(row.id) || `${prefix}:${index + 1}`),
    type: text(row.line_type) || (['Service', 'Product', 'Code'].includes(text(row.productGroup)) ? text(row.productGroup) : 'Service'),
    code: text(row.code), name: text(row.product || row.name || row.description), description: text(row.description),
    unit: text(row.unit) || 'vnt', quantity, price, discount: text(row.discount_rate || '0'),
    ...(row.discount != null ? { discountAmount: amount(row.discount) } : {}),
    ...(row.vat != null ? { vatAmount: amount(row.vat) } : {}), vatRate: amount(row.vatPct ?? 0),
    glAccount: text(row.expense ?? draft.glAccount), vatClassifier: text(row.vatClass ?? draft.vatClassifier),
    department: text(row.department ?? draft.department), project: text(row.object ?? draft.project), costCenter: text(row.center ?? draft.costCenter),
    series: text(row.series ?? draft.series), barcode: text(row.barcode), productGroup: text(row.productGroup),
    lineNote: text(row.line_note), analyticalSeries: text(row.analytical_series), mainAnalyticalAccount: text(row.main_analytical_account), relatedContract: text(row.related_contract),
    itemCode: text(row.item_code), warehouseId: text(row.warehouse_id),
    responsibleId: text(row.accountable_responsible_id ?? draft.responsibleId),
    includeVatInDebt: typeof row.include_vat_in_debt === 'boolean' ? row.include_vat_in_debt : draft.includeVatInDebt,
    accountingDefaultOverrides: row.accounting_default_overrides as InvoiceLineDraft['accountingDefaultOverrides'] ??
      { vatClassifier: true, vatRate: true, department: true, costCenter: true, includeVatInDebt: true },
  };
}

export function invoiceFormFromDocument(document: InvoiceRecord, parties: Company[], baseCurrency: string) {
  const date = text(document.document_date || document.invoice_contract_date).slice(0, 10);
  const defaults = (document.invoice_accounting_defaults || {}) as InvoiceRecord;
  const draft: InvoiceDraft = { ...newInvoiceDraft(date, text(document.currency) || baseCurrency),
    status: text(document.status), purpose: /^sale$/i.test(text(document.document_purpose || document.type)) || /^sale$/i.test(text(document.type)) ? 'Sale' : 'Purchase',
    kind: text(document.document_subtype) || 'INVOICE', number: text(document.number), series: text(document.series), orderNo: text(document.order_no),
    counterpartyId: invoiceCreditCounterparty(document as never, invoiceFormCounterparties(document, parties))?.id || text(document.counterparty_id) || `document-party:${text(document.id)}`,
    exchangeRate: text(document.exchange_rate) || (document.currency === baseCurrency ? '1' : ''),
    operationDate: text(document.operation_date).slice(0, 10) || date, dueDate: text(document.due_end_date).slice(0, 10) || date,
    paymentTerms: text(document.payment_terms) || 'custom', glAccount: text(document.expense_account),
    vatClassifier: text(defaults.vatClassifier ?? document.vat_classifier), department: text(defaults.department ?? document.department_code),
    costCenter: text(defaults.costCenter ?? document.cost_center), project: text(document.object_project),
    includeVatInDebt: typeof defaults.includeVatInDebt === 'boolean' ? defaults.includeVatInDebt : document.include_vat_in_debt !== false,
    responsibleId: text(document.accountable_responsible_id), customerManagerId: text(document.invoice_customer_manager_id),
    language: text(document.invoice_language) || 'EN', notes: text(document.notes),
    analyticalSeries: text(document.analytical_series), mainAnalyticalAccount: text(document.main_analytical_account), relatedContract: text(document.related_contract),
    creditSourceDocumentId: text(document.correction_of_document_id),
    advanceEmployeeId: text(document.advance_employee_id),
  };
  const quantity = records(document.line_items), allocations = records(document.summary_line_items);
  draft.lines = (quantity.length ? quantity : allocations).map((row, i) => hydrateLine(row, i, draft, `${text(document.id)}:line`));
  if (!draft.lines.length) draft.lines = [hydrateLine({ id: `${text(document.id)}:line:1`, product: document.number,
    qty: '1', price: document.amount_without_vat, subtotal: document.amount_without_vat, vat: document.vat, vatPct: document.vat_percent,
  }, 0, draft, text(document.id))];
  if (quantity.length && allocations.length) {
    const mapped = allocations.map((row, i) => hydrateLine(row, i, draft, `${text(document.id)}:allocation`));
    const comparable = (lines: InvoiceLineDraft[]) => lines.map(({ id: _id, ...line }) => line);
    if (JSON.stringify(comparable(mapped)) !== JSON.stringify(comparable(draft.lines))) draft.allocations = mapped;
    else draft.lines = draft.lines.map((line, i) => ({ ...line, allocationId: mapped[i].id }));
  }
  const attachments = records(document.invoice_attachments).map(row => ({ name: text(row.name), size: Number(row.size), type: text(row.type), url: text(row.url) }));
  return { draft, attachments: attachments as InvoiceAttachment[] };
}

export function validateInvoiceDocumentEdit(document: InvoiceRecord, companyId: string, expected: string, allowed: boolean) {
  if (!allowed) throw new Error('You need View and Edit access to this company’s documents.');
  if (document.company_id !== companyId || !usesManualInvoiceForm(document)) throw new Error('This document cannot be changed using the manual invoice form.');
  const blocked = documentEditStateError(document as InlineDocumentSource);
  if (blocked) throw new Error(blocked);
  if (invoiceDocumentSnapshot(document) !== expected) throw new Error('The document changed. Reopen it before saving your changes.');
}

/** Only invoice content is replaceable. Source, identity, posting, issues,
 * original creation information and every existing audit entry survive edits. */
export function invoiceDocumentEditPatch(document: InvoiceRecord, prepared: InvoiceRecord, draft: InvoiceDraft): InvoiceRecord {
  const { id: _id, company_id: _company, source: _source, entry_method: _origin, created_at: _at, created_by: _by,
    creation_request_id: _request, creation_history: _history, receive_date: _received, correction_history: _corrections,
    ...patch } = prepared;
  const mergeLines = (key: 'line_items' | 'summary_line_items', lines: InvoiceLineDraft[]) => {
    const originals = records(document[key]);
    return records(prepared[key]).map((row, i) => {
      const original = originals.find(item => item.id === (key === 'summary_line_items' ? lines[i]?.allocationId || lines[i]?.id : lines[i]?.id));
      return { ...original, ...row, id: original?.id || lines[i]?.id || row.id,
        ...(!lines[i]?.responsibleId && original?.accountable_responsible && !original.accountable_responsible_id
          ? { accountable_responsible: original.accountable_responsible } : {}) };
    });
  };
  patch.line_items = mergeLines('line_items', draft.lines);
  patch.summary_line_items = mergeLines('summary_line_items', draft.allocations || draft.lines);
  if (!draft.responsibleId && document.accountable_responsible && !document.accountable_responsible_id) patch.accountable_responsible = document.accountable_responsible;
  if (!draft.customerManagerId && document.invoice_customer_manager && !document.invoice_customer_manager_id) patch.invoice_customer_manager = document.invoice_customer_manager;
  if (invoiceSourceAttachment(document) || (!records(document.invoice_attachments).length && !records(prepared.invoice_attachments).length)) {
    delete patch.image_url; delete patch.file_case;
  }
  if ((draft.creditSourceDocumentId || '') !== text(document.correction_of_document_id)) throw new Error('The original document link is retained for audit. Create a new corrective document to use a different original.');
  delete patch.correction_of_document_id; delete patch.correction_kind;
  return patch;
}
