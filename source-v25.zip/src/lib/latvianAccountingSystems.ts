/** Stable choices; file and API variants are deliberately separate. */
export const LATVIAN_ACCOUNTING_SYSTEMS = [
  { id: 'moneo-excel', name: 'MONEO Excel', family: 'moneo', method: 'file', format: 'XLSX' },
  { id: 'moneo-api', name: 'MONEO API', family: 'moneo', method: 'api', format: 'REST / JSON' },
  { id: 'jumis-excel', name: 'Jumis Excel', family: 'jumis', method: 'file', format: 'XLSX' },
  { id: 'jumis-xml', name: 'Jumis XML', family: 'jumis', method: 'file', format: 'Jumis XML' },
  { id: 'jumis-api', name: 'Jumis API', family: 'jumis', method: 'api', format: 'REST / XMLrequest' },
  { id: 'horizon-peppol-xml', name: 'Horizon Peppol XML', family: 'horizon', method: 'file', format: 'Peppol BIS Billing 3.0' },
  { id: 'horizon-api', name: 'Horizon API', family: 'horizon', method: 'api', format: 'Horizon REST' },
  { id: 'zalktis-xml', name: 'Zalktis XML', family: 'zalktis', method: 'file', format: 'Purchase e-invoice XML' },
  { id: 'zalktis-accounting-xml', name: 'Zalktis Accounting XML', family: 'zalktis', method: 'file', format: 'Zalktis Root / FailaPase XML' },
] as const;
export const latvianAccountingSystem = (value: string) => LATVIAN_ACCOUNTING_SYSTEMS.find(item => item.id === value || item.name === value);
export const LATVIAN_EXPORT_FORMATS = LATVIAN_ACCOUNTING_SYSTEMS.map(item => item.name);

/** Current customer-facing choices. Keep legacy schemas for saved-data compatibility. */
export const SELECTABLE_ACCOUNTING_EXPORT_FORMATS = [
  'Agnum', 'BSS', 'BSS Api', 'Rivilė', 'Rivilė API', 'Rivilė ERP', 'Site.pro',
  ...LATVIAN_EXPORT_FORMATS,
];
export const isSelectableAccountingExportFormat = (format: string) => SELECTABLE_ACCOUNTING_EXPORT_FORMATS.includes(format);

const familyNames = { moneo: 'MONEO', jumis: 'Jumis', horizon: 'Horizon', zalktis: 'Zalktis' } as const;
export function accountingSystemChoice(format: string) {
  const system = latvianAccountingSystem(format);
  return system ? familyNames[system.family] : format;
}
/** Group only the new providers; keep all established formats and stored values intact. */
export function accountingSystemChoices(formats: readonly string[]) {
  return [...new Set(formats.map(accountingSystemChoice))];
}
export function accountingSystemFormat(choice: string, currentFormat = '') {
  if (accountingSystemChoice(currentFormat) === choice) return currentFormat;
  return LATVIAN_ACCOUNTING_SYSTEMS.find(system => familyNames[system.family] === choice)?.name || choice;
}
const methodLabels: Record<string, string> = {
  'MONEO Excel': 'Excel (XLSX)', 'MONEO API': 'API (REST / JSON)',
  'Jumis Excel': 'Excel (XLSX)', 'Jumis XML': 'XML file', 'Jumis API': 'API (REST / XMLrequest)',
  'Horizon Peppol XML': 'Peppol XML file', 'Horizon API': 'API (Horizon REST)',
  'Zalktis XML': 'Purchase e-invoice XML', 'Zalktis Accounting XML': 'Accounting entries XML',
};
export function accountingImportMethods(format: string) {
  const selected = latvianAccountingSystem(format);
  return selected ? LATVIAN_ACCOUNTING_SYSTEMS.filter(system => system.family === selected.family)
    .map(system => ({ value: system.name, label: methodLabels[system.name] })) : [];
}

/** Short instructions for the actual selected route, not a generic Rivilė form. */
export const LATVIAN_EXPORT_SETUP: Record<string, { description: string; facts: Array<[string, string]>; sourceIndexes: number[] }> = {
  'MONEO Excel': {
    description: 'Use the official purchase or sales workbook. Keep its columns and worksheets unchanged; supplier/customer cards and GL accounts must already exist in MONEO.',
    facts: [['File format', 'XLSX'], ['Maximum rows per file', '200'], ['Purchase template', 'Pieg_Rekinu_Imp.xlsx'], ['Sales template', 'Rekinu_Imp_2024.xlsx']], sourceIndexes: [0, 1],
  },
  'MONEO API': {
    description: 'Use the API address and company ID from MONEO → Help → Server information. The API user must have access to this company and invoice tables.',
    facts: [['Transfer format', 'REST / JSON'], ['Authorization', 'Authorization header + request.compuid']], sourceIndexes: [2, 3],
  },
  'Jumis Excel': {
    description: 'Choose the official financial or stock-document template. For invoices with multiple lines, use the structured workbook with linked document and line IDs.',
    facts: [['File format', 'XLSX'], ['Import location', 'Konfigurācija → Jumis datu imports → Excel']], sourceIndexes: [0],
  },
  'Jumis XML': {
    description: 'Use the XML structure matching the receiving Jumis register. Stock/trading documents and financial operations use different document blocks.',
    facts: [['File format', 'Jumis XML'], ['Import location', 'Konfigurēšana → Tj datu imports']], sourceIndexes: [1, 3, 4],
  },
  'Jumis API': {
    description: 'The Jumis cloud service requires the cloud user, special SQL password, database and API key. Invoice data is supplied in the XMLrequest parameter.',
    facts: [['Transfer format', 'HTTPS POST / JSON + XMLrequest']], sourceIndexes: [2, 3, 4],
  },
  'Horizon Peppol XML': {
    description: 'Purchase e-invoices are imported into Metarēķini. Review the intermediate invoice and its GL/dimension mapping before posting in Horizon.',
    facts: [['File format', 'Peppol BIS Billing 3.0 XML'], ['Receiving register', 'Metarēķini']], sourceIndexes: [0, 1],
  },
  'Horizon API': {
    description: 'Use the REST server and WEB integration user configured by the Horizon administrator. Agree the invoice resource and document type for the receiving company.',
    facts: [['Transfer format', 'Horizon REST'], ['Access', 'WEB integration user']], sourceIndexes: [2, 3],
  },
  'Zalktis XML': {
    description: 'Import purchase e-invoices from the Zalktis invoice list. Configure default posting schemes first; the invoice recipient registration number must match the company.',
    facts: [['File format', 'Purchase e-invoice XML'], ['Receiving register', 'Purchase invoices']], sourceIndexes: [0],
  },
  'Zalktis Accounting XML': {
    description: 'This is a separate accounting-entry import, not the purchase e-invoice route. Use the full Zalktis XML specification and balanced debit/credit mappings.',
    facts: [['File format', 'UTF-8 XML · Root / FailaPase / Dokuments'], ['Import location', 'Pamatdati → Administratora rīki → Zalktis datu eksports/imports']], sourceIndexes: [1],
  },
};

/** Add the new catalog entries without re-enabling explicitly disabled choices. */
export function withLatvianDestinations<T extends { id?: unknown; name?: unknown }>(existing: T[]) {
  if (!existing.length) return existing;
  const normalize = (value: unknown) => String(value ?? '').trim().toLowerCase();
  return [...existing, ...LATVIAN_ACCOUNTING_SYSTEMS.filter(item => !existing.some(value => value && (normalize(value.id) === normalize(item.id) || normalize(value.name) === normalize(item.name))))
    .map(({ id, name }) => ({ id, name, apiUrl: '' }))];
}
export const LATVIAN_INTEGRATION_SOURCES = {
  moneo: [
    { label: 'MONEO · Pieg_Rekinu_Imp.xlsx', url: 'https://help.moneo.lv/hc/lv/articles/4421201318930-Piegādātāju-rēķinu-ierakstu-datu-imports' },
    { label: 'MONEO · Rekinu_Imp_2024.xlsx', url: 'https://help.moneo.lv/hc/lv/articles/4411375066258-Realizācijas-rēķinu-ierakstu-datu-imports' },
    { label: 'MONEO · API access', url: 'https://help.moneo.lv/hc/lv/articles/360010833199-Ievads-MONEO-API-integrācijā' },
    { label: 'MONEO · API workflow', url: 'https://help.moneo.lv/hc/lv/articles/360010833279-MONEO-API-integrācija-darba-plūsma' },
    { label: 'MONEO · API tables', url: 'https://help.moneo.lv/hc/lv/articles/360016232680-API-biežāk-lietotās-tabulas' },
  ],
  jumis: [
    { label: 'Jumis · Excel import and examples', url: 'https://atbalsts.mansjumis.lv/hc/lv/articles/21877654728466-Kā-importēt-Jumī-datus-no-Excel-faila' },
    { label: 'Jumis · XML import', url: 'https://atbalsts.mansjumis.lv/hc/lv/articles/360016793000-Datu-imports-un-eksports-sistēmā-Jumis-ar-XML-failiem' },
    { label: 'Jumis · REST API', url: 'https://atbalsts.mansjumis.lv/hc/lv/articles/6482469051922-Jumis-REST-API-specifikācija' },
    { label: 'Jumis · FinancialDoc fields', url: 'https://atbalsts.mansjumis.lv/hc/lv/articles/8656940904082-XML-pieprasījums-FINANŠU-DOKUMENTU-importam-Jumī-izmantojot-REST-API-savienojumu' },
    { label: 'Jumis · StoreDoc fields', url: 'https://atbalsts.mansjumis.lv/hc/lv/articles/8657129965458-XML-pieprasījums-NOLIKTAVAS-DOKUMENTU-importam-Jumī-izmantojot-REST-API-savienojumu' },
  ],
  horizon: [
    { label: 'Horizon · Metarēķini', url: 'https://community.visma.com/t5/Zinasanu-baze-Horizon/Kas-ir-metarekini/ta-p/148974' },
    { label: 'Horizon · Peppol import', url: 'https://community.visma.com/xqnef94594/attachments/xqnef94594/LV_VE_Horizon_zinasanu_baze/644/3/HORv565_Versijas%20apraksts%20%283%29.pdf' },
    { label: 'Horizon · REST integration', url: 'https://community.visma.com/t5/Zinasanu-baze-Integracija/Kas-jazina-lai-veiktu-sistemu-integraciju-izmantojot-REST/ta-p/118374' },
    { label: 'Horizon · REST documentation', url: 'https://horizon-rest-doc.visma.lv/lv' },
  ],
  zalktis: [
    { label: 'Zalktis · Purchase e-invoice import', url: 'https://help.zalktis.lv/Kaimportete-rekinus.html' },
    { label: 'Zalktis · Accounting XML structure', url: 'https://help.zalktis.lv/Zalktisdatueksportsunimports.html' },
  ],
};
