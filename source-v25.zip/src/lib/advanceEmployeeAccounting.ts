import { savedDocumentStornoError, type StornoDocument, type StornoContext, type DocumentStorno } from './documentStorno';
import { isPurchaseInvoice } from './invoiceAdvanceEmployee';

export type AdvanceEmployeeDocument = StornoDocument & {
  advance_employee_id?: string; advance_employee?: string;
  advance_employee_reversal?: DocumentStorno;
  advance_employee_history?: DocumentStorno['history'];
};

/** Atomic with the document write. Never derive GL accounts from invoice totals. */
export function prepareAdvanceEmployeeAccounting(previous: AdvanceEmployeeDocument, next: AdvanceEmployeeDocument, context: StornoContext): AdvanceEmployeeDocument {
  if (previous.advance_employee_reversal) {
    if (next.advance_employee_id !== previous.advance_employee_id || !isPurchaseInvoice(next)
      || JSON.stringify(next.accounting_posting) !== JSON.stringify(previous.accounting_posting)
      || savedDocumentStornoError({ ...next, accounting_storno: previous.advance_employee_reversal }))
      throw new Error('The Advance employee reversal is already recorded. Its employee, source and history cannot be changed.');
    return { ...next, advance_employee_reversal: previous.advance_employee_reversal, advance_employee_history: previous.advance_employee_history };
  }
  const selected = isPurchaseInvoice(next) && Boolean(next.advance_employee_id);
  const changed = previous.advance_employee_id !== next.advance_employee_id;
  if (!selected && !changed) return next;
  if (selected && (next.document_deletion || next.inactive || next.active === false || next.is_active === false || /^(cancelled|inactive|deleted|transferred|exported|reversed)$/i.test(String(next.status || '')) || next.accounting_storno || next.document_storno))
    throw new Error('This document cannot be assigned to an Advance employee in its current state.');
  const history = [...(previous.advance_employee_history || [])];
  if (changed) history.push({ id: `${next.id}:advance-assignment:${context.now}`, at: context.now, actor: context.actor,
    action: selected ? 'Advance employee assigned' : 'Advance employee removed', details: selected ? String(next.advance_employee) : String(previous.advance_employee || '') });
  // Assignment classifies the invoice. GL transfers belong to a confirmed
  // reconciliation and its actual allocated amount, not the invoice total.
  return { ...next, advance_employee_history: history };
}
