export type PdfPageGroup = { name: string; pages: string };
export type PdfSplitHistory = { id: string; at: string; actor: string; children: { id: string; name: string; pages: number[] }[] };
export type PdfMergePage = { documentId: string; page: number };
export type PdfMergeSource = { id: string; name: string; number?: string; url: string; snapshot: string };

/** Search affects visible candidates only, not their IDs, selection or page order. */
export function filterPdfMergeSources(sources: readonly PdfMergeSource[], search: string): PdfMergeSource[] {
  const terms = search.trim().toLocaleLowerCase().split(/\s+/).filter(Boolean);
  return sources.filter(source => {
    const value = `${source.name} ${source.number || ''}`.toLocaleLowerCase();
    return terms.every(term => value.includes(term));
  });
}

export function validatePdfMergePages(counts: ReadonlyMap<string, number>, pages: readonly PdfMergePage[]) {
  if (counts.size < 2) throw new Error('Select at least two PDF documents.');
  const used = new Set<string>();
  for (const item of pages) {
    const count = counts.get(item.documentId);
    const key = `${item.documentId}:${item.page}`;
    if (!count || !Number.isInteger(item.page) || item.page < 1 || item.page > count || used.has(key))
      throw new Error('Every page must belong to exactly one document.');
    used.add(key);
  }
  if (used.size !== [...counts.values()].reduce((total, count) => total + count, 0)) throw new Error('Assign every original page to a document.');
}

export async function mergePdfSources(sources: readonly Pick<PdfMergeSource, 'id' | 'url'>[], pages: readonly PdfMergePage[]) {
  const { PDFDocument } = await import('pdf-lib');
  const documents = new Map(await Promise.all(sources.map(async source => [source.id, await readPdfSource(source.url)] as const)));
  validatePdfMergePages(new Map([...documents].map(([id, pdf]) => [id, pdf.getPageCount()])), pages);
  const result = await PDFDocument.create();
  for (const item of pages) {
    const [page] = await result.copyPages(documents.get(item.documentId)!, [item.page - 1]);
    result.addPage(page);
  }
  return result.saveAsBase64({ dataUri: true });
}

export function validatePdfPageGroups(groups: readonly PdfPageGroup[], pageCount: number) {
  if (!Number.isInteger(pageCount) || pageCount < 2) throw new Error('The PDF must contain at least two pages.');
  if (groups.length < 2 || groups.length > pageCount) throw new Error('Create at least two documents with one or more pages each.');
  const used = new Set<number>(), names = new Set<string>();
  const result = groups.map(group => {
    const name = group.name.trim().replace(/\.pdf$/i, '');
    if (!name || name.length > 120 || /[\\/<>:"|?*]/.test(name)) throw new Error('Enter a valid, unique file name for each document.');
    if (names.has(name.toLowerCase())) throw new Error('Enter a valid, unique file name for each document.');
    names.add(name.toLowerCase());
    const pages: number[] = [];
    for (const token of group.pages.split(',')) {
      const match = token.trim().match(/^(\d+)(?:\s*-\s*(\d+))?$/);
      if (!match) throw new Error('Use page numbers or ranges, for example 1-2, 4.');
      const start = Number(match[1]), end = Number(match[2] || match[1]);
      if (start < 1 || end > pageCount || start > end) throw new Error('A page number is outside the PDF or the range is reversed.');
      for (let page = start; page <= end; page++) {
        if (used.has(page)) throw new Error('Every page must belong to exactly one document.');
        used.add(page); pages.push(page);
      }
    }
    return { name: `${name}.pdf`, pages: pages.sort((a, b) => a - b) };
  });
  if (used.size !== pageCount) throw new Error('Assign every original page to a document.');
  return result;
}

export async function readPdfSource(url: string) {
  const response = await fetch(url);
  if (!response.ok) throw new Error('The original PDF could not be loaded.');
  const bytes = new Uint8Array(await response.arrayBuffer());
  if (bytes.byteLength > 50 * 1024 * 1024) throw new Error('The PDF exceeds the 50 MB file size limit.');
  const { PDFDocument } = await import('pdf-lib');
  const pdf = await PDFDocument.load(bytes);
  if (pdf.getForm().getFields().length) throw new Error('PDFs with signatures or interactive form fields cannot be split here. Use an unsigned, non-interactive copy.');
  return pdf;
}

/** Copy original PDF pages without rasterizing text, images or page geometry. */
export async function splitPdfSource(url: string, groups: readonly PdfPageGroup[]) {
  const { PDFDocument } = await import('pdf-lib');
  const source = await readPdfSource(url);
  const checked = validatePdfPageGroups(groups, source.getPageCount());
  return Promise.all(checked.map(async group => {
    const pdf = await PDFDocument.create();
    (await pdf.copyPages(source, group.pages.map(page => page - 1))).forEach(page => pdf.addPage(page));
    return { ...group, url: await pdf.saveAsBase64({ dataUri: true }) };
  }));
}
