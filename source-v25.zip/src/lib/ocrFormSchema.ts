import type { OcrFieldValidationRule } from './ocrFieldValidation';

export const OCR_FORM_GROUPS = [
  { id: 'document', label: 'Document information' },
  { id: 'parties', label: 'Parties' },
  { id: 'financial', label: 'Financial information' },
  { id: 'lines', label: 'Line items' },
  { id: 'additional', label: 'Additional information' },
  { id: 'calculated', label: 'Calculated fields (ADDINFO)' },
] as const;
export type OcrFormGroup = typeof OCR_FORM_GROUPS[number]['id'];
export const OCR_FORM_INPUT_TYPES = ['text', 'number', 'date', 'email', 'textarea', 'select', 'boolean'] as const;
export type OcrFormInputType = typeof OCR_FORM_INPUT_TYPES[number];
export type OcrPartyBinding = 'independent' | 'counterparty' | 'seller' | 'buyer';
export type OcrDocumentParty = { id: string; role: string; roleId?: string; values: Record<string, string> };
export type OcrFormPresentation = {
  formVersion?: 1; group?: OcrFormGroup; order?: number;
  inputType?: OcrFormInputType; options?: string[]; partyRole?: string;
  partyRoleId?: string; partyBinding?: OcrPartyBinding; partyDataKey?: string;
  /** Migration retains the original counterparty-only mandatory checks. */
  partyRequiredScope?: 'counterparty'; partySchemaVersion?: 2;
};

export const OCR_WORKSPACE_FIELD_KEYS = {
  number: 'invoiceNumber', documentDate: 'invoiceDate', dueEndDate: 'dueDate', clientCounterparty: 'companyName',
  streetAddress: 'streetAddress', city: 'city', zipCode: 'zipCode', phoneNumber: 'phoneNumber', email: 'email',
  vatPercent: 'taxRate', discountRate: 'discountRate', totalDiscount: 'totalDiscount', totalAmount: 'totalAmount',
} as const;
export const OCR_LINE_FIELD_KEYS = { lineName: 'name', lineDescription: 'description', lineQuantity: 'quantity', linePrice: 'price' } as const;
export const OCR_LINE_DOCUMENT_KEYS = { lineName: 'product', lineDescription: 'description', lineQuantity: 'qty', linePrice: 'price' } as const;
// These describe processing metadata, not editable content extracted from a document.
export const OCR_NON_FORM_FIELDS = new Set(['invoice', 'source', 'fileCase', 'status', 'approvedBy']);

const DEFAULT_LAYOUT: Record<string, [OcrFormGroup, number, OcrFormInputType?, string?]> = {
  documentType: ['document', 0], number: ['document', 10], documentDate: ['document', 20, 'date'],
  documentPurpose: ['document', 30], operationDate: ['document', 40, 'date'], dueEndDate: ['document', 50, 'date'],
  validFrom: ['document', 60, 'date'], orderNo: ['document', 70],
  clientCounterparty: ['parties', 10, 'text', 'counterparty'], counterpartyCode: ['parties', 20, 'text', 'counterparty'],
  streetAddress: ['parties', 30, 'text', 'counterparty'], city: ['parties', 40, 'text', 'counterparty'],
  zipCode: ['parties', 50, 'text', 'counterparty'], phoneNumber: ['parties', 60, 'text', 'counterparty'], email: ['parties', 70, 'email', 'counterparty'],
  amountWithoutVat: ['financial', 10, 'number'], vatPercent: ['financial', 20, 'number'], vat: ['financial', 30, 'number'],
  totalAmount: ['financial', 40, 'number'], currency: ['financial', 50], discountRate: ['financial', 60, 'number'], totalDiscount: ['financial', 70, 'number'],
  lineName: ['lines', 10], lineDescription: ['lines', 20, 'textarea'], lineQuantity: ['lines', 30, 'number'], linePrice: ['lines', 40, 'number'],
  advanceEmployee: ['additional', 10], notes: ['additional', 20, 'textarea'],
  departmentCode: ['calculated', 10], objectProject: ['calculated', 20], series: ['calculated', 30], costCenter: ['calculated', 40],
  accountablePerson: ['calculated', 50], productGroup: ['calculated', 60], glAccount: ['calculated', 70], vatClassifier: ['calculated', 80],
};

/** Add the fields that the legacy editor displayed outside its validation catalog. */
export const LEGACY_OCR_FORM_FIELDS: OcrFieldValidationRule[] = [
  ['streetAddress', 'Street Address'], ['city', 'City'], ['zipCode', 'Zip Code'], ['phoneNumber', 'Phone Number'], ['email', 'E-mail'],
  ['discountRate', 'Discount Rate'], ['totalDiscount', 'Total Discount'], ['lineName', 'Name'], ['lineDescription', 'Description'],
  ['lineQuantity', 'Quantity'], ['linePrice', 'Unit cost'], ['advanceEmployee', 'Advance employee'], ['notes', 'Note'],
].map(([key, label]) => ({ key, label, type: 'OCR', subtype: 'OCR', level: 'yellow', required: false }));

export function normalizeOcrFormRule(rule: OcrFieldValidationRule, index = 0): OcrFieldValidationRule {
  const fallback = DEFAULT_LAYOUT[rule.key] || ['additional', (index + 1) * 10, 'text'];
  const group = OCR_FORM_GROUPS.some(item => item.id === rule.group) ? rule.group! : fallback[0];
  return { ...rule, formVersion: 1, group,
    order: Number.isFinite(rule.order) ? Number(rule.order) : fallback[1],
    inputType: OCR_FORM_INPUT_TYPES.includes(rule.inputType!) ? rule.inputType : fallback[2] || 'text',
    ...(group === 'parties' ? { partyRole: rule.partyRole?.trim() || fallback[3] || 'counterparty' } : {}),
    options: Array.isArray(rule.options) ? [...new Set(rule.options.map(value => String(value).trim()).filter(Boolean))] : [],
  };
}

export function normalizeOcrFormRules(rules: readonly OcrFieldValidationRule[]): OcrFieldValidationRule[] {
  const keys = new Set(rules.map(rule => rule.key));
  const legacy = rules.some(rule => rule.formVersion === 1) ? [] : LEGACY_OCR_FORM_FIELDS.filter(rule => !keys.has(rule.key));
  return [...rules, ...legacy].map(normalizeOcrFormRule);
}

export function ocrFormGroups(rules: readonly OcrFieldValidationRule[]) {
  const visible = rules.map(normalizeOcrFormRule).filter(rule => rule.enabled !== false && !rule.inactive && !OCR_NON_FORM_FIELDS.has(rule.key));
  return OCR_FORM_GROUPS.map(group => ({ ...group, fields: visible.filter(rule => rule.group === group.id)
    .sort((a, b) => (a.order! - b.order!) || a.key.localeCompare(b.key)) })).filter(group => group.fields.length > 0);
}

export const ocrPartyRoleKey = (role: string) => role.trim().toLocaleLowerCase();
export const ocrRulePartyId = (rule: OcrFieldValidationRule) => rule.partyRoleId || ocrPartyRoleKey(rule.partyRole || 'counterparty');
export const ocrSavedPartyId = (party: OcrDocumentParty) => party.roleId || ocrPartyRoleKey(party.role);
export function ocrPartyIsCounterparty(rule: OcrFieldValidationRule, purpose?: string): boolean {
  const binding = rule.partyBinding || (ocrRulePartyId(rule) === 'counterparty' ? 'counterparty' : 'independent');
  return binding === 'counterparty' || binding === 'seller' && purpose === 'Purchase' || binding === 'buyer' && purpose === 'Sale';
}
export function ocrPartyRoleLabel(role: string, purpose?: string) {
  return ocrPartyRoleKey(role) === 'counterparty' ? purpose === 'Sale' ? 'Buyer' : purpose === 'Purchase' ? 'Seller' : 'Counterparty' : role;
}

/** Stable role/party identities keep drafts intact while groups or labels change. */
export function configuredOcrParties(rules: readonly OcrFieldValidationRule[], saved: readonly OcrDocumentParty[] = [], documentId = 'document', purpose?: string) {
  const roles = [...new Map(rules.map(rule => [ocrRulePartyId(rule), rule])).values()];
  return roles.flatMap(rule => {
    const roleId = ocrRulePartyId(rule), role = rule.partyRole || 'counterparty';
    const existing = saved.filter(party => ocrSavedPartyId(party) === roleId);
    const migrated = existing.length ? existing : ocrPartyIsCounterparty(rule, purpose)
      ? saved.filter(party => ocrSavedPartyId(party) === 'counterparty') : [];
    return migrated.length ? migrated.map(party => ({ ...party, role, roleId })) : [{ id: `${documentId}:party:${roleId}`, role, roleId, values: {} }];
  });
}
