import type { DbDocument } from './supabase';
import { documentIssueEvent } from './documentIssues';
import type { OcrRoutingResult } from './ocrApprovalRouting';

/** The document and issue lifecycle are committed together by the OCR command.
 * Worker correction alone never resolves an issue; final OCR/TeamLead approval does. */
export function completeOcrDocument(document: DbDocument, patch: Partial<DbDocument>, route: OcrRoutingResult,
  actor: string, at = new Date().toISOString()): DbDocument {
  if (document.digitization_issues?.some(issue => ['Open', 'In progress'].includes(issue.status)))
    throw new Error('Finish correcting the reported issue and return it to OCR first.');
  const processed = route.destination === 'FH';
  const routing = { ...route, completedAt: at, completedBy: actor };
  const request = document.ocr_rerun_request;
  const finishedRequest = request ? { ...request, status: processed ? 'Completed' as const : 'Awaiting TeamLead' as const,
    ...(processed ? { completedAt: at, completedBy: actor } : {}) } : undefined;
  const issues = document.digitization_issues?.map(issue => {
    if (issue.status !== 'Awaiting OCR' || !processed) return issue;
    const event = { ...documentIssueEvent(actor, 'OCR review completed', 'Corrections reviewed and confirmed. The document is available to the accountant.'), at };
    return { ...issue, status: 'Resolved' as const, blocksApproval: false, resolvedAt: at,
      resolution: issue.correctionNote || 'Document corrections reviewed and confirmed.', events: [...issue.events, event] };
  });
  return { ...document, ...patch, status: processed ? 'Processed' : 'Processing',
    ocr_approval_route: routing, ocr_approval_history: [...(document.ocr_approval_history || []), routing],
    ...(issues ? { digitization_issues: issues } : {}),
    ...(finishedRequest ? { ocr_rerun_request: finishedRequest,
      ocr_rerun_requests: (document.ocr_rerun_requests || [request!]).map(item => item.id === request!.id ? finishedRequest : item) } : {}),
  };
}

export function ocrWorkflowSnapshot(document: DbDocument) {
  return JSON.stringify([document.status, document.company_id, document.ocr_approval_route,
    document.ocr_rerun_request, document.digitization_issues, document.ocr_worker_handoff?.id, document.ocr_document_structure]);
}
