import type { DbDocument } from './supabase';
import type { WorkspaceTask } from '../components/WorkspaceView';
import type { OcrDocumentType } from './ocrApprovalRouting';
import type { OcrFieldValidationRule } from './ocrFieldValidation';
import { awaitingOcrProcessing, ocrDocumentStage, ocrNeedsAttention } from './ocrDocumentWorkflow';
import { isRecognizedOcrDocumentType, missingOcrRequiredFields } from './ocrRequiredFields';
import { requiresDocumentStructureReview } from './ocrHandwriting';

export function isOcrResult(document: DbDocument, task?: WorkspaceTask): boolean {
  return Boolean(document.company_id) && document.entry_method !== 'manual' && !document.accounting_posting
    && !document.document_deletion && !ocrNeedsAttention(document) && !awaitingOcrProcessing(document, task)
    && ocrDocumentStage(document, task)?.queue === 'processing'
    && document.document_type?.trim().toLowerCase() !== 'ocr intake'
    && !['received', 'queued', 'awaiting ocr', 'pending ocr', 'new', 'uploaded', 'submitted'].includes(document.status.trim().toLowerCase())
    && (document.status.trim().toLowerCase() !== 'pending' || Boolean(task?.fields));
}

/** Route actual failed/incomplete results to a person, never pending machine work. */
export function ocrQueueStatus(document: DbDocument, task: WorkspaceTask | undefined,
  catalog: readonly OcrDocumentType[], rules: readonly OcrFieldValidationRule[]): 'Awaiting OCR' | 'Worker review' | undefined {
  if (!document.company_id || document.entry_method === 'manual' || document.accounting_posting
    || ocrNeedsAttention(document) || ocrDocumentStage(document, task)?.queue !== 'processing') return;
  if (awaitingOcrProcessing(document, task)) return 'Awaiting OCR';
  if (isOcrResult(document, task) && (!isRecognizedOcrDocumentType(document, catalog)
    || missingOcrRequiredFields(document, rules).length > 0 || requiresDocumentStructureReview(document)
    || document.ocr_poor_quality === true || document.ocr_quality_review_required === true)) return 'Worker review';
}

/** Only recognized, unreviewed OCR results may bypass the human queue.
 * A pending rerun is not a new recognition result, even if old fields are full. */
export function canAutomaticallyCompleteOcr(document: DbDocument, task: WorkspaceTask | undefined,
  catalog: readonly OcrDocumentType[], rules: readonly OcrFieldValidationRule[]): boolean {
  if (!isOcrResult(document, task)
    || task?.ocrRunRequest || task?.savedAt || task?.lastCorrectedAt || task?.editStartedAt
    || ocrDocumentStage(document, task)?.queue !== 'processing') return false;
  return isRecognizedOcrDocumentType(document, catalog) && missingOcrRequiredFields(document, rules).length === 0 && !requiresDocumentStructureReview(document)
    && document.ocr_poor_quality !== true && document.ocr_quality_review_required !== true;
}
