import type { DbDocument } from './supabase';
import type { WorkspaceTask } from '../components/WorkspaceView';
import type { OcrDocumentType } from './ocrApprovalRouting';
import { ocrCompletionPatch } from './ocrRequiredFields';

const DRAFT_KEY = 'finansu-harmonija:v12:workspace:review-document-tasks';
type IssueDraft = WorkspaceTask & { issueCorrectionId: string };

export function loadIssueCorrectionDraft(documentId: string, issueId: string, companyId: string | undefined, storage: Pick<Storage, 'getItem'>): IssueDraft | undefined {
  try {
    const task = JSON.parse(storage.getItem(DRAFT_KEY) || '{}')[documentId] as IssueDraft | undefined;
    return task?.issueCorrectionId === issueId && task.accounting?.documentId === documentId
      && (!companyId || task.accounting.companyId === companyId) ? task : undefined;
  } catch { return undefined; }
}

export function saveIssueCorrectionDraft(task: WorkspaceTask, documentId: string, issueId: string, storage: Pick<Storage, 'getItem' | 'setItem'>) {
  const collection = JSON.parse(storage.getItem(DRAFT_KEY) || '{}');
  if (!collection || typeof collection !== 'object' || Array.isArray(collection)) throw new Error('Unable to read the saved tasks. No existing work has been overwritten.');
  const saved: IssueDraft = { ...task, issueCorrectionId: issueId, savedAt: new Date().toISOString() };
  storage.setItem(DRAFT_KEY, JSON.stringify({ ...collection, [documentId]: saved }));
  return saved;
}

/** OCR corrections never create accounting reversals or approve a document. */
export function ocrIssueCorrectionPatch(task: WorkspaceTask, original: DbDocument, catalog: readonly OcrDocumentType[]) {
  const patch = ocrCompletionPatch(task, catalog, original);
  delete patch.advance_employee_id;
  delete patch.advance_employee;
  if (task.fields.companyName.trim() !== original.client_counterparty) patch.counterparty_id = '';
  const previous = original.line_items || [];
  patch.line_items = task.products.map(product => {
    const old = previous.find(line => line.id === product.id);
    return { barcode: '', unit: '', code: '', subtotal: '', discount: '', vat: '', vatPct: '', total: '',
      department: '', object: '', series: '', center: '', expense: '', vatClass: '', ...old,
      id: product.id, product: product.name, description: product.description, qty: product.quantity, price: product.price,
      ...(product.ocrValues ? { ocr_values: product.ocrValues } : {}) };
  });
  return patch;
}
