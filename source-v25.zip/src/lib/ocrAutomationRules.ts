import { AUTH_SESSION_KEY, getCurrentUserIdentity } from './currentUser';
import { canEditMenu, canViewMenu, parseSession, type AppSession } from './accessControl';
import { canAccessAssignedOrganization, type LinkedOrganization } from './linkedSettingsData';

export type AutomationRule = {
  id: string; name: string; documentType: string; organizationId: string; fieldKey: string;
  conditionText: string; match: 'contains' | 'equals'; action: 'assign' | 'required' | 'equals';
  value: string; enabled: boolean; overwrite: boolean; updatedAt: string;
};
export type AutomationAudit = {
  at: string; actor: { name: string; email: string }; before?: AutomationRule; after: AutomationRule;
};
export type AutomationStore = { version: 1; rules: AutomationRule[]; history: AutomationAudit[] };
export type AutomationContext = {
  documentTypeCodes: string[]; organizationId: string; text: string; values: Record<string, string>;
  protectedFields?: string[];
};
export type AutomationResult = {
  values: Record<string, string>; assignments: { fieldKey: string; value: string; ruleId: string }[];
  warnings: { fieldKey: string; message: string; ruleId: string }[]; matchedRuleIds: string[];
};

export const OCR_AUTOMATION_KEY = 'finansu-harmonija:v25:ocr:document-automation-rules';
export const OCR_AUTOMATION_CHANGED = 'finansu-harmonija:ocr-document-automation-changed';
export const emptyAutomationStore = (): AutomationStore => ({ version: 1, rules: [], history: [] });
const unsafeKeys = new Set(['__proto__', 'prototype', 'constructor']);
const hasOwn = (object: object, key: string) => Object.prototype.hasOwnProperty.call(object, key);
const normalizeText = (value: string) => value.normalize('NFC').trim().replace(/\s+/g, ' ').toLocaleLowerCase();
const emptyValue = (value: string) => ['', '—', '-'].includes(value.trim());

export function validateAutomationRule(rule: AutomationRule): string[] {
  const errors: string[] = [];
  if (!rule || typeof rule !== 'object') return ['Invalid automation rule.'];
  for (const [key, label] of [['id', 'Rule identifier'], ['name', 'Rule name'], ['documentType', 'Document type'],
    ['fieldKey', 'Field'], ['conditionText', 'Document text']] as const) {
    if (typeof rule[key] !== 'string' || !rule[key].trim()) errors.push(`${label} is required.`);
  }
  if (typeof rule.organizationId !== 'string') errors.push('Choose a valid organization.');
  if (!['contains', 'equals'].includes(rule.match)) errors.push('Choose a valid text condition.');
  if (!['assign', 'required', 'equals'].includes(rule.action)) errors.push('Choose a valid rule action.');
  if (typeof rule.value !== 'string' || (rule.action !== 'required' && !rule.value.trim())) errors.push('Value is required.');
  if (typeof rule.enabled !== 'boolean' || typeof rule.overwrite !== 'boolean') errors.push('Invalid rule settings.');
  if (typeof rule.updatedAt !== 'string' || (rule.updatedAt && !Number.isFinite(Date.parse(rule.updatedAt)))) errors.push('Invalid update date.');
  if (typeof rule.fieldKey === 'string' && unsafeKeys.has(rule.fieldKey.trim())) errors.push('Choose a valid field.');
  if (typeof rule.name === 'string' && rule.name.length > 200) errors.push('Rule name is too long (maximum 200 characters).');
  if (typeof rule.conditionText === 'string' && rule.conditionText.length > 2000) errors.push('Document text is too long (maximum 2000 characters).');
  if (typeof rule.value === 'string' && rule.value.length > 2000) errors.push('Value is too long (maximum 2000 characters).');
  return errors;
}

/** Literal text rules only: no executable expressions, regular expressions or model claims. */
export function evaluateAutomationRules(rules: readonly AutomationRule[], context: AutomationContext): AutomationResult {
  const result: AutomationResult = { values: { ...context.values }, assignments: [], warnings: [], matchedRuleIds: [] };
  const text = normalizeText(context.text);
  const protectedFields = new Set(context.protectedFields || []);
  const matches = rules.filter(rule => rule.enabled && validateAutomationRule(rule).length === 0
    && hasOwn(context.values, rule.fieldKey) && typeof context.values[rule.fieldKey] === 'string'
    && context.documentTypeCodes.includes(rule.documentType)
    && (!rule.organizationId || rule.organizationId === context.organizationId)
    && Boolean(text) && (rule.match === 'contains' ? text.includes(normalizeText(rule.conditionText)) : text === normalizeText(rule.conditionText)));
  result.matchedRuleIds = matches.map(rule => rule.id).sort();
  const groups = new Map<string, AutomationRule[]>();
  for (const rule of matches) {
    const key = JSON.stringify([rule.fieldKey, rule.action]);
    groups.set(key, [...(groups.get(key) || []), rule]);
  }
  const priority = (rule: AutomationRule) => [rule.organizationId ? 1 : 0, -context.documentTypeCodes.indexOf(rule.documentType)];
  const strongest = (candidates: AutomationRule[]) => {
    const sorted = [...candidates].sort((a, b) => priority(b)[0] - priority(a)[0] || priority(b)[1] - priority(a)[1] || a.id.localeCompare(b.id));
    const first = priority(sorted[0]);
    return sorted.filter(rule => priority(rule)[0] === first[0] && priority(rule)[1] === first[1]);
  };
  const selected = [...groups.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([, candidates]) => strongest(candidates));
  // Assign first so validation checks the result of this evaluation, not intermediate field values.
  for (const candidates of selected.filter(group => group[0].action === 'assign')) {
    const rule = candidates[0];
    if (protectedFields.has(rule.fieldKey)) continue;
    if (new Set(candidates.map(item => item.value.trim())).size > 1) {
      result.warnings.push({ fieldKey: rule.fieldKey, ruleId: rule.id, message: 'Conflicting automation rules. Review the field value.' });
      continue;
    }
    if (candidates.length > 1 && new Set(candidates.map(item => item.overwrite)).size > 1 && !emptyValue(result.values[rule.fieldKey])) {
      result.warnings.push({ fieldKey: rule.fieldKey, ruleId: rule.id, message: 'Conflicting overwrite settings. Review the field value.' });
      continue;
    }
    const value = rule.value.trim();
    if ((rule.overwrite || emptyValue(result.values[rule.fieldKey])) && result.values[rule.fieldKey] !== value) {
      result.values[rule.fieldKey] = value;
      result.assignments.push({ fieldKey: rule.fieldKey, value, ruleId: rule.id });
    }
  }
  for (const candidates of selected.filter(group => group[0].action !== 'assign')) {
    const rule = candidates[0], value = result.values[rule.fieldKey];
    if (rule.action === 'required' && emptyValue(value)) {
      result.warnings.push({ fieldKey: rule.fieldKey, ruleId: rule.id, message: 'This field is required by a document rule.' });
    } else if (rule.action === 'equals') {
      if (new Set(candidates.map(item => item.value.trim())).size > 1) {
        result.warnings.push({ fieldKey: rule.fieldKey, ruleId: rule.id, message: 'Conflicting validation rules. Review the expected value.' });
      } else if (value.trim() !== rule.value.trim()) {
        result.warnings.push({ fieldKey: rule.fieldKey, ruleId: rule.id, message: `Expected value: ${rule.value.trim()}` });
      }
    }
  }
  return result;
}

function validStore(value: unknown): value is AutomationStore {
  if (!value || typeof value !== 'object') return false;
  const store = value as AutomationStore;
  if (store.version !== 1 || !Array.isArray(store.rules) || !Array.isArray(store.history)
    || store.rules.some(rule => validateAutomationRule(rule).length > 0)
    || new Set(store.rules.map(rule => rule.id)).size !== store.rules.length) return false;
  return store.history.every(entry => entry && typeof entry.at === 'string' && Number.isFinite(Date.parse(entry.at))
    && entry.actor && typeof entry.actor.name === 'string' && typeof entry.actor.email === 'string'
    && validateAutomationRule(entry.after).length === 0 && (!entry.before || validateAutomationRule(entry.before).length === 0));
}

export function loadAutomationStore(strict = false): AutomationStore {
  try {
    const raw = localStorage.getItem(OCR_AUTOMATION_KEY);
    if (!raw) return emptyAutomationStore();
    const parsed: unknown = JSON.parse(raw);
    if (!validStore(parsed)) throw new Error('Invalid document automation rule history.');
    return parsed;
  } catch (error) {
    // Fail closed: an unreadable store never causes fictional/partial rules to run.
    if (strict) throw error;
    return emptyAutomationStore();
  }
}

const organizationStorageKey = 'finansu-harmonija-v4:data:companies';

function unrestrictedOrganizationScope(session: AppSession): boolean {
  // Match the shared access helper's role precedence. An accountant assigned to
  // every current company is still scoped; newly created companies are not theirs.
  if (session.roleNames.includes('External demo user')) return false;
  const roles = session.roleNames.map(role => role.toLowerCase());
  if (roles.some(role => ['administrator', 'administration'].includes(role))) return true;
  return !roles.includes('meso accountant');
}

function organizationAccessible(organizationId: string, session: AppSession): boolean {
  if (!organizationId) return unrestrictedOrganizationScope(session);
  try {
    // readTable refreshes this cache before the form offers organizations. Never
    // trust an organization's presence in a stale dropdown or caller-supplied list.
    const rows: unknown = JSON.parse(localStorage.getItem(organizationStorageKey) || 'null');
    if (!Array.isArray(rows) || rows.some(row => !row || typeof row.id !== 'string' || typeof row.name !== 'string')) return false;
    const organization = rows.find(row => row.id === organizationId) as (LinkedOrganization & { assigned_accountant?: string }) | undefined;
    return Boolean(organization && canAccessAssignedOrganization(organization, session));
  } catch { return false; }
}

export function automationPermissions(): { edit: boolean; global: boolean } {
  try {
    const session = parseSession(localStorage.getItem(AUTH_SESSION_KEY));
    const edit = Boolean(session && canViewMenu(session, 'ocr-document-rules') && canEditMenu(session, 'ocr-document-rules'));
    return { edit, global: Boolean(edit && session && unrestrictedOrganizationScope(session)) };
  } catch { return { edit: false, global: false }; }
}

/** Global rules are relevant to scoped users, but are read-only for them. */
export function automationRuleVisible(rule: Pick<AutomationRule, 'organizationId'>): boolean {
  try {
    const session = parseSession(localStorage.getItem(AUTH_SESSION_KEY));
    return Boolean(session && canViewMenu(session, 'ocr-document-rules')
      && (!rule.organizationId || organizationAccessible(rule.organizationId, session)));
  } catch { return false; }
}

/** Used by both the UI and the persistence boundary; re-evaluated at action time. */
export function canEditAutomationRule(rule: Pick<AutomationRule, 'organizationId'>): boolean {
  try {
    const session = parseSession(localStorage.getItem(AUTH_SESSION_KEY));
    return Boolean(session && canViewMenu(session, 'ocr-document-rules') && canEditMenu(session, 'ocr-document-rules')
      && organizationAccessible(rule.organizationId, session));
  } catch { return false; }
}

export function saveAutomationRule(input: AutomationRule): AutomationStore {
  if (!automationPermissions().edit) throw new Error('You do not have permission to edit document rules.');
  const errors = validateAutomationRule(input);
  if (errors.length) throw new Error(errors[0]);
  const store = loadAutomationStore(true);
  const identity = getCurrentUserIdentity();
  if (!identity.email) throw new Error('Sign in to edit document rules.');
  const rule: AutomationRule = { ...input, id: input.id.trim(), name: input.name.trim(), documentType: input.documentType.trim(),
    organizationId: input.organizationId.trim(), fieldKey: input.fieldKey.trim(), conditionText: input.conditionText.trim(), value: input.value.trim(), updatedAt: new Date().toISOString() };
  const before = store.rules.find(item => item.id === rule.id);
  if (!canEditAutomationRule(rule) || (before && !canEditAutomationRule(before)))
    throw new Error('You do not have permission to change rules for this organization.');
  const next: AutomationStore = { version: 1, rules: before ? store.rules.map(item => item.id === rule.id ? rule : item) : [...store.rules, rule],
    history: [...store.history, { at: rule.updatedAt, actor: { name: identity.fullName, email: identity.email }, before, after: rule }] };
  localStorage.setItem(OCR_AUTOMATION_KEY, JSON.stringify(next));
  window.dispatchEvent(new CustomEvent(OCR_AUTOMATION_CHANGED));
  return next;
}

/** Keep the rule and its history; rules may already be referenced by documents. */
export function setAutomationRuleEnabled(id: string, enabled: boolean): AutomationStore {
  if (!automationPermissions().edit) throw new Error('You do not have permission to edit document rules.');
  const store = loadAutomationStore(true), rule = store.rules.find(item => item.id === id);
  if (!rule) throw new Error('The document rule no longer exists. Refresh the list.');
  return saveAutomationRule({ ...rule, enabled });
}

const exampleRule = (input: Partial<AutomationRule>): AutomationRule => ({ id: 'TEST-TEXT-PVM', name: 'TEST · str.42 → PVM1', documentType: 'VAT_INVOICE',
  organizationId: '', fieldKey: 'vatClassifier', conditionText: 'str.42', match: 'contains', action: 'assign', value: 'PVM1',
  enabled: true, overwrite: false, updatedAt: '2026-11-25T00:00:00Z', ...input });

/** Isolated test fixtures for the preview UI; never inserted into the active rule store. */
export const AUTOMATION_TEST_EXAMPLES: { id: string; name: string; rule: AutomationRule; context: AutomationContext; expected: string }[] = [
  { id: 'TEST-TEXT-PVM', name: 'TEST · str.42 → PVM1', rule: exampleRule({}),
    context: { documentTypeCodes: ['VAT_INVOICE', 'INVOICES'], organizationId: 'TEST-ORG-A', text: 'TEST DOCUMENT — NOT FOR PAYMENT\nVAT invoice. Exemption: str.42.', values: { vatClassifier: '' } }, expected: 'PVM1' },
  { id: 'TEST-ORG-SCOPE', name: 'TEST · Organization-specific rule', rule: exampleRule({ id: 'TEST-ORG-SCOPE', name: 'TEST · Organization A only', organizationId: 'TEST-ORG-A' }),
    context: { documentTypeCodes: ['VAT_INVOICE', 'INVOICES'], organizationId: 'TEST-ORG-B', text: 'TEST DOCUMENT — NOT FOR PAYMENT\nExemption: str.42.', values: { vatClassifier: '' } }, expected: 'No match: a different organization.' },
  { id: 'TEST-REQUIRED', name: 'TEST · Missing order number', rule: exampleRule({ id: 'TEST-REQUIRED', name: 'TEST · Contract requires order number', fieldKey: 'orderNo', conditionText: 'contract', action: 'required', value: '' }),
    context: { documentTypeCodes: ['VAT_INVOICE', 'INVOICES'], organizationId: 'TEST-ORG-A', text: 'TEST DOCUMENT — NOT FOR PAYMENT\nServices under contract.', values: { orderNo: '' } }, expected: 'This field is required by a document rule.' },
];
