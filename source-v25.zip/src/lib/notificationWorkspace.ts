import type { AttentionNotification } from './notifications';
import type { WorkspaceMode } from './workspaceMode';
import type { InvoiceChatContext } from '../components/invoices/invoiceChat';

/** Scope comes from the originating workflow, not merely the fact that a row is a Chat. */
export function notificationWorkspace(row: AttentionNotification, conversations: readonly InvoiceChatContext[] = []): 'ocr' | 'fh' {
  if (row.ocrTarget) return 'ocr';
  if (row.workspace) return row.workspace;
  if ('sourceChatId' in row && row.sourceChatId) {
    const context = conversations.find(item => item.storageKey === row.sourceChatId);
    return context?.workspace || (context?.participantType === 'Worker' ? 'ocr' : 'fh');
  }
  return row.type === 'OCR' ? 'ocr' : 'fh';
}

export function notificationVisibleInWorkspace(row: AttentionNotification, mode: WorkspaceMode, conversations: readonly InvoiceChatContext[] = []) {
  return mode === 'combined' || notificationWorkspace(row, conversations) === mode;
}
