import { isSystemAdministratorRole, parseSession } from './accessControl';
import { AUTH_SESSION_KEY } from './currentUser';
import { defaultCompanySaasPlan, validateCompanySaasPlan, type CompanySaasPlan } from './companySaas';

export type ContractPriceTier = { id: string; from: number; to: number | null; basePriceCents: number; discountPercent: number };
export type DocumentPricing = 'progressive' | 'flat';
export type ContractPlan = { id: string; name: string; tiers: ContractPriceTier[]; linePriceCents: number; minimumLines: number; saas?: CompanySaasPlan; documentPricing?: DocumentPricing };
export type PricingChange = { at: string; by: string; planId: string; area: string; previous: unknown; next: unknown };
export type ContractPricingCatalog = { revision: number; plans: ContractPlan[]; history: PricingChange[] };
type PricingStorage = Pick<Storage, 'getItem' | 'setItem'>;
export const CONTRACT_PRICING_KEY = 'finansu-harmonija-v24:contract-pricing:v1';
export const CONTRACT_PRICING_CHANGED = 'finansu-harmonija:contract-pricing-changed';
export const DEFAULT_CONTRACT_PLAN_ID = 'documents-and-lines';

/** Older plans remain progressive; defaults are read without rewriting stored prices. */
export const contractPlanSaas = (plan: ContractPlan): CompanySaasPlan => structuredClone(plan.saas ?? defaultCompanySaasPlan());
export const contractDocumentPricing = (plan: ContractPlan): DocumentPricing => plan.documentPricing ?? 'progressive';
export const hasProgressiveDocumentPricing = (plan: ContractPlan) => contractPlanSaas(plan).kainodara === 'docs' && contractDocumentPricing(plan) === 'progressive';

export function defaultContractPricing(): ContractPricingCatalog {
  const ends = [250, 500, 1000, 1500, 2000, 3000, 6000, 10000, null];
  return { revision: 0, history: [], plans: [{
    id: DEFAULT_CONTRACT_PLAN_ID, name: 'Documents and digitized lines', linePriceCents: 2, minimumLines: 5,
    tiers: ends.map((to, index) => ({ id: `tier-${index + 1}`, from: index ? (ends[index - 1] as number) + 1 : 0, to, basePriceCents: 30, discountPercent: index * 5 })),
  }] };
}
const finite = (value: number, max: number) => Number.isFinite(value) && value >= 0 && value <= max;
export function validateContractPlan(plan: ContractPlan) {
  if (!plan || typeof plan.id !== 'string' || typeof plan.name !== 'string' || !plan.id.trim() || !plan.name.trim() || plan.name.length > 120) return 'Enter a plan name (up to 120 characters).';
  if (plan.documentPricing !== undefined && !['progressive', 'flat'].includes(plan.documentPricing)) return 'Select a valid document pricing method.';
  if (plan.saas !== undefined) {
    if (!plan.saas || !Array.isArray(plan.saas.moduliai)) return 'Select valid SaaS plan options.';
    const error = validateCompanySaasPlan(plan.saas); if (error) return error;
  }
  if (!finite(plan.linePriceCents, 100000) || !Number.isInteger(plan.minimumLines) || plan.minimumLines < 1 || plan.minimumLines > 100000) return 'Enter a valid line price and a positive minimum line count.';
  if (!Array.isArray(plan.tiers) || !plan.tiers.length || plan.tiers.some(tier => !tier || typeof tier.id !== 'string') || new Set(plan.tiers.map(tier => tier.id)).size !== plan.tiers.length) return 'The document pricing tiers are invalid.';
  for (const [index, tier] of plan.tiers.entries()) {
    const previous = plan.tiers[index - 1];
    if (!tier.id || !Number.isInteger(tier.from) || tier.from !== (index ? Number(previous.to) + 1 : 0)
      || (index === plan.tiers.length - 1 ? tier.to !== null : !Number.isInteger(tier.to) || Number(tier.to) < tier.from)
      || !finite(tier.basePriceCents, 100000) || !finite(tier.discountPercent, 100)) return 'Enter a valid price and a discount between 0 and 100%.';
  }
  return '';
}
export function readContractPricing(storage: Pick<Storage, 'getItem'>): ContractPricingCatalog {
  const raw = storage.getItem(CONTRACT_PRICING_KEY);
  if (!raw) return defaultContractPricing();
  let value: ContractPricingCatalog;
  try { value = JSON.parse(raw); } catch { throw new Error('Pricing could not be loaded. Saved data has not been changed.'); }
  if (!value || !Number.isInteger(value.revision) || value.revision < 0 || !Array.isArray(value.plans) || !value.plans.length
    || value.plans.some(plan => validateContractPlan(plan)) || new Set(value.plans.map(plan => plan.id)).size !== value.plans.length || !Array.isArray(value.history)) {
    throw new Error('Pricing could not be loaded. Saved data has not been changed.');
  }
  return value;
}
export function canManageContractPricing(storage: Pick<Storage, 'getItem'>) {
  try { const session = parseSession(storage.getItem(AUTH_SESSION_KEY)); return Boolean(session && !session.roleNames.includes('Inactive') && session.roleNames.some(isSystemAdministratorRole)); } catch { return false; }
}
const round = (value: number) => Math.round((value + Number.EPSILON) * 10000) / 10000;
export const discountedDocumentPrice = (tier: ContractPriceTier) => round(tier.basePriceCents * (1 - tier.discountPercent / 100));
export const contractTierRange = (tier: ContractPriceTier) => tier.to === null ? tier.from === 0 ? '0+' : `> ${tier.from - 1}` : `${tier.from}–${tier.to}`;

/** Changes range boundaries without leaving gaps or overlapping tiers. */
export function updateContractTier(tiers: ContractPriceTier[], id: string, patch: Pick<ContractPriceTier, 'to' | 'basePriceCents' | 'discountPercent'>) {
  const next = structuredClone(tiers), index = next.findIndex(tier => tier.id === id);
  if (index < 0) throw new Error('The document pricing tiers are invalid.');
  const tier = next[index], following = next[index + 1];
  if ((following && (!Number.isSafeInteger(patch.to) || Number(patch.to) < Math.max(1, tier.from) || (following.to !== null && Number(patch.to) >= following.to))) || (!following && patch.to !== null)) throw new Error('Enter an upper limit within the adjacent pricing ranges.');
  if (!finite(patch.basePriceCents, 100000) || !finite(patch.discountPercent, 100)) throw new Error('Enter a valid price and a discount between 0 and 100%.');
  Object.assign(tier, patch);
  if (following) following.from = Number(patch.to) + 1;
  return next;
}

export function addContractTier(tiers: ContractPriceTier[], input: { to: number; basePriceCents: number; discountPercent: number }) {
  const next = structuredClone(tiers), tail = next[next.length - 1];
  if (!tail || tail.to !== null || !Number.isSafeInteger(input.to) || input.to < Math.max(1, tail.from)) throw new Error('Enter an upper limit within the adjacent pricing ranges.');
  if (!finite(input.basePriceCents, 100000) || !finite(input.discountPercent, 100)) throw new Error('Enter a valid price and a discount between 0 and 100%.');
  next.splice(next.length - 1, 0, { id: crypto.randomUUID(), from: tail.from, ...input });
  tail.from = input.to + 1;
  return next;
}

export function removeContractTier(tiers: ContractPriceTier[], id: string) {
  const next = structuredClone(tiers), index = next.findIndex(tier => tier.id === id);
  if (index < 0 || next.length < 2) throw new Error('Keep at least one pricing tier.');
  const [removed] = next.splice(index, 1);
  if (next[index]) next[index].from = removed.from;
  else next[next.length - 1].to = null;
  return next;
}
export function contractDocumentCostCents(plan: ContractPlan, count: number) {
  if (!Number.isSafeInteger(count) || count < 0) throw new Error('Enter a non-negative whole document count.');
  if (contractDocumentPricing(plan) === 'flat') return round(count * Number(contractPlanSaas(plan).kaina) * 100);
  return round(plan.tiers.reduce((total, tier) => {
    const quantity = Math.max(0, Math.min(count, tier.to ?? count) - Math.max(1, tier.from) + 1);
    return total + quantity * discountedDocumentPrice(tier);
  }, 0));
}
export function averageContractPriceCents(plan: ContractPlan, count: number) { return count ? round(contractDocumentCostCents(plan, count) / count) : 0; }
export function contractExample(plan: ContractPlan) {
  const lineCount = 10 * Math.max(5, plan.minimumLines);
  const totalCents = round(contractDocumentCostCents(plan, 1300) + lineCount * plan.linePriceCents);
  return { total: totalCents / 100, averageCents: totalCents / 1300, lineCount };
}

export type ContractPricingEdit =
  | { kind: 'tier'; planId: string; tierId: string; basePriceCents: number; discountPercent: number }
  | { kind: 'lines'; planId: string; linePriceCents: number; minimumLines: number }
  | { kind: 'rename'; planId: string; name: string }
  | { kind: 'configuration'; planId: string; name: string; saas: CompanySaasPlan; documentPricing: DocumentPricing }
  | { kind: 'details'; planId: string; name: string; saas: CompanySaasPlan; documentPricing: DocumentPricing; tiers: ContractPriceTier[]; linePriceCents: number; minimumLines: number }
  | { kind: 'create'; sourcePlanId: string; name: string; saas?: CompanySaasPlan; documentPricing?: DocumentPricing };

/** Frontend configuration only. Re-check the current session and catalog revision
 * on every save; confirmed contract snapshots and billing records are untouched. */
export function saveContractPricing(storage: PricingStorage, expectedRevision: number, edit: ContractPricingEdit): ContractPricingCatalog {
  if (!canManageContractPricing(storage)) throw new Error('Only an administrator can edit contract pricing.');
  const current = readContractPricing(storage);
  if (current.revision !== expectedRevision) throw new Error('Pricing has changed. Close this window and open the editor again.');
  const next = structuredClone(current);
  const plan = next.plans.find(item => item.id === (edit.kind === 'create' ? edit.sourcePlanId : edit.planId));
  if (!plan) throw new Error('Select an available plan.');
  let previous: unknown, changed: unknown, area: string, planId = plan.id;
  if (edit.kind === 'create') {
    const name = edit.name.trim();
    if (next.plans.some(item => item.name.toLocaleLowerCase() === name.toLocaleLowerCase())) throw new Error('A plan with this name already exists.');
    const created = { ...structuredClone(plan), id: crypto.randomUUID(), name,
      ...(edit.saas ? { saas: structuredClone(edit.saas) } : {}), ...(edit.documentPricing ? { documentPricing: edit.documentPricing } : {}),
    };
    const error = validateContractPlan(created); if (error) throw new Error(error);
    next.plans.push(created); previous = null; changed = created; area = 'plan'; planId = created.id;
  } else if (edit.kind === 'details') {
    const name = edit.name.trim();
    if (next.plans.some(item => item.id !== plan.id && item.name.toLocaleLowerCase() === name.toLocaleLowerCase())) throw new Error('A plan with this name already exists.');
    previous = structuredClone(plan);
    Object.assign(plan, { name, saas: structuredClone(edit.saas), documentPricing: edit.documentPricing, tiers: structuredClone(edit.tiers), linePriceCents: edit.linePriceCents, minimumLines: edit.minimumLines });
    changed = structuredClone(plan); area = 'configuration';
  } else if (edit.kind === 'configuration') {
    const name = edit.name.trim();
    if (next.plans.some(item => item.id !== plan.id && item.name.toLocaleLowerCase() === name.toLocaleLowerCase())) throw new Error('A plan with this name already exists.');
    previous = { name: plan.name, saas: contractPlanSaas(plan), documentPricing: contractDocumentPricing(plan) };
    plan.name = name; plan.saas = structuredClone(edit.saas); plan.documentPricing = edit.documentPricing;
    changed = { name, saas: structuredClone(plan.saas), documentPricing: plan.documentPricing }; area = 'configuration';
  } else if (edit.kind === 'rename') {
    const name = edit.name.trim();
    if (next.plans.some(item => item.id !== plan.id && item.name.toLocaleLowerCase() === name.toLocaleLowerCase())) throw new Error('A plan with this name already exists.');
    previous = plan.name; plan.name = name; changed = name; area = 'name';
  } else if (edit.kind === 'tier') {
    const tier = plan.tiers.find(item => item.id === edit.tierId);
    if (!tier) throw new Error('The document pricing tiers are invalid.');
    previous = { ...tier }; tier.basePriceCents = edit.basePriceCents; tier.discountPercent = edit.discountPercent;
    changed = { ...tier }; area = tier.id;
  } else {
    previous = { linePriceCents: plan.linePriceCents, minimumLines: plan.minimumLines };
    plan.linePriceCents = edit.linePriceCents; plan.minimumLines = edit.minimumLines;
    changed = { linePriceCents: plan.linePriceCents, minimumLines: plan.minimumLines }; area = 'lines';
  }
  const error = validateContractPlan(plan); if (error) throw new Error(error);
  const actor = parseSession(storage.getItem(AUTH_SESSION_KEY));
  next.revision += 1;
  next.history.push({ at: new Date().toISOString(), by: actor?.email || '', planId, area, previous, next: changed });
  storage.setItem(CONTRACT_PRICING_KEY, JSON.stringify(next));
  return next;
}
