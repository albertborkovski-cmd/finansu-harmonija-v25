import type { ColConfig } from '../components/ColumnSettingsPanel';

const primary = [
  ['organization', 'Organization'], ['number', 'Document No.'],
  ['clientCounterparty', 'Counterparty'], ['documentType', 'Document type'],
  ['issueReason', 'Issue reason'], ['receiveDate', 'Receive date'],
  ['waitingTime', 'Waiting time'], ['priority', 'Priority'], ['status', 'Task status'],
] as const;
export function taskColumnLabels(columns: readonly ColConfig[]): ColConfig[] {
  const labels = new Map<string, string>(primary);
  return columns.map(column => ({ ...column, label: labels.get(column.key) || column.label }));
}
export function defaultOcrTaskColumns(columns: readonly ColConfig[]): ColConfig[] {
  const keys = new Set<string>(primary.map(([key]) => key));
  return [...primary.map(([key, label]) => ({ ...columns.find(c => c.key === key), key, label, width: columns.find(c => c.key === key)?.width || 180, visible: true })),
    ...columns.filter(c => !keys.has(c.key) && c.key !== 'documentPages').map(c => ({ ...c, visible: false })),
    { key: 'documentPages', label: 'Document pages', width: 170, visible: false }];
}

/** Apply the requested layout once even when a live update carried old state
 * into the new preference key. Keep a recoverable copy of that layout. */
export function migrateOcrTaskLayout(storage: Pick<Storage, 'getItem' | 'setItem'>, scope: string, columns: readonly ColConfig[], defaults: readonly ColConfig[]): ColConfig[] {
  const key = `finansu-harmonija:ocr:${scope}:nine-column-layout-applied-v2`;
  if (storage.getItem(key) === '1') return [...columns];
  const next = defaultOcrTaskColumns([...columns, ...defaults.filter(d => !columns.some(c => c.key === d.key))]);
  storage.setItem(`${key}:previous`, JSON.stringify(columns));
  storage.setItem(key, '1');
  return next;
}
export function taskWaitingTime(since: number, now = Date.now()): string {
  if (!Number.isFinite(since) || since === Number.MAX_SAFE_INTEGER) return '—';
  const minutes = Math.max(0, Math.floor((now - since) / 60000));
  return `${Math.floor(minutes / 1440)}d ${Math.floor(minutes % 1440 / 60)}h ${minutes % 60}m`;
}

/** Uploads retain their precise receipt timestamp in created_at. Date-only
 * legacy records must not be presented as having arrived at midnight. */
export function taskReceiveDate(document: { receive_date?: string; created_at?: string }, timeZone?: string): string {
  for (const value of [document.receive_date, document.created_at]) {
    if (!value || !/[T ]\d{2}:\d{2}/.test(value)) continue;
    const date = new Date(value);
    if (!Number.isFinite(date.getTime())) continue;
    const parts = new Intl.DateTimeFormat('en-GB', { timeZone, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(date);
    const part = (type: string) => parts.find(p => p.type === type)?.value;
    return `${part('year')}-${part('month')}-${part('day')} ${part('hour')}:${part('minute')}`;
  }
  return document.receive_date ? `${document.receive_date} --:--` : '—';
}
