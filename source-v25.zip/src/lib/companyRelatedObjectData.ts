import type { Company } from './supabase';

export interface DebtRow {
  id: string;
  direction?: 'receivable' | 'payable';
  counterpartyCode: string;
  counterpartyName: string;
  counterpartyType: string;
  documentReference: string;
  documentType: string;
  issueDate: string;
  dueDate: string;
  currency: string;
  totalAmount: string;
  paidAmount: string;
  outstandingAmount: string;
  daysOverdue: number;
  debtStatus: string;
  reminderStage: string;
  lastReminderDate: string;
  nextReminderDate?: string;
  paymentPriority: string;
  department: string;
  notes: string;
}

export const DEBT_ROWS: DebtRow[] = [
  {
    id: 'debt-1',
    counterpartyCode: '123456',
    counterpartyName: 'UAB Alfa',
    counterpartyType: 'Buyer',
    documentReference: 'INV-1025',
    documentType: 'Sales invoice',
    issueDate: '03.11.2026',
    dueDate: '13.11.2026',
    currency: 'EUR',
    totalAmount: '1,200.00',
    paidAmount: '900.00',
    outstandingAmount: '300.00',
    daysOverdue: 5,
    debtStatus: 'Partially paid',
    reminderStage: 'Final',
    lastReminderDate: '16.11.2026',
    paymentPriority: 'Low',
    department: 'Project A',
    notes: '—',
  },
  {
    id: 'debt-2',
    counterpartyCode: '305600002',
    counterpartyName: 'Baltic Services, UAB',
    counterpartyType: 'Supplier',
    documentReference: 'PUR-2041',
    documentType: 'Purchase invoice',
    issueDate: '03.11.2026',
    dueDate: '13.11.2026',
    currency: 'EUR',
    totalAmount: '1,200.00',
    paidAmount: '900.00',
    outstandingAmount: '300.00',
    daysOverdue: 5,
    debtStatus: 'Partially paid',
    reminderStage: 'Final',
    lastReminderDate: '16.11.2026',
    paymentPriority: 'Low',
    department: 'Project A',
    notes: '—',
  },
  { id: 'debt-3', counterpartyCode: '123456', counterpartyName: 'UAB Alfa', counterpartyType: 'Buyer',
    documentReference: 'INV-1026', documentType: 'Sales invoice', issueDate: '10.11.2026', dueDate: '30.11.2026', currency: 'EUR',
    totalAmount: '450.50', paidAmount: '0.00', outstandingAmount: '450.50', daysOverdue: 0, debtStatus: 'Unpaid',
    reminderStage: '—', lastReminderDate: '—', paymentPriority: 'Normal', department: 'Project A', notes: '—' },
  { id: 'debt-4', counterpartyCode: '305600002', counterpartyName: 'Baltic Services, UAB', counterpartyType: 'Supplier',
    documentReference: 'PUR-2042', documentType: 'Purchase invoice', issueDate: '12.11.2026', dueDate: '30.11.2026', currency: 'EUR',
    totalAmount: '125.25', paidAmount: '0.00', outstandingAmount: '125.25', daysOverdue: 0, debtStatus: 'Unpaid',
    reminderStage: '—', lastReminderDate: '—', paymentPriority: 'Normal', department: 'Project B', notes: '—' },
  { id: 'debt-5', counterpartyCode: '305600003', counterpartyName: 'Amber Trade, UAB', counterpartyType: 'Buyer',
    documentReference: 'INV-1027', documentType: 'Sales invoice', issueDate: '01.11.2026', dueDate: '10.11.2026', currency: 'USD',
    totalAmount: '800.00', paidAmount: '200.00', outstandingAmount: '600.00', daysOverdue: 8, debtStatus: 'Partially paid',
    reminderStage: 'First', lastReminderDate: '12.11.2026', paymentPriority: 'Normal', department: 'Project B', notes: '—' },
  { id: 'debt-6', counterpartyCode: '305600004', counterpartyName: 'Northwind, UAB', counterpartyType: 'Supplier',
    documentReference: 'PUR-2043', documentType: 'Purchase invoice', issueDate: '02.11.2026', dueDate: '12.11.2026', currency: 'USD',
    totalAmount: '240.00', paidAmount: '0.00', outstandingAmount: '240.00', daysOverdue: 6, debtStatus: 'Unpaid',
    reminderStage: '—', lastReminderDate: '—', paymentPriority: 'High', department: 'Project C', notes: '—' },
];

export type ClientRow = {
  id: string;
  registrationNumber: string;
  companyCode: string;
  vatCode: string;
  name: string;
  email: string;
};

export function seedClients(company: Pick<Company, 'name'>): ClientRow[] {
  if (company.name.toLocaleLowerCase() === "alice stone") {
    return [
      {
        id: "alice-client-001",
        registrationNumber: "305499987",
        companyCode: "305499987",
        vatCode: "—",
        name: "Nord 1, UAB",
        email: "—",
      },
      {
        id: "alice-client-002",
        registrationNumber: "305499987",
        companyCode: "305499987",
        vatCode: "—",
        name: "Nord 1, UAB",
        email: "—",
      },
    ];
  }
  return [];
}

