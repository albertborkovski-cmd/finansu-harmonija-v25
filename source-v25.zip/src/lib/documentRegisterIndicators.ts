import type { DocumentTestDelivery } from './documentTestDelivery';

type Source = Record<string, unknown>;
const text = (value: unknown) => String(value ?? '').trim();

/** Only saved delivery responses are evidence of a failed transfer. */
export function documentDeliveryWarning(document: Source) {
  const receipts = Array.isArray(document.accounting_test_deliveries)
    ? document.accounting_test_deliveries as DocumentTestDelivery[] : [];
  const latest = receipts.reduce<DocumentTestDelivery | undefined>((result, receipt) =>
    !result || receipt.at >= result.at ? receipt : result, undefined);
  if (!latest || latest.outcome === 'Accepted') return null;
  const message = text(latest.message);
  return {
    reason: message || 'The accounting system did not accept this document.',
    destination: latest.destinationName,
    // A local FH cutoff alone is not proof of a locked external ERP period.
    periodLocked: /(?:period.{0,30}(?:lock|clos|unavailable)|(?:lock|clos).{0,30}period|laikotarp.{0,30}(?:užrak|uzrak|uždar|uzdar|neprieinam))/i.test(message),
  };
}

/** Compare against the whole accessible register, not only the current page/filter. */
export function duplicateDocumentIds(documents: readonly Source[]): Set<string> {
  const index = new Map<string, Set<string>>();
  for (const document of documents) {
    const number = text(document.number).toLocaleUpperCase();
    if (!number || document.document_deletion) continue;
    const key = `${text(document.company_id)}\u0000${number}`;
    const ids = index.get(key) ?? new Set<string>();
    ids.add(text(document.id));
    index.set(key, ids);
  }
  return new Set([...index.values()].filter(ids => ids.size > 1).flatMap(ids => [...ids]));
}

function dateParts(value: unknown): [number, number, number] | null {
  const input = text(value);
  const iso = input.match(/^(\d{4})-(\d{2})-(\d{2})(?:T.*)?$/);
  const local = input.match(/^(\d{1,2})[./](\d{1,2})[./](\d{4})$/);
  const parts: [number, number, number] | null = iso ? [+iso[1], +iso[2], +iso[3]] : local ? [+local[3], +local[2], +local[1]] : null;
  if (!parts) return null;
  const date = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2]));
  return date.getUTCFullYear() === parts[0] && date.getUTCMonth() + 1 === parts[1] && date.getUTCDate() === parts[2] ? parts : null;
}

/** A month's invoices are late after the configured day of the following month.
 * Receipt dates are evaluated historically; current-month invoices are never late.
 */
export function lateDocumentSubmission(document: Source, policy: { enabled: boolean; cutoffDay: number }) {
  if (!policy.enabled || !Number.isInteger(policy.cutoffDay) || policy.cutoffDay < 1 || policy.cutoffDay > 31) return null;
  const invoice = dateParts(document.document_date);
  const received = dateParts(document.receive_date) ?? dateParts(document.created_at);
  if (!invoice || !received) return null;
  if (received[0] * 12 + received[1] <= invoice[0] * 12 + invoice[1]) return null;
  const lastDay = new Date(Date.UTC(invoice[0], invoice[1] + 1, 0)).getUTCDate();
  const deadline = new Date(Date.UTC(invoice[0], invoice[1], Math.min(policy.cutoffDay, lastDay)));
  if (Date.UTC(received[0], received[1] - 1, received[2]) <= deadline.getTime()) return null;
  return { deadline: deadline.toISOString().slice(0, 10) };
}

export function documentQuantityLineCount(document: Source): number {
  return Array.isArray(document.line_items) ? document.line_items.filter(row => row && typeof row === 'object').length : 0;
}

export function documentDirection(document: Source): 'Sale' | 'Purchase' | null {
  const purpose = text(document.document_purpose).toLocaleLowerCase();
  if (['sale', 'sales', 'pardavimas'].includes(purpose)) return 'Sale';
  if (['purchase', 'purchases', 'pirkimas'].includes(purpose)) return 'Purchase';
  const type = text(document.type).toLocaleLowerCase();
  if (['sale', 'sales', 'income', 'pardavimas'].includes(type)) return 'Sale';
  if (['purchase', 'purchases', 'expense', 'pirkimas'].includes(type)) return 'Purchase';
  return null;
}

export function documentAmountCents(value: unknown): number | null {
  let raw = text(value).replace(/[^\d.,+−-]/g, '').replace('−', '-');
  if (!raw) return null;
  if (raw.includes('.') && raw.includes(',')) raw = raw.lastIndexOf('.') > raw.lastIndexOf(',') ? raw.replaceAll(',', '') : raw.replaceAll('.', '').replace(',', '.');
  else raw = raw.replace(',', '.');
  if (!/^[+-]?\d+(?:\.\d+)?$/.test(raw)) return null;
  const cents = Math.round(Number(raw) * 100);
  return Number.isSafeInteger(cents) ? cents : null;
}

/** Original OCR facts only: no FH reversal adjustments or currency mixing. */
export function documentRegisterTotals(documents: readonly Source[]) {
  const groups = new Map<string, { direction: 'Sale' | 'Purchase'; currency: string; count: number; total: number; net: number }>();
  for (const document of documents) {
    if (document.document_deletion) continue;
    const direction = documentDirection(document);
    const total = documentAmountCents(document.total_amount), net = documentAmountCents(document.amount_without_vat);
    if (!direction || total === null || net === null) continue;
    const currency = text(document.currency).toUpperCase() || '—';
    const key = `${direction}:${currency}`;
    const group = groups.get(key) ?? { direction, currency, count: 0, total: 0, net: 0 };
    group.count++; group.total += total; group.net += net;
    groups.set(key, group);
  }
  return [...groups.values()].sort((a, b) => (a.direction === b.direction ? a.currency.localeCompare(b.currency) : a.direction === 'Sale' ? -1 : 1));
}

export function singleOrganizationSelection(selection: string[] | null): string[] | null {
  return selection?.length === 1 ? selection : null;
}
