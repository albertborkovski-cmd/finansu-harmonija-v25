/** Company-scoped cash workspace. All amounts are stored as integer minor units. */
export const CASH_SECTIONS = [
  { id: 'transactions', label: 'Cash transactions' },
  { id: 'receipts', label: 'Money receipts' },
  { id: 'book', label: 'Cash book' },
  { id: 'accounts', label: 'Cash accounts' },
  { id: 'people', label: 'Responsible persons' },
  { id: 'series', label: 'Series & numbering' },
] as const;
export type CashSection = typeof CASH_SECTIONS[number]['id'];
export type CashKind = 'Cash income order' | 'Cash expense order' | 'Money receipt';
export const CASH_KINDS: CashKind[] = ['Cash income order', 'Cash expense order', 'Money receipt'];
export type CashBase = { id: string; companyId: string; revision: number; inactive: boolean };
export type CashAccount = CashBase & { code: string; name: string; glAccount: string; currency: string };
export type CashPerson = CashBase & { accountId: string; userId: string; name: string; role: 'Cashier' | 'Accountant'; validFrom: string; validTo: string };
export type CashSeries = CashBase & { prefix: string; kind: CashKind; nextNumber: number; digits: number };
export type CashLine = { id: string; account: string; amountMinor: number; description: string; relatedDocumentId: string; relatedDocumentNumber: string };
export type CashDocument = CashBase & {
  exampleKey?: string;
  kind: CashKind; number: string; seriesId: string; accountId: string; date: string;
  counterparty: string; purpose: string; notes: string; status: 'Draft' | 'Approved';
  currency: string; cashGlAccount: string; cashier: string; accountant: string;
  lines: CashLine[]; receiptId: string; createdAt: string; createdBy: string; approvedAt: string; approvedBy: string;
};
export type CashAudit = { id: string; recordId: string; action: string; at: string; actor: string; detail: string };
export type CashStore = { version: 1; companyId: string; revision: number; examplesVersion?: number; accounts: CashAccount[]; people: CashPerson[]; series: CashSeries[]; documents: CashDocument[]; audit: CashAudit[] };
export type CashMasterCollection = 'accounts' | 'people' | 'series';
export type CashMaster = CashAccount | CashPerson | CashSeries;
export type CashValidation = { activeGlAccounts: string[]; activeUserIds: string[]; currencies: string[]; relatedDocuments?: { id: string; number: string; currency: string }[]; periodError?: (date: string) => string | null };
export const cashId = () => crypto.randomUUID();
export const cashToday = () => { const date = new Date(); return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`; };
export const cashAmount = (minor: number) => (minor / 100).toFixed(2);
export const emptyCash = (companyId: string): CashStore => ({ version: 1, companyId, revision: 0, accounts: [], people: [], series: [], documents: [], audit: [] });
export function cashMinor(value: string): number {
  const normalized = value.trim().replace(',', '.');
  if (!/^\d+(\.\d{1,2})?$/.test(normalized)) throw new Error('Enter a positive amount with no more than two decimal places.');
  const [whole, decimals = ''] = normalized.split('.');
  const result = Number(whole) * 100 + Number(decimals.padEnd(2, '0'));
  if (!Number.isSafeInteger(result) || result <= 0) throw new Error('The amount must be greater than zero and within the supported range.');
  return result;
}
export function validCashDate(date: string): boolean {
  return /^\d{4}-\d{2}-\d{2}$/.test(date) && !Number.isNaN(Date.parse(`${date}T12:00:00Z`)) && new Date(`${date}T12:00:00Z`).toISOString().slice(0, 10) === date;
}
export function cashTotal(document: CashDocument): number {
  const result = document.lines.reduce((sum, line) => sum + line.amountMinor, 0);
  if (!Number.isSafeInteger(result)) throw new Error('The document total is outside the supported range.');
  return result;
}
export function blankCashDocument(store: CashStore, kind: CashKind, actor: string, date = cashToday()): CashDocument {
  return { id: cashId(), companyId: store.companyId, revision: 0, inactive: false, kind, number: '', seriesId: store.series.find(row => !row.inactive && row.kind === kind)?.id || '', accountId: store.accounts.find(row => !row.inactive)?.id || '', date, counterparty: '', purpose: '', notes: '', status: 'Draft', currency: '', cashGlAccount: '', cashier: '', accountant: '', lines: [{ id: cashId(), account: '', amountMinor: 0, description: '', relatedDocumentId: '', relatedDocumentNumber: '' }], receiptId: '', createdAt: '', createdBy: actor, approvedAt: '', approvedBy: '' };
}
function recordAudit(store: CashStore, recordId: string, action: string, actor: string, detail = '', at = new Date().toISOString()) {
  store.audit.push({ id: cashId(), recordId, action, actor, detail, at });
  store.revision += 1;
  return store;
}
function assertScope(store: CashStore, record: CashBase) {
  if (!record.id || record.companyId !== store.companyId) throw new Error('This record belongs to a different company.');
}
function requireCurrent(current: CashBase | undefined, draft: CashBase) {
  if ((current?.revision || 0) !== draft.revision) throw new Error('This record changed in another window. Close and reopen it before saving.');
  if (current?.inactive) throw new Error('Inactive records cannot be changed.');
}
export function cashMasterLinked(store: CashStore, collection: CashMasterCollection, id: string): boolean {
  if (collection === 'accounts') return store.documents.some(row => row.accountId === id) || store.people.some(row => row.accountId === id);
  if (collection === 'series') return store.documents.some(row => row.seriesId === id);
  const person = store.people.find(row => row.id === id);
  return !!person && store.documents.some(row => row.status === 'Approved' && row.accountId === person.accountId && (row.cashier === person.name || row.accountant === person.name));
}
export function cashDocumentLinked(store: CashStore, id: string): boolean {
  return store.documents.some(row => row.id === id && row.status === 'Approved' || row.receiptId === id);
}
export function saveCashMaster(store: CashStore, collection: CashMasterCollection, draft: CashMaster, actor: string, validation: CashValidation): CashStore {
  assertScope(store, draft);
  const current = store[collection].find(row => row.id === draft.id);
  requireCurrent(current, draft);
  const copy = structuredClone(draft);
  if (collection === 'accounts') {
    const row = copy as CashAccount;
    row.code = row.code.trim(); row.name = row.name.trim();
    if (!row.code || !row.name) throw new Error('Enter a cash account code and name.');
    if (!validation.activeGlAccounts.includes(row.glAccount)) throw new Error('Select an active GL account from this company’s chart of accounts.');
    if (!validation.currencies.includes(row.currency)) throw new Error('Select an available currency.');
    if (store.accounts.some(item => item.id !== row.id && item.code.toLowerCase() === row.code.toLowerCase())) throw new Error('This cash account code is already used.');
    if (current && cashMasterLinked(store, collection, row.id) && ((current as CashAccount).glAccount !== row.glAccount || (current as CashAccount).currency !== row.currency)) throw new Error('The GL account and currency of a used cash account cannot be changed. Create a separate cash account.');
  } else if (collection === 'series') {
    const row = copy as CashSeries;
    row.prefix = row.prefix.trim().toUpperCase();
    if (!/^[A-Z0-9-]{1,16}$/.test(row.prefix) || !CASH_KINDS.includes(row.kind)) throw new Error('Enter a series prefix (letters, numbers or hyphens) and choose an operation type.');
    if (!Number.isSafeInteger(row.nextNumber) || row.nextNumber < 1 || !Number.isInteger(row.digits) || row.digits < 1 || row.digits > 10) throw new Error('The next number must be a positive integer; number length must be 1–10.');
    if (store.series.some(item => item.id !== row.id && item.prefix === row.prefix)) throw new Error('This series prefix is already used.');
    if (current && cashMasterLinked(store, collection, row.id) && ((current as CashSeries).prefix !== row.prefix || (current as CashSeries).kind !== row.kind || row.nextNumber < (current as CashSeries).nextNumber)) throw new Error('A used series cannot be renamed, reassigned or numbered backwards.');
  } else {
    const row = copy as CashPerson;
    if (!store.accounts.some(item => item.id === row.accountId && !item.inactive)) throw new Error('Choose an active cash account.');
    if (!validation.activeUserIds.includes(row.userId) || !row.name.trim() || !['Cashier', 'Accountant'].includes(row.role)) throw new Error('Select an active internal user and a responsibility.');
    if (!validCashDate(row.validFrom) || row.validTo && (!validCashDate(row.validTo) || row.validTo < row.validFrom)) throw new Error('Enter a valid responsibility period.');
    if (store.people.some(item => item.id !== row.id && !item.inactive && item.accountId === row.accountId && item.role === row.role && item.validFrom <= (row.validTo || '9999-12-31') && (item.validTo || '9999-12-31') >= row.validFrom)) throw new Error('This responsibility already has an assigned person during that period.');
  }
  copy.revision = (current?.revision || 0) + 1; copy.inactive = current?.inactive || false;
  const next = structuredClone(store);
  (next[collection] as CashMaster[]) = [...next[collection].filter(row => row.id !== copy.id), copy];
  return recordAudit(next, copy.id, current ? 'Settings updated' : 'Settings created', actor);
}
export function saveCashDocument(store: CashStore, draft: CashDocument, approve: boolean, actor: string, validation: CashValidation, at = new Date().toISOString()): CashStore {
  assertScope(store, draft);
  const current = store.documents.find(row => row.id === draft.id);
  requireCurrent(current, draft);
  if (current?.status === 'Approved') throw new Error('Approved cash documents are read-only. Their original accounting entries are retained.');
  if (!CASH_KINDS.includes(draft.kind) || !validCashDate(draft.date)) throw new Error('Select an operation type and a valid date.');
  const periodError = validation.periodError?.(draft.date);
  if (periodError) throw new Error(periodError);
  const account = store.accounts.find(row => row.id === draft.accountId && !row.inactive);
  const series = store.series.find(row => row.id === draft.seriesId && !row.inactive && row.kind === draft.kind);
  if (!account || !series) throw new Error('Choose an active cash account and the matching document series.');
  if (!validation.activeGlAccounts.includes(account.glAccount)) throw new Error('The cash account’s GL account is unavailable in this company.');
  if (!draft.counterparty.trim() || !draft.purpose.trim()) throw new Error('Enter the counterparty and purpose of payment.');
  if (!draft.lines.length || new Set(draft.lines.map(row => row.id)).size !== draft.lines.length) throw new Error('Add at least one unique accounting line.');
  draft.lines.forEach((line, index) => {
    if (!line.id || !Number.isSafeInteger(line.amountMinor) || line.amountMinor <= 0) throw new Error(`Enter a positive amount on line ${index + 1}.`);
    if (!validation.activeGlAccounts.includes(line.account) || line.account === account.glAccount) throw new Error(`Choose a different, active correspondence GL account on line ${index + 1}.`);
    if (line.relatedDocumentId && validation.relatedDocuments && !validation.relatedDocuments.some(row => row.id === line.relatedDocumentId && row.number === line.relatedDocumentNumber && (!row.currency || row.currency === account.currency))) throw new Error(`The related document on line ${index + 1} is unavailable for this company or currency.`);
  });
  cashTotal(draft);
  const responsible = (role: CashPerson['role']) => store.people.find(row => !row.inactive && row.accountId === account.id && row.role === role && row.validFrom <= draft.date && (!row.validTo || row.validTo >= draft.date) && validation.activeUserIds.includes(row.userId));
  const cashier = responsible('Cashier'), accountant = responsible('Accountant');
  if (approve && (!cashier || !accountant)) throw new Error('Assign a cashier and accountant for this cash account and date under Responsible persons.');
  if (draft.receiptId) {
    const receipt = store.documents.find(row => row.id === draft.receiptId && row.kind === 'Money receipt' && row.status === 'Approved' && !row.inactive);
    if (!receipt || draft.kind !== 'Cash income order' || receipt.accountId !== account.id || cashTotal(receipt) !== cashTotal(draft)) throw new Error('The linked receipt and cash income order must have the same cash account and total.');
    if (store.documents.some(row => row.id !== draft.id && row.receiptId === draft.receiptId)) throw new Error('An income order already exists for this receipt.');
  }
  const next = structuredClone(store);
  const storedSeries = next.series.find(row => row.id === series.id)!;
  let number = current?.number || '';
  if (!number) {
    do { number = `${series.prefix}-${String(storedSeries.nextNumber++).padStart(series.digits, '0')}`; }
    while (next.documents.some(row => row.number === number) || next.audit.some(row => row.action === 'Document created' && row.detail === number));
    storedSeries.revision++;
  } else if (current?.seriesId !== draft.seriesId || current.kind !== draft.kind) throw new Error('A numbered document cannot change its series or operation type. Create a new document.');
  const saved: CashDocument = { ...structuredClone(draft), number, revision: (current?.revision || 0) + 1, inactive: false, status: approve ? 'Approved' : 'Draft', currency: account.currency, cashGlAccount: account.glAccount, cashier: cashier?.name || '', accountant: accountant?.name || '', counterparty: draft.counterparty.trim(), purpose: draft.purpose.trim(), createdAt: current?.createdAt || at, createdBy: current?.createdBy || actor, approvedAt: approve ? at : '', approvedBy: approve ? actor : '' };
  next.documents = [...next.documents.filter(row => row.id !== draft.id), saved];
  recordAudit(next, saved.id, current ? 'Draft updated' : 'Document created', actor, number, at);
  if (approve) recordAudit(next, saved.id, 'Document approved', actor, number, at);
  return next;
}
export function removeCashRecord(store: CashStore, collection: CashMasterCollection | 'documents', id: string, actor: string, externallyLinked = false): CashStore {
  const record = store[collection].find(row => row.id === id);
  if (!record || record.inactive) throw new Error('The record is unavailable or already inactive.');
  const linked = externallyLinked || (collection === 'documents' ? cashDocumentLinked(store, id) : cashMasterLinked(store, collection, id));
  const next = structuredClone(store);
  if (linked) {
    const target = next[collection].find(row => row.id === id)!;
    target.inactive = true; target.revision++;
  } else (next[collection] as CashBase[]) = next[collection].filter(row => row.id !== id);
  return recordAudit(next, id, linked ? 'Record deactivated' : 'Record deleted', actor, collection === 'documents' ? (record as CashDocument).number : collection);
}
export function copyCashDocument(store: CashStore, source: CashDocument, actor: string, asIncomeOrder = false): CashDocument {
  assertScope(store, source);
  if (asIncomeOrder && (source.kind !== 'Money receipt' || source.status !== 'Approved' || source.inactive || store.documents.some(row => row.receiptId === source.id))) throw new Error('This receipt cannot be converted to another income order.');
  const fresh = blankCashDocument(store, asIncomeOrder ? 'Cash income order' : source.kind, actor);
  return { ...fresh, accountId: source.accountId, counterparty: source.counterparty, purpose: source.purpose, notes: source.notes, lines: source.lines.map(line => ({ ...line, id: cashId() })), receiptId: asIncomeOrder ? source.id : '' };
}
export function cashBook(store: CashStore, accountId: string, from: string, to: string) {
  if (!store.accounts.some(row => row.id === accountId)) throw new Error('Choose a cash account.');
  if (!validCashDate(from) || !validCashDate(to) || from > to) throw new Error('Choose a valid date range.');
  // Inactive posted records remain accounting history; PPK does not duplicate a KPO movement.
  const documents = store.documents.filter(row => row.accountId === accountId && row.status === 'Approved' && row.kind !== 'Money receipt' && row.date <= to).sort((a, b) => a.date.localeCompare(b.date) || a.number.localeCompare(b.number));
  const signed = (row: CashDocument) => cashTotal(row) * (row.kind === 'Cash expense order' ? -1 : 1);
  const opening = documents.filter(row => row.date < from).reduce((sum, row) => sum + signed(row), 0);
  let balance = opening;
  const rows = documents.filter(row => row.date >= from).map(row => { const amount = cashTotal(row); balance += signed(row); return { document: row, income: row.kind === 'Cash income order' ? amount : 0, expense: row.kind === 'Cash expense order' ? amount : 0, balance }; });
  return { opening, closing: balance, income: rows.reduce((sum, row) => sum + row.income, 0), expense: rows.reduce((sum, row) => sum + row.expense, 0), rows };
}
export function cashCorrespondences(document: CashDocument) {
  if (document.kind === 'Money receipt') return [];
  const income = document.kind === 'Cash income order';
  const total = cashTotal(document);
  return [{ account: document.cashGlAccount, debit: income ? total : 0, credit: income ? 0 : total }, ...document.lines.map(line => ({ account: line.account, debit: income ? 0 : line.amountMinor, credit: income ? line.amountMinor : 0 }))];
}
