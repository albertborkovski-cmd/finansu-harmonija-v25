type BankAccountDisplay = { iban?: string; bank?: string };

const ALICE_STONE_ID = '00000000-0000-4000-8000-000000000002';
const EXAMPLE_BANK_ACCOUNTS: Record<string, string> = {
  '10000000-0000-4000-8000-000000000004': 'SEB · •••• 1234',
  '10000000-0000-4000-8000-000000000003': 'Swedbank · •••• 5678',
};

/** Compact presentation only: never replaces the full stored IBAN or creates a bank account. */
export function companyBankAccountLabel(documentId: string, companyId: string, account: BankAccountDisplay) {
  const iban = account.iban?.replace(/\s/g, '').trim();
  if (iban) {
    const bank = account.bank?.trim();
    return `${bank ? `${bank} · ` : ''}•••• ${iban.slice(-4)}`;
  }
  return companyId === ALICE_STONE_ID ? EXAMPLE_BANK_ACCOUNTS[documentId] || '—' : '—';
}
