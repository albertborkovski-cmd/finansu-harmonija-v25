import type { DbDocument } from './supabase';
import type { WorkspaceTask } from '../components/WorkspaceView';
import type { OcrFieldValidationRule } from './ocrFieldValidation';
import { configuredPartyDefaults } from './ocrPartyConfiguration';
import { configuredOcrParties, ocrRulePartyId, ocrSavedPartyId } from './ocrFormSchema';
import { createOcrFormExamples as createBaseExamples } from './ocrFormExamples';

export const OCR_FORM_EXAMPLES_BATCH = 'v25-ocr-document-parties-v1';
const scenarios = [
  ['PURCHASE', 'Purchase invoice (parties test)', 'INVOICE', 'Purchase'],
  ['SALE', 'Sales invoice (parties test)', 'INVOICE', 'Sale'],
  ['INSURANCE', 'Insurance policy (parties test)', 'INSURANCE_POLICY', ''],
  ['EMPLOYMENT', 'Employment contract (parties test)', 'EMPLOYMENT_CONTRACT', ''],
  ['LOAN', 'Loan agreement (parties test)', 'LOAN_AGREEMENT', ''],
  ['WAYBILL', 'Waybill (parties test)', 'WAYBILL', ''],
] as const;
export const OCR_FORM_EXAMPLE_TYPES = [
  { code: 'FH_TEST_FORMS', fullName: 'OCR test documents', parentCode: '' },
  ...scenarios.map(([key, fullName]) => ({ code: `FH_TEST_PARTIES_${key}`, fullName, parentCode: 'FH_TEST_FORMS' })),
].map(item => ({ ...item, country: '', status: 'Active', description: 'Synthetic document-party example. Not for accounting.' }));

export const OCR_FORM_EXAMPLE_CONFIGS: Record<string, OcrFieldValidationRule[]> = Object.fromEntries(scenarios.map(([key, , source, purpose]) => {
  const base: OcrFieldValidationRule[] = [
    { key: 'documentType', label: 'Document type', type: 'OCR', subtype: 'OCR', level: 'red', formVersion: 1, group: 'document', order: 0 },
    { key: 'number', label: 'Document Number', type: 'OCR', subtype: 'OCR', level: 'red', formVersion: 1, group: 'document', order: 10 },
    { key: 'documentDate', label: 'Document date', type: 'OCR', subtype: 'OCR', level: 'red', formVersion: 1, group: 'document', order: 20, inputType: 'date' },
    { key: 'clientCounterparty', label: 'Name', type: 'OCR', subtype: 'OCR', level: 'yellow', formVersion: 1, group: 'parties', partyRole: 'counterparty', order: 10 },
    ...(purpose ? [{ key: 'documentPurpose', label: 'Document purpose', type: 'OCR', subtype: 'OCR', level: 'red' as const, formVersion: 1 as const, group: 'document' as const, order: 30 }] : []),
  ];
  const rules = configuredPartyDefaults(base, [source]);
  if (key === 'LOAN') rules.push(...rules.filter(rule => rule.partyRole === 'Borrower').slice(0, 3).map(rule => ({ ...rule,
    key: rule.key.replace('borrower', 'guarantor'), partyRole: 'Guarantor', partyRoleId: 'guarantor', order: (rule.order || 0) + 1000 })));
  return [`FH_TEST_PARTIES_${key}`, rules];
}));

export function createOcrFormExamples(companyId: string, organization: string, owner: { email: string; fullName: string }, at: string) {
  const base = createBaseExamples(companyId, organization, owner, at), original = base.documents[0], originalTask = base.tasks[original.id];
  const documents: DbDocument[] = [], tasks: Record<string, WorkspaceTask> = {};
  const escape = (text: string) => text.replace(/[&<>"']/g, value => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' })[value]!);
  scenarios.forEach(([key, label, , purpose], index) => {
    const id = `${companyId}:${OCR_FORM_EXAMPLES_BATCH}:${key}`, name = `OCR-PARTIES-${key}-${String(index + 1).padStart(2, '0')}.svg`, subtype = `FH_TEST_PARTIES_${key}`;
    const rules = OCR_FORM_EXAMPLE_CONFIGS[subtype], partyRules = rules.filter(rule => rule.group === 'parties');
    const parties = configuredOcrParties(partyRules, [], id, purpose).map((party, partyIndex) => ({ ...party, values: Object.fromEntries(partyRules
      .filter(rule => ocrRulePartyId(rule) === ocrSavedPartyId(party)).map(rule => {
        const data: Record<string, string> = { clientCounterparty: `FH Test ${party.role}`, counterpartyCode: `TEST-${key}-${partyIndex + 1}`,
          partyVatCode: `TEST-VAT-${partyIndex + 1}`, streetAddress: `Test street ${partyIndex + 1}`, city: 'Test City', zipCode: 'TEST-001',
          partyCountry: 'Lithuania', email: `${party.role.toLowerCase()}@example.test`, phoneNumber: '', partyIban: '' };
        return [rule.key, data[rule.partyDataKey || rule.key] || ''];
      })) }));
    const counterparty = purpose === 'Sale' ? 'FH Test Buyer' : purpose === 'Purchase' ? 'FH Test Seller' : '';
    const lines = [label, `Document number: FH-PARTIES-${index + 1}`, `Document date: ${at.slice(0, 10)}`,
      ...parties.flatMap(party => [party.role, ...partyRules.filter(rule => ocrRulePartyId(rule) === ocrSavedPartyId(party))
        .filter(rule => party.values[rule.key]).map(rule => `  ${rule.label}: ${party.values[rule.key]}`)]),
      'TEST: document number was not extracted. Fill it from this original.', 'Party roles and fields come only from the document type configuration.'];
    const height = Math.max(1050, lines.length * 27 + 190);
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="${height}" viewBox="0 0 800 ${height}"><rect width="800" height="${height}" fill="white"/><rect x="40" y="35" width="720" height="75" rx="8" fill="#EAF4F8"/><text x="55" y="65" font-family="Arial" font-size="22" fill="#10233A">Finansu harmonija</text><text x="55" y="93" font-family="Arial" font-size="13" fill="#7288A3">SYNTHETIC DOCUMENT — NOT FOR PAYMENT OR ACCOUNTING</text>${lines.map((line, row) => `<text x="55" y="${155 + row * 27}" font-family="Arial" font-size="${row === 0 ? 20 : 14}" fill="#10233A">${escape(line)}</text>`).join('')}</svg>`;
    const document: DbDocument = { ...original, id, number: '', file_case: name, document_subtype: subtype,
      document_purpose: purpose, type: purpose, client_counterparty: counterparty, counterparty_code: '', total_amount: '',
      image_url: `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`, ocr_values: {}, ocr_parties: parties, line_items: [],
      notes: 'SYNTHETIC TEST: configurable document parties; document number intentionally not extracted.' };
    const bound = parties.find(party => party.role === (purpose === 'Sale' ? 'Buyer' : 'Seller'));
    const boundValue = (field: string) => bound?.values[`party_${bound.roleId}_${field}`] || '';
    document.counterparty_code = boundValue('counterpartyCode');
    tasks[id] = { ...originalTask, id, name, documentType: subtype, description: label, sourceRunId: OCR_FORM_EXAMPLES_BATCH,
      fields: { ...originalTask.fields, invoiceNumber: '', companyName: counterparty, totalAmount: '', streetAddress: boundValue('streetAddress'), city: boundValue('city'),
        zipCode: boundValue('zipCode'), email: boundValue('email') }, ocrFieldValues: {}, ocrParties: parties, products: [],
      accounting: undefined };
    documents.push(document);
  });
  return { documents, tasks };
}
