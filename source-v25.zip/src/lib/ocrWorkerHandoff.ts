import type { WorkspaceTask } from '../components/WorkspaceView';
import type { DbDocument } from './supabase';
import type { OcrDocumentType } from './ocrApprovalRouting';
import { ocrIssueCorrectionPatch } from './ocrIssueCorrection';
import { requestTeamLeadReview } from './ocrTeamLeadReview';

export const RETURN_DOCUMENT_REASONS = ['Unreadable document', 'Missing information', 'Incomplete document', 'Irrelevant document'] as const;
export const ESCALATION_REASONS = ['Unclear document type', 'Unsupported document type', 'Unresolved validation error', 'Extraction issue', 'Configuration issue', 'Other'] as const;
export type WorkerHandoffAction = 'return' | 'escalate';
export type WorkerHandoffInput = { reason: string; comment: string };
export type WorkerHandoffDecision = WorkerHandoffInput & {
  id: string; action: WorkerHandoffAction; at: string; actor: string; actorEmail: string;
};
export type SavedWorkerHandoff = WorkerHandoffDecision & { draft: WorkspaceTask };

export function validateWorkerHandoff(action: WorkerHandoffAction, input: WorkerHandoffInput): WorkerHandoffInput {
  const reasons: readonly string[] = action === 'return' ? RETURN_DOCUMENT_REASONS : action === 'escalate' ? ESCALATION_REASONS : [];
  if (!reasons.includes(input.reason)) throw new Error('Select a reason.');
  const comment = input.comment.trim();
  if (input.reason === 'Other' && !comment) throw new Error('A comment is required when Other is selected.');
  if (comment.length > 5000) throw new Error('The comment must not exceed 5,000 characters.');
  return { reason: input.reason, comment };
}

export function prepareWorkerHandoff(task: WorkspaceTask, action: WorkerHandoffAction, input: WorkerHandoffInput,
  actor: { fullName: string; email: string }, at = new Date().toISOString()): WorkspaceTask {
  const values = validateWorkerHandoff(action, input);
  if (!actor.email.trim()) throw new Error('Sign in before changing the document workflow.');
  const decision: WorkerHandoffDecision = { ...values, id: crypto.randomUUID(), action, at, actor: actor.fullName, actorEmail: actor.email };
  const next = action === 'escalate'
    ? requestTeamLeadReview(task, values.comment, actor, at, values.reason)
    : { ...task, status: 'In Progress' as const, trainingStatus: undefined, trainingConfirmedAt: undefined, teamLeadReview: undefined };
  return { ...next, workerHandoff: decision, savedAt: at, ocrRunRequest: undefined };
}

/** One canonical record retains corrections, the decision, its actor and a recoverable editor draft. */
export function applyWorkerHandoff(document: DbDocument, task: WorkspaceTask, catalog: readonly OcrDocumentType[]): DbDocument {
  const decision = task.workerHandoff;
  if (!decision) throw new Error('Select a reason.');
  validateWorkerHandoff(decision.action, decision);
  if (document.ocr_worker_handoff?.id === decision.id) return document;
  if (document.status.trim().toLowerCase() !== 'worker review' || document.accounting_posting || document.entry_method === 'manual'
    || document.document_deletion || document.digitization_issues?.some(issue => ['Open', 'In progress'].includes(issue.status)))
    throw new Error('This document is no longer in the worker review queue.');
  const patch = ocrIssueCorrectionPatch(task, document, catalog);
  const route = decision.action === 'escalate'
    ? { destination: 'TeamLead' as const, completedAt: decision.at, completedBy: decision.actor } : undefined;
  return { ...document, ...patch, status: decision.action === 'return' ? 'Rejected' : 'Escalated',
    ocr_approval_route: route,
    ...(route ? { ocr_approval_history: [...(document.ocr_approval_history || []), route] } : {}),
    ocr_worker_handoff: { ...decision, draft: task },
    ocr_worker_handoff_history: [...(document.ocr_worker_handoff_history || []), decision],
  };
}

export function handoffDraft(document: Pick<DbDocument, 'ocr_worker_handoff' | 'ocr_rerun_request'>, current?: WorkspaceTask): WorkspaceTask | undefined {
  const handoff = document.ocr_worker_handoff;
  if (!handoff || document.ocr_rerun_request?.requestedAt && document.ocr_rerun_request.requestedAt > handoff.at) return current;
  return current?.savedAt && current.savedAt >= handoff.at ? current : handoff.draft;
}

/** Never advance into another worker's assignment; an unassigned row is not an assignment. */
export function belongsToWorker(task: { savedTask?: WorkspaceTask; cells: Record<string, unknown> }, email: string) {
  const assigned = String(task.savedTask?.assignedToEmail || task.cells.assignedToEmail || '').trim().toLowerCase();
  return Boolean(assigned && assigned === email.trim().toLowerCase());
}
