import type { DbDocument } from './supabase';

type Line = NonNullable<DbDocument['summary_line_items']>[number];
type Example = {
  purpose: string; party: string; status: string; side: 'Purchase' | 'Sale'; net: number;
  currency?: string; vat?: number; products?: number; allocations?: number;
  subtype?: string; type?: string; discount?: number; missingGl?: boolean; missingNumber?: boolean; issue?: boolean;
};

const EXAMPLES: Example[] = [
  { purpose: 'Office supplies · one allocation', party: 'Demo Paper Supply UAB', status: 'Draft', side: 'Purchase', net: 18650 },
  { purpose: 'Computer accessories · 12 products, one allocation', party: 'Demo Baltic Technology UAB', status: 'Pending', side: 'Purchase', net: 145899, products: 12 },
  { purpose: 'Office rent · one service, three allocations', party: 'Demo City Property UAB', status: 'Manual', side: 'Purchase', net: 240000, allocations: 3 },
  { purpose: 'Consulting services · sales invoice', party: 'Demo Amber Consulting UAB', status: 'Draft', side: 'Sale', net: 125000, products: 2 },
  { purpose: 'Support subscription · six services, two allocations', party: 'Demo Northwind Services UAB', status: 'Pending', side: 'Sale', net: 89750, products: 6, allocations: 2 },
  { purpose: 'Cloud services · USD invoice', party: 'Demo Atlantic Cloud Ltd', status: 'Correcting', side: 'Purchase', net: 32890, currency: 'USD', vat: 0, products: 3 },
  { purpose: 'Software licence · GBP, two allocations', party: 'Demo London Software Ltd', status: 'Draft', side: 'Purchase', net: 54999, currency: 'GBP', vat: 0, allocations: 2 },
  { purpose: 'Customer refund · negative sales credit', party: 'Demo Amber Consulting UAB', status: 'Draft', side: 'Sale', net: -15000, subtype: 'CREDIT_INVOICE' },
  { purpose: 'Returned goods · negative purchase credit', party: 'Demo Paper Supply UAB', status: 'Manual', side: 'Purchase', net: -7250, subtype: 'CREDIT_INVOICE', products: 2 },
  { purpose: 'Project advance · advance invoice', party: 'Demo Sunrise Projects UAB', status: 'Pending', side: 'Sale', net: 300000, subtype: 'VAT_ADVANCE_INVOICE' },
  { purpose: 'Supplier details require verification · open reported issue', party: 'Demo River Transport UAB', status: 'Provide Additional', side: 'Purchase', net: 62000, issue: true },
  { purpose: 'GL account missing · manual assignment required', party: 'Demo Office Care UAB', status: 'Exception', side: 'Purchase', net: 8900, missingGl: true },
  { purpose: 'International services · zero VAT, USD', party: 'Demo Horizon Partners Ltd', status: 'Draft', side: 'Sale', net: 184575, currency: 'USD', vat: 0, products: 5 },
  { purpose: 'Cash receipt · small amount', party: 'Demo Corner Shop UAB', status: 'Draft', side: 'Purchase', net: 2479, subtype: 'OTHER_INVOICE_DOCUMENT' },
  { purpose: 'Supplier discount · discount correction example', party: 'Demo Warehouse Supply UAB', status: 'Pending', side: 'Purchase', net: 46750, discount: 8250, products: 4 },
  { purpose: 'Accrued service cost · accounting note', party: 'Demo Maintenance UAB', status: 'New', side: 'Purchase', net: 120000, vat: 0, type: 'ACCOUNTING_NOTE' },
  { purpose: 'Annual services · invoice number not recognized', party: 'Demo Studio Partners UAB', status: 'Worker review', side: 'Sale', net: 360000, vat: 0, missingNumber: true },
  { purpose: 'Confirmed purchase · read-only / Storno example', party: 'Demo Baltic Technology UAB', status: 'Approved', side: 'Purchase', net: 78000 },
  { purpose: 'Transferred invoice · read-only state example', party: 'Demo Greenfield Services UAB', status: 'Transferred', side: 'Sale', net: 219900 },
  { purpose: 'OCR processing · editing locked until processing ends', party: 'Demo Quick Logistics UAB', status: 'Processing', side: 'Purchase', net: 39999, products: 3 },
];

const money = (minor: number) => (minor / 100).toFixed(2);
const shares = (minor: number, count: number) => Array.from({ length: count }, (_, i) =>
  Math.round(minor * (i + 1) / count) - Math.round(minor * i / count));
export const documentTestingPrefix = (companyId: string) => `${companyId}:v20-document-testing-v1:`;

/** Explicit synthetic examples, scoped to one company. Stable IDs make seeding
 * repeat-safe; no existing document, posting or integration is ever replaced. */
export function createDocumentTestingExamples(companyId: string, createdAt = '2026-11-03T10:00:00.000Z'): DbDocument[] {
  if (!companyId.trim() || !Number.isFinite(Date.parse(createdAt))) throw new Error('A company and a valid creation time are required.');
  return EXAMPLES.map((example, index) => {
    const sequence = String(index + 1).padStart(3, '0');
    const id = `${documentTestingPrefix(companyId)}${sequence}`;
    const number = `TEST-V20-${sequence}`;
    const day = new Date(createdAt);
    day.setUTCDate(day.getUTCDate() - (19 - index));
    const date = day.toISOString().slice(0, 10);
    const due = new Date(day); due.setUTCDate(due.getUTCDate() + 30);
    const currency = example.currency ?? 'EUR';
    const rate = example.vat ?? 21;
    const vat = Math.round(example.net * rate / 100);
    const total = example.net + vat;
    const expense = example.missingGl ? '' : example.side === 'Purchase' ? '6300' : '5000';
    const createLines = (count: number, mode: 'product' | 'allocation'): Line[] => {
      const netParts = shares(example.net, count), vatParts = shares(vat, count);
      const discounts = shares(mode === 'product' ? example.discount ?? 0 : 0, count);
      return netParts.map((net, i) => ({
        id: `${id}:${mode}:${i + 1}`, systemId: `TEST-${sequence}-${mode}-${i + 1}`,
        barcode: '', product: `${example.purpose.split(' · ')[0]}${count > 1 ? ` — ${mode} ${i + 1}` : ''}`,
        productGroup: 'Services', unit: 'vnt', qty: '1', code: `TEST-ITEM-${sequence}-${i + 1}`,
        price: money(net + discounts[i]), subtotal: money(net), discount: money(discounts[i]),
        vat: money(vatParts[i]), vatPct: `${rate}%`, total: money(net + vatParts[i]),
        department: ['Administration', 'Sales', 'Operations'][i % 3],
        object: `TEST-PROJECT-${String(index % 4 + 1).padStart(2, '0')}`,
        series: 'TEST-V20', center: ['Office', 'Marketing', 'Logistics'][i % 3],
        expense: mode === 'allocation' && count > 1 && i % 2 && !example.missingGl ? (example.side === 'Purchase' ? '6000' : '5000') : expense,
        vatClass: rate ? 'PVM1' : 'PVM5',
      }));
    };
    const allocations = createLines(example.allocations ?? 1, 'allocation');
    const common = (key: keyof Line) => allocations.every(line => line[key] === allocations[0][key]) ? String(allocations[0][key]) : '';
    const document: DbDocument = {
      id, company_id: companyId, number: example.missingNumber ? '' : number, file_case: `${number}.pdf`, receive_date: date,
      client_counterparty: example.party, counterparty_id: '', counterparty_code: `DEMO-CP-${sequence}`,
      document_type: example.type ?? 'INVOICES', document_subtype: example.subtype ?? 'VAT_INVOICE',
      source: ['Manual', 'Email', 'Upload'][index % 3], type: example.side,
      status: example.status, document_date: date, invoice_contract_date: date, operation_date: date,
      due_end_date: due.toISOString().slice(0, 10), order_no: example.issue ? '' : `TEST-ORDER-${sequence}`,
      document_purpose: example.purpose, valid_form: date, currency,
      amount_without_vat: money(example.net), vat: money(vat), total_amount: money(total), vat_percent: `${rate}%`,
      expense_account: common('expense'), vat_classifier: common('vatClass'), department_code: common('department'),
      object_project: common('object'), cost_center: common('center'), series: 'TEST-V20', accountable_responsible: '',
      notes: `Synthetic V20 test document ${sequence}/020. ${example.purpose}. No real invoice or external transmission.${example.discount ? ' Product lines include a fixed-amount discount.' : ''}`,
      created_by: 'V20 test data', created_at: new Date(Date.parse(createdAt) + index).toISOString(), image_url: null,
      line_items: createLines(example.products ?? 1, 'product'), summary_line_items: allocations,
      ...(example.type === 'ACCOUNTING_NOTE' ? { accounting_note_status: 'New', debit: money(example.net), credit: '0.00' } : {}),
    };
    if (example.issue) {
      const message = 'TEST: Please verify the supplier code and document details. Do not approve or transfer until this issue is resolved.';
      document.digitization_issues = [{
        id: `${id}:issue`, message, status: 'Open', organizationId: companyId, documentLabel: number,
        blocksApproval: true, createdAt, createdBy: 'V20 test data',
        events: [{ id: `${id}:issue:reported`, at: createdAt, actor: 'V20 test data', action: 'Reported to MESO Worker', details: message }],
      }];
    }
    if (example.status === 'Approved') {
      document.accounting_posting = {
        id: `${id}:posting`, number: `TEST-GL-${sequence}`, companyId, documentId: id,
        status: 'Posted', date, postedAt: createdAt, postedBy: 'V20 test data', baseCurrency: 'EUR',
        integration: { destination: 'Local', status: 'Not sent' },
        lines: [
          { id: `${id}:debit`, account: '6300', accountName: 'Operating expenses', currency, debitMinor: example.net, creditMinor: 0, baseDebitMinor: example.net, baseCreditMinor: 0 },
          { id: `${id}:vat`, account: '2441', accountName: 'Input VAT', currency, debitMinor: vat, creditMinor: 0, baseDebitMinor: vat, baseCreditMinor: 0 },
          { id: `${id}:credit`, account: '4430', accountName: 'Trade payables', currency, debitMinor: 0, creditMinor: total, baseDebitMinor: 0, baseCreditMinor: total },
        ],
      };
    }
    return document;
  });
}

/** Once a batch exists, never recreate deleted examples or reset edited ones. */
export function missingDocumentTestingExamples(existing: { id?: unknown }[], companyId: string, createdAt?: string) {
  if (existing.some(document => String(document.id ?? '').startsWith(documentTestingPrefix(companyId)))) return [];
  return createDocumentTestingExamples(companyId, createdAt);
}
