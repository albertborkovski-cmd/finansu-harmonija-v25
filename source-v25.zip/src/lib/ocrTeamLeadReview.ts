import type { WorkspaceTask } from '../components/WorkspaceView';
import type { ColConfig } from '../components/ColumnSettingsPanel';

export const TEAM_LEAD_QUEUE_KEY = 'finansu-harmonija:v18:ocr:team-lead-review';
export const WORKER_COMMENT_COLUMN: ColConfig = { key: 'workerComment', label: 'Worker comment', width: 320, visible: true };
export const WORKER_COLUMN: ColConfig = { key: 'worker', label: 'Worker', width: 230, visible: true };

export function teamLeadReviewHistory(tasks: readonly WorkspaceTask[]) {
  const history = new Map<string, NonNullable<WorkspaceTask['teamLeadReview']>>();
  for (const task of tasks) for (const review of [...(task.teamLeadReviewHistory || []), ...(task.teamLeadReview ? [task.teamLeadReview] : [])]) {
    history.set(`${review.requestedAt}:${(review.requestedByEmail || review.requestedBy || '').trim().toLowerCase()}`, review);
  }
  return [...history.values()].sort((a, b) => a.requestedAt.localeCompare(b.requestedAt));
}

export function teamLeadColumns(columns: readonly ColConfig[]): ColConfig[] {
  const saved = columns.find(column => column.key === WORKER_COMMENT_COLUMN.key);
  return [{ ...WORKER_COMMENT_COLUMN, ...saved, label: WORKER_COMMENT_COLUMN.label },
    { ...WORKER_COLUMN, ...columns.find(column => column.key === WORKER_COLUMN.key), label: WORKER_COLUMN.label },
    ...columns.filter(column => ![WORKER_COMMENT_COLUMN.key, WORKER_COLUMN.key].includes(column.key))];
}

export function requestTeamLeadReview(task: WorkspaceTask, comment: string, actor: { fullName: string; email: string }, at = new Date().toISOString(), reason?: string): WorkspaceTask {
  const message = comment.trim();
  if (!message && !reason) throw new Error('Describe what is wrong or what the team lead should check.');
  if (message.length > 5000) throw new Error('The comment must not exceed 5,000 characters.');
  if (!actor.email.trim()) throw new Error('Sign in before sending a document to the team lead.');
  if (task.teamLeadReview?.status === 'Pending') throw new Error('This document is already awaiting team lead review.');
  const review = { status: 'Pending' as const, requestedAt: at, comment: message, reason, requestedBy: actor.fullName, requestedByEmail: actor.email };
  return {
    ...task, status: 'In Progress', trainingStatus: undefined, trainingConfirmedAt: undefined,
    teamLeadReview: review,
    teamLeadReviewHistory: [...teamLeadReviewHistory([task]), review],
    comments: [...task.comments, { id: crypto.randomUUID(), author: actor.fullName, createdAt: at, text: [reason, message].filter(Boolean).join('\n') }],
  };
}

/** Preserve the worker's explanation when the team lead saves or confirms. */
export function updateTeamLeadReview(task: WorkspaceTask): WorkspaceTask {
  if (!task.teamLeadReview) return task;
  return { ...task, teamLeadReview: { ...task.teamLeadReview, status: task.status === 'Completed' ? 'Approved' : task.teamLeadReview.status } };
}

export function saveTeamLeadReviewTask(task: WorkspaceTask, storage: Pick<Storage, 'getItem' | 'setItem'>): void {
  if (!task.teamLeadReview) return;
  let queue: Record<string, WorkspaceTask>;
  try {
    queue = JSON.parse(storage.getItem(TEAM_LEAD_QUEUE_KEY) || '{}');
    if (!queue || typeof queue !== 'object' || Array.isArray(queue)) throw new Error();
  } catch { throw new Error('The team lead queue could not be read. Existing reviews were not overwritten.'); }
  storage.setItem(TEAM_LEAD_QUEUE_KEY, JSON.stringify({ ...queue, [task.id]: updateTeamLeadReview(task) }));
}
