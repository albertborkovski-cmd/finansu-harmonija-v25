import { supabase, type Company, type DbDocument } from './supabase';
import { canEditCompanyDocuments, canViewCompanyDocuments } from './documentEditAccess';
import { canCreateCompanyDocument, documentActionRights } from './documentRowActionAccess';
import { getCurrentUserIdentity } from './currentUser';
import { isInactiveRecord, isRecordLinked } from './recordLifecycle';
import { addCompanyGeneralLedgerAccount, loadCompanyGeneralLedgerAccountHierarchy, loadGeneralLedgerTemplates } from '../components/GeneralLedgerView';
import { loadStornoPeriodPolicy } from './documentStornoAccess';
import { stornoPeriodError } from './documentStorno';
import { rememberReconciliationLedgerUsage } from './generalLedgerUsage';
import { assetMinor, assetStorageKey, assetToday, changeAssetStore, parseAssetStore, type AssetCommand, type AssetStore } from './fixedAssets';
import type { GlJournalRow } from './glJournal';
import { hasBlockingDocumentIssue, isApprovedDocumentStatus } from './documentIssues';
import { ASSET_EXAMPLE_ACCOUNTS, prepareAssetExamples, shouldPrepareAssetExamples } from './fixedAssetExamples';

export const ASSETS_CHANGED = 'finansu-harmonija:fixed-assets-changed';
export function assetPermissions(company: Company) {
  const view = !isInactiveRecord(company) && canViewCompanyDocuments(company), edit = view && canEditCompanyDocuments(company);
  return { view, edit, create: edit && canCreateCompanyDocument(company), delete: edit && documentActionRights(company).delete };
}
export function loadAssets(company: Company) {
  if (!assetPermissions(company).view) throw new Error('You do not have access to fixed assets.');
  return parseAssetStore(localStorage.getItem(assetStorageKey(company.id)), company.id, company.base_currency || 'EUR');
}
export function loadAssetAccounts(company: Company) {
  if (!company.general_ledger || !loadGeneralLedgerTemplates().some(t => t.name === company.general_ledger)) throw new Error('Assign an available chart of accounts in Accounting setup.');
  return loadCompanyGeneralLedgerAccountHierarchy(company.id, company.general_ledger);
}
/** User-requested Alice Stone fixtures, initialized once with fresh permissions. */
export async function initializeAssetExamples(company: Company) {
  if (!assetPermissions(company).create || !shouldPrepareAssetExamples(company, loadAssets(company))) return;
  const response = await supabase.from('companies').select('*').eq('id', company.id);
  const fresh = (response.data as unknown as Company[] | null)?.find(c => c.id === company.id);
  if (response.error || !fresh || !assetPermissions(fresh).create) throw new Error('You do not have permission to change fixed assets.');
  if (fresh.general_ledger !== company.general_ledger || fresh.base_currency !== company.base_currency) throw new Error('Company accounting settings changed. Reopen this page.');
  const current = loadAssets(fresh);
  if (!shouldPrepareAssetExamples(fresh, current)) return;
  const accounts = loadAssetAccounts(fresh), planned = ASSET_EXAMPLE_ACCOUNTS.filter(a => !accounts.some(existing => existing.code === a.code));
  // Import a historical fixture snapshot, not a user posting into a closed period.
  // The normal updateAssets path continues to enforce the company's period locks.
  const today = assetToday();
  const next = prepareAssetExamples(current, { today, by: 'System', at: new Date().toISOString(), id: () => crypto.randomUUID(), accounts: [...accounts, ...planned], periodError: () => '' });
  const serialized = JSON.stringify(next); parseAssetStore(serialized, fresh.id, next.currency);
  const chartKey = `finansu-harmonija:v12:company-general-ledger:${fresh.id}`, previousChart = localStorage.getItem(chartKey);
  if (previousChart) JSON.parse(previousChart);
  let writtenChart: string | null = null;
  try {
    for (const account of planned) {
      if (!addCompanyGeneralLedgerAccount(fresh.id, fresh.general_ledger || '', account)) throw new Error('The asset example accounts could not be prepared. Check the company chart of accounts.');
      writtenChart = localStorage.getItem(chartKey);
    }
    localStorage.setItem(assetStorageKey(fresh.id), serialized);
  } catch (cause) {
    if (writtenChart && localStorage.getItem(chartKey) === writtenChart) {
      if (previousChart === null) localStorage.removeItem(chartKey); else localStorage.setItem(chartKey, previousChart);
      window.dispatchEvent(new CustomEvent('company-general-ledger-updated', { detail: { companyId: fresh.id } }));
    }
    throw cause;
  }
  rememberReconciliationLedgerUsage(next, fresh.id, fresh.general_ledger || '');
  window.dispatchEvent(new CustomEvent(ASSETS_CHANGED, { detail: { companyId: fresh.id } }));
}
/** Creation/edit audit is not an accounting assignment; real references remain protected. */
export function assetHasExternalLinks(record: { id: string }, company: Company, storage: Storage = localStorage) {
  const key = assetStorageKey(company.id);
  const readable = {
    get length() { return storage.length; }, key: (index: number) => storage.key(index),
    getItem: (name: string) => { const raw = storage.getItem(name); return name === key && raw !== null ? JSON.stringify({ ...parseAssetStore(raw, company.id, company.base_currency || 'EUR'), audit: [] }) : raw; },
  } as Storage;
  return isRecordLinked({ ...record, companyId: company.id }, key, readable);
}
export function assetPurchaseDocuments(documents: DbDocument[], company: Company) {
  return documents.filter(d => d.company_id === company.id && !isInactiveRecord(d) && !d.document_deletion &&
    isApprovedDocumentStatus(d.status) && !hasBlockingDocumentIssue(d) &&
    /purchase|pirkim/i.test(d.document_purpose || '') && !/credit|kredit/i.test(d.document_subtype || '') &&
    (d.currency || 'EUR') === (company.base_currency || 'EUR'));
}
/** One company-scoped atomic commit; fresh rights, source documents and revision checks. */
export async function updateAssets(company: Company, revision: number, command: AssetCommand) {
  if (!assetPermissions(company).edit) throw new Error('You do not have permission to change fixed assets.');
  const result = await supabase.from('companies').select('*').eq('id', company.id);
  const fresh = (result.data as unknown as Company[] | null)?.find(c => c.id === company.id);
  if (result.error || !fresh || !assetPermissions(fresh).edit) throw new Error('You do not have permission to change fixed assets.');
  if (fresh.general_ledger !== company.general_ledger || fresh.base_currency !== company.base_currency) throw new Error('Company accounting settings changed. Reopen this page.');
  let documents: DbDocument[] = [];
  if (command.type === 'save-asset' && command.asset.sources.length) {
    const response = await supabase.from('documents').select('*').eq('company_id', company.id);
    if (response.error) throw new Error('Acquisition documents could not be verified.');
    documents = assetPurchaseDocuments((response.data || []) as unknown as DbDocument[], fresh);
  }
  const rights = assetPermissions(fresh), current = loadAssets(fresh);
  if (current.revision !== revision) throw new Error('Asset records changed in another window. Refresh and try again.');
  const creating = command.type === 'post' || command.type === 'depreciate' ||
    (command.type === 'save-asset' && !current.assets.some(a => a.id === command.asset.id)) ||
    (command.type === 'save-group' && !current.groups.some(g => g.id === command.group.id)) ||
    (command.type === 'save-inventory' && !current.inventories.some(i => i.id === command.inventory.id));
  if (!rights.edit || (creating && !rights.create) || (command.type === 'remove' && !rights.delete)) throw new Error('You do not have permission to change fixed assets.');
  if (command.type === 'save-asset') for (const source of command.asset.sources) {
    const document = documents.find(d => d.id === source.id);
    const allocated = current.assets.filter(a => a.id !== command.asset.id).flatMap(a => a.sources).filter(d => d.id === source.id).reduce((n, d) => n + d.amount, 0);
    if (!document || source.amount + allocated > assetMinor(document.amount_without_vat)) throw new Error('The acquisition document is unavailable or its amount is already allocated.');
    if (source.number !== document.number) throw new Error('The acquisition document changed. Select it again.');
  }
  let verifiedCommand = command;
  if (command.type === 'remove') {
    const record = current[command.collection].find(r => r.id === command.id);
    verifiedCommand = { ...command, linked: !!record && assetHasExternalLinks(record, fresh) };
  }
  const user = getCurrentUserIdentity(), today = assetToday(), period = loadStornoPeriodPolicy(company.id);
  const next = changeAssetStore(current, verifiedCommand, { today, by: user.fullName || user.email, at: new Date().toISOString(), id: () => crypto.randomUUID(), accounts: loadAssetAccounts(fresh), periodError: date => stornoPeriodError(date, date, today, period) });
  const serialized = JSON.stringify(next); parseAssetStore(serialized, company.id, next.currency);
  rememberReconciliationLedgerUsage(next, company.id, company.general_ledger || '');
  localStorage.setItem(assetStorageKey(company.id), serialized);
  window.dispatchEvent(new CustomEvent(ASSETS_CHANGED, { detail: { companyId: company.id } }));
  return next;
}
export function fixedAssetJournalRows(s: AssetStore, accounts: ReadonlySet<string>): GlJournalRow[] {
  return s.operations.flatMap(op => op.lines.map((line, index) => ({
    id: `fixed-asset:${s.companyId}:${op.id}:${index}`, assetOperationId: op.id,
    documentNumber: op.number, internalNumber: op.number, operationDate: op.date,
    counterparty: '', account: line.account, description: `${op.assetNumber} · ${op.assetName} · ${op.reason}`,
    documentType: 'Fixed assets', documentSubtype: op.kind, costCenter: '',
    createdBy: op.by, createdAt: op.at, postingStatus: 'Posted', posted: true, balanced: true,
    accountActive: accounts.has(line.account), debit: line.debit / 100, credit: line.credit / 100,
    total: Math.max(line.debit, line.credit) / 100, sample: false,
    baseCurrency: s.currency, baseDebit: line.debit / 100, baseCredit: line.credit / 100,
    document: { id: `fixed-asset:${s.companyId}:${op.id}`, number: op.number, currency: s.currency,
      status: 'Approved', documentType: 'Accounting note', source: 'Fixed assets', documentDate: op.date,
      note: `${op.assetNumber} · ${op.assetName}\n${op.reason}` },
  })));
}
