import { supabase, recordAdministrativeAction, type Company } from './supabase';
import { canEditCompanySettings } from './documentEditAccess';
import { isInactiveRecord, isRecordLinked, removeOrDeactivateRecords } from './recordLifecycle';
import { validateExpenseCodeImport, type ExpenseCodeDraft } from './companyExpenseImport';

export const ADDITIONAL_CODE_SECTIONS = [
  { key: 'departments', label: 'Departments', field: 'department_codes', lookup: 'department_code' },
  { key: 'objects', label: 'Objects', field: 'objects', lookup: 'object_project' },
  { key: 'series', label: 'Series', field: 'document_series', lookup: 'series' },
  { key: 'centers', label: 'Centers', field: 'cost_centers', lookup: 'cost_center' },
  { key: 'persons', label: 'Accountable persons', field: 'accountable_person_codes', lookup: 'accountable_person' },
  { key: 'groups', label: 'Product groups', field: 'product_groups', lookup: 'product_group' },
] as const;
export type AdditionalCodeSection = typeof ADDITIONAL_CODE_SECTIONS[number]['key'];
export type OrganizationCode = { id: string; code: string; name: string; active: boolean; inactive?: boolean };
export type OrganizationCodeConfig = { enabled: boolean; items: OrganizationCode[] };
export function parseOrganizationCodes(raw?: string): OrganizationCodeConfig {
  if (!raw?.trim()) return { enabled: false, items: [] };
  if (!/^[\[{]/.test(raw.trim())) return { enabled: true, items: raw.split(',').map(value => value.trim()).filter(Boolean).map(code => ({ id: `legacy-${code}`, code, name: '', active: true })) };
  const value = JSON.parse(raw);
  if (!value || !Array.isArray(value.items) || value.items.some((item: OrganizationCode) => !item || typeof item.code !== 'string')) throw new Error('Could not read organization codes.');
  return { ...value, enabled: Boolean(value.enabled), items: value.items.map((item: OrganizationCode, index: number) => ({ ...item, id: String(item.id || `stored-${index}`), name: String(item.name || ''), active: !isInactiveRecord(item) })) };
}
export function organizationCodeLinked(companyId: string, row: OrganizationCode) {
  return isRecordLinked({ ...row, company_id: companyId }, 'finansu-harmonija-v4:data:companies');
}
export async function saveOrganizationCodes(companyId: string, section: AdditionalCodeSection, command:
  | { type: 'add'; rows: ExpenseCodeDraft[] }
  | { type: 'edit'; original: OrganizationCode; row: ExpenseCodeDraft }
  | { type: 'remove'; ids: string[] }) {
  const run = async () => {
    const sectionInfo = ADDITIONAL_CODE_SECTIONS.find(item => item.key === section);
    if (!sectionInfo) throw new Error('Unknown code list.');
    const response = await supabase.from('companies').select('*').eq('id', companyId);
    const company = response.data?.[0] as unknown as Company | undefined;
    if (response.error || !company) throw new Error('Could not load organization settings.');
    if (!canEditCompanySettings(company) || isInactiveRecord(company)) throw new Error('You do not have permission to change this organization.');
    const config = parseOrganizationCodes(company[sectionInfo.field]);
    let next = config.items;
    if (command.type === 'add') {
      const values = validateExpenseCodeImport(command.rows, 'Code', next);
      next = [...next, ...values.map(row => ({ id: crypto.randomUUID(), code: row.code, name: row.name, active: true }))];
    } else if (command.type === 'edit') {
      const original = next.find(row => row.id === command.original.id);
      if (!original || JSON.stringify(original) !== JSON.stringify(command.original)) throw new Error('This code has changed. Refresh the list and try again.');
      const [value] = validateExpenseCodeImport([command.row], 'Code', next.filter(row => row.id !== original.id));
      if (value.code !== original.code && organizationCodeLinked(companyId, original)) throw new Error('A used code cannot be renamed. Its name can still be updated.');
      next = next.map(row => row.id === original.id ? { ...row, code: value.code, name: value.name } : row);
    } else {
      next = removeOrDeactivateRecords(next, new Set(command.ids), 'finansu-harmonija-v4:data:companies', row => ({ ...row, active: false, inactive: true }), row => organizationCodeLinked(companyId, row));
    }
    // Write only this dimension. Never change its Required flag or another company's list.
    const patch = { [sectionInfo.field]: JSON.stringify({ ...config, items: next }) };
    const result = await supabase.from('companies').update(patch).eq('id', companyId);
    if (result.error) throw new Error(result.error.message);
    const lookupType = `${sectionInfo.lookup}::company::${companyId}`;
    const rows = new Map(next.map(row => [row.code, { type: lookupType, value: row.code, active: row.active, inactive: !row.active }]));
    config.items.filter(row => !next.some(item => item.code === row.code)).forEach(row => rows.set(row.code, { type: lookupType, value: row.code, active: false, inactive: true }));
    if (rows.size) {
      const synced = await supabase.from('lookup_values').upsert([...rows.values()], { onConflict: 'type,value' });
      if (synced.error) throw new Error(synced.error.message);
    }
    await recordAdministrativeAction(companyId, 'Organization codes', command.type === 'remove' ? 'Codes deleted or deactivated' : 'Codes saved', sectionInfo.label);
    window.dispatchEvent(new Event('organization-reference-updated'));
    return { company: { ...company, ...patch }, rows: next };
  };
  return navigator.locks ? navigator.locks.request(`organization-codes:${companyId}`, run) : run();
}
