import type { OcrFieldValidationLevel } from './ocrFieldValidation';

/** Importance is configuration, not the current validation result or source mapping. */
export const OCR_FIELD_IMPORTANCE: Record<OcrFieldValidationLevel, { label: string; color: string; background: string }> = {
  red: { label: 'Critical field', color: '#B42318', background: '#FEF3F2' },
  yellow: { label: 'Important field', color: '#946200', background: '#FFFAEB' },
  green: { label: 'Optional field', color: '#067647', background: '#ECFDF3' },
};
