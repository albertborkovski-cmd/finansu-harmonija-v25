/** Replace the retired sample-company name, preserving records and identifiers. */
export function neutralDemoNames<T>(value: T): T {
  if (typeof value === 'string') return value.replace(/\b(?:UAB\s+)?Robolabs\b/gi, 'UAB Pavyzdinė įmonė') as T;
  if (Array.isArray(value)) return value.map(neutralDemoNames) as T;
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([key, item]) =>
    [key, ['id', 'documentId', 'companyId', 'company_id'].includes(key) ? item : neutralDemoNames(item)])) as T;
  return value;
}

export function migrateDemoNames(storage: Storage) {
  for (let index = 0; index < storage.length; index++) {
    const key = storage.key(index);
    if (!key?.startsWith('finansu-harmonija:')) continue;
    const raw = storage.getItem(key);
    if (!raw || !/Robolabs/i.test(raw)) continue;
    try {
      const updated = JSON.stringify(neutralDemoNames(JSON.parse(raw)));
      if (updated !== raw) storage.setItem(key, updated);
    } catch { /* Never replace unreadable stored data. */ }
  }
}
