import type { IntegrationArticle } from './integrationHelp';
import type { IntegrationHelpTopic } from './integrationHelpTopics';
import { API_EXPORT_STEPS, CURRENT_INTEGRATION_NOTICE, FILE_EXPORT_STEPS, exportSetupSteps, type HelpText } from './exportHelpGuide';

const resultChecks: HelpText[] = [
  ['Check the company, invoice number and direction, currency, net amount, VAT and total against the original. Verify mandatory codes before exporting; a saved code name is not necessarily the destination identifier.', 'Sutikrinkite įmonę, sąskaitos numerį ir kryptį, valiutą, sumą be PVM, PVM bei bendrą sumą su originalu. Prieš eksportuodami patikrinkite privalomus kodus; išsaugotas pavadinimas nebūtinai yra gavėjo identifikatorius.'],
  ['A download, a manual Exported mark and a confirmed external receipt are different events. In a live integration verify the receiving document and its accounting posting separately.', 'Atsisiuntimas, rankinė Eksportuota žyma ir patvirtintas išorinis gavimas yra skirtingi įvykiai. Tikroje integracijoje gavėjo dokumentą ir jo registravimą apskaitoje tikrinkite atskirai.'],
  ['For an uncertain result, search the receiving company by document number and counterparty before repeating. Retry only failed documents after correcting the stated cause; do not resend successful ones with the batch.', 'Kai rezultatas neaiškus, prieš kartodami gavėjo įmonėje ieškokite pagal dokumento numerį bei kontrahentą. Pašalinę priežastį kartokite tik nepavykusius dokumentus, ne sėkmingą paketo dalį.'],
  ['For support, provide the format, company, document number, time and error text without keys, passwords or confidential attachments. If the invoice was digitized incorrectly, use Report issue and the document conversation.', 'Pagalbai pateikite formatą, įmonę, dokumento numerį, laiką bei klaidos tekstą be raktų, slaptažodžių ar konfidencialių priedų. Jei sąskaita nuskaityta neteisingai, naudokite Pranešti apie klaidą ir dokumento susirašinėjimą.'],
];

export function integrationWorkflowTopics(article: IntegrationArticle): IntegrationHelpTopic[] {
  const accounting = article.group === 'accounting';
  const setupSteps = accounting ? exportSetupSteps(article.id).map(step => step.body) : article.steps || [];
  const screenshot = accounting ? 'export-settings.jpg' : ['google-drive', 'sharepoint'].includes(article.id) ? `${article.id}.jpg` : undefined;
  const setup: IntegrationHelpTopic = {
    id: 'configuration',
    title: accounting ? ['Configuration and every field explained', 'Konfigūravimas ir visų laukų paaiškinimai'] : ['Connection settings and collection workflow', 'Prijungimo nustatymai ir surinkimo eiga'],
    description: article.summary,
    fieldReference: true,
    sections: [
      { title: ['Where to start', 'Nuo ko pradėti'], system: 'FH', paragraphs: [article.setup], steps: setupSteps },
      ...(accounting ? [{ title: ['Directories and additional columns', 'Registrai ir papildomi stulpeliai'] as HelpText, system: 'FH', steps: [
        ['In the organization gear, Counterparties holds company identifiers and accounting codes. Additional columns holds departments, objects, series, centers, accountable persons, product groups and expenses. These lists belong to the selected organization.', 'Organizacijos dantratyje Kontrahentai saugo įmonių identifikatorius ir apskaitos kodus. Papildomi stulpeliai apima padalinius, objektus, serijas, centrus, atskaitingus asmenis, prekių grupes ir išlaidas. Sąrašai priklauso pasirinktai organizacijai.'],
        ['Use New code for one record or Import from Excel to paste code and name separated by TAB. For expense codes choose Code, Service or Product. Review parsed rows before saving; do not import spreadsheet headings as data.', 'Vienam įrašui rinkitės Naujas kodas, keliems – Įkelti iš Excel ir įklijuokite TAB atskirtus kodą bei pavadinimą. Išlaidoms parinkite Kodas, Paslauga arba Prekė. Prieš išsaugodami patikrinkite peržiūrą; antraščių neįkelkite kaip duomenų.'],
        ['Under Additional column settings, Required marks missing values, Default value supplies the configured fallback, and Assign automatically enables that field’s default-assignment rule. Assignment during digitization and during export are separate stages where the selected format supports them.', 'Papildomų stulpelių nustatymuose Privalomas pažymi trūkstamas reikšmes, Numatytoji reikšmė nurodo atsarginę reikšmę, o Priskirti automatiškai įjungia to lauko numatytosios reikšmės priskyrimą. Skaitmeninimo ir eksportavimo etapai yra atskiri, kai pasirinktas formatas juos palaiko.'],
      ] as HelpText[] }] : []),
    ],
    note: accounting ? CURRENT_INTEGRATION_NOTICE : ['Only configuration and frontend previews are available. Live authorization, background collection and API-key issuance are not connected. No production account is contacted by this help page.', 'Veikia konfigūravimas ir frontend peržiūra. Tikra autorizacija, foninis surinkimas bei API rakto išdavimas neprijungti. Šis pagalbos puslapis nesikreipia į produkcinę paskyrą.'],
    ...(screenshot ? { screenshot: { file: screenshot, caption: ['Actual Finansų harmonija settings screen; credentials are not shown.', 'Tikras Finansų harmonijos nustatymų ekranas; prisijungimo duomenys nerodomi.'] as HelpText } } : {}),
  };
  const checks: IntegrationHelpTopic = {
    id: 'workflow-and-checks',
    title: accounting ? ['Transfer, result and troubleshooting', 'Perdavimas, rezultatas ir klaidų tikrinimas'] : ['Result, access and troubleshooting', 'Rezultatas, prieiga ir klaidų tikrinimas'],
    description: article.checks,
    sections: [
      { title: ['Workflow', 'Veiksmų eiga'], system: 'FH', steps: accounting
        ? article.method === 'api' ? API_EXPORT_STEPS : article.method === 'email' ? [
          ['UCS StoreHouse v4 exposes a receiving-email setting in FH. Confirm the receiver and required code mappings with its administrator.', 'FH UCS StoreHouse v4 turi gavėjo el. pašto nustatymą. Su gavėjo administratoriumi patvirtinkite adresą ir reikalingus kodų atitikmenis.'],
          ['The current frontend does not send email attachments to the accounting system. Delivery, attachment parsing and posting must each be verified once a secure backend service is connected.', 'Dabartinis frontend nesiunčia priedų el. paštu į apskaitos sistemą. Prijungus saugią serverio tarnybą, atskirai reikės patikrinti pristatymą, priedo nuskaitymą ir registravimą.'],
        ] : FILE_EXPORT_STEPS
        : article.steps || [] },
      { title: ['Checks specific to this integration', 'Šios integracijos patikrinimai'], system: 'FH', paragraphs: [article.checks] },
      { title: accounting ? ['Verify the result before retrying', 'Patikrinkite rezultatą prieš kartodami'] : ['Document processing in FH', 'Dokumento apdorojimas FH'], system: 'FH', steps: accounting ? resultChecks : [
        ['When an actual collection service is connected, received files appear in All Documents → Uploaded documents. Review the source details to distinguish the sending email or folder from the assigned organization.', 'Prijungus tikrą surinkimo tarnybą, gauti failai patenka į Visi dokumentai → Įkelti dokumentai. Šaltinio detalėse atskirkite siuntėjo el. paštą ar aplanką nuo dokumentui priskirtos organizacijos.'],
        ['Open the status details for rejected, duplicate, unreadable or unidentified documents. Assign the organization where missing. Processing tasks are reviewed in OCR → Workspace → My tasks or TeamLead; after approval they appear in Documents.', 'Atverkite atmestų, pasikartojančių, neįskaitomų arba neatpažintos organizacijos dokumentų būsenos detales. Priskirkite trūkstamą organizaciją. Apdorojimo užduotys tikrinamos OCR → Darbo sritis → Mano užduotys arba Komandos vadovas; patvirtintos patenka į Dokumentai.'],
        ['A source connection problem and a document validation problem are different. Check access to the configured folder / inbox first, then investigate the individual document. Do not upload the same file repeatedly before checking duplicates.', 'Šaltinio ryšio ir dokumento validacijos klaidos yra skirtingos. Pirmiausia patikrinkite prieigą prie nurodyto aplanko ar pašto, tada konkretų dokumentą. Neįkelkite to paties failo pakartotinai nepatikrinę dublikatų.'],
      ] },
    ],
    note: accounting ? CURRENT_INTEGRATION_NOTICE : setup.note,
  };
  return [setup, checks];
}
