import { createOcrHandwritingExamples } from './ocrHandwritingExamples';

export const OCR_RECOGNITION_EXAMPLES_BATCH = 'v25-ocr-pdf-recognition-v1';
export async function createOcrRecognitionExamples(companyId: string, organization: string, owner: { email: string; fullName: string }, at: string) {
  const { PDFDocument, StandardFonts, rgb } = await import('pdf-lib');
  const base = createOcrHandwritingExamples(companyId, organization, owner, at);
  const documents = [], tasks: typeof base.tasks = {};
  for (let index = 0; index < 3; index++) {
    const original = base.documents[index], id = `${companyId}:${OCR_RECOGNITION_EXAMPLES_BATCH}:${index + 1}`;
    const file = `OCR-SPLIT-00${index + 1}.pdf`;
    const pdf = await PDFDocument.create(), font = await pdf.embedFont(StandardFonts.Helvetica);
    for (let page = 1; page <= (index === 2 ? 2 : 4); page++) {
      const sheet = pdf.addPage([595, 842]);
      sheet.drawText('FINANSU HARMONIJA - SYNTHETIC OCR TEST', { x: 40, y: 785, size: 17, font, color: rgb(0.06, 0.14, 0.23) });
      sheet.drawText(`Example ${index + 1} / Document ${index === 2 ? 'A' : page <= 2 ? 'A' : 'B'} / Page ${page}`, { x: 40, y: 735, size: 15, font });
      sheet.drawText('Not a real invoice. Do not use for payment or accounting.', { x: 40, y: 695, size: 11, font });
      sheet.drawText(page % 2 ? 'Invoice page: sample services, quantity 1, amount 100.00 EUR.' : 'Continuation page: additional information for this sample.', { x: 40, y: 620, size: 11, font });
      sheet.drawText(index === 1 ? 'Printed sample.' : 'OCR test flag: partially handwritten document.', { x: 40, y: 580, size: 11, font });
      sheet.drawText(`Source page ${page}`, { x: 40, y: 55, size: 11, font });
    }
    const document = { ...original, id, number: '', file_case: file, image_url: await pdf.saveAsBase64({ dataUri: true }),
      ocr_handwriting: index === 1 ? 'none' as const : 'partial' as const, ocr_multiple_documents: index !== 2,
      created_by: 'V25 synthetic PDF splitting example', created_at: at };
    tasks[id] = { ...base.tasks[original.id], id, name: file, sourceRunId: OCR_RECOGNITION_EXAMPLES_BATCH,
      fields: { ...base.tasks[original.id].fields, invoiceNumber: '' } };
    documents.push(document);
  }
  return { documents, tasks };
}
