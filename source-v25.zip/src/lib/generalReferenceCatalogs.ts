export type GeneralReferenceRecord = {
  code: string;
  fullName: string;
  description: string;
  country: string;
  status: string;
  parentCode: string;
};

const identity = (value: string) => value.trim().normalize('NFKC').toLocaleLowerCase();
const text = (value: string) => value.trim().replace(/\s+/g, ' ');

export function assertGeneralReferenceStorageReadable(key: string) {
  const raw = window.localStorage.getItem(key);
  if (raw === null) return;
  let value: unknown;
  try { value = JSON.parse(raw); } catch { throw new Error('The catalog could not be read. Restore its saved data before making changes.'); }
  if (!Array.isArray(value) || value.some(row => !(typeof row === 'string' && row.trim()) && !(row && typeof row === 'object' && typeof row.code === 'string' && row.code.trim())))
    throw new Error('The catalog contains invalid data. Restore it before making changes.');
}

/** Stable codes identify catalog entries; editing a label must not break existing links. */
export function prepareGeneralReferenceSave(
  records: readonly GeneralReferenceRecord[],
  draft: GeneralReferenceRecord,
  original: GeneralReferenceRecord | null,
): GeneralReferenceRecord[] {
  const next = { ...draft, code: text(draft.code), fullName: text(draft.fullName), description: draft.description.trim(), country: '', parentCode: '' };
  if (!next.code || !next.fullName) throw new Error('Code and Name are required.');
  if ([draft.code, draft.fullName].some(value => [...value].some(char => char.charCodeAt(0) < 32 || char.charCodeAt(0) === 127))) throw new Error('Code and Name cannot contain control characters.');
  if (next.code.length > 80 || next.fullName.length > 80 || next.description.length > 2000) throw new Error('Code and Name can contain up to 80 characters; Description up to 2,000.');
  if (!['Active', 'Inactive'].includes(next.status)) throw new Error('Select Active or Inactive.');
  if (original && next.code !== original.code) throw new Error('The code of an existing record cannot be changed.');
  const index = original ? records.findIndex(record => record.code === original.code) : -1;
  if (original && (index === -1 || JSON.stringify(records[index]) !== JSON.stringify(original))) throw new Error('This record has changed. Refresh and open it again before saving.');
  if (records.some((record, position) => position !== index && identity(record.code) === identity(next.code))) throw new Error('This Code already exists.');
  if (records.some((record, position) => position !== index && identity(record.fullName) === identity(next.fullName))) throw new Error('This Name already exists.');
  return original ? records.map((record, position) => position === index ? next : record) : [...records, next];
}
