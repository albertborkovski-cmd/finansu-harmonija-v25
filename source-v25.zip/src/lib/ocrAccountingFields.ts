import type { OcrFieldValidationRule } from './ocrFieldValidation';
import { EXPORT_FORMAT_SCHEMAS } from './exportFormatSchemas';
import { normalizeOcrFormRule } from './ocrFormSchema';

const ACCOUNTING_COLUMNS: Record<string, string> = {
  departmentCode: 'departmentCode', objectProject: 'objectProject', series: 'series', costCenter: 'costCenter',
  accountablePerson: 'accountableResponsible', productGroup: 'productGroup', glAccount: 'expenseAccount',
  expenseAccount: 'expenseAccount', vatClassifier: 'vatClassifier',
};
const INTERNAL_SUPPLIER_KEYS = new Set(['counterpartyCode', 'supplierCode', 'accountingCode', 'accountingSystemCode', 'supplier_code', 'accounting_system_code']);

/** A document's extracted company/personal code is not its internal accounting reference. */
export function isOcrInternalSupplierField(rule: OcrFieldValidationRule): boolean {
  const key = rule.partyDataKey || rule.key;
  if (key === 'counterpartyCode' && rule.partySchemaVersion === 2 && rule.partyDataKey === key) return false;
  return INTERNAL_SUPPLIER_KEYS.has(key);
}

export function isOcrAccountingField(rule: OcrFieldValidationRule): boolean {
  return rule.group === 'calculated' || Object.prototype.hasOwnProperty.call(ACCOUNTING_COLUMNS, rule.key);
}

/** Use the active integration's existing column schema, never a guessed default format. */
export function ocrEditorRulesForIntegration(rules: readonly OcrFieldValidationRule[], format?: string): OcrFieldValidationRule[] {
  const schema = format && Object.prototype.hasOwnProperty.call(EXPORT_FORMAT_SCHEMAS, format) ? EXPORT_FORMAT_SCHEMAS[format] : undefined;
  const columns = new Set(schema?.columns.flatMap(column => [column.key, ...(column.sourceKey ? [column.sourceKey] : [])]) || []);
  return rules.map(normalizeOcrFormRule).filter(rule => {
    if (isOcrInternalSupplierField(rule)) return false;
    if (!isOcrAccountingField(rule)) return true;
    const column = ACCOUNTING_COLUMNS[rule.key] || rule.key;
    return columns.has(column);
  }).map(rule => isOcrAccountingField(rule) ? { ...rule, group: 'calculated' as const } : rule);
}
