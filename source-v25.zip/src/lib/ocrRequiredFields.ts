import type { DbDocument } from './supabase';
import type { OcrFieldValidationRule } from './ocrFieldValidation';
import type { WorkspaceTask } from '../components/WorkspaceView';
import type { OcrDocumentType } from './ocrApprovalRouting';
import { recognizedOcrDocumentPurpose } from './documentPurposeCatalog';
import { sharedDocumentField } from './documentSharedFields';
import { isOcrAccountingField, isOcrInternalSupplierField } from './ocrAccountingFields';
import { normalizeOcrFormRule, OCR_LINE_DOCUMENT_KEYS, OCR_WORKSPACE_FIELD_KEYS, configuredOcrParties, ocrPartyIsCounterparty } from './ocrFormSchema';

export function isRecognizedOcrDocumentType(document: Pick<DbDocument, 'document_type' | 'document_subtype'>,
  catalog: readonly OcrDocumentType[]): boolean {
  const normalize = (value = '') => value.trim().toLowerCase().replace(/[_-]+/g, ' ');
  const value = normalize(document.document_subtype || document.document_type);
  return Boolean(value) && catalog.some(type => type.status !== 'Inactive'
    && [type.code, type.fullName, ...(type.previousNames || [])].some(label => normalize(label) === value));
}

export function hasOcrValue(value: unknown): boolean {
  return value !== null && value !== undefined && !['', '—', '-'].includes(String(value).trim());
}

export function isRequiredOcrRule(rule: OcrFieldValidationRule): boolean {
  return !isOcrAccountingField(rule) && !isOcrInternalSupplierField(rule)
    && !rule.inactive && rule.enabled !== false && (rule.required === true || rule.level === 'red');
}
export function isRequiredOcrPartyField(rule: OcrFieldValidationRule, purpose?: string): boolean {
  return isRequiredOcrRule(rule) && (rule.partyRequiredScope !== 'counterparty' || ocrPartyIsCounterparty(rule, purpose));
}
export function ocrDocumentPartyPurpose(document?: Partial<DbDocument>): string | undefined {
  return document ? recognizedOcrDocumentPurpose(document)?.code : undefined;
}

/** Additional configured OCR fields use the same mapping in editor and save guard. */
export const OCR_EDITABLE_FIELD_KEYS = {
  documentPurpose: 'document_purpose', operationDate: 'operation_date', amountWithoutVat: 'amount_without_vat',
  vat: 'vat', currency: 'currency', validFrom: 'valid_form', orderNo: 'order_no', departmentCode: 'department_code',
  objectProject: 'object_project', series: 'series', costCenter: 'cost_center', accountablePerson: 'accountable_responsible',
  productGroup: 'product_group', notes: 'notes',
} as const;
export function ocrAdditionalFieldsPatch(values: Record<string, string> = {}): Partial<DbDocument> {
  return Object.fromEntries(Object.entries(OCR_EDITABLE_FIELD_KEYS)
    .filter(([key]) => Object.prototype.hasOwnProperty.call(values, key))
    .map(([key, column]) => [column, values[key]]));
}

export function ocrDocumentFieldValue(document: Partial<DbDocument>, key: string): unknown {
  if (key === 'documentPurpose') return recognizedOcrDocumentPurpose(document)?.code || '';
  if (key === 'productGroup') {
    if (document.summary_line_items?.length) return sharedDocumentField(document, 'product_group');
    if (document.product_group !== undefined) return document.product_group;
    const values = (document.line_items || []).map(line => line.productGroup || '');
    return values.length && values.every(value => value === values[0]) ? values[0] : '';
  }
  const fields: Record<string, unknown> = {
    documentType: document.document_subtype || document.document_type, invoice: hasOcrValue(document.document_type) ? /invoice/i.test(document.document_type || '') : undefined,
    documentDate: document.document_date, operationDate: document.operation_date,
    number: document.number, clientCounterparty: document.client_counterparty, counterpartyCode: document.counterparty_code,
    amountWithoutVat: document.amount_without_vat, vat: document.vat, vatPercent: document.vat_percent, totalAmount: document.total_amount,
    dueEndDate: document.due_end_date, validFrom: document.valid_form, orderNo: document.order_no, departmentCode: document.department_code,
    objectProject: document.object_project, series: document.series, costCenter: document.cost_center, accountablePerson: document.accountable_responsible,
    glAccount: document.expense_account, vatClassifier: document.vat_classifier, currency: document.currency,
    source: document.source, fileCase: document.file_case, status: document.status, receiveDate: document.receive_date,
    invoiceContractDate: document.invoice_contract_date, type: document.type, subtype: document.document_subtype,
  };
  return fields[key] ?? document.ocr_values?.[key] ?? (document as Record<string, unknown>)[key];
}

export function missingOcrRequiredFields(document: Partial<DbDocument>, rules: readonly OcrFieldValidationRule[]): string[] {
  const purpose = ocrDocumentPartyPurpose(document);
  return rules.filter(isRequiredOcrRule).filter(raw => {
    const rule = normalizeOcrFormRule(raw);
    if (rule.group === 'lines') {
      const lines = document.line_items || [];
      const key = OCR_LINE_DOCUMENT_KEYS[rule.key as keyof typeof OCR_LINE_DOCUMENT_KEYS];
      return !lines.length || lines.some(line => !hasOcrValue(key ? line[key] : line.ocr_values?.[rule.key]));
    }
    if (rule.group === 'parties') {
      const key = rule.partyDataKey || rule.key;
      if (rule.partyRequiredScope === 'counterparty') {
        // An unknown direction cannot bypass the old mandatory counterparty guard or
        // assign its saved facts to an invented Seller/Buyer role.
        if (!purpose) return rules.find(item => item.partyRequiredScope === 'counterparty' && (item.partyDataKey || item.key) === key && isRequiredOcrRule(item)) === raw
          && !hasOcrValue(ocrDocumentFieldValue(document, key));
        if (!ocrPartyIsCounterparty(rule, purpose)) return false;
      }
      const parties = configuredOcrParties([rule], document.ocr_parties, document.id, purpose);
      return parties.some((party, index) => !hasOcrValue(party.values[rule.key] ?? party.values[key]
        ?? (index === 0 && ocrPartyIsCounterparty(rule, purpose) ? ocrDocumentFieldValue(document, key) : undefined)));
    }
    return !hasOcrValue(ocrDocumentFieldValue(document, rule.key));
  }).map(rule => rule.label);
}

/** Use exactly the same document-level values for preview and the final guard. */
export function ocrCompletionPatch(task: WorkspaceTask, catalog: readonly OcrDocumentType[] = [], original?: Partial<DbDocument>): Partial<DbDocument> {
  const type = catalog.find(item => [item.code, item.fullName, ...(item.previousNames || [])].some(value => value.toLowerCase() === task.documentType.toLowerCase()));
  const previousSubtype = catalog.find(item => item.code === original?.document_subtype || item.fullName === original?.document_subtype);
  return {
    ocr_values: { ...original?.ocr_values, ...task.ocrFieldValues,
      ...Object.fromEntries(Object.entries(OCR_WORKSPACE_FIELD_KEYS).map(([key, field]) => [key, task.fields[field] ?? ''])) },
    ...(task.ocrParties ? { ocr_parties: task.ocrParties } : {}),
    ...(task.products ? { line_items: task.products.map(product => {
      const previous = original?.line_items?.find(line => line.id === product.id);
      return { barcode: '', unit: '', code: '', subtotal: '', discount: '', vat: '', vatPct: '', total: '',
        department: '', object: '', series: '', center: '', expense: '', vatClass: '', ...previous,
        id: product.id, product: product.name, description: product.description, qty: product.quantity, price: product.price,
        ...(product.ocrValues ? { ocr_values: product.ocrValues } : {}) };
    }) } : {}),
    ...(task.documentStructure ? { ocr_document_structure: task.documentStructure } : {}),
    ...ocrAdditionalFieldsPatch(task.ocrFieldValues),
    ...(type ? { document_type: type.parentCode || type.code,
      ...(type.parentCode ? { document_subtype: type.code } : original && previousSubtype?.parentCode !== type.code ? { document_subtype: '' } : {}) } : {}),
    number: task.fields.invoiceNumber, document_date: task.fields.invoiceDate, due_end_date: task.fields.dueDate,
    total_amount: task.fields.totalAmount, client_counterparty: task.fields.companyName.trim(), vat_percent: task.fields.taxRate,
    ...((task.advanceEmployeeId !== undefined || task.advanceEmployee !== undefined) ? {
      advance_employee_id: task.advanceEmployeeId || '', advance_employee: task.advanceEmployee || '',
      ...((task.advanceEmployeeId || task.advanceEmployee) && (original?.document_purpose === 'Purchase' || (!['Purchase', 'Sale'].includes(original?.document_purpose || '') && original?.type === 'Purchase')) && (type ? (type.parentCode || type.code) === 'INVOICES' : original?.document_type === 'INVOICES') ? { document_subtype: 'ADVANCE_INVOICE' } : {}),
    } : {}),
    ...(task.accounting ? { expense_account: task.accounting.expenseAccount, vat_classifier: task.accounting.vatClassifier } : {}),
    // Only explicitly corrected document requisites can change this extracted code.
    // Never assign the internal supplier reference from an accounting context/draft.
    ...(task.ocrFieldValues?.partyRegistrationCode !== undefined ? { counterparty_code: task.ocrFieldValues.partyRegistrationCode } : {}),
  };
}
