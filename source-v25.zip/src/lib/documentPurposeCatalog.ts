import type { LineTypeCatalogRecord } from './invoiceLineTypes';

/** Document direction has its own catalog. Never replace item/service line types. */
export const DOCUMENT_PURPOSE_CATALOG_KEY = 'finansu-harmonija:organization-reference:Document purpose';
export const DEFAULT_DOCUMENT_PURPOSE_RECORDS: LineTypeCatalogRecord[] = [
  { code: 'Purchase', fullName: 'Purchases', description: '', country: '', status: 'Active', parentCode: '' },
  { code: 'Sale', fullName: 'Sales', description: '', country: '', status: 'Active', parentCode: '' },
];
export function loadDocumentPurposeCatalog(): LineTypeCatalogRecord[] {
  const raw = typeof window === 'undefined' ? null : window.localStorage.getItem(DOCUMENT_PURPOSE_CATALOG_KEY);
  if (raw === null) return DEFAULT_DOCUMENT_PURPOSE_RECORDS.map(row => ({ ...row }));
  try {
    const rows: unknown = JSON.parse(raw);
    if (!Array.isArray(rows)) return [];
    return rows.filter(row => row && typeof row.code === 'string' && row.code.trim()).map(row => ({
      code: row.code.trim(), fullName: String(row.fullName || row.code), description: String(row.description || ''),
      country: '', status: row.status === 'Inactive' ? 'Inactive' : 'Active', parentCode: '',
    }));
  } catch { return []; }
}
export function documentPurposeSelection(document: Record<string, unknown>): string {
  const direction = (value: unknown) => {
    const normalized = String(value ?? '').trim().toLocaleLowerCase();
    if (['sale', 'sales', 'pardavimas', 'pardavimai'].includes(normalized)) return 'Sale';
    if (['purchase', 'purchases', 'pirkimas', 'pirkimai'].includes(normalized)) return 'Purchase';
    return '';
  };
  return direction(document.document_purpose) || direction(document.type) || direction(document.document_purpose_code);
}
export function documentPurposeCatalogOptions() {
  return loadDocumentPurposeCatalog().filter(row => row.status === 'Active')
    .map(row => ({ value: row.code, label: row.fullName || row.code }));
}

/** OCR purpose is a catalog classification, never a description or error message.
 * An empty/unrecognized OCR value stays empty; do not guess from the legacy Type. */
export function recognizedOcrDocumentPurpose(document: { document_purpose?: string }, records = loadDocumentPurposeCatalog()) {
  const normalize = (value: string) => {
    const key = value.trim().toLocaleLowerCase();
    if (['purchase', 'purchases', 'pirkimas', 'pirkimai'].includes(key)) return 'purchase';
    if (['sale', 'sales', 'pardavimas', 'pardavimai'].includes(key)) return 'sale';
    return key;
  };
  const value = normalize(document.document_purpose || '');
  return value ? records.find(record => record.status === 'Active'
    && [record.code, record.fullName].some(label => normalize(label) === value)) : undefined;
}

export function validateDocumentPurposeCode(value: string) {
  if (!documentPurposeCatalogOptions().some(option => option.value === value))
    throw new Error('Select an active document purpose from General settings.');
}

export function globalDocumentColumn<T extends { key: string; label: string; width?: number; visible?: boolean }>(column: T): T {
  if (column.key === 'type') return { ...column, key: 'purposeCode', label: 'Document purpose', ...(column.width === undefined ? {} : { width: 160 }) };
  return column;
}

/** Remove register columns, not their stored document/line data. */
export function globalDocumentColumns<T extends { key: string; label: string; width?: number; visible?: boolean }>(columns: readonly T[]): T[] {
  return columns.filter(column => !['documentPurpose', 'productGroup'].includes(column.key)).map(globalDocumentColumn);
}
