import { createOcrFormExamples as baseExamples, OCR_FORM_EXAMPLE_CONFIGS, OCR_FORM_EXAMPLE_TYPES } from './ocrFormExamples';
export { OCR_FORM_EXAMPLE_CONFIGS, OCR_FORM_EXAMPLE_TYPES };
export const OCR_FORM_EXAMPLES_BATCH = 'v25-ocr-task-tabs-v1';
export function createOcrFormExamples(companyId: string, organization: string, owner: { email: string; fullName: string }, at: string) {
  const base = baseExamples(companyId, organization, owner, at);
  const original = base.documents[0], draft = base.tasks[original.id];
  const documents = ['PENDING', 'IN-PROGRESS', 'COMPLETED'].map((state, index) => {
    const id = `${companyId}:${OCR_FORM_EXAMPLES_BATCH}:${state}`;
    return { ...original, id, file_case: `OCR-TABS-${state}.svg`,
      status: state === 'COMPLETED' ? 'Processed' : 'Worker review',
      ocr_values: { ...original.ocr_values, ...(state === 'COMPLETED' ? { policyStart: at.slice(0, 10) } : {}) },
      number: `FH-TABS-${index + 1}`, notes: 'SYNTHETIC TASK STATUS TEST. Not for accounting.' };
  });
  const tasks = Object.fromEntries(documents.map((document, index) => [document.id, {
    ...draft, id: document.id, name: document.file_case, sourceRunId: OCR_FORM_EXAMPLES_BATCH,
    fields: { ...draft.fields, invoiceNumber: document.number }, ocrFieldValues: document.ocr_values,
    accounting: { ...draft.accounting!, documentId: document.id, documentName: document.file_case },
    status: index === 2 ? 'Completed' as const : index === 0 ? 'Available' as const : 'In Progress' as const,
    ...(index ? { editStartedAt: at } : {}), ...(index === 2 ? { savedAt: at, trainingStatus: 'Confirmed' as const } : {}),
  }]));
  return { documents, tasks };
}
