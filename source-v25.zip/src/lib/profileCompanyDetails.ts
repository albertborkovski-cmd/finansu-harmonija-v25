/** Shared identity from Profile settings → General & status → Company details. */
export const PROFILE_COMPANY_DETAILS_KEY = 'finansu-harmonija:v16:system-owner';
export const PROFILE_COMPANY_DETAILS_CHANGED = 'finansu-harmonija:profile-company-details-changed';

export function readProfileCompanyName(storage: Pick<Storage, 'getItem'>): string {
  try {
    const name = JSON.parse(storage.getItem(PROFILE_COMPANY_DETAILS_KEY) || 'null')?.fields?.name;
    return typeof name === 'string' ? name.trim() : '';
  } catch {
    return '';
  }
}
