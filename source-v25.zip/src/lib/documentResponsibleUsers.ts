import type { LinkedDirectoryUser } from './linkedSettingsData';

const userName = (user: LinkedDirectoryUser) => (user.fullName || user.username || user.email || user.id).trim();
const activeUser = (user: LinkedDirectoryUser) => ['active', 'enabled'].includes((user.status || 'Enabled').trim().toLowerCase())
  && ![true, 'true'].includes(user.inactive as string | boolean) && ![false, 'false'].includes(user.active as string | boolean);

/** Callers supply the Internal Users directory, never external users or free text. */
export function documentResponsibleOptions(users: LinkedDirectoryUser[]) {
  const active = users.filter(activeUser);
  return [{ value: '', label: '—' }, ...active.map(user => {
    const name = userName(user);
    const duplicate = active.some(other => other.id !== user.id && userName(other) === name);
    return { value: user.id, label: name, description: user.email || (duplicate ? user.id : '') };
  })];
}

export function documentResponsibleSelection(document: Record<string, unknown>, users: LinkedDirectoryUser[]) {
  const id = String(document.accountable_responsible_id || '');
  if (id) return id;
  const name = String(document.accountable_responsible || '');
  const matches = users.filter(user => [userName(user), user.email].includes(name));
  // Do not silently bind an ambiguous historic name to a different person.
  return name && matches.length === 1 ? matches[0].id : name;
}

export function documentResponsiblePatch(userId: string, users: LinkedDirectoryUser[]) {
  if (!userId) return { accountable_responsible: '', accountable_responsible_id: '' };
  const user = users.find(item => item.id === userId && activeUser(item));
  if (!user) throw new Error('Select an active user from Settings → Internal Users → Users.');
  return { accountable_responsible: userName(user), accountable_responsible_id: user.id };
}
