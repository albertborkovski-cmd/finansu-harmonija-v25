import { loadLinkedDirectoryUsers, loadOrganizationUserIds, organizationAssignmentStorageKey } from './linkedSettingsData';
import { assignedAdvanceEmployees } from './invoiceAdvanceEmployee';

export function loadCompanyAdvanceEmployees(company: { id: string; name: string }) {
  const explicit = window.localStorage.getItem(organizationAssignmentStorageKey(company.id, 'External users')) !== null;
  return assignedAdvanceEmployees(company, loadLinkedDirectoryUsers('External users'), explicit ? loadOrganizationUserIds(company.id, 'External users') : null);
}
