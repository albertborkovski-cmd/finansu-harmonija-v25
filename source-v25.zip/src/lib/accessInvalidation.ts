/** UI preferences, scrolling and document edits do not change organization access. */
export function affectsOrganizationAccess(key: string | null): boolean {
  return key === null || key === 'finansu-harmonija-v7:authenticated'
    || key === 'finansu-harmonija-v4:data:companies'
    || key === 'finansu-harmonija:v14:organization-substitutions'
    || key.startsWith('finansu-harmonija:v7:settings:internal:')
    || key.startsWith('finansu-harmonija:v7:settings:external:')
    || key.startsWith('finansu-harmonija:v7:organization-users:')
    || key.startsWith('finansu-harmonija:v14:organization-accountants:');
}

export function affectsDocumentRegister(key: string | null): boolean {
  return key === null || key === 'finansu-harmonija-v4:data:documents'
    || key === 'finansu-harmonija-v4:data:companies';
}
