import type { DbDocument } from './supabase';
import type { DocumentIssue } from './documentIssues';
import type { WorkspaceTask } from '../components/WorkspaceView';
import type { OcrDocumentWorkLog } from '../components/ocrDocumentWorkTimeStore';
import { isInactiveRecord } from './recordLifecycle';
import { ocrDocumentStage, ocrNeedsAttention } from './ocrDocumentWorkflow';

export type MyOcrTask = {
  id: string;
  kind: 'Document review' | 'Document issue';
  document: DbDocument;
  issue?: DocumentIssue;
  savedTask?: WorkspaceTask;
  cells: Record<string, string>;
};

const normalize = (value?: string) => value?.trim().toLowerCase() ?? '';

export type OcrTaskTab = 'Pending' | 'In progress' | 'Completed';
export function ocrTaskTab(task: MyOcrTask): OcrTaskTab {
  if (task.cells.status === 'Completed') return 'Completed';
  return task.savedTask?.editStartedAt || task.cells.workStarted === 'true' ? 'In progress' : 'Pending';
}

export function isWorkerProcessingDocument(document: DbDocument, saved?: WorkspaceTask): boolean {
  const request = document.ocr_rerun_request;
  const newCycle = request && request.status !== 'Completed' && (!saved?.savedAt || saved.savedAt < request.requestedAt);
  const stage = ocrDocumentStage(document, newCycle ? undefined : saved);
  return !isInactiveRecord(document) && stage?.queue === 'processing' && stage.status === 'Worker review' && !ocrNeedsAttention(document);
}

/** The Workspace table shows each accessible document needing worker review once. */
export function assignedOcrDocumentIds(tasks: readonly MyOcrTask[]): ReadonlySet<string> {
  return new Set(tasks.map(task => task.document.id));
}

/** Recheck company access and queue membership before opening a stale row. */
export function requireAssignedOcrTask(tasks: readonly MyOcrTask[], document: { id: string; companyId?: string }): MyOcrTask {
  const matching = tasks.filter(task => task.document.id === document.id
    && (!document.companyId || task.document.company_id === document.companyId));
  const task = matching.find(item => item.issue) ?? matching[0];
  if (!task) throw new Error('This task is completed, moved to another queue or no longer accessible.');
  return task;
}

/** Failed/incomplete OCR results only. Pending OCR and reported issues have their own queues. */
export function myOcrTasks(documents: DbDocument[], companyNames: ReadonlyMap<string, string>, email: string,
  savedTasks: ReadonlyMap<string, WorkspaceTask>, workLog: OcrDocumentWorkLog,
  access: { documents: boolean; issues: boolean }, includeCompleted = false): MyOcrTask[] {
  const identity = normalize(email);
  if (!identity) return [];
  return documents.flatMap(document => {
    const organization = companyNames.get(document.company_id ?? '');
    if (!organization || isInactiveRecord(document)) return [];
    const rows: MyOcrTask[] = [];
    const common = { organization, number: document.number || document.file_case || '—', fileCase: document.file_case || '—' };
    const saved = savedTasks.get(document.id);
    const request = document.ocr_rerun_request;
    const newCycle = request && request.status !== 'Completed' && (!saved?.savedAt || saved.savedAt < request.requestedAt);
    // Reload corrected source data instead of an older completed OCR draft.
    const task = newCycle ? undefined : saved;
    // Explicit assignment wins over the legacy work log, which records actual OCR work.
    const work = workLog[document.id] ?? workLog[`document-set-${document.id}`];
    const owner = task?.assignedToEmail || work?.email;
    const completed = includeCompleted && !newCycle && Boolean(task)
      && (normalize(task?.status) === 'completed' || task?.trainingStatus === 'Confirmed')
      && !ocrDocumentStage(document, task) && !ocrNeedsAttention(document)
      && !['rejected', 'split', 'merged', 'cancelled', 'canceled', 'reversed', 'storno'].includes(normalize(document.status));
    if (access.documents && (isWorkerProcessingDocument(document, saved) || completed)) {
      rows.push({ id: `document:${document.id}`, kind: 'Document review', document, savedTask: task,
        cells: { ...common, kind: 'Document review', description: document.document_purpose || task?.description || '—',
          status: completed ? 'Completed' : 'Processing', workStarted: String(Boolean(work?.seconds && (!request?.requestedAt || work.updatedAt >= request.requestedAt))), assignedToEmail: owner || '', assignedTo: task?.assignedToName || work?.user || owner || '—',
          assignedAt: task?.assignedAt || task?.editStartedAt || '—', updatedAt: task?.lastCorrectedAt || work?.updatedAt || '—' } });
    }
    return rows;
  }).sort((a, b) => b.cells.updatedAt.localeCompare(a.cells.updatedAt));
}
