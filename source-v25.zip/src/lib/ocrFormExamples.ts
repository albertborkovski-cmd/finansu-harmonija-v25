import type { DbDocument } from './supabase';
import type { WorkspaceTask } from '../components/WorkspaceView';
import type { OcrFieldValidationRule } from './ocrFieldValidation';
import { normalizeOcrFormRule, type OcrFormGroup, type OcrDocumentParty } from './ocrFormSchema';

export const OCR_FORM_EXAMPLES_BATCH = 'v25-ocr-configured-form-v1';
const rule = (key: string, label: string, group: OcrFormGroup, order: number, extra: Partial<OcrFieldValidationRule> = {}): OcrFieldValidationRule =>
  normalizeOcrFormRule({ key, label, type: 'OCR', subtype: 'OCR', level: 'yellow', enabled: true, formVersion: 1, group, order, ...extra });
export const OCR_FORM_EXAMPLE_CONFIGS: Record<string, OcrFieldValidationRule[]> = {
  FH_TEST_INSURANCE: [
    rule('documentType', 'Document type', 'document', 0, { level: 'red' }),
    rule('number', 'Document Number', 'document', 10, { level: 'red' }),
    rule('policyStart', 'Insurance start date', 'document', 20, { inputType: 'date', level: 'red' }),
    rule('policyEnd', 'Insurance end date', 'document', 30, { inputType: 'date' }),
    rule('insurerName', 'Insurer name', 'parties', 10, { partyRole: 'Insurer', level: 'red' }),
    rule('insurerCode', 'Insurer code', 'parties', 20, { partyRole: 'Insurer' }),
    rule('policyholderName', 'Policyholder name', 'parties', 30, { partyRole: 'Policyholder', level: 'red' }),
    rule('insuredName', 'Insured person', 'parties', 40, { partyRole: 'Insured person', level: 'red' }),
    rule('premium', 'Insurance premium', 'financial', 10, { inputType: 'number', level: 'red' }),
    rule('currency', 'Currency', 'financial', 20, { level: 'red' }),
    rule('coverage', 'Coverage', 'additional', 10, { inputType: 'select', options: ['Property', 'Liability', 'Travel'] }),
    rule('notes', 'Note', 'additional', 20, { inputType: 'textarea' }),
    rule('costCenter', 'Cost center', 'calculated', 10, { level: 'green' }),
  ],
  FH_TEST_DELIVERY: [
    rule('documentType', 'Document type', 'document', 0, { level: 'red' }),
    rule('number', 'Document Number', 'document', 10, { level: 'red' }),
    rule('documentDate', 'Document date', 'document', 20, { level: 'red' }),
    rule('senderName', 'Sender name', 'parties', 10, { partyRole: 'Sender', level: 'red' }),
    rule('recipientName', 'Recipient name', 'parties', 20, { partyRole: 'Recipient', level: 'red' }),
    rule('lineName', 'Name', 'lines', 10, { level: 'red' }),
    rule('lineQuantity', 'Quantity', 'lines', 20, { level: 'red', inputType: 'number' }),
    rule('packageCode', 'Package code', 'lines', 30, { level: 'red' }),
    rule('deliveryNote', 'Delivery instructions', 'additional', 10, { inputType: 'textarea' }),
  ],
};
export const OCR_FORM_EXAMPLE_TYPES = [
  { code: 'FH_TEST_FORMS', fullName: 'OCR test documents', parentCode: '' },
  { code: 'FH_TEST_INSURANCE', fullName: 'Insurance policy (test)', parentCode: 'FH_TEST_FORMS' },
  { code: 'FH_TEST_DELIVERY', fullName: 'Delivery note (test)', parentCode: 'FH_TEST_FORMS' },
].map(row => ({ ...row, description: 'Synthetic V25 field-grouping example. Not for accounting.', country: '', status: 'Active' }));

export function createOcrFormExamples(companyId: string, organization: string, owner: { email: string; fullName: string }, at: string) {
  const date = at.slice(0, 10), documents: DbDocument[] = [], tasks: Record<string, WorkspaceTask> = {};
  const escape = (text: string) => text.replace(/[&<>"']/g, value => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' })[value]!);
  for (const [index, subtype] of ['FH_TEST_INSURANCE', 'FH_TEST_DELIVERY'].entries()) {
    const insurance = index === 0, id = `${companyId}:${OCR_FORM_EXAMPLES_BATCH}:${index + 1}`;
    const name = insurance ? 'OCR-GROUPS-INSURANCE-01.svg' : 'OCR-GROUPS-DELIVERY-02.svg';
    const parties: OcrDocumentParty[] = insurance ? [
      { id: `${id}:insurer`, role: 'Insurer', values: { insurerName: 'FH Test Insurance Ltd', insurerCode: 'TEST-INS-001' } },
      { id: `${id}:holder`, role: 'Policyholder', values: { policyholderName: organization } },
      { id: `${id}:insured1`, role: 'Insured person', values: { insuredName: 'Test Person One' } },
      { id: `${id}:insured2`, role: 'Insured person', values: { insuredName: 'Test Person Two' } },
    ] : [
      { id: `${id}:sender`, role: 'Sender', values: { senderName: 'FH Test Warehouse' } },
      { id: `${id}:recipient`, role: 'Recipient', values: { recipientName: organization } },
    ];
    const values: Record<string, string> = insurance ? { policyStart: '', policyEnd: `${Number(date.slice(0, 4)) + 1}${date.slice(4)}`, premium: '240.00', currency: 'EUR', coverage: 'Travel', notes: '' }
      : { deliveryNote: 'Deliver to the reception desk.' };
    const lines: NonNullable<DbDocument['line_items']> = insurance ? [] : [{ id: `${id}:line:1`, product: 'Test package', description: '', qty: '3', price: '', barcode: '', unit: 'pcs', code: '',
      subtotal: '', discount: '', vat: '', vatPct: '', total: '', department: '', object: '', series: '', center: '', expense: '', vatClass: '', ocr_values: { packageCode: '' } }];
    const sourceText = insurance ? ['INSURANCE POLICY - TEST', `Policy number: FH-POLICY-001`, `Insurance start date: ${date}`, `Insurer: FH Test Insurance Ltd`,
      `Policyholder: ${organization}`, 'Insured person: Test Person One', 'Insured person: Test Person Two', 'Insurance premium: 240.00 EUR', 'Coverage: Travel',
      'TEST: fill the missing start date, collapse groups, add another insured person.', 'This document has no Line items group.']
      : ['DELIVERY NOTE - TEST', 'Document number: FH-DELIVERY-002', `Document date: ${date}`, 'Sender: FH Test Warehouse', `Recipient: ${organization}`,
        'Goods: Test package | Quantity: 3 pcs | Package code: PKG-003', 'Deliver to the reception desk.', 'TEST: fill Package code in Line items.', 'Financial information and ADDINFO are not configured for this type.'];
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="1050" viewBox="0 0 800 1050"><rect width="800" height="1050" fill="white"/><rect x="45" y="40" width="710" height="80" rx="8" fill="#EAF4F8"/><text x="65" y="76" font-family="Arial" font-size="23" fill="#10233A">Finansu harmonija</text><text x="65" y="103" font-family="Arial" font-size="13" fill="#7288A3">SYNTHETIC DOCUMENT - NOT FOR PAYMENT OR ACCOUNTING</text>${sourceText.map((text, line) => `<text x="55" y="${180 + line * 45}" font-family="Arial" font-size="${line === 0 ? 23 : 15}" fill="#10233A">${escape(text)}</text>`).join('')}</svg>`;
    const document: DbDocument = { id, company_id: companyId, receive_date: date, created_at: at, created_by: 'V25 synthetic grouped fields',
      client_counterparty: insurance ? 'FH Test Insurance Ltd' : 'FH Test Warehouse', counterparty_code: 'TEST-GROUPS', document_type: 'FH_TEST_FORMS', document_subtype: subtype,
      number: insurance ? 'FH-POLICY-001' : 'FH-DELIVERY-002', file_case: name, source: 'Upload', entry_method: 'ocr', status: 'Worker review',
      total_amount: insurance ? '240.00' : '', amount_without_vat: '', vat: '', vat_percent: '', currency: 'EUR', document_date: date, operation_date: date,
      due_end_date: '', document_purpose: 'Purchase', type: 'Purchase', invoice_contract_date: date, valid_form: '', order_no: '',
      expense_account: '', vat_classifier: '', department_code: '', object_project: '', series: '', cost_center: '', accountable_responsible: '',
      image_url: `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`, ocr_values: values, ocr_parties: parties, line_items: lines,
      notes: 'SYNTHETIC TEST: schema-driven field groups, custom roles and fields. No real OCR service was used.' };
    const task: WorkspaceTask = { id, name, documentType: subtype, status: 'In Progress', priority: 2, description: 'Configured field groups test', sourceRunId: OCR_FORM_EXAMPLES_BATCH,
      createdBy: owner.fullName, assignedToEmail: owner.email, assignedToName: owner.fullName, assignedAt: at, creationDate: at,
      fields: { invoiceNumber: document.number, invoiceDate: date, dueDate: '', companyName: document.client_counterparty, streetAddress: '', city: '', zipCode: '', phoneNumber: '', email: '',
        taxRate: '', discountRate: '', totalDiscount: '', totalAmount: document.total_amount },
      ocrFieldValues: values, ocrParties: parties, products: lines.map(line => ({ id: line.id, name: line.product, description: '', quantity: line.qty, price: '', ocrValues: line.ocr_values })), comments: [],
      accounting: { documentId: id, documentName: name, companyId, companyName: organization, supplierKey: `name:${document.client_counterparty.toLowerCase()}`, supplierName: document.client_counterparty,
        supplierCode: 'TEST-GROUPS', vatRate: '', expenseAccount: '', vatClassifier: '' } };
    documents.push(document); tasks[id] = task;
  }
  return { documents, tasks };
}
