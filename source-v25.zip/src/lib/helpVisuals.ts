import { COMPANY_EXPORT_FORMATS } from './companyDigitizationSettings';
import type { HelpText } from './exportHelpGuide';
import { latvianAccountingSystem } from './latvianAccountingSystems';

export type HelpVisual = { file: string; caption: HelpText };
export const helpImageSlug = (value: string) => value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-');

/** Captures are taken from the selected V25 screen, never a different provider. */
export function exportHelpVisual(format: string, area: 'setup' | 'columns' = 'setup'): HelpVisual | undefined {
  if (!(COMPANY_EXPORT_FORMATS as readonly string[]).includes(format)) return undefined;
  // Do not substitute another provider's screenshot or link to a missing capture.
  if (latvianAccountingSystem(format)) return undefined;
  if (area === 'columns') return { file: `columns-${helpImageSlug(format)}.jpg`, caption: [`${format} → Additional column settings. These are this format’s fields, not the Rivilė field list. Required, automatic assignment and defaults are separate controls.`, `${format} → Papildomų stulpelių nustatymai. Rodomi šio formato laukai, ne bendras Rivilės sąrašas. Privalomumas, automatinis priskyrimas ir numatytoji reikšmė yra atskiri pasirinkimai.`] };
  return { file: `export-${helpImageSlug(format)}.jpg`, caption: [`FH → Organization settings → Documents & digitization setup. Export format: ${format}. Choose this format before filling its fields.`, `FH → Organizacijos nustatymai → Dokumentų ir skaitmeninimo nustatymai. Eksporto formatas: ${format}. Prieš pildydami laukus pasirinkite šį formatą.`] };
}

const names: Record<string, HelpText> = {
  departments: ['Departments', 'Padaliniai'], objects: ['Objects', 'Objektai'], series: ['Series', 'Serija'], centers: ['Centers', 'Centrai'],
  persons: ['Accountable persons', 'Atskaitingi asmenys'], groups: ['Product groups', 'Prekių grupės'], expenses: ['Expenses', 'Išlaidos'], counterparties: ['Counterparties', 'Kontrahentai'],
};
export function organizationHelpVisuals(section: string, topic = 'overview'): HelpVisual[] {
  if (section === 'overview' || section === 'digitization') return [{ file: 'export-format-menu.jpg', caption: ['Open the Export format list in the selected organization. Each format has its own settings; use the format-specific guide below.', 'Pasirinktos organizacijos lange atverkite Eksporto formato sąrašą. Kiekvienas formatas turi savo nustatymus; jo vaizdą rasite konkretaus formato instrukcijoje.'] }];
  const name = names[section];
  if (!name) return [];
  const list: HelpVisual = { file: `organization-${section}.jpg`, caption: [`1. Select ${name[0]} in the left menu. New, import, search and row actions belong to this list.`, `1. Kairėje pasirinkite „${name[1]}“. Kūrimo, įkėlimo, paieškos ir eilutės veiksmai priklauso šiam sąrašui.`] };
  const create: HelpVisual = { file: `organization-${section}-new.jpg`, caption: [`2. ${name[0]} → ${section === 'counterparties' ? 'Add company' : 'New code'}. Fill the form and save. Cancel leaves the list unchanged.`, `2. ${name[1]} → ${section === 'counterparties' ? 'Pridėti įmonę' : 'Naujas kodas'}. Užpildykite formą ir išsaugokite. „Atšaukti“ sąrašo nekeičia.`] };
  const imported: HelpVisual = { file: `organization-${section}-import.jpg`, caption: [`3. ${name[0]} → Import from Excel. Paste rows, check the preview, then import. The screenshot shows an unsaved example.`, `3. ${name[1]} → Įkelti iš Excel. Įklijuokite eilutes, patikrinkite peržiūrą ir įkelkite. Nuotraukoje – dar neišsaugotas pavyzdys.`] };
  if (topic === 'excel') return [list, imported];
  if (['code', 'name', 'type', 'alternativeCodes', 'accountingCode', 'companyCode', 'vatCode', 'ibans', 'email', 'phone'].includes(topic)) return [create];
  if (['delete', 'status', 'export'].includes(topic)) return [list];
  return [list, create, imported];
}

export function integrationHelpVisuals(integration: string, topic: string): HelpVisual[] {
  if (topic === 'item-codes' || topic === 'codes') return organizationHelpVisuals('expenses', 'excel');
  if (topic === 'warehouses') { const visual = exportHelpVisual(integration, 'columns'); return visual ? [visual] : []; }
  if (topic === 'workflow-and-checks') return [{ file: 'documents-register.jpg', caption: ['FH Documents: review the selected organization’s processed invoices before export.', 'FH Dokumentai: prieš eksportą patikrinkite pasirinktos organizacijos apdorotas sąskaitas.'] }];
  if (topic === 'configuration' || topic === 'invoice-import' || topic === 'gateway-api') {
    const image = exportHelpVisual(integration);
    const columns = topic === 'configuration' ? exportHelpVisual(integration, 'columns') : undefined;
    return image ? [image, ...(columns ? [columns] : [])] : [];
  }
  return [];
}
