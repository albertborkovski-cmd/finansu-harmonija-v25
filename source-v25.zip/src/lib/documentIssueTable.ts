import type { DbDocument } from './supabase';
import { documentIssueStatusLabel, type DocumentIssue } from './documentIssues';
import { documentCounterpartyCode, sharedDocumentField } from './documentSharedFields';

export type DocumentIssueRow = {
  id: string;
  document: DbDocument;
  issue: DocumentIssue;
  cells: Record<string, string>;
};

const text = (value: unknown) => value === null || value === undefined || value === '' ? '—' : String(value);

export function documentIssueRows(documents: DbDocument[], organizationNames: ReadonlyMap<string, string>): DocumentIssueRow[] {
  return documents.flatMap(document => {
    const cells = {
      number: text(document.number), organization: text(organizationNames.get(document.company_id ?? '')),
      status: text(document.status), receiveDate: text(document.receive_date),
      clientCounterparty: text(document.client_counterparty), counterpartyCode: text(documentCounterpartyCode(document)),
      documentType: text(document.document_type), invoice: /invoice/i.test(document.document_type) ? 'Yes' : 'No',
      documentSubtype: text(document.document_subtype), source: text(document.source),
      totalAmount: text(document.total_amount), amountWithoutVat: text(document.amount_without_vat),
      vat: text(document.vat), vatPercent: text(sharedDocumentField(document, 'vat_percent')), currency: text(document.currency),
      dueEndDate: text(document.due_end_date), fileCase: text(document.file_case), orderNo: text(document.order_no),
      type: text(document.type), documentDate: text(document.document_date), documentPurpose: text(document.document_purpose),
      invoiceContractDate: text(document.invoice_contract_date), operationDate: text(document.operation_date),
      glAccount: text(sharedDocumentField(document, 'expense_account')),
      vatClassifier: text(sharedDocumentField(document, 'vat_classifier')),
      productGroup: text(sharedDocumentField(document, 'product_group')),
      series: text(sharedDocumentField(document, 'series')), costCenter: text(sharedDocumentField(document, 'cost_center')),
      objectProject: text(sharedDocumentField(document, 'object_project')),
      departmentCode: text(sharedDocumentField(document, 'department_code')),
      accountableResponsible: text(sharedDocumentField(document, 'accountable_responsible')), validFrom: text(document.valid_form),
      note: text(document.notes), createdAt: text(document.created_at), createdBy: text(document.created_by),
    };
    return (document.digitization_issues ?? []).map(issue => ({
      id: `${document.id}:${issue.id}`, document, issue,
      cells: { ...cells, reportedIssue: issue.message, issueStatus: documentIssueStatusLabel(issue.status),
        assignedTo: text(issue.assignedToName || issue.assignedToEmail),
        reportedBy: issue.createdBy, reportedAt: issue.createdAt, resolution: text(issue.resolution || issue.correctionNote) },
    }));
  }).sort((left, right) => right.issue.createdAt.localeCompare(left.issue.createdAt));
}

export function filterDocumentIssueRows(rows: DocumentIssueRow[], query: string, activeKeys: string[], values: Record<string, string[]>) {
  const search = query.trim().toLocaleLowerCase();
  return rows.filter(row => (!search || Object.values(row.cells).some(value => value.toLocaleLowerCase().includes(search)))
    && activeKeys.every(key => !values[key]?.length || values[key].includes(row.cells[key])));
}

/** Completed reports stay on the document as history, not in the Worker queue.
 * Awaiting OCR is not resolved until reprocessing and validation finish.
 */
export function openDocumentIssueRows(rows: DocumentIssueRow[]) {
  return rows.filter(row => row.issue.status !== 'Resolved');
}
