import type { WorkspaceTask } from '../components/WorkspaceView';
import type { DbDocument } from './supabase';
import { ocrDocumentStage } from './ocrDocumentWorkflow';
import { teamLeadReviewHistory } from './ocrTeamLeadReview';
import { handoffDraft } from './ocrWorkerHandoff';

export function isOcrReviewDocument(document: Partial<DbDocument>): boolean {
  return ocrDocumentStage(document)?.queue === 'approval';
}

/** Use the destination queue, not the subset of documents teaching one field. */
export function reviewDocumentPosition(document: DocumentIdentity, documents: DbDocument[]) {
  const matches = (item: DbDocument) => item.id === document.id
    && (!document.companyId || item.company_id === document.companyId);
  const source = documents.find(matches);
  if (!source) return { position: 1, total: 1 };
  const queue = isOcrReviewDocument(source) ? documents.filter(isOcrReviewDocument) : documents;
  return { position: queue.findIndex(matches) + 1, total: queue.length };
}

export const OCR_REVIEW_DOCUMENT_TASK_KEYS = [
  'finansu-harmonija:v12:ocr:review-tasks',
  'finansu-harmonija:v18:ocr:team-lead-review',
  'finansu-harmonija:v12:workspace:review-document-tasks',
  'finansu-harmonija:v7:ml-document-tasks',
] as const;

type DocumentIdentity = { id: string; companyId?: string };

export function findSavedReviewDocumentTask(document: DocumentIdentity, collections: Record<string, WorkspaceTask>[]): WorkspaceTask | undefined {
  const matches = collections.flatMap(collection => Object.entries(collection)).filter(([key, task]) => {
    if (!task?.fields || !Array.isArray(task.products)) return false;
    if (task.accounting) return task.accounting.documentId === document.id
      && (!document.companyId || task.accounting.companyId === document.companyId);
    // Older saved drafts use the document ID as their key, not a filename.
    return key === document.id || key === `document-set-${document.id}`
      || task.id === document.id || task.id === `document-set-${document.id}`;
  }).map(([, task]) => task);
  const savedAt = (task: WorkspaceTask) => Math.max(0, ...[
    task.savedAt, task.lastCorrectedAt, task.trainingConfirmedAt, task.teamLeadReview?.requestedAt,
  ].map(value => value ? Date.parse(value) || 0 : 0));
  const latest = matches.sort((a, b) => savedAt(b) - savedAt(a))[0];
  if (!latest) return undefined;
  const history = teamLeadReviewHistory(matches);
  return history.length ? { ...latest, teamLeadReviewHistory: history } : latest;
}

export function loadSavedReviewDocumentTask(document: DocumentIdentity, storage: Pick<Storage, 'getItem'>): WorkspaceTask | undefined {
  return findSavedReviewDocumentTask(document, loadReviewTaskCollections(storage));
}

function loadReviewTaskCollections(storage: Pick<Storage, 'getItem'>) {
  const collections = OCR_REVIEW_DOCUMENT_TASK_KEYS.map(key => {
    try {
      const value = JSON.parse(storage.getItem(key) ?? '{}');
      return value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, WorkspaceTask> : {};
    } catch { return {}; }
  });
  return collections;
}

export function loadSavedReviewDocumentTasks(documents: readonly DbDocument[], storage: Pick<Storage, 'getItem'>) {
  const collections = loadReviewTaskCollections(storage);
  return new Map(documents.map(document => [document.id,
    handoffDraft(document, findSavedReviewDocumentTask({ id: document.id, companyId: document.company_id }, collections))]));
}
