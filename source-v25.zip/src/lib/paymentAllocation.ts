import type { Company } from './supabase';
import type { DebtRow } from './companyRelatedObjectData';
import { debtAmountInCents, debtDirection } from './debtActions';

export type PaymentAllocation = { debtId: string; paymentAmount: string };
export type BeneficiaryAccount = { iban: string; bank: string; bankCode: string; bic: string; primary: boolean };
export const normalizedIban = (value: string) => value.replace(/\s/g, '').toUpperCase();

/** Read the contact's accounts only. Choosing an account never changes the contact. */
export function beneficiaryBankAccounts(contact?: Pick<Company, 'counterparty_bank_accounts'>): BeneficiaryAccount[] {
  const raw = contact?.counterparty_bank_accounts;
  if (!raw) return [];
  let source: unknown;
  try { source = JSON.parse(raw); } catch { source = raw.split(/[,;]/); }
  if (!Array.isArray(source)) return [];
  const seen = new Set<string>();
  return source.flatMap(value => {
    const row = typeof value === 'string' ? { iban: value } : value;
    if (!row || typeof row.iban !== 'string' || row.inactive || row.active === false) return [];
    const iban = normalizedIban(row.iban);
    if (!iban || seen.has(iban)) return [];
    seen.add(iban);
    return [{ iban, bank: String(row.bank || ''), bankCode: String(row.bankCode || ''), bic: String(row.bic || row.swift || ''), primary: row.primary === true }];
  });
}

export function preferredBeneficiaryAccount(accounts: readonly BeneficiaryAccount[], payer?: { bank?: string; bankCode?: string; iban: string }) {
  const bank = (value = '') => value.toLowerCase().replace(/[^\p{L}\p{N}]/gu, '');
  const code = (account: { bankCode?: string; iban: string }) => account.bankCode || (/^LT\d{18}$/.test(normalizedIban(account.iban)) ? normalizedIban(account.iban).slice(4, 9) : '');
  const sameBank = payer && accounts.find(account => (bank(payer.bank) && bank(payer.bank) === bank(account.bank)) || (code(payer) && code(payer) === code(account)));
  return sameBank || accounts.find(account => account.primary) || accounts[0];
}

export function paymentAmountCents(value: string) {
  const amount = value.trim().replace(',', '.');
  return /^\d+(?:\.\d{1,2})?$/.test(amount) ? debtAmountInCents(amount) : null;
}

/** Validate against current payable balances, not amounts supplied by the form. */
export function validatePaymentAllocations(allocations: readonly PaymentAllocation[], debts: readonly DebtRow[], beneficiary: string, beneficiaryCode: string, currency: string) {
  const seen = new Set<string>();
  let total = 0;
  const rows = allocations.map(allocation => {
    if (seen.has(allocation.debtId)) throw new Error('A document can only be included once.');
    seen.add(allocation.debtId);
    const debt = debts.find(row => row.id === allocation.debtId);
    if (!debt || debtDirection(debt) !== 'payable') throw new Error('Select available payable documents.');
    const sameParty = beneficiaryCode ? debt.counterpartyCode === beneficiaryCode : debt.counterpartyName.trim().toLowerCase() === beneficiary.trim().toLowerCase();
    if (!sameParty || debt.currency !== currency) throw new Error('One payment can include documents of one supplier and one currency only.');
    const cents = paymentAmountCents(allocation.paymentAmount), outstanding = debtAmountInCents(debt.outstandingAmount);
    if (cents === null || outstanding === null || cents > outstanding) throw new Error('Payment amount must be positive and cannot exceed the document’s outstanding amount.');
    total += cents;
    if (!Number.isSafeInteger(total)) throw new Error('The selected debt total is too large.');
    return { ...allocation, paymentAmount: (cents / 100).toFixed(2), documentReference: debt.documentReference, outstandingAmount: (outstanding / 100).toFixed(2) };
  });
  return { total: (total / 100).toFixed(2), rows };
}
