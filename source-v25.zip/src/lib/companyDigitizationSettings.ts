import { normalizeAdditionalColumnRules, type AdditionalColumnRule } from './documentAdditionalColumns';
import { exportSchema, exportSections } from './exportFormatSchemas';
import { LATVIAN_EXPORT_FORMATS } from './latvianAccountingSystems';

export type ExportFormatProfile = { fields: Record<string, string | boolean>; columns: Record<string, AdditionalColumnRule> };

export const COMPANY_EXPORT_FORMATS = [
  'Agnum', 'Apskaita5', 'BSS', 'BSS Api', 'Business Central', 'Būtent', 'Būtent kiekinis', 'Centas', 'CSV',
  'Debetas', 'Debetas Excel', 'Dineta', 'Directo', 'Euroskaita', 'Excel', 'Finvalda', 'Finvalda Excel', 'iSAF',
  'Json', 'Lobasoft', 'Monet', 'Odoo', 'Optimum', 'Paulita', 'Pragma3', 'Pragma4', 'Pragma4 V2', 'Rivilė',
  'Rivilė API', 'Rivilė ERP', 'Roda', 'Saikas', 'Site.pro', 'StandardERP', 'Syrve', 'UCS StoreHouse v4', 'Uniconta', 'XML',
  ...LATVIAN_EXPORT_FORMATS,
] as const;

export const SALES_OPERATION_TYPES = ['Waybill', 'Order', 'Reservation', 'Offer'] as const;
export const PURCHASE_OPERATION_TYPES = ['Waybill', 'Order', 'Offer'] as const;
export const DEFAULT_DIGITIZATION_SETTINGS = {
  database: '', itemAccountLinkCode: '', itemType: '', updateProducts: false, updateServices: false, updateCodes: false,
  postInRivile: false, salesPaymentAccount: '', purchasePaymentAccount: '', salesOperation: 'Waybill', purchaseOperation: 'Waybill',
  individualBuyerCode: 'unique', fixedBuyerCode: '', primaryLineCode: 'barcode', additionalColumnsAt: 'digitization',
  vatSeparation: 'automatic', foreignVatAsCompanyCode: false, dueDateFromInvoiceDate: false,
  createCompaniesOnExport: false, createProductsOnExport: false, exportAfterDigitization: false,
  additionalColumns: normalizeAdditionalColumnRules(undefined),
  formatProfiles: {} as Record<string, ExportFormatProfile>,
};
export type CompanyDigitizationSettings = typeof DEFAULT_DIGITIZATION_SETTINGS;

/** Explicit whitelist: credentials are never serialized into browser/shared demo data. */
export function parseCompanyDigitizationSettings(raw?: string, company?: Record<string, unknown>): CompanyDigitizationSettings {
  const value: unknown = raw ? JSON.parse(raw) : {};
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('Could not read export settings.');
  return Object.fromEntries(Object.entries(DEFAULT_DIGITIZATION_SETTINGS).map(([key, fallback]) => {
    const saved = (value as Record<string, unknown>)[key];
    if (key === 'additionalColumns') return [key, normalizeAdditionalColumnRules(saved, company)];
    if (key === 'formatProfiles') return [key, normalizeFormatProfiles(saved)];
    return [key, typeof saved === typeof fallback ? saved : fallback];
  })) as CompanyDigitizationSettings;
}

function normalizeFormatProfiles(raw: unknown): Record<string, ExportFormatProfile> {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};
  return Object.fromEntries(COMPANY_EXPORT_FORMATS.filter(format => Object.prototype.hasOwnProperty.call(raw, format)).map(format => [format, normalizeFormatProfile(format, (raw as Record<string, unknown>)[format])]));
}

/** Only schema-declared non-secret fields are persisted. Unknown fields and credentials are discarded. */
export function normalizeFormatProfile(format: string, raw: unknown, legacy?: CompanyDigitizationSettings): ExportFormatProfile {
  const saved = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw as Partial<ExportFormatProfile> : {};
  const fields = Object.fromEntries(exportSections(format).flatMap(section => section.fields).filter(field => field.type !== 'password').map(field => {
    const fallback = field.defaultValue ?? (field.type === 'checkbox' ? false : '');
    const value = saved.fields?.[field.key] ?? (legacy as unknown as Record<string, unknown> | undefined)?.[field.key];
    return [field.key, typeof value === typeof fallback && (!field.options || field.options.includes(String(value))) ? value : fallback];
  }));
  const columns = Object.fromEntries(exportSchema(format).columns.map(column => {
    const rule = saved.columns?.[column.key] ?? (column.sourceKey ? legacy?.additionalColumns[column.sourceKey] : undefined);
    return [column.key, { required: rule?.required === true, automatic: rule?.automatic === true, defaultValue: typeof rule?.defaultValue === 'string' ? rule.defaultValue : '', defaultLabel: typeof rule?.defaultLabel === 'string' ? rule.defaultLabel : '' }];
  }));
  return { fields: fields as ExportFormatProfile['fields'], columns };
}

export function initializeExportFormat(settings: CompanyDigitizationSettings, format: string): CompanyDigitizationSettings {
  return { ...settings, formatProfiles: { ...settings.formatProfiles, [format]: normalizeFormatProfile(format, settings.formatProfiles[format], settings.formatProfiles[format] ? undefined : settings) } };
}

export function serializeCompanyDigitizationSettings(settings: CompanyDigitizationSettings, activeFormat?: string) {
  let clean = parseCompanyDigitizationSettings(JSON.stringify(settings));
  if (activeFormat) {
    if (!COMPANY_EXPORT_FORMATS.includes(activeFormat as typeof COMPANY_EXPORT_FORMATS[number])) throw new Error('Select a valid settings option.');
    const profile = normalizeFormatProfile(activeFormat, clean.formatProfiles[activeFormat]);
    if (profile.fields.individualBuyerCode === 'fixed' && !String(profile.fields.fixedBuyerCode || '').trim()) throw new Error('Enter the fixed buyer code.');
    for (const field of exportSections(activeFormat).flatMap(section => section.fields)) {
      const value = profile.fields[field.key];
      if (typeof value === 'string' && value.length > 500) throw new Error('One of the values is too long.');
      if (field.type === 'number' && value !== '' && (!Number.isFinite(Number(value)) || Number(value) < 0)) throw new Error('Enter a valid non-negative number.');
    }
    // Keep the established OCR required/default logic pointed at the active format only.
    const projected = { ...DEFAULT_DIGITIZATION_SETTINGS, ...Object.fromEntries(Object.entries(profile.fields).filter(([key]) => key in DEFAULT_DIGITIZATION_SETTINGS)), additionalColumns: normalizeAdditionalColumnRules(profile.columns) };
    clean = { ...projected, formatProfiles: { ...clean.formatProfiles, [activeFormat]: profile } };
  }
  if (!SALES_OPERATION_TYPES.includes(clean.salesOperation as typeof SALES_OPERATION_TYPES[number])
    || !PURCHASE_OPERATION_TYPES.includes(clean.purchaseOperation as typeof PURCHASE_OPERATION_TYPES[number])
    || !['unique', 'fixed'].includes(clean.individualBuyerCode)
    || !['barcode', 'code'].includes(clean.primaryLineCode)
    || !['digitization', 'export'].includes(clean.additionalColumnsAt)
    || !['automatic', 'separate-non-payers', 'include-payers'].includes(clean.vatSeparation)) throw new Error('Select a valid settings option.');
  if (clean.individualBuyerCode === 'fixed' && !clean.fixedBuyerCode.trim()) throw new Error('Enter the fixed buyer code.');
  if (Object.values(clean).some(value => typeof value === 'string' && value.length > 500)) throw new Error('One of the values is too long.');
  if (Object.values(clean.additionalColumns).some(rule => rule.defaultValue.length > 500 || rule.defaultLabel.length > 500)) throw new Error('One of the values is too long.');
  for (const profile of Object.values(clean.formatProfiles)) {
    if (Object.values(profile.fields).some(value => typeof value === 'string' && value.length > 500)
      || Object.values(profile.columns).some(rule => rule.defaultValue.length > 500 || rule.defaultLabel.length > 500)) throw new Error('One of the values is too long.');
  }
  return JSON.stringify(clean);
}
