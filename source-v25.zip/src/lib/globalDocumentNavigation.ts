/** Shared global entry points; company navigation retains its company-only tree. */
export const GLOBAL_DOCUMENT_MENU_ITEMS = [
  { id: 'uploaded-documents-documents', label: 'Documents', area: 'documents' },
  { id: 'uploaded-documents-uploaded', label: 'Uploaded documents', area: 'uploaded-documents' },
] as const;

export function isGlobalDocumentsMenu(menu: string): boolean {
  return menu === 'uploaded-documents' || GLOBAL_DOCUMENT_MENU_ITEMS.some(item => item.id === menu);
}

export function globalDocumentMenuArea(menu: string): string | undefined {
  return GLOBAL_DOCUMENT_MENU_ITEMS.find(item => item.id === menu)?.area;
}
