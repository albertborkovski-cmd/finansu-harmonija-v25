import type { DocumentTypeReference } from './documentSubtypeOptions';

type DocumentClassification = { document_type?: unknown; document_subtype?: unknown } | Record<string, unknown>;

export function findDocumentTypeRecord(records: readonly DocumentTypeReference[], value: string) {
  const normalize = (text: string) => text.trim().toLocaleLowerCase().replace(/[_-]+/g, ' ').replace(/\s+/g, ' ');
  const aliases: Record<string, string> = { 'credit note': 'credit invoice', 'debit note': 'debit invoice', receipt: 'cash receipt' };
  const normalized = normalize(value);
  if (!normalized) return undefined;
  return records.find(record => record.code === value)
    ?? records.find(record => [record.code, record.fullName, ...(record.previousNames || [])]
      .some(label => normalize(label) === normalized))
    ?? records.find(record => [record.code, record.fullName].some(label => normalize(label) === aliases[normalized]));
}

/** Keep legacy name-based records linked after a Settings rename. New edits save codes. */
export function renamedDocumentType<T extends DocumentTypeReference>(record: T, previous?: DocumentTypeReference): T {
  const previousNames = [...new Set([...(previous?.previousNames || []), ...(record.previousNames || []),
    ...(previous && previous.fullName !== record.fullName ? [previous.fullName] : []),
    ...(previous && previous.code !== record.code ? [previous.code] : [])])].filter(Boolean);
  return { ...record, ...(previousNames.length ? { previousNames } : {}) };
}

function activePath(records: readonly DocumentTypeReference[], record: DocumentTypeReference) {
  const path: DocumentTypeReference[] = [];
  const seen = new Set<string>();
  let current: DocumentTypeReference | undefined = record;
  while (current) {
    if (seen.has(current.code) || current.status.toLowerCase() !== 'active') return [];
    seen.add(current.code);
    path.unshift(current);
    if (!current.parentCode) return path;
    current = records.find(item => item.code === current?.parentCode);
  }
  return [];
}

/** Settings order and parent descriptions make every active type/subtype searchable. */
export function documentTypeCatalogOptions(records: readonly DocumentTypeReference[]) {
  const options: { value: string; label: string; description?: string }[] = [];
  const visited = new Set<string>();
  const append = (record: DocumentTypeReference) => {
    if (visited.has(record.code)) return;
    visited.add(record.code);
    const path = activePath(records, record);
    if (!path.length) return;
    const parents = path.slice(0, -1);
    options.push({ value: record.code, label: record.fullName || record.code,
      ...(parents.length ? { description: parents.map(parent => parent.fullName || parent.code).join(' / ') } : {}) });
    records.filter(child => child.parentCode === record.code).forEach(append);
  };
  records.filter(record => !record.parentCode).forEach(append);
  return options;
}

export function documentTypeCatalogSelection(document: DocumentClassification, records: readonly DocumentTypeReference[]) {
  const value = String(document.document_subtype || document.document_type || '');
  return findDocumentTypeRecord(records, value)?.code || value;
}

/** Every document register resolves the subtype first and shows the current Settings name. */
export function documentTypeCatalogLabel(document: DocumentClassification, records: readonly DocumentTypeReference[]) {
  const value = documentTypeCatalogSelection(document, records);
  return findDocumentTypeRecord(records, value)?.fullName || value;
}

/** One classification column; migrate legacy Type/Subtype without resetting layout preferences. */
export function documentTypeColumns<T extends { key: string; label: string }>(columns: readonly T[]): T[] {
  const aliases = ['documentType', 'type', 'subtype', 'documentSubtype'];
  const preferred = columns.find(column => column.key === 'documentType')
    || columns.find(column => aliases.includes(column.key));
  const labels: Record<string, string> = { number: 'Document Number', clientCounterparty: 'Counterparty',
    amountWithoutVat: 'Amount without VAT', vat: 'VAT', vatPercent: 'VAT %' };
  const seen = new Set<string>();
  return columns.flatMap(column => aliases.includes(column.key)
    ? column === preferred ? [{ ...column, key: 'documentType', label: 'Document type' }] : []
    : column.key === 'invoice' ? [] : [{ ...column, label: labels[column.key] || column.label }])
    .filter(column => { if (seen.has(column.key)) return false; seen.add(column.key); return true; });
}

/** A subtype selection never replaces the parent type with a child code. */
export function documentTypeCatalogPatch(records: readonly DocumentTypeReference[], value: string) {
  const selected = records.find(record => record.code === value);
  const path = selected ? activePath(records, selected) : [];
  if (!selected || !path.length) throw new Error('Select an active document type or subtype from General settings.');
  return { document_type: path[0].code, document_subtype: path.length > 1 ? selected.code : '' };
}
