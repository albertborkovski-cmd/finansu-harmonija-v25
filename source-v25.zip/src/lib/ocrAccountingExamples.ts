import type { DbDocument } from './supabase';
import type { WorkspaceTask } from '../components/WorkspaceView';
import type { OcrFieldValidationRule } from './ocrFieldValidation';
import { createOcrFormExamples as createPartyExamples, OCR_FORM_EXAMPLE_CONFIGS as partyConfigs } from './ocrPartyExamples';

export const OCR_FORM_EXAMPLES_BATCH = 'v25-ocr-accounting-fields-v1';
const scenarios = [['EMPTY', 'Empty accounting codes (test)'], ['SAVED', 'Saved accounting codes (test)']] as const;
export const OCR_FORM_EXAMPLE_TYPES = [
  { code: 'FH_TEST_FORMS', fullName: 'OCR test documents', parentCode: '' },
  ...scenarios.map(([key, fullName]) => ({ code: `FH_TEST_ADDINFO_${key}`, fullName, parentCode: 'FH_TEST_FORMS' })),
].map(item => ({ ...item, country: '', status: 'Active', description: 'Synthetic ADDINFO example. Not for accounting.' }));
export const OCR_FORM_EXAMPLE_CONFIGS: Record<string, OcrFieldValidationRule[]> = Object.fromEntries(scenarios.map(([key]) => [
  `FH_TEST_ADDINFO_${key}`, [
    ...partyConfigs.FH_TEST_PARTIES_PURCHASE,
    ...[['departmentCode', 'Department code'], ['objectProject', 'Object / Project'], ['series', 'Series'], ['costCenter', 'Cost center'],
      ['accountablePerson', 'Accountable person'], ['productGroup', 'Product group'], ['glAccount', 'Expense account'], ['vatClassifier', 'VAT classifier']]
      .map(([key, label], index): OcrFieldValidationRule => ({ key, label, type: 'OCR', subtype: 'OCR', level: 'red', required: true,
        formVersion: 1, group: 'calculated', order: index * 10, enabled: true })),
    { key: 'supplierCode', label: 'Supplier code', type: 'OCR', subtype: 'OCR', level: 'red', required: true, formVersion: 1, group: 'additional', order: 0 },
  ],
]));

export function createOcrFormExamples(companyId: string, organization: string, owner: { email: string; fullName: string }, at: string) {
  const base = createPartyExamples(companyId, organization, owner, at), original = base.documents[0], originalTask = base.tasks[original.id];
  const documents: DbDocument[] = [], tasks: Record<string, WorkspaceTask> = {};
  scenarios.forEach(([key, label], index) => {
    const id = `${companyId}:${OCR_FORM_EXAMPLES_BATCH}:${key}`, name = `OCR-ADDINFO-${key}-${index + 1}.svg`, subtype = `FH_TEST_ADDINFO_${key}`;
    const saved = key === 'SAVED', expenseAccount = saved ? 'TEST-6300' : '', vatClassifier = saved ? 'TEST-PVM' : '';
    const values = { ...(saved ? { departmentCode: 'TEST-DEP', costCenter: 'TEST-CENTER' } : {}), supplierCode: '' };
    const parties = original.ocr_parties?.map(party => ({ ...party, id: party.id.replace(original.id, id), values: { ...party.values } }));
    const lines = [label, `Document number: FH-ADDINFO-${index + 1}`, `Document date: ${at.slice(0, 10)}`, 'Seller: FH Test Seller', 'Buyer: FH Test Buyer',
      'TEST: fill only the missing document number from this original.', 'Accounting codes are not OCR extraction errors.',
      'ADDINFO is last and initially collapsed; its fields follow the organization export format.', 'No internal Supplier code assignment is available in the Worker editor.'];
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="900" height="1100"><rect width="900" height="1100" fill="white"/><text x="40" y="55" font-family="Arial" font-size="22" fill="#10233A">Finansu harmonija — SYNTHETIC TEST, NOT FOR ACCOUNTING</text>${lines.map((line, row) => `<text x="40" y="${125 + row * 42}" font-family="Arial" font-size="15" fill="#10233A">${line}</text>`).join('')}</svg>`;
    const document: DbDocument = { ...original, id, file_case: name, document_subtype: subtype, ocr_values: values, ocr_parties: parties,
      expense_account: expenseAccount, vat_classifier: vatClassifier, department_code: saved ? 'TEST-DEP' : '', cost_center: saved ? 'TEST-CENTER' : '',
      image_url: `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`, notes: 'SYNTHETIC ADDINFO TEST: missing document number is the only OCR error; empty accounting codes must not block OCR.' };
    tasks[id] = { ...originalTask, id, name, documentType: subtype, sourceRunId: OCR_FORM_EXAMPLES_BATCH, description: label,
      ocrFieldValues: values, ocrParties: parties, accounting: { companyId, companyName: organization, documentId: id, documentName: name,
        supplierKey: 'name:fh test seller', supplierName: 'FH Test Seller', vatRate: '', expenseAccount, vatClassifier } };
    documents.push(document);
  });
  return { documents, tasks };
}
