import { createOcrMyTaskExamples } from './ocrMyTaskExamples';
import { exampleInvoiceImage } from './ocrVisualExamples';
import type { DbDocument } from './supabase';
import type { WorkspaceTask } from '../components/WorkspaceView';
import type { OcrHandwriting } from './ocrHandwriting';

export const OCR_HANDWRITING_EXAMPLES_BATCH = 'v25-ocr-handwriting-priority-v1';

/** Explicitly requested synthetic examples; never infer handwriting on real invoices. */
export function createOcrHandwritingExamples(companyId: string, organization: string, owner: { email: string; fullName: string }, at: string) {
  const source = createOcrMyTaskExamples(companyId, owner, at, false);
  const tasks: Record<string, WorkspaceTask> = {};
  const documents = source.documents.slice(0, 9).map((original, index): DbDocument => {
    const sequence = String(index + 1).padStart(3, '0');
    const id = `${companyId}:${OCR_HANDWRITING_EXAMPLES_BATCH}:${sequence}`;
    const number = `OCR-HW-${sequence}`;
    const handwriting: OcrHandwriting = (['full', 'partial', 'none'] as const)[index % 3];
    const rekey = (lines: DbDocument['line_items'], kind: string) => lines?.map((line, i) => ({ ...line, id: `${id}:${kind}:${i}` }));
    const document: DbDocument = { ...original, id, number, file_case: `${number}.svg`, status: 'Worker review',
      created_by: 'V25 OCR handwriting test data', notes: `Synthetic test document · ${handwriting} handwriting · not for payment`,
      ocr_handwriting: handwriting, line_items: rekey(original.line_items, 'line'), summary_line_items: rekey(original.summary_line_items, 'summary') };
    const svg = decodeURIComponent(exampleInvoiceImage(document, organization).split(',')[1]);
    const style = handwriting === 'full'
      ? '<style>text { font-family: "Bradley Hand", "Segoe Print", "Comic Sans MS", cursive; font-style: italic; }</style>'
      : handwriting === 'partial' ? '<style>text[y="188"], text[y="177"], text[y="429"] { font-family: "Bradley Hand", "Segoe Print", "Comic Sans MS", cursive; font-style: italic; fill: #1c4e92; }</style>' : '';
    const label = handwriting === 'full' ? 'VISIŠKAI RANKA RAŠYTAS · TESTINIS PAVYZDYS'
      : handwriting === 'partial' ? 'DALIS DUOMENŲ ĮRAŠYTA RANKA · TESTINIS PAVYZDYS' : 'SPAUSDINTAS DOKUMENTAS · TESTINIS PAVYZDYS';
    document.image_url = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg.replace('</svg>', `${style}<text x="44" y="1008" font-family="Arial, sans-serif" font-size="12" fill="#9A6700">${label}</text></svg>`))}`;
    const originalTask = source.tasks[original.id];
    tasks[id] = { ...originalTask, id, name: document.file_case, priority: Math.floor(index / 3) + 1,
      sourceRunId: OCR_HANDWRITING_EXAMPLES_BATCH, documentType: document.document_subtype || 'VAT_INVOICE',
      fields: { ...originalTask.fields, invoiceNumber: number },
      products: originalTask.products.map((row, i) => ({ ...row, id: `${id}:product:${i}` })), comments: [] };
    // Every task has an actual missing mandatory OCR value, not just a warning badge.
    if (index % 3 === 0) { document.number = ''; tasks[id].fields.invoiceNumber = ''; }
    if (index % 3 === 1) { document.document_date = ''; tasks[id].fields.invoiceDate = ''; }
    if (index % 3 === 2) { document.client_counterparty = ''; tasks[id].fields.companyName = ''; }
    return document;
  });
  return { documents, tasks };
}
