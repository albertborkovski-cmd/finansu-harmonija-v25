export const OCR_STATUS_SETTINGS_KEY = 'finansu-harmonija:v23:ocr:status-descriptions';
export const OCR_STATUS_SETTINGS_CHANGED = 'finansu-harmonija:ocr-status-settings-changed';
export const OCR_STATUS_GROUPS = [
  { name: 'Processing', statuses: ['Received', 'Queued', 'Processing', 'Awaiting OCR', 'Worker review', 'Awaiting TeamLead', 'Escalated'] },
  { name: 'Processed', statuses: ['Processed', 'Approved'] },
  { name: 'Needs attention', statuses: ['Exception', 'Duplicate', 'Organization not identified', 'Not document', 'Rejected'] },
] as const;
/** These catalog entries are not assigned to an automatic workflow group. */
export const OCR_STATUS_CATALOG_GROUPS = [...OCR_STATUS_GROUPS,
  { name: 'Other statuses', statuses: ['Uploaded', 'Deleted', 'Split', 'Merged'] },
] as const;

export const OCR_STATUS_DESCRIPTIONS: Record<string, string> = {
  Received: 'The document has been received and is waiting for processing.',
  Queued: 'The document is waiting for automatic OCR processing in Uploaded documents.',
  Processing: 'OCR is digitizing the document. It is not a worker task yet.',
  'Awaiting OCR': 'An OCR processing request is pending. The document stays in Uploaded documents until a new result is available.',
  'Worker review': 'OCR could not complete the required checks. Open My tasks to correct missing required fields or the document type.',
  'Awaiting TeamLead': 'The document is waiting for TeamLead approval or correction.',
  Escalated: 'The worker sent this document to TeamLead with a reason for review.',
  Rejected: 'The worker returned this document. Review the return reason before resubmitting it.',
  Processed: 'OCR review is complete. The accountant can review the document, send it to accounting or report an issue.',
  Approved: 'The accountant has approved this document. It is available in the company document register.',
  Exception: 'A processing error or reported document issue requires attention. Review and correct the document before continuing.',
  Duplicate: 'A matching document was detected. Compare this file with the original before continuing.',
  'Organization not identified': 'The organization could not be identified. Select the correct organization before processing can continue.',
  'Not document': 'The file was identified as not being an accounting document. Review the original file.',
  Inactive: 'The document is inactive. Its data and action history are retained.',
  Uploaded: 'The document has been uploaded. Processing has not started.',
  Deleted: 'The document has been deleted from the active register. Its history is retained.',
  Split: 'The original PDF has been split into separate documents. The original and page assignments are retained.',
  Merged: 'This original is retained after merging. The combined PDF is queued for OCR.',
};
export type OcrStatusGroup = typeof OCR_STATUS_GROUPS[number]['name'];
export type OcrStatusCatalogGroup = typeof OCR_STATUS_CATALOG_GROUPS[number]['name'];
export type OcrStatusRecord = { status: string; displayName?: string; group: OcrStatusCatalogGroup; custom: boolean; inactive?: boolean; deleted?: boolean };
type StatusSettings = {
  descriptions: Record<string, string>;
  history: { status: string; before: string; after: string; at: string; actor: string }[];
  records?: OcrStatusRecord[];
  lifecycleHistory?: { status: string; action: 'Created' | 'Deleted' | 'Deactivated'; at: string; actor: string }[];
  nameHistory?: { status: string; before: string; after: string; at: string; actor: string }[];
};
const defaults: OcrStatusRecord[] = OCR_STATUS_CATALOG_GROUPS.flatMap(group => group.statuses.map(status => ({ status, group: group.name, custom: false })));
const normalize = (value: string) => value.trim().toLocaleLowerCase();
const reservedNames = ['Inactive', 'Active', 'Draft', 'New', 'Pending', 'Approved', 'Confirmed', 'Posted', 'Transferred', 'Exported', 'Paid', 'Accepted', 'Completed',
  'Rejected', 'Deleted', 'Cancelled', 'Canceled', 'Reversed', 'Storno', 'Needs attention', 'Uploaded', 'Submitted', 'In progress', 'Pending OCR', 'Awaiting approval', 'Needs review',
  'Need review', 'Needs info', 'Provide additional', 'Provide additional data', 'Correcting', 'Exceptional', 'Dublicate', 'Not documented', 'Overdue', 'Deactivated'];
function validateStatusName(name: string, current: StatusSettings, ownStatus?: string) {
  if (!name || name.length > 100) throw new Error('Enter a status name (1–100 characters).');
  const otherNames = [...defaults, ...(current.records ?? [])].filter(row => row.status !== ownStatus)
    .flatMap(row => [row.status, row.displayName ?? '']);
  if ([...otherNames, ...reservedNames.filter(value => value !== ownStatus)].some(value => normalize(value) === normalize(name)))
    throw new Error('An OCR status with this name already exists or the name is reserved.');
}
export function loadOcrStatusSettings(storage: Pick<Storage, 'getItem'>): StatusSettings {
  const raw = storage.getItem(OCR_STATUS_SETTINGS_KEY);
  if (!raw) return { descriptions: {}, history: [] };
  const parsed = JSON.parse(raw);
  if (!parsed || !parsed.descriptions || typeof parsed.descriptions !== 'object' || Array.isArray(parsed.descriptions) || !Array.isArray(parsed.history)
    || (parsed.records !== undefined && (!Array.isArray(parsed.records) || parsed.records.some((row: OcrStatusRecord) => !row || typeof row.status !== 'string'
      || !OCR_STATUS_CATALOG_GROUPS.some(group => group.name === row.group) || typeof row.custom !== 'boolean'
      || (row.displayName !== undefined && (typeof row.displayName !== 'string' || !row.displayName.trim() || row.displayName.length > 100)))))
    || (parsed.lifecycleHistory !== undefined && !Array.isArray(parsed.lifecycleHistory))
    || (parsed.nameHistory !== undefined && !Array.isArray(parsed.nameHistory))) throw new Error('OCR status settings could not be read.');
  return parsed;
}
export function ocrStatusRecords(storage?: Pick<Storage, 'getItem'>): OcrStatusRecord[] {
  try {
    const store = storage ?? (typeof window !== 'undefined' ? window.localStorage : undefined);
    const saved = store ? loadOcrStatusSettings(store).records ?? [] : [];
    const rows = new Map(defaults.map(row => [normalize(row.status), { ...row }]));
    saved.forEach(row => rows.set(normalize(row.status), { ...row }));
    return [...rows.values()].filter(row => !row.deleted);
  } catch { return defaults.map(row => ({ ...row })); }
}
export function customOcrStatus(status: string, storage?: Pick<Storage, 'getItem'>) {
  // Inactive values remain recognizable on historical documents.
  return ocrStatusRecords(storage).find(row => row.custom && row.group !== 'Other statuses' && normalize(row.status) === normalize(status));
}
export function customOcrProcessingStatus(status: string, storage?: Pick<Storage, 'getItem'>) {
  const record = customOcrStatus(status, storage);
  return record?.group === 'Processing' ? record : undefined;
}
export function ocrStatusLabel(status: string, translate: (value: string) => string, storage?: Pick<Storage, 'getItem'>) {
  // User labels are presentation only: workflow, filters and historical references keep the stable status code.
  return ocrStatusRecords(storage).find(row => row.status === status)?.displayName ?? translate(status);
}
export function ocrStatusGroup(status: string, storage?: Pick<Storage, 'getItem'>): OcrStatusGroup | undefined {
  // Removed catalog entries may still occur in historical records; their original grouping remains valid.
  const group = [...ocrStatusRecords(storage), ...defaults].find(row => normalize(row.status) === normalize(status))?.group;
  return group === 'Other statuses' ? undefined : group;
}
export function isAuxiliaryOcrStatus(status: string, storage?: Pick<Storage, 'getItem'>) {
  return [...ocrStatusRecords(storage), ...defaults].some(row => row.group === 'Other statuses' && normalize(row.status) === normalize(status));
}
export function createOcrStatus(group: OcrStatusCatalogGroup, status: string, description: string, actor: string, storage: Pick<Storage, 'getItem' | 'setItem'>) {
  const current = loadOcrStatusSettings(storage);
  if (!OCR_STATUS_CATALOG_GROUPS.some(item => item.name === group)) throw new Error('Unknown OCR status.');
  const name = status.trim();
  validateStatusName(name, current);
  if (!description.trim() || description.length > 5000) throw new Error('Enter a description (1–5,000 characters).');
  const next: StatusSettings = { ...current, descriptions: { ...current.descriptions, [name]: description.trim() },
    records: [...(current.records ?? []), { status: name, group, custom: true }],
    lifecycleHistory: [...(current.lifecycleHistory ?? []), { status: name, action: 'Created', at: new Date().toISOString(), actor }] };
  storage.setItem(OCR_STATUS_SETTINGS_KEY, JSON.stringify(next));
  return next;
}
export function createOcrProcessingStatus(status: string, description: string, actor: string, storage: Pick<Storage, 'getItem' | 'setItem'>) {
  return createOcrStatus('Processing', status, description, actor, storage);
}
export function removeOcrStatus(status: string, linked: boolean, actor: string, storage: Pick<Storage, 'getItem' | 'setItem'>) {
  const current = loadOcrStatusSettings(storage);
  const record = ocrStatusRecords(storage).find(row => row.status === status);
  if (!record) throw new Error('Unknown OCR status.');
  if (record.inactive) return current;
  const next: StatusSettings = { ...current,
    // Tombstones prevent default rows from returning after refresh; workflow codes are never rewritten.
    records: [...(current.records ?? []).filter(row => row.status !== status), { ...record, inactive: linked, deleted: !linked }],
    lifecycleHistory: [...(current.lifecycleHistory ?? []), { status, action: linked ? 'Deactivated' : 'Deleted', at: new Date().toISOString(), actor }] };
  storage.setItem(OCR_STATUS_SETTINGS_KEY, JSON.stringify(next));
  return next;
}
export function removeOcrProcessingStatus(status: string, linked: boolean, actor: string, storage: Pick<Storage, 'getItem' | 'setItem'>) {
  if (!ocrStatusRecords(storage).some(row => row.status === status && row.group === 'Processing')) throw new Error('Unknown OCR status.');
  return removeOcrStatus(status, linked, actor, storage);
}
export function ocrStatusDescription(status: string, storage?: Pick<Storage, 'getItem'>) {
  try {
    const settings = storage || (typeof window !== 'undefined' ? window.localStorage : undefined);
    const custom = settings && loadOcrStatusSettings(settings).descriptions[status];
    if (typeof custom === 'string' && custom.trim()) return custom;
  } catch { /* Display remains available; saving rejects invalid settings. */ }
  return OCR_STATUS_DESCRIPTIONS[status] || OCR_STATUS_DESCRIPTIONS.Processing;
}
export function saveOcrStatusDescription(status: string, description: string, actor: string, storage: Pick<Storage, 'getItem' | 'setItem'>, displayName?: string) {
  const current = loadOcrStatusSettings(storage);
  const record = ocrStatusRecords(storage).find(row => row.status === status);
  if (!record) throw new Error('Unknown OCR status.');
  if (!description.trim() || description.length > 5000) throw new Error('Enter a description (1–5,000 characters).');
  const name = displayName?.trim();
  if (name !== undefined) validateStatusName(name, current, status);
  const at = new Date().toISOString();
  const next: StatusSettings = { ...current, descriptions: { ...current.descriptions, [status]: description.trim() }, history: [...current.history,
    { status, before: ocrStatusDescription(status, storage), after: description.trim(), at, actor }] };
  if (name !== undefined && name !== (record.displayName ?? status)) {
    next.records = [...(current.records ?? []).filter(row => row.status !== status), { ...record, displayName: name }];
    next.nameHistory = [...(current.nameHistory ?? []), { status, before: record.displayName ?? status, after: name, at, actor }];
  }
  storage.setItem(OCR_STATUS_SETTINGS_KEY, JSON.stringify(next));
  return next;
}
