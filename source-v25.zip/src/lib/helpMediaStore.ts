const DB_NAME = 'finansu-harmonija-help-media';
const STORE = 'media';
type HelpMediaRecord = { id: string; name: string; type: string; blob: Blob };
export function validateHelpMedia(file: Pick<File, 'size' | 'type'>): 'image' | 'video' {
  const kind = ['image/png', 'image/jpeg', 'image/webp', 'image/gif'].includes(file.type) ? 'image'
    : ['video/mp4', 'video/webm'].includes(file.type) ? 'video' : null;
  if (!kind) throw new Error('Supported media: PNG, JPG, WebP, GIF, MP4, WebM.');
  if (!file.size || file.size > (kind === 'image' ? 10 : 50) * 1024 * 1024) throw new Error('Media limit: images 10 MB, videos 50 MB.');
  return kind;
}
function openMediaDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => request.result.createObjectStore(STORE, { keyPath: 'id' });
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}
export async function saveHelpMedia(file: File) {
  const kind = validateHelpMedia(file), id = crypto.randomUUID(), db = await openMediaDb();
  try {
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).put({ id, name: file.name, type: file.type, blob: file } satisfies HelpMediaRecord);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error || new Error('Media could not be saved.'));
    });
    return { url: `help-media:${id}`, kind };
  } finally { db.close(); }
}
export async function readHelpMedia(url: string): Promise<HelpMediaRecord | undefined> {
  if (!/^help-media:[a-f0-9-]{36}$/.test(url)) return undefined;
  const db = await openMediaDb();
  try {
    return await new Promise((resolve, reject) => {
      const request = db.transaction(STORE, 'readonly').objectStore(STORE).get(url.slice(11));
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  } finally { db.close(); }
}
