import type { Document } from '../components/Documents';
import type { GlJournalRow } from './glJournal';

const POSTED_STATUSES = new Set(['Approved', 'Paid', 'Transferred']);
const inactive = (document: Document) => Boolean(document.inlineSource.inactive || document.inlineSource.active === false || document.inlineSource.is_active === false);

function amount(value: string | number | undefined) {
  if (typeof value === 'number') return Number.isFinite(value) ? value : 0;
  const numeric = String(value ?? '').replace(/[^0-9,.-]/g, '');
  const parsed = Number(numeric.includes('.') ? numeric.replace(/,/g, '') : numeric.replace(',', '.'));
  return Number.isFinite(parsed) ? parsed : 0;
}

/** Company journal rows are a projection, not a second editable copy of a document.
 * Accounting allocations take precedence over OCR/product lines. */
export function createJournalCandidates(document: Document, activeAccounts: Set<string>): GlJournalRow[] {
  const documentTotal = amount(document.totalAmount || document.amountWithoutVat);
  const isAccountingNote = /accounting[\s_-]*note/i.test(document.documentType);
  const posted = POSTED_STATUSES.has(document.status);
  const sourceLines = document.summaryLineItems.length > 0 ? document.summaryLineItems : document.lineItems;
  const lineAccounts = sourceLines.map((line, index) => ({
    id: line.id || `${document.id}-${index}`, account: line.expense?.trim() || '',
    value: amount(line.total || line.subtotal), line,
  })).filter(line => line.account);
  const accountLines = lineAccounts.length > 0 ? lineAccounts : document.expenseAccount.trim()
    ? [{ id: document.id, account: document.expenseAccount.trim(), value: documentTotal, line: undefined }]
    : [];
  const fallbackLineValue = accountLines.length > 0 ? documentTotal / accountLines.length : documentTotal;
  return accountLines.map(({ id, account, value, line }) => {
    const total = value > 0 ? value : fallbackLineValue;
    const debit = isAccountingNote ? amount(document.debit) : total;
    const credit = isAccountingNote ? amount(document.credit) : total;
    return {
      id: `${document.id}:${id}`, documentNumber: document.number || '—', internalNumber: document.id,
      costCenter: line?.center || document.costCenter || '—', object: line?.object || document.objectProject || '',
      department: line?.department || document.departmentCode || '', employee: document.accountableResponsible || '',
      operationDate: document.operationDate || document.documentDate || '—', documentType: document.documentType || '—',
      documentSubtype: document.documentSubtype || '—', counterparty: document.clientCounterparty || '—',
      description: document.note || '', inactive: inactive(document), account, postingStatus: posted ? 'Posted' : 'Unposted',
      debit, credit, total: Math.max(debit, credit, total), accountActive: activeAccounts.has(account), posted,
      balanced: debit > 0 && credit > 0 && Math.abs(debit - credit) < 0.01, document,
    };
  });
}

/** Opening an approved source still uses its existing correction/approval workflow.
 * No source document is saved through the browser-only journal-draft store. */
export function journalEditTarget(context: {
  row: GlJournalRow; companyId: string; allowed: boolean; sourceMode: 'test' | 'company';
  savedEntry?: { id: string; inactive?: boolean }; sourceDocument?: Document;
}): 'journal' | 'document' | null {
  const { row, companyId, allowed, sourceMode, savedEntry, sourceDocument } = context;
  if (!allowed || row.inactive || row.reconciliationBatchId || row.assetOperationId) return null;
  if (savedEntry?.id === row.document.id) return savedEntry.inactive ? null : 'journal';
  if (sourceMode === 'test' && row.sample) return 'journal';
  return sourceDocument?.id === journalSourceDocumentId(row) && sourceDocument.companyId === companyId
    && !inactive(sourceDocument) && !sourceDocument.inlineSource.document_deletion ? 'document' : null;
}

export const journalSourceDocumentId = (row: GlJournalRow) => row.sourceDocumentId || row.document.id;

export function isJournalSourceChange(event: { type: string; key?: string | null; detail?: { table?: string } }) {
  if (event.type === 'storage') return event.key == null || event.key === 'finansu-harmonija-v4:data:documents';
  return event.type === 'finansu-harmonija:data-changed' && (!event.detail?.table || event.detail.table === 'documents');
}
