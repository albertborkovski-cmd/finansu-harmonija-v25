import { AUTH_SESSION_KEY, getCurrentUserIdentity } from './currentUser';
import { canEditMenu, isSystemAdministratorRole, parseSession } from './accessControl';
import { supabase, type Company, type DbDocument } from './supabase';
import { learnOcrDocument, applyLearnedOcrFields } from './ocrDocumentLearning';
import { OCR_SHARED_FIELDS, sharedDocumentField, documentCounterpartyCode, type OcrSharedField } from './documentSharedFields';
import {
  automaticLearningValue, confirmLearning, createLearningExamples, forgetLatestLearning, learnedRows, setLearningPaused, updateLearningRule,
  type LearningActor, type LearningContext, type LearningField, type LearningStore, type LearningRuleInput,
} from './ocrLearning';

export const OCR_LEARNING_KEY = 'finansu-harmonija:v19:ocr:supplier-learning';
export const OCR_LEARNING_CHANGED = 'finansu-harmonija:ocr-learning-changed';

export function loadLearningStore(strict = false): LearningStore {
  try {
    const raw = localStorage.getItem(OCR_LEARNING_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as LearningStore;
      if (parsed.version === 1 && Array.isArray(parsed.evidence) && parsed.controls && Array.isArray(parsed.audit)) return parsed;
      throw new Error('Unsupported learning history');
    }
  } catch (error) {
    // Never replace unreadable persisted history with fictional observations.
    if (strict) throw error;
    return { version: 1, evidence: [], controls: {}, audit: [] };
  }
  return createLearningExamples();
}

export function persistLearningStore(store: LearningStore) {
  localStorage.setItem(OCR_LEARNING_KEY, JSON.stringify(store));
  window.dispatchEvent(new CustomEvent(OCR_LEARNING_CHANGED));
}

export function learningPermissions() {
  const session = parseSession(localStorage.getItem(AUTH_SESSION_KEY));
  return { edit: Boolean(session && canEditMenu(session, 'ocr-machine-learning')),
    administrator: Boolean(session?.roleNames.some(isSystemAdministratorRole)) };
}

const actor = (): LearningActor => {
  const identity = getCurrentUserIdentity();
  return { name: identity.fullName, email: identity.email };
};

export function changeLearningState(rowId: string, action: 'pause' | 'resume' | 'forget'): boolean {
  const permissions = learningPermissions();
  if (!permissions.edit || (action === 'forget' && !permissions.administrator)) return false;
  const store = loadLearningStore(true);
  const row = learnedRows(store).find(item => item.id === rowId);
  if (!row) return false;
  const now = new Date().toISOString();
  const next = action === 'forget' ? forgetLatestLearning(store, rowId, actor(), now, permissions.administrator)
    : setLearningPaused(store, row, action === 'pause', actor(), now);
  persistLearningStore(next);
  return next !== store;
}

export function saveLearningRule(rowId: string, input: LearningRuleInput | null): void {
  if (!learningPermissions().edit) throw new Error('You do not have permission to edit learned values.');
  const store = loadLearningStore(true);
  const next = updateLearningRule(store, rowId, input, actor(), new Date().toISOString());
  if (next !== store) persistLearningStore(next);
}

export type DocumentLearningContext = LearningContext & {
  documentId: string; documentName: string; expenseAccount: string; vatClassifier: string;
  supplierCode?: string;
  values?: Partial<Record<OcrSharedField, string>>;
  explanations?: Partial<Record<LearningField, string>>;
};

export async function documentLearningContext(document: DbDocument, organization?: Company): Promise<DocumentLearningContext | undefined> {
  if (!document.company_id) return undefined;
  const result = organization?.id === document.company_id ? { data: [organization], error: null }
    : await supabase.from('companies').select('*').eq('id', document.company_id);
  if (result.error) throw result.error;
  const company = result.data?.[0];
  if (!company) return undefined;
  const supplierKey = document.counterparty_id?.trim() || (document.client_counterparty?.trim() ? `name:${document.client_counterparty.trim().toLocaleLowerCase()}` : '');
  if (!supplierKey) return undefined;
  return { companyId: document.company_id, companyName: String(company.name), supplierKey,
    supplierName: document.client_counterparty, supplierCode: documentCounterpartyCode(document), vatRate: sharedDocumentField(document, 'vat_percent'),
    documentId: document.id, documentName: document.file_case || document.number || document.id,
    expenseAccount: sharedDocumentField(document, 'expense_account'), vatClassifier: sharedDocumentField(document, 'vat_classifier'),
    values: Object.fromEntries((Object.keys(OCR_SHARED_FIELDS) as OcrSharedField[]).map(field => [field, sharedDocumentField(document, field)])) };
}

export function suggestDocumentAccounting(context: DocumentLearningContext): DocumentLearningContext {
  const store = loadLearningStore();
  const result = { ...context, explanations: { ...context.explanations } };
  for (const [field, property] of [['expense_account', 'expenseAccount'], ['vat_classifier', 'vatClassifier']] as const) {
    if (result[property]?.trim() && result[property] !== '—') continue;
    const row = automaticLearningValue(store, context, field);
    if (row) {
      result[property] = row.value;
      result.explanations[field] = row.rule
        ? `Suggested using a manual rule: ${row.confidence}% confidence · set by ${row.rule.changedBy.name}. Confirm to teach this document.`
        : `Suggested: ${Math.round(row.consistency * 100)}% consistent · ${row.count} of ${row.total} reviewed documents. Confirm to teach this document.`;
    } else {
      result[property] = '';
      result.explanations[field] = 'Requires review: no eligible learned value (at least 2 documents and 90% confidence; learning must not be paused).';
    }
  }
  return result;
}

export function confirmDocumentAccounting(context: DocumentLearningContext) {
  let store = loadLearningStore(true);
  const confirmedAt = new Date().toISOString();
  const values = { ...context.values, expense_account: context.expenseAccount, vat_classifier: context.vatClassifier };
  for (const [field, value] of Object.entries(values) as [LearningField, string][]) {
    if (!value.trim() || value === '—') continue;
    store = confirmLearning(store, { ...context, field, value, confirmedAt, confirmedBy: actor() });
  }
  persistLearningStore(store);
}

export function recordOcrDocumentLearning(document: object, company: object, source: 'review' | 'accountant' | 'addinfo') {
  const store = loadLearningStore(true);
  const next = learnOcrDocument(store, document, company, actor(), source, new Date().toISOString());
  if (next !== store) persistLearningStore(next);
}

export function suggestOcrDocumentFields<T extends object>(document: T, company: object): T {
  return applyLearnedOcrFields(loadLearningStore(), document, company);
}

export async function recordReviewedOcrDocuments(ids: string[]) {
  if (!ids.length) return;
  const result = await supabase.from('documents').select('*').in('id', ids);
  if (result.error) throw result.error;
  const contexts = await Promise.all(((result.data ?? []) as unknown as DbDocument[]).map(document => documentLearningContext(document)));
  contexts.forEach(context => { if (context) confirmDocumentAccounting(context); });
}
