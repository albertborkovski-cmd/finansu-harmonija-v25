/** Match within this editor only; repeated parties/lines prefer the invalid instance. */
export function focusOcrValidationTarget(root: HTMLElement, label?: string): boolean {
  const fields = Array.from(root.querySelectorAll<HTMLElement>('[data-ocr-field-label]'))
    .filter(field => !label || field.dataset.ocrFieldLabel === label);
  const field = fields.find(item => item.dataset.ocrValidation === 'missing') || fields[0];
  const target = field || root.querySelector<HTMLElement>('[data-preview-viewport]');
  if (!target) return false;
  let parent: HTMLElement | null = target.parentElement;
  while (parent && root.contains(parent)) {
    if (parent instanceof HTMLDetailsElement) parent.open = true;
    parent = parent.parentElement;
  }
  const input = target.querySelector<HTMLElement>('input:not([disabled]), textarea:not([disabled]), [role="combobox"], select:not([disabled])');
  (input || target).focus({ preventScroll: true });
  target.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'smooth' });
  return true;
}
