import type { WorkspaceTask, ProductLine } from '../components/WorkspaceView';
import type { DbDocument } from './supabase';
import type { OcrFieldValidationRule } from './ocrFieldValidation';
import { OCR_WORKSPACE_FIELD_KEYS, OCR_LINE_FIELD_KEYS, type OcrDocumentParty, ocrPartyIsCounterparty, ocrRulePartyId, ocrSavedPartyId } from './ocrFormSchema';
import { ocrDocumentFieldValue, ocrDocumentPartyPurpose } from './ocrRequiredFields';
import { isOcrInternalSupplierField } from './ocrAccountingFields';

export type OcrFieldScope = { party?: OcrDocumentParty; primary?: boolean; line?: ProductLine; purpose?: string };
export function ocrEditorValue(task: WorkspaceTask, document: Partial<DbDocument> | undefined, rule: OcrFieldValidationRule, scope: OcrFieldScope = {}): string {
  if (scope.line) {
    const key = OCR_LINE_FIELD_KEYS[rule.key as keyof typeof OCR_LINE_FIELD_KEYS];
    return String(key ? scope.line[key] : scope.line.ocrValues?.[rule.key] ?? '');
  }
  const key = scope.party ? rule.partyDataKey || rule.key : rule.key;
  if (scope.party) {
    const saved = scope.party.values[rule.key] ?? scope.party.values[key];
    if (saved !== undefined) return saved;
    if (!scope.primary || !ocrPartyIsCounterparty(rule, scope.purpose ?? ocrDocumentPartyPurpose(document))) return '';
  }
  const mapped = OCR_WORKSPACE_FIELD_KEYS[key as keyof typeof OCR_WORKSPACE_FIELD_KEYS];
  if (mapped) return task.fields[mapped] ?? '';
  if (rule.key === 'documentType') return task.documentType;
  if (key === 'counterpartyCode') return task.ocrFieldValues?.partyRegistrationCode ?? String(document?.counterparty_code || '');
  if (rule.key === 'glAccount') return task.accounting?.expenseAccount ?? String(document?.expense_account || '');
  if (rule.key === 'vatClassifier') return task.accounting?.vatClassifier ?? String(document?.vat_classifier || '');
  if (rule.key === 'advanceEmployee') return task.advanceEmployeeId ?? document?.advance_employee_id ?? '';
  return task.ocrFieldValues?.[key] ?? String(document ? ocrDocumentFieldValue(document, key) ?? '' : '');
}

export function updateOcrEditorValue(task: WorkspaceTask, rule: OcrFieldValidationRule, value: string, scope: OcrFieldScope = {}, parties: readonly OcrDocumentParty[] = [], rules: readonly OcrFieldValidationRule[] = [], document?: Partial<DbDocument>): WorkspaceTask {
  if (isOcrInternalSupplierField(rule)) return task;
  if (scope.line) {
    const key = OCR_LINE_FIELD_KEYS[rule.key as keyof typeof OCR_LINE_FIELD_KEYS];
    return { ...task, products: task.products.map(line => line.id !== scope.line!.id ? line
      : key ? { ...line, [key]: value } : { ...line, ocrValues: { ...line.ocrValues, [rule.key]: value } }) };
  }
  let next = task;
  const key = scope.party ? rule.partyDataKey || rule.key : rule.key;
  if (scope.party) {
    // Preserve configured-out roles too; hiding a field must never erase its saved values.
    const all = new Map((task.ocrParties || []).map(party => [party.id, party]));
    parties.forEach(party => { all.set(party.id, { ...party, values: all.get(party.id)?.values ?? party.values }); });
    all.set(scope.party.id, { ...scope.party, values: { ...scope.party.values, ...all.get(scope.party.id)?.values, [rule.key]: value } });
    next = { ...task, ocrParties: [...all.values()] };
    if (!scope.primary || !ocrPartyIsCounterparty(rule, scope.purpose ?? ocrDocumentPartyPurpose(document))) return next;
  }
  // Snapshot both sides before a direction change; never relabel the old supplier as the buyer.
  if (rule.key === 'documentPurpose' && rules.some(item => ['seller', 'buyer'].includes(item.partyBinding || ''))) {
    const previousPurpose = task.ocrFieldValues?.documentPurpose ?? ocrDocumentPartyPurpose(document);
    const currentParties = parties.map(party => ({ ...party, values: { ...party.values, ...task.ocrParties?.find(item => item.id === party.id)?.values } }));
    const saved = currentParties.map(party => ({ ...party, values: { ...party.values, ...Object.fromEntries(rules
      .filter(item => item.group === 'parties' && ocrRulePartyId(item) === ocrSavedPartyId(party))
      .map(item => [item.key, ocrEditorValue(task, document, item, { party, primary: currentParties.find(candidate => ocrSavedPartyId(candidate) === ocrSavedPartyId(party))?.id === party.id, purpose: previousPurpose })])) } }));
    const all = new Map((task.ocrParties || []).map(party => [party.id, party]));
    saved.forEach(party => all.set(party.id, party));
    next = { ...next, ocrParties: [...all.values()] };
    for (const item of rules.filter(item => item.group === 'parties' && ocrPartyIsCounterparty(item, value))) {
      const party = saved.find(candidate => ocrSavedPartyId(candidate) === ocrRulePartyId(item));
      const target = item.partyDataKey || item.key, nextValue = party?.values[item.key] ?? '';
      const field = OCR_WORKSPACE_FIELD_KEYS[target as keyof typeof OCR_WORKSPACE_FIELD_KEYS];
      if (field) next = { ...next, fields: { ...next.fields, [field]: nextValue } };
      if (target === 'counterpartyCode') next = { ...next, ocrFieldValues: { ...next.ocrFieldValues, partyRegistrationCode: nextValue } };
    }
  }
  const mapped = OCR_WORKSPACE_FIELD_KEYS[key as keyof typeof OCR_WORKSPACE_FIELD_KEYS];
  if (mapped) return { ...next, fields: { ...next.fields, [mapped]: value } };
  if (rule.key === 'documentType') return { ...next, documentType: value, trainingStatus: undefined, trainingConfirmedAt: undefined };
  const accountingKeys = { glAccount: 'expenseAccount', vatClassifier: 'vatClassifier' } as const;
  const accountingKey = accountingKeys[key as keyof typeof accountingKeys];
  if (accountingKey && next.accounting) return { ...next, accounting: { ...next.accounting, [accountingKey]: value,
    ...(rule.key === 'glAccount' || rule.key === 'vatClassifier' ? { explanations: { ...next.accounting.explanations, [rule.key === 'glAccount' ? 'expense_account' : 'vat_classifier']: undefined } } : {}) } };
  if (rule.key === 'advanceEmployee') return { ...next, advanceEmployeeId: value, advanceEmployee: '', ...(value ? { documentType: 'ADVANCE_INVOICE' } : {}) };
  if (scope.party && key === 'counterpartyCode') return { ...next, ocrFieldValues: { ...next.ocrFieldValues, partyRegistrationCode: value } };
  if (scope.party && key !== 'counterpartyCode') return next;
  return { ...next, ocrFieldValues: { ...next.ocrFieldValues, [key]: value } };
}
