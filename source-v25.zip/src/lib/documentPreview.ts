export type PreviewSize = { width: number; height: number };
export type PreviewFit = 'width' | 'page' | 'manual';
export const MIN_PREVIEW_ZOOM = 0.1;
export const MAX_PREVIEW_ZOOM = 4;

export function documentPreviewKind(url: string, filename = ''): 'pdf' | 'image' {
  if (/^data:image\//i.test(url)) return 'image';
  if (/^data:application\/pdf/i.test(url)) return 'pdf';
  return /\.(png|jpe?g|webp|gif|svg|avif|bmp)($|[?#])/i.test(url) || /\.(png|jpe?g|webp|gif|svg|avif|bmp)$/i.test(filename) ? 'image' : 'pdf';
}

export function clampPreviewZoom(value: number) {
  return Math.min(MAX_PREVIEW_ZOOM, Math.max(MIN_PREVIEW_ZOOM, Number.isFinite(value) ? value : 1));
}

export function rotatePreview(rotation: number, direction: -1 | 1) {
  return ((rotation + direction * 90) % 360 + 360) % 360;
}

/** Convert a pointer in rotated/scaled preview bounds back into document coordinates. */
export function documentPreviewPoint(x: number, y: number, size: PreviewSize, scale: number, rotation: number) {
  const px = x / scale, py = y / scale;
  switch (((rotation % 360) + 360) % 360) {
    case 90: return { x: py, y: size.height - px };
    case 180: return { x: size.width - px, y: size.height - py };
    case 270: return { x: size.width - py, y: px };
    default: return { x: px, y: py };
  }
}

/** Rotated bounds reserve real scrollable space, so no page edge is clipped. */
export function documentPreviewLayout(size: PreviewSize, available: PreviewSize, rotation: number, fit: PreviewFit, zoom: number) {
  const sideways = rotation % 180 !== 0;
  const width = Math.max(1, sideways ? size.height : size.width);
  const height = Math.max(1, sideways ? size.width : size.height);
  const widthScale = Math.max(1, available.width - 32) / width;
  const pageScale = Math.min(widthScale, Math.max(1, available.height - 32) / height);
  const scale = fit === 'manual' ? clampPreviewZoom(zoom) : Math.max(0.01, Math.min(MAX_PREVIEW_ZOOM, fit === 'width' ? widthScale : pageScale));
  return { scale, width: width * scale, height: height * scale };
}
