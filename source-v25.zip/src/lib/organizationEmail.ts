export type OrganizationEmailTemplate = {
  id: string;
  name: string;
  language: string;
  subject: string;
  body: string;
  active: boolean;
  purpose?: 'reminder' | 'balance-confirmation';
};

export type OrganizationEmailPartyDetails = {
  name: string;
  companyCode?: string;
  vatCode?: string;
  address?: string;
  email?: string;
  phone?: string;
};

export type OrganizationEmailHistoryEntry = {
  id: string;
  organizationId?: string;
  sentAt: string;
  sender: string;
  senderEmail?: string;
  senderDetails?: OrganizationEmailPartyDetails;
  recipient: string;
  recipientEmail: string;
  recipientDetails?: OrganizationEmailPartyDetails;
  templateName: string;
  language: string;
  subject: string;
  body: string;
  reconciliationDate: string;
  debtBalance: string;
  portalUrl: string;
  documentReference: string;
  responseReceivedAt?: string;
  responseDecision?: 'matches' | 'differs';
  resendOfId?: string;
  purpose?: 'reminder' | 'balance-confirmation';
  relatedDebtIds?: string[];
  deliveryStatus?: 'saved' | 'sent';
  balanceStatement?: import('./balanceConfirmation').BalanceStatement;
  attachBalancePdf?: boolean;
};

export type OrganizationEmailTemplateData = {
  sender: string;
  recipient: string;
  reconciliationDate: string;
  debtBalance: string;
  portalUrl: string;
  documentReference: string;
};

const TEMPLATE_KEY = 'finansu-harmonija:v12:organization-email-templates';
const HISTORY_KEY = 'finansu-harmonija:v12:organization-email-history';
const PORTAL_PREVIEW_KEY = 'finansu-harmonija:v12:debt-reconciliation-previews';

const DEFAULT_TEMPLATES: OrganizationEmailTemplate[] = [
  {
    id: 'debt-reconciliation-lt',
    name: 'Skolų suderinimas',
    language: 'LT',
    active: true,
    subject: 'Skolų suderinimas – {{sender}}',
    body: 'Sveiki, {{recipient}},\n\n{{sender}} prašo suderinti {{reconciliationDate}} dienos skolos likutį: {{debtBalance}}.\n\nDokumentą galite peržiūrėti ir patikslinti čia:\n{{portalUrl}}\n\nDokumento numeris: {{documentReference}}\n\nPagarbiai\n{{sender}}',
  },
  {
    id: 'debt-reconciliation-en',
    name: 'Debt reconciliation',
    language: 'EN',
    active: true,
    subject: 'Debt reconciliation – {{sender}}',
    body: 'Hello {{recipient}},\n\n{{sender}} asks you to reconcile the outstanding balance of {{debtBalance}} as of {{reconciliationDate}}.\n\nOpen the reconciliation document to review or update it:\n{{portalUrl}}\n\nDocument reference: {{documentReference}}\n\nKind regards\n{{sender}}',
  },
];

export type DebtEmailPurpose = 'reminder' | 'balance-confirmation';

const REMINDER_TEMPLATES: OrganizationEmailTemplate[] = [
  { id: 'debt-reminder-lt', name: 'Priminimas apie skolą', language: 'LT', active: true, purpose: 'reminder',
    subject: 'Priminimas apie mokėjimą – {{sender}}',
    body: 'Sveiki, {{recipient}},\n\nPrimename apie neapmokėtų dokumentų likutį {{reconciliationDate}}: {{debtBalance}}.\nDokumentai: {{documentReference}}.\n\nPrašome patikrinti ir apmokėti skolą arba informuoti mus, jei mokėjimas jau atliktas.\n\nPagarbiai\n{{sender}}' },
  { id: 'debt-reminder-en', name: 'Payment reminder', language: 'EN', active: true, purpose: 'reminder',
    subject: 'Payment reminder – {{sender}}',
    body: 'Hello {{recipient}},\n\nThis is a reminder of the outstanding balance as of {{reconciliationDate}}: {{debtBalance}}.\nDocuments: {{documentReference}}.\n\nPlease review and arrange payment, or let us know if payment has already been made.\n\nKind regards\n{{sender}}' },
];

/** Reuse company templates; supply purpose-specific defaults without modifying company settings. */
export function debtEmailTemplates(templates: OrganizationEmailTemplate[], purpose: DebtEmailPurpose, language: string) {
  const matches = (template: OrganizationEmailTemplate) => template.purpose === purpose || (!template.purpose &&
    (purpose === 'reminder' ? template.id.startsWith('debt-reminder-') : template.id.startsWith('debt-reconciliation-')));
  const active = templates.filter(template => template.active);
  const preferred = active.filter(matches);
  const defaults = purpose === 'reminder' ? REMINDER_TEMPLATES : DEFAULT_TEMPLATES;
  const available = preferred.length ? preferred : defaults.filter(template => !templates.some(saved => saved.id === template.id));
  const ordered = [...available].sort((a, b) => Number(b.language.toLowerCase() === language.toLowerCase()) - Number(a.language.toLowerCase() === language.toLowerCase()));
  return [...ordered, ...active.filter(template => !matches(template) && !template.purpose && !template.id.startsWith('debt-reconciliation-') && !template.id.startsWith('debt-reminder-'))];
}

function readArray<T>(key: string): T[] | null {
  if (typeof window === 'undefined') return null;
  try {
    const parsed = JSON.parse(window.localStorage.getItem(key) ?? 'null');
    return Array.isArray(parsed) ? parsed as T[] : null;
  } catch {
    return null;
  }
}

export function loadOrganizationEmailTemplates(organizationId?: string) {
  const defaults = readArray<OrganizationEmailTemplate>(TEMPLATE_KEY) ?? DEFAULT_TEMPLATES.map((template) => ({ ...template }));
  if (!organizationId) return defaults;
  const key = `${TEMPLATE_KEY}:company:${organizationId}`;
  const saved = readArray<OrganizationEmailTemplate>(key);
  if (saved !== null) return saved;
  // Copy legacy templates once; company changes never update the shared originals.
  if (typeof window !== 'undefined') window.localStorage.setItem(key, JSON.stringify(defaults));
  return defaults;
}

export function saveOrganizationEmailTemplates(templates: OrganizationEmailTemplate[], organizationId?: string) {
  const key = organizationId ? `${TEMPLATE_KEY}:company:${organizationId}` : TEMPLATE_KEY;
  window.localStorage.setItem(key, JSON.stringify(templates));
  window.dispatchEvent(new CustomEvent('organization-email-settings-updated', { detail: { organizationId } }));
}

export function loadOrganizationEmailHistory() {
  return readArray<OrganizationEmailHistoryEntry>(HISTORY_KEY) ?? [];
}

export function loadOrganizationEmailHistoryForOrganization(
  organizationId: string,
  organizationName: string,
) {
  const normalizedName = organizationName.trim().toLocaleLowerCase();
  return loadOrganizationEmailHistory().filter((entry) =>
    entry.organizationId
      ? entry.organizationId === organizationId
      : Boolean(normalizedName) &&
        entry.sender.trim().toLocaleLowerCase() === normalizedName,
  );
}

export function appendOrganizationEmailHistory(entry: OrganizationEmailHistoryEntry) {
  const history = [entry, ...loadOrganizationEmailHistory()];
  window.localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
  window.dispatchEvent(new CustomEvent('organization-email-history-updated'));
}

/** Save a prepared batch in one write; retrying the same IDs cannot duplicate messages. */
export function appendOrganizationEmailHistoryBatch(entries: OrganizationEmailHistoryEntry[]) {
  const ids = new Set(entries.map(entry => entry.id));
  if (ids.size !== entries.length) throw new Error('Duplicate message IDs.');
  const history = [...entries, ...loadOrganizationEmailHistory().filter(entry => !ids.has(entry.id))];
  window.localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
  window.dispatchEvent(new CustomEvent('organization-email-history-updated'));
}

export function saveDebtReconciliationPortalPreview(entry: OrganizationEmailHistoryEntry) {
  const previews = readArray<OrganizationEmailHistoryEntry>(PORTAL_PREVIEW_KEY) ?? [];
  const next = [entry, ...previews.filter((item) => item.portalUrl !== entry.portalUrl)];
  window.localStorage.setItem(PORTAL_PREVIEW_KEY, JSON.stringify(next));
}

export function loadDebtReconciliationPortalPreview(path: string) {
  const previews = readArray<OrganizationEmailHistoryEntry>(PORTAL_PREVIEW_KEY) ?? [];
  return previews.find((item) => {
    try {
      return new URL(item.portalUrl).pathname === path;
    } catch {
      return false;
    }
  });
}

export function markOrganizationEmailResponseReceived(
  entryId: string,
  responseReceivedAt: string,
  responseDecision?: 'matches' | 'differs',
) {
  const history = loadOrganizationEmailHistory().map((entry) =>
    entry.id === entryId ? { ...entry, responseReceivedAt, responseDecision } : entry,
  );
  window.localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
  window.dispatchEvent(new CustomEvent('organization-email-history-updated'));
}

export function renderOrganizationEmailTemplate(
  value: string,
  data: OrganizationEmailTemplateData,
) {
  return Object.entries(data).reduce(
    (result, [key, replacement]) => result.replaceAll(`{{${key}}}`, replacement || '—'),
    value,
  );
}

export function createDebtReconciliationPortalUrl(documentReference: string) {
  const safeReference = documentReference.trim().replace(/[^a-zA-Z0-9_-]+/g, '-') || crypto.randomUUID();
  return `${window.location.origin}/debt-reconciliation/${safeReference}-${crypto.randomUUID().slice(0, 8)}`;
}
