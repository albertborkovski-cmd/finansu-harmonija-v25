import { documentEditStateError, documentInlineEditError, documentInlinePatch, documentInlineSnapshot, documentInlineValue, isInlineDocumentField, type InlineDocumentSource } from './documentInlineEditing';
import { documentResponsibleOptions } from './documentResponsibleUsers';
import { hasBlockingDocumentIssue } from './documentIssues';
import type { LinkedDirectoryUser } from './linkedSettingsData';
import type { Company } from './supabase';

export const DOCUMENT_ASSIGNMENT_FIELDS = [
  { key: 'departmentCode', label: 'Department', lookup: 'department_code', config: 'department_codes' },
  { key: 'objectProject', label: 'Object / Project', lookup: 'object_project', config: 'objects' },
  { key: 'series', label: 'Series', lookup: 'series', config: 'document_series' },
  { key: 'costCenter', label: 'Center', lookup: 'cost_center', config: 'cost_centers' },
  { key: 'accountableResponsible', label: 'Accountable / Responsible person', lookup: null, config: null },
  { key: 'productGroup', label: 'Product group', lookup: 'product_group', config: 'product_groups' },
  { key: 'note', label: 'Note', lookup: null, config: null },
  { key: 'expenseAccount', label: 'Expense account', lookup: 'gl_account', config: null },
  { key: 'vatClassifier', label: 'VAT classifier', lookup: 'vat_class', config: null },
  { key: 'operationDate', label: 'Operation date', lookup: null, config: null },
  { key: 'seller', label: 'Seller', lookup: null, config: null },
  { key: 'buyer', label: 'Buyer', lookup: null, config: null },
  { key: 'vatRate', label: 'VAT %', lookup: null, config: null },
  { key: 'other', label: 'Other', lookup: null, config: null },
] as const;
export type DocumentAssignmentField = typeof DOCUMENT_ASSIGNMENT_FIELDS[number]['key'];
export type DocumentAssignmentValues = Partial<Record<DocumentAssignmentField, string>>;
export type DocumentAssignmentOption = { value: string; label: string; description?: string };
export type DocumentAssignmentOptions = Record<DocumentAssignmentField, DocumentAssignmentOption[]>;
export const ASSIGN_DOCUMENT_DATE = '__document_date__';
export const ASSIGN_RESTORE_PARTY = '__restore__';
export const ASSIGN_EMPTY = '__empty__';
export const DOCUMENT_EXPORT_ACTIONS = [
  { value: 'exported', label: 'Mark as exported' }, { value: 'not-exported', label: 'Mark as not exported' },
  { value: 'exclude', label: 'Exclude from export' }, { value: 'include', label: 'Include in export' },
] as const;
type Lookup = { type?: unknown; value?: unknown; inactive?: unknown; active?: unknown; is_active?: unknown; status?: unknown; company_status?: unknown };
const active = (row: Lookup) => ![true, 'true'].includes(row.inactive as boolean | string)
  && ![false, 'false'].includes(row.active as boolean | string) && ![false, 'false'].includes(row.is_active as boolean | string)
  && ![row.status, row.company_status].some(value => ['inactive', 'deactivated', 'blocked', 'deleted'].includes(String(value || '').toLowerCase()));

/** Company dimensions never leak into another company's list. */
export function documentAssignmentOptions(company: Company, lookups: readonly Lookup[], accounts: Array<{ code: string; name: string }>, vat: Array<{ code: string; description: string; active: boolean }>, companies: Company[] = [], users: LinkedDirectoryUser[] = []): DocumentAssignmentOptions {
  return Object.fromEntries(DOCUMENT_ASSIGNMENT_FIELDS.map(field => {
    if (field.key === 'seller' || field.key === 'buyer') return [field.key, companies.filter(row => active(row as unknown as Lookup)).map(row => ({ value: row.id, label: row.name, description: row.company_code })).sort((a, b) => a.label.localeCompare(b.label))];
    if (field.key === 'accountableResponsible') return [field.key, documentResponsibleOptions(users).filter(option => option.value)];
    if (field.key === 'other') return [field.key, [...DOCUMENT_EXPORT_ACTIONS]];
    const values = new Map<string, string>();
    if (field.key === 'expenseAccount') accounts.forEach(row => values.set(row.code, `${row.code} · ${row.name}`));
    else if (field.key === 'vatClassifier') vat.filter(row => row.active).forEach(row => values.set(row.code, row.description ? `${row.code} · ${row.description}` : row.code));
    else if (field.lookup) {
      if (field.config) {
        try {
          const config = JSON.parse(company[field.config] || '{}');
          if (Array.isArray(config.items)) config.items.filter(active).forEach((row: { code?: string; name?: string }) => {
            if (row.code?.trim()) values.set(row.code.trim(), row.name ? `${row.code.trim()} · ${row.name}` : row.code.trim());
          });
        } catch { /* Existing lookup records remain available for legacy settings. */ }
      }
      const scoped = lookups.filter(row => row.type === `${field.lookup}::company::${company.id}`);
      scoped.forEach(row => {
        const value = String(row.value || '').trim();
        if (!active(row)) values.delete(value);
        else if (value && !values.has(value)) values.set(value, value);
      });
    }
    return [field.key, [...values].map(([value, label]) => ({ value, label })).sort((a, b) => a.value.localeCompare(b.value, undefined, { numeric: true }))];
  })) as DocumentAssignmentOptions;
}

/** This snapshot also protects fields that are not editable inline in a table. */
export function documentAssignmentSnapshot(document: InlineDocumentSource) {
  return JSON.stringify({ inline: documentInlineSnapshot(document), extra: Object.fromEntries([
    'operation_date', 'document_date', 'invoice_contract_date', 'client_counterparty', 'counterparty_id', 'counterparty_code',
    'seller_company_id', 'seller_name', 'seller_code', 'buyer_company_id', 'buyer_name', 'buyer_code', 'assignment_original_parties',
    'line_items', 'vat_percent', 'vat', 'total_amount', 'amount_without_vat', 'amount_due', 'include_vat_in_debt',
    'manual_export_status', 'excluded_from_export', 'digitization_issues',
  ].map(key => [key, document[key] ?? null])) });
}

export function documentAssignmentError(document: InlineDocumentSource, field: DocumentAssignmentField, allowed: boolean) {
  if (isInlineDocumentField(field)) return documentInlineEditError(document, field, allowed, true);
  return !allowed ? 'You need View and Edit access to Documents and access to this company.' : documentEditStateError(document, true);
}

export function documentAssignmentValue(document: InlineDocumentSource, field: DocumentAssignmentField, owner?: Company): string {
  if (isInlineDocumentField(field)) return documentInlineValue(document, field);
  if (field === 'seller' || field === 'buyer') {
    const counterpartySide = field === (/^sale$/i.test(String(document.document_purpose || document.type || '')) ? 'buyer' : 'seller');
    return [document[`${field}_name`] ?? (counterpartySide ? document.client_counterparty : owner?.name),
      document[`${field}_code`] ?? (counterpartySide ? document.counterparty_code : owner?.company_code)].filter(Boolean).join(' · ');
  }
  if (field === 'other') return `${document.manual_export_status || 'Not exported'} · ${document.excluded_from_export ? 'Excluded from export' : 'Included in export'}`;
  return String(document[field === 'operationDate' ? 'operation_date' : 'vat_percent'] ?? '');
}

function assignmentDate(value: unknown): string {
  const text = String(value || '').trim().replace(/^(\d{2})\.(\d{2})\.(\d{4})$/, '$3-$2-$1');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(text) || !Number.isFinite(Date.parse(text)) || new Date(text).toISOString().slice(0, 10) !== text) throw new Error('Select a valid operation date.');
  return text;
}

function money(value: unknown): number {
  let text = String(value ?? '').trim().replace(/(?:[A-Z]{3}|€|\$|£)/g, '').replace(/\s/g, '');
  if (text.includes(',') && text.includes('.')) text = text.lastIndexOf(',') > text.lastIndexOf('.') ? text.replaceAll('.', '').replace(',', '.') : text.replaceAll(',', '');
  else text = text.replace(',', '.');
  if (!/^-?\d+(?:\.\d+)?$/.test(text) || !Number.isSafeInteger(Math.round(Number(text) * 100))) throw new Error('Complete the document line amounts before assigning VAT.');
  return Math.round(Number(text) * 100);
}

/** Product lines and accounting distributions are separate representations, not
 * additive totals. Keep both in sync, including split-allocation rounding. */
function vatPatch(document: InlineDocumentSource, value: string): Record<string, unknown> {
  const normalized = value.trim().replace(',', '.');
  if (!/^\d+(?:\.\d{1,4})?$/.test(normalized) || Number(normalized) > 100) throw new Error('Enter a VAT rate between 0 and 100.');
  const rate = Number(normalized), format = (cents: number) => (cents / 100).toFixed(2);
  const tax = (net: number) => Math.sign(net) * Math.round(Math.abs(net) * rate / 100);
  const update = (source: unknown) => {
    if (source == null) return [];
    if (!Array.isArray(source) || source.some(row => !row || typeof row !== 'object' || Array.isArray(row))) throw new Error('Complete the document line amounts before assigning VAT.');
    return source.map(row => { const net = money(row.subtotal), vat = tax(net);
      return { ...row, vatPct: String(rate), vat: format(vat), total: format(net + vat) }; });
  };
  const lines = update(document.line_items), allocations = update(document.summary_line_items);
  const primary = lines.length ? lines : allocations;
  const net = primary.length ? primary.reduce((sum, row) => sum + money(row.subtotal), 0) : money(document.amount_without_vat);
  const vat = primary.length ? primary.reduce((sum, row) => sum + money(row.vat), 0) : tax(net);
  if (lines.length && allocations.length) {
    if (allocations.reduce((sum, row) => sum + money(row.subtotal), 0) !== net) throw new Error('Accounting allocations do not match the document totals.');
    const difference = vat - allocations.reduce((sum, row) => sum + money(row.vat), 0);
    const last = allocations.at(-1)!;
    last.vat = format(money(last.vat) + difference); last.total = format(money(last.subtotal) + money(last.vat));
  }
  const debtLines = allocations.length ? allocations : lines;
  const debt = debtLines.length ? debtLines.reduce((sum, row) => sum + money(row.subtotal) + ((row.include_vat_in_debt ?? document.include_vat_in_debt) === false ? 0 : money(row.vat)), 0) : net + (document.include_vat_in_debt === false ? 0 : vat);
  return { vat_percent: String(rate), amount_without_vat: format(net), vat: format(vat), total_amount: format(net + vat), amount_due: format(debt),
    ...(lines.length ? { line_items: lines } : {}), ...(allocations.length ? { summary_line_items: allocations } : {}) };
}

function partyPatch(document: InlineDocumentSource, field: 'seller' | 'buyer', value: string, options: DocumentAssignmentOptions, owner?: Company) {
  const sale = /^sale$/i.test(String(document.document_purpose || document.type || ''));
  const counterpartySide = field === (sale ? 'buyer' : 'seller');
  const original = (document.assignment_original_parties || {}) as Record<string, Record<string, unknown>>;
  const existing: Record<string, unknown> = { [`${field}_company_id`]: document[`${field}_company_id`] ?? (counterpartySide ? document.counterparty_id : owner?.id) ?? '',
    [`${field}_name`]: document[`${field}_name`] ?? (counterpartySide ? document.client_counterparty : owner?.name) ?? '',
    [`${field}_code`]: document[`${field}_code`] ?? (counterpartySide ? document.counterparty_code : owner?.company_code) ?? '',
    ...(counterpartySide ? { client_counterparty: document.client_counterparty ?? '', counterparty_id: document.counterparty_id ?? '', counterparty_code: document.counterparty_code ?? '' } : {}) };
  if (value === ASSIGN_RESTORE_PARTY) return Object.fromEntries(Object.keys(existing).map(key => [key, original[field]?.[key] ?? existing[key]]));
  const selected = options[field].find(option => option.value === value);
  if (!selected) throw new Error('The selected company is no longer available.');
  return { [`${field}_company_id`]: selected.value, [`${field}_name`]: selected.label, [`${field}_code`]: selected.description || '',
    assignment_original_parties: { ...original, [field]: original[field] || existing },
    ...(counterpartySide ? { client_counterparty: selected.label, counterparty_id: selected.value, counterparty_code: selected.description || '' } : {}) };
}

export function commonDocumentAssignmentOptions(catalogs: DocumentAssignmentOptions[]): DocumentAssignmentOptions {
  return Object.fromEntries(DOCUMENT_ASSIGNMENT_FIELDS.map(({ key }) => [key,
    (catalogs[0]?.[key] || []).filter(option => catalogs.every(catalog => catalog[key].some(item => item.value === option.value))),
  ])) as DocumentAssignmentOptions;
}

/** Reuse the same allocation and lifecycle restrictions as direct list editing. */
export function documentBulkAssignmentPatch(document: InlineDocumentSource, values: DocumentAssignmentValues, expectedSnapshot: string, allowed: boolean, options: DocumentAssignmentOptions, owner?: Company) {
  const entries = Object.entries(values);
  if (!entries.length) throw new Error('Choose at least one field value to assign.');
  if (documentAssignmentSnapshot(document) !== expectedSnapshot) throw new Error('A selected document changed. Reopen the assignment window.');
  let current = document;
  let patch: Record<string, unknown> = {};
  for (const [key, value] of entries) {
    const field = DOCUMENT_ASSIGNMENT_FIELDS.find(item => item.key === key);
    if (!field || typeof value !== 'string') throw new Error('Choose a value from the available list.');
    const error = documentAssignmentError(current, field.key, allowed);
    if (error) throw new Error(error);
    let change: Record<string, unknown>;
    if (field.key === 'note') change = documentInlinePatch(current, 'note', value, documentInlineSnapshot(current), allowed, true);
    else if (field.key === 'operationDate') change = { operation_date: assignmentDate(value === ASSIGN_DOCUMENT_DATE ? current.document_date || current.invoice_contract_date : value) };
    else if (field.key === 'vatRate') change = vatPatch(current, value);
    else if (field.key === 'seller' || field.key === 'buyer') change = partyPatch(current, field.key, value, options, owner);
    else if (field.key === 'other') {
      if (!DOCUMENT_EXPORT_ACTIONS.some(option => option.value === value)) throw new Error('Choose an export action.');
      if (value === 'exported' && hasBlockingDocumentIssue(current)) throw new Error('Resolve the reported digitization issue before marking this document as exported.');
      change = value === 'exclude' || value === 'include' ? { excluded_from_export: value === 'exclude' } : { manual_export_status: value === 'exported' ? 'Exported' : 'Not exported' };
    } else if (field.key === 'accountableResponsible') {
      const person = options.accountableResponsible.find(option => option.value === value);
      if (!person && value !== ASSIGN_EMPTY) throw new Error('Select an active user from Settings → Internal Users → Users.');
      change = { accountable_responsible_id: person?.value || '', accountable_responsible: person?.label || '' };
    } else {
      if (!options[field.key].some(option => option.value === value)) throw new Error('The selected value is not available for every selected organization.');
      change = documentInlinePatch(current, field.key, value, documentInlineSnapshot(current), allowed, true);
    }
    patch = { ...patch, ...change };
    current = { ...current, ...change };
  }
  return patch;
}
