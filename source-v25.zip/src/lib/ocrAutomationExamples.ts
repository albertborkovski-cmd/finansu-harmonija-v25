import { createOcrFormExamples as baseExamples } from './ocrFormExamples';
import type { OcrFieldValidationRule } from './ocrFieldValidation';

export const OCR_FORM_EXAMPLES_BATCH = 'v25-ocr-document-rules-v1';
export const OCR_FORM_EXAMPLE_TYPES = [{ code: 'FH_TEST_AUTOMATION', fullName: 'Text rule invoice (test)', parentCode: '',
  description: 'Synthetic text rule test. Not for accounting.', country: '', status: 'Active' }];
export const OCR_FORM_EXAMPLE_CONFIGS: Record<string, OcrFieldValidationRule[]> = { FH_TEST_AUTOMATION: [
  { key: 'number', label: 'Document Number', group: 'document', order: 10, type: 'OCR', subtype: 'OCR', level: 'red', enabled: true },
  { key: 'documentDate', label: 'Document date', group: 'document', order: 20, type: 'OCR', subtype: 'OCR', level: 'red', enabled: true },
  { key: 'totalAmount', label: 'Total amount', group: 'financial', order: 10, type: 'OCR', subtype: 'OCR', level: 'red', enabled: true },
  { key: 'currency', label: 'Currency', group: 'financial', order: 20, type: 'OCR', subtype: 'OCR', level: 'red', enabled: true },
  { key: 'orderNo', label: 'Order number', group: 'additional', order: 10, type: 'OCR', subtype: 'OCR', level: 'yellow', enabled: true },
  { key: 'vatClassifier', label: 'VAT classifier', group: 'calculated', order: 10, type: 'OCR', subtype: 'OCR', level: 'green', enabled: true },
] };

/** Separate, idempotently appended fixture: no enabled rules or real data are created. */
export function createOcrFormExamples(companyId: string, organization: string, owner: { email: string; fullName: string }, at: string) {
  const base = baseExamples(companyId, organization, owner, at);
  const original = base.documents[0], saved = base.tasks[original.id];
  const id = `${companyId}:${OCR_FORM_EXAMPLES_BATCH}:TEXT`, date = at.slice(0, 10);
  const text = ['SYNTHETIC TEST — NOT FOR PAYMENT', 'Invoice number: TEST-RULE-001', `Date: ${date}`,
    'Seller: FH Test Supplier', `Buyer: ${organization}`, 'Total: 100.00 EUR', 'VAT note: str.42', 'Services under contract.'];
  const escape = (value: string) => value.replace(/[&<>]/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[char]!);
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="1050" viewBox="0 0 800 1050"><rect width="800" height="1050" fill="white"/><rect x="40" y="40" width="720" height="80" rx="8" fill="#EAF4F8"/>${text.map((value, index) => `<text x="55" y="${90 + index * 65}" font-family="Arial" font-size="${index ? 20 : 22}" fill="#10233A">${escape(value)}</text>`).join('')}</svg>`;
  const document = { ...original, id, file_case: 'OCR-RULE-STR42-TEST.svg', document_type: 'FH_TEST_AUTOMATION', document_subtype: '',
    status: 'Worker review', number: '', client_counterparty: 'FH Test Supplier', total_amount: '100.00', amount_without_vat: '100.00', vat: '0.00',
    ocr_text: text.join('\n'), ocr_values: {}, ocr_parties: [], vat_classifier: '', expense_account: '',
    image_url: `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`,
    notes: 'SYNTHETIC TEXT RULE TEST. Select Text rule invoice (test), VAT classifier, str.42 → PVM1. The invoice number is deliberately blank so the task remains available for testing.' };
  const task = { ...saved, id, name: document.file_case, documentType: document.document_type, sourceRunId: OCR_FORM_EXAMPLES_BATCH,
    status: 'Available' as const, description: 'Synthetic document text automation example', ocrFieldValues: {}, ocrParties: [],
    fields: { ...saved.fields, invoiceNumber: '', companyName: document.client_counterparty, totalAmount: '100.00' },
    accounting: { ...saved.accounting!, documentId: id, documentName: document.file_case, supplierName: document.client_counterparty, supplierCode: '', vatClassifier: '' } };
  return { documents: [document], tasks: { [id]: task } };
}
