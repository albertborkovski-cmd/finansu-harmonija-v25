import type { Company, DbDocument } from './supabase';
import { bankTransactionFromDocument } from './bankTransaction';
import { loadCompanyBankDocument } from './companyBankEditing';
import { loadInvoiceCounterparties } from './invoiceCreation';
import { bankProcessingStatusEditError } from './bankProcessingStatus';

export type BankMatchingDraft = { matchingPurpose: string; documentNo: string; counterpartyId: string };
export type BankMatchingDemo = {
  version: 1; companyId: string; documentId: string; revision: number; updatedAt: string;
  input: BankMatchingDraft; counterpartyName: string;
  suggestion: { documentNo: string; counterpartyName: string; amount: string; currency: string };
};
export const bankMatchingDemoKey = (companyId: string, documentId: string) =>
  `finansu-harmonija:v20:bank-matching-demo:${companyId}:${documentId}`;

export function readBankMatchingDemo(companyId: string, documentId: string): BankMatchingDemo | null {
  try {
    const value = JSON.parse(window.localStorage.getItem(bankMatchingDemoKey(companyId, documentId)) || 'null');
    if (!value || value.version !== 1 || value.companyId !== companyId || value.documentId !== documentId
      || !Number.isSafeInteger(value.revision) || value.revision < 1
      || typeof value.updatedAt !== 'string' || typeof value.counterpartyName !== 'string'
      || !['matchingPurpose', 'documentNo', 'counterpartyId'].every(key => typeof value.input?.[key] === 'string')
      || !['documentNo', 'counterpartyName', 'amount', 'currency'].every(key => typeof value.suggestion?.[key] === 'string')) return null;
    return value;
  } catch { return null; }
}

export function bankMatchingDefaults(record: DbDocument, company: Company): BankMatchingDraft {
  const original = bankTransactionFromDocument(record, company);
  return { matchingPurpose: original.paymentPurpose, documentNo: original.referenceNo, counterpartyId: original.counterpartyId };
}

export function prepareBankMatchingDemo(record: DbDocument, company: Company, draft: BankMatchingDraft,
  parties: Pick<Company, 'id' | 'name'>[], revision: number, now: string): BankMatchingDemo {
  const unavailable = bankProcessingStatusEditError(record, true);
  if (unavailable) throw new Error(unavailable);
  if (record.company_id !== company.id) throw new Error('The bank entry is no longer in this company.');
  if (!draft || Object.keys(draft).some(key => !['matchingPurpose', 'documentNo', 'counterpartyId'].includes(key))
    || typeof draft.matchingPurpose !== 'string' || draft.matchingPurpose.length > 5000
    || typeof draft.documentNo !== 'string' || draft.documentNo.length > 200
    || typeof draft.counterpartyId !== 'string' || draft.counterpartyId.length > 500) throw new Error('Check the matching data and try again.');
  const original = bankTransactionFromDocument(record, company);
  const party = parties.find(row => row.id === draft.counterpartyId);
  if (draft.counterpartyId !== original.counterpartyId && !party) throw new Error('Select a counterparty from this company.');
  const counterpartyName = party?.name || original.counterpartyName || '—';
  const input = { ...draft, matchingPurpose: draft.matchingPurpose.trim(), documentNo: draft.documentNo.trim() };
  // This is deliberately a presentation fixture, not a scoring / lookup / matching algorithm.
  return { version: 1, companyId: company.id, documentId: record.id, revision, updatedAt: now, input, counterpartyName,
    suggestion: { documentNo: input.documentNo || 'DEMO-INV-001', counterpartyName, amount: original.amount, currency: original.currency } };
}

/** Separate frontend-demo storage only. Never writes documents, bank_transaction, GL or reconciliation batches. */
export async function saveBankMatchingDemo(record: DbDocument, company: Company, draft: BankMatchingDraft, expectedRevision: number) {
  const fresh = await loadCompanyBankDocument(record.id, company.id); // rechecks current access and ownership
  if (JSON.stringify(bankTransactionFromDocument(fresh, company)) !== JSON.stringify(bankTransactionFromDocument(record, company)))
    throw new Error('The bank entry changed. Reopen matching data before saving.');
  const parties = loadInvoiceCounterparties(company.id).filter(row => !(row as unknown as { inactive?: boolean }).inactive
    && (row as unknown as { active?: boolean }).active !== false);
  const previous = readBankMatchingDemo(company.id, record.id);
  if ((previous?.revision || 0) !== expectedRevision) throw new Error('Matching data changed in another window. Close and reopen this form.');
  const next = prepareBankMatchingDemo(fresh, company, draft, parties, expectedRevision + 1, new Date().toISOString());
  window.localStorage.setItem(bankMatchingDemoKey(company.id, record.id), JSON.stringify(next));
  return next;
}
