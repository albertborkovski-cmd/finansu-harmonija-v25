import { createOcrFormExamples as originalExample, OCR_FORM_EXAMPLE_CONFIGS, OCR_FORM_EXAMPLE_TYPES } from './ocrAutomationExamples';
import { canEditAutomationRule, loadAutomationStore, saveAutomationRule, type AutomationRule } from './ocrAutomationRules';
import type { DbDocument } from './supabase';
import type { WorkspaceTask } from '../components/WorkspaceView';
export { OCR_FORM_EXAMPLE_CONFIGS, OCR_FORM_EXAMPLE_TYPES };
export const OCR_FORM_EXAMPLES_BATCH = 'v25-ocr-document-rules-workflow-v2';

/** Repair only untouched v2 test originals, never a user's clear/correction or v1. */
export function automationExampleTaxRateUpgrade(document: DbDocument, task?: WorkspaceTask) {
  if (!document.id.startsWith(`${document.company_id}:${OCR_FORM_EXAMPLES_BATCH}:`) || document.entry_method !== 'ocr'
    || !['Worker review', 'Processing'].includes(document.status) || document.accounting_posting || document.document_deletion
    || document.ocr_approval_route || document.ocr_rerun_request || document.digitization_issues?.length
    || !task || task.sourceRunId !== OCR_FORM_EXAMPLES_BATCH || task.savedAt || task.editStartedAt || task.lastCorrectedAt
    || document.vat_percent !== '' || task.fields.taxRate !== '') return null;
  return { document: { ...document, vat_percent: '0' }, task: { ...task, fields: { ...task.fields, taxRate: '0' } } };
}

export type AutomationExampleTaskRepairs = Record<string, { before: WorkspaceTask; after: WorkspaceTask }>;
/** Merge against the latest store after the document write; a newer draft wins. */
export function mergeAutomationExampleTaskRepairs(current: Record<string, WorkspaceTask>, repairs: AutomationExampleTaskRepairs) {
  let next = current;
  for (const [id, repair] of Object.entries(repairs)) {
    if (!current[id] || JSON.stringify(current[id]) !== JSON.stringify(repair.before)) continue;
    if (next === current) next = { ...current };
    next[id] = repair.after;
  }
  return next;
}

export function demoAutomationRules(companyId: string, at: string): AutomationRule[] {
  const base: AutomationRule = { id: '', name: '', documentType: 'FH_TEST_AUTOMATION', organizationId: companyId, fieldKey: 'vatClassifier',
    conditionText: 'FH-DEMO-ASSIGN str.42', match: 'contains', action: 'assign', value: 'PVM1', enabled: true, overwrite: false, updatedAt: at };
  return [
    { ...base, id: `${companyId}:${OCR_FORM_EXAMPLES_BATCH}:assign`, name: 'TEST · str.42 → PVM1' },
    { ...base, id: `${companyId}:${OCR_FORM_EXAMPLES_BATCH}:required`, name: 'TEST · Required order number', fieldKey: 'orderNo', conditionText: 'FH-DEMO-REQUIRED', action: 'required', value: '' },
    { ...base, id: `${companyId}:${OCR_FORM_EXAMPLES_BATCH}:expected`, name: 'TEST · Expected PVM1', conditionText: 'FH-DEMO-EXPECTED', action: 'equals' },
  ];
}

/** Dedicated synthetic subtype and accessible organization only. Never restore disabled/deleted examples. */
export function ensureDemoAutomationRules(companyId: string, at: string): void {
  for (const rule of demoAutomationRules(companyId, at)) {
    if (!canEditAutomationRule(rule)) throw new Error('You do not have permission to create the scoped OCR test rules.');
    const store = loadAutomationStore(true);
    if (store.rules.some(existing => existing.id === rule.id) || store.history.some(entry => entry.after.id === rule.id)) continue;
    saveAutomationRule(rule);
  }
}

export function createOcrFormExamples(companyId: string, organization: string, owner: { email: string; fullName: string }, at: string) {
  const base = originalExample(companyId, organization, owner, at), original = base.documents[0], task = base.tasks[original.id];
  const scenarios = [
    { key: 'ASSIGN', note: 'VAT note: FH-DEMO-ASSIGN str.42', classifier: '', number: '', title: 'Automatic PVM1 assignment' },
    { key: 'NO-MATCH', note: 'VAT note: str.43', classifier: '', number: '', title: 'No matching text rule' },
    { key: 'REQUIRED', note: 'FH-DEMO-REQUIRED. Services under contract.', classifier: '', number: 'TEST-RULE-REQUIRED', title: 'Missing order number' },
    { key: 'EXPECTED', note: 'FH-DEMO-EXPECTED. Recorded VAT classifier: PVM2.', classifier: 'PVM2', number: 'TEST-RULE-EXPECTED', title: 'VAT classifier must be PVM1' },
  ];
  const documents = scenarios.map(scenario => {
    const id = `${companyId}:${OCR_FORM_EXAMPLES_BATCH}:${scenario.key}`;
    const text = ['SYNTHETIC TEST — NOT FOR PAYMENT', `Invoice number: TEST-RULE-${scenario.key}`, `Date: ${at.slice(0, 10)}`,
      'Seller: FH Test Supplier', `Buyer: ${organization}`, 'Total: 100.00 EUR', scenario.note, ...(scenario.key === 'REQUIRED' ? ['Order number: TEST-ORDER-042'] : [])];
    const escape = (value: string) => value.replace(/[&<>]/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[char]!);
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="1050" viewBox="0 0 800 1050"><rect width="800" height="1050" fill="white"/><rect x="40" y="40" width="720" height="80" rx="8" fill="#EAF4F8"/>${text.map((value, index) => `<text x="55" y="${90 + index * 65}" font-family="Arial" font-size="${index ? 20 : 22}" fill="#10233A">${escape(value)}</text>`).join('')}</svg>`;
    return { ...original, id, file_case: `OCR-RULE-${scenario.key}-TEST.svg`, number: scenario.number, vat_classifier: scenario.classifier, vat_percent: '0',
      ocr_text: text.join('\n'), ocr_values: { vatClassifier: scenario.classifier, orderNo: '' },
      image_url: `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`,
      notes: `SYNTHETIC OCR AUTOMATION TEST: ${scenario.title}. Not for accounting.` };
  });
  const tasks = Object.fromEntries(documents.map((document, index) => [document.id, { ...task, id: document.id, name: document.file_case,
    sourceRunId: OCR_FORM_EXAMPLES_BATCH, description: scenarios[index].title, ocrFieldValues: document.ocr_values,
    fields: { ...task.fields, invoiceNumber: document.number, taxRate: '0' },
    accounting: { ...task.accounting!, documentId: document.id, documentName: document.file_case, vatClassifier: document.vat_classifier },
  }]));
  return { documents, tasks };
}
