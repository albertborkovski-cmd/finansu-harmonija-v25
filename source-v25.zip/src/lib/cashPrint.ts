import { cashAmount, cashBook, cashTotal, type CashDocument, type CashStore } from './cash';

export type CashPrintReport = {
  title: string;
  company: string;
  details: [string, string][];
  columns: string[];
  rows: string[][];
  footer: string;
};

export function cashDocumentReport(document: CashDocument, store: CashStore, company: string): CashPrintReport {
  const account = store.accounts.find(row => row.id === document.accountId);
  return {
    title: `${document.kind} · ${document.number}`, company,
    details: [['Status', document.status], ['Date', document.date], ['Cash account', account?.name || '—'], ['Counterparty', document.counterparty], ['Purpose', document.purpose], ['Currency', document.currency]],
    columns: ['GL account', 'Description', 'Related document', 'Amount'],
    rows: document.lines.map(line => [line.account, line.description || document.purpose, line.relatedDocumentNumber || '—', cashAmount(line.amountMinor)]),
    footer: `Total: ${cashAmount(cashTotal(document))} ${document.currency}\nCashier: ${document.cashier || '—'}\nAccountant: ${document.accountant || '—'}\nNotes: ${document.notes || '—'}`,
  };
}

export function cashBookReport(store: CashStore, accountId: string, from: string, to: string, company: string): CashPrintReport {
  const book = cashBook(store, accountId, from, to);
  const account = store.accounts.find(row => row.id === accountId)!;
  return {
    title: 'Cash book', company,
    details: [['Period', `${from} — ${to}`], ['Cash account', `${account.code} · ${account.name}`], ['GL account', account.glAccount], ['Currency', account.currency], ['Opening balance', cashAmount(book.opening)]],
    columns: ['Date', 'Document No.', 'Counterparty / purpose', 'Income', 'Expense', 'Balance'],
    rows: book.rows.map(row => [row.document.date, row.document.number, `${row.document.counterparty} · ${row.document.purpose}`, cashAmount(row.income), cashAmount(row.expense), cashAmount(row.balance)]),
    footer: `Income: ${cashAmount(book.income)} ${account.currency}\nExpense: ${cashAmount(book.expense)} ${account.currency}\nClosing balance: ${cashAmount(book.closing)} ${account.currency}`,
  };
}
