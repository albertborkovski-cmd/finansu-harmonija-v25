import type { Company } from './supabase';
import type { LedgerAccount } from '../components/GeneralLedgerView';
import { companyCounterpartiesKey } from './organizationDirectory';

/** Never falls back to the global directory or another company's counterparties. */
export function loadOrganizationCounterparties(companyId: string, storage: Pick<Storage, 'getItem'> = window.localStorage): Company[] {
  if (!companyId) return [];
  const rows: unknown = JSON.parse(storage.getItem(companyCounterpartiesKey(companyId)) || '[]');
  if (!Array.isArray(rows)) throw new Error('Could not load organization counterparties.');
  return rows.filter((row): row is Company => Boolean(row && typeof row === 'object' && typeof row.id === 'string' && typeof row.name === 'string'))
    .sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' }));
}

export function organizationLedgerRows(accounts: LedgerAccount[], collapsed: ReadonlySet<string>, query: string) {
  const ordered = [...accounts].sort((a, b) => a.code.localeCompare(b.code, undefined, { numeric: true }));
  const byCode = new Map(ordered.map(account => [account.code, account]));
  const children = new Map<string, LedgerAccount[]>();
  for (const account of ordered) if (account.parentCode && byCode.has(account.parentCode) && account.parentCode !== account.code) {
    const siblings = children.get(account.parentCode) || [];
    siblings.push(account); children.set(account.parentCode, siblings);
  }
  const needle = query.trim().toLocaleLowerCase(), matches = new Set<string>();
  if (needle) for (const account of ordered) {
    if (!`${account.code} ${account.name} ${account.type} ${account.expenseType || ''} ${(account.alternativeCodes || []).join(' ')} ${account.costCenter || ''}`.toLocaleLowerCase().includes(needle)) continue;
    let current: LedgerAccount | undefined = account;
    const chain = new Set<string>();
    while (current && !chain.has(current.id)) {
      chain.add(current.id); matches.add(current.id); current = byCode.get(current.parentCode || '');
    }
  }
  const result: Array<{ account: LedgerAccount; depth: number; hasChildren: boolean }> = [], visited = new Set<string>();
  const visit = (account: LedgerAccount, depth: number, visible = true) => {
    if (visited.has(account.id)) return;
    visited.add(account.id);
    const descendants = children.get(account.code) || [];
    if (visible && (!needle || matches.has(account.id))) result.push({ account, depth, hasChildren: descendants.length > 0 });
    descendants.forEach(child => visit(child, depth + 1, visible && (Boolean(needle) || !collapsed.has(account.id))));
  };
  ordered.filter(account => !account.parentCode || !byCode.has(account.parentCode) || account.parentCode === account.code).forEach(account => visit(account, 0));
  ordered.forEach(account => { if (!visited.has(account.id)) visit(account, 0); });
  return result;
}
