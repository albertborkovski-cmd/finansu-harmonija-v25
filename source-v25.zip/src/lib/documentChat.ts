import { canEditMenu, canViewMenu } from './accessControl';
import { documentIssueSession } from './documentIssueAccess';
import { canAccessAssignedOrganization } from './linkedSettingsData';
import { chatWorkerRecipients } from './newChat';
import { supabase, type Company, type DbDocument } from './supabase';
import { invoiceChatPersistenceKey, loadChatConversations, registerChatConversation, type InvoiceChatContext } from '../components/invoices/invoiceChat';

export function documentConversationMatches(context: InvoiceChatContext, document: DbDocument, company: Company, documents: readonly DbDocument[]) {
  if (context.organizationId ? context.organizationId !== company.id : context.companyName !== company.name) return false;
  if (context.relatedObject) return ['Document', 'Invoice'].includes(context.relatedObject.type)
    && context.relatedObject.id === document.id && context.relatedObject.organizationId === company.id;
  // Old conversations used numbers. Do not mix histories of duplicate numbers.
  if (context.sourceType !== 'Document' || !context.subject) return false;
  const matches = documents.filter(row => row.company_id === company.id && [row.number, row.file_case].includes(context.subject!));
  return matches.length === 1 && matches[0].id === document.id;
}
export async function loadDocumentConversationData(documentId: string, companyId: string) {
  const [docs, companies] = await Promise.all([supabase.from('documents').select('*').eq('company_id', companyId), supabase.from('companies').select('*').eq('id', companyId)]);
  const session = documentIssueSession();
  const company = companies.data?.[0] as unknown as Company | undefined;
  const documents = (docs.data || []) as unknown as DbDocument[];
  const document = documents.find(row => row.id === documentId);
  if (docs.error || companies.error || !session || !company || !document || !canAccessAssignedOrganization(company, session)
    || !canViewMenu(session, 'messages') || !['documents', 'dashboard', 'ocr-workspace', 'ocr-workspace-my-tasks', 'ocr-workspace-document-issues', 'ocr-ml'].some(menu => canViewMenu(session, menu)))
    throw new Error('You do not have access to this document conversation.');
  const registered = loadChatConversations();
  const subject = document.number || document.file_case;
  const legacyKey = `${company.name}:${subject}`;
  const legacy: InvoiceChatContext = { storageKey: legacyKey, companyName: company.name, organizationId: company.id,
    title: `${company.name} / ${subject}`, subject, sourceType: 'Document', workspace: 'ocr' };
  const candidates = registered.some(context => context.storageKey === legacyKey) ? registered : [...registered, legacy];
  const contexts = candidates.filter(context => documentConversationMatches(context, document, company, documents))
    .filter(context => context.createdByEmail ? [context.createdByEmail, context.recipientEmail].some(email => email?.toLowerCase() === session.email.toLowerCase())
      : Boolean(window.localStorage.getItem(invoiceChatPersistenceKey(context.storageKey))));
  return { document, company, session, contexts };
}
export async function createDocumentConversation(documentId: string, companyId: string, recipientId: string) {
  const { document, company, session, contexts } = await loadDocumentConversationData(documentId, companyId);
  if (!canEditMenu(session, 'messages')) throw new Error('You do not have permission to start a chat.');
  const recipient = recipientId === 'fh-ai' ? { id: 'fh-ai', name: 'FH AI', email: undefined }
    : chatWorkerRecipients(company, session.email).find(person => person.id === recipientId);
  if (!recipient) throw new Error('Select a participant assigned to this organization.');
  const existing = contexts.find(context => context.recipientId === recipient.id && context.createdByEmail?.toLowerCase() === session.email.toLowerCase());
  if (existing) return existing;
  const subject = document.number || document.file_case || document.id;
  const context: InvoiceChatContext = { workspace: 'ocr', storageKey: `document-chat:${company.id}:${document.id}:${crypto.randomUUID()}`,
    title: `${company.name} / ${subject}`, companyName: company.name, organizationId: company.id, subject, sourceType: 'Document',
    recipientId: recipient.id, recipientEmail: recipient.email, recipientName: recipient.name,
    createdByEmail: session.email, createdByName: session.fullName, participantType: recipient.id === 'fh-ai' ? 'FH AI' : 'Worker', aiEnabled: recipient.id === 'fh-ai',
    relatedObject: { id: document.id, organizationId: company.id, type: 'Document', label: subject } };
  registerChatConversation(context);
  return context;
}
export async function validateDocumentConversationSend(documentId: string, companyId: string, storageKey: string) {
  const { session, contexts } = await loadDocumentConversationData(documentId, companyId);
  if (!canEditMenu(session, 'messages') || !contexts.some(context => context.storageKey === storageKey)) throw new Error('You no longer have access to send to this conversation.');
}
