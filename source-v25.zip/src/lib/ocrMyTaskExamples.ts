import type { WorkspaceTask } from '../components/WorkspaceView';
import type { DbDocument } from './supabase';
import { exampleInvoiceImage } from './ocrVisualExamples';

export const MY_TASK_EXAMPLES_BATCH = 'v22-ocr-my-tasks-v1';
export const WORKSPACE_DOCUMENT_TASKS_KEY = 'finansu-harmonija:v12:workspace:review-document-tasks';

/** Replace only the untouched synthetic contract-classification scenario requested
 * by the user. Real documents, corrected fields and workflow history are not reset. */
export function missingInvoiceNumberExampleUpgrade(document: DbDocument, task?: WorkspaceTask) {
  if (document.id !== `${document.company_id}:v20-document-testing-v1:017`
    || document.created_by !== 'V20 test data' || document.file_case !== 'TEST-V20-017.pdf'
    || !['Draft', 'Processing', 'Worker review'].includes(document.status)
    || document.entry_method === 'manual' || document.accounting_posting || document.document_deletion
    || document.ocr_approval_route || document.ocr_rerun_request || document.digitization_issues?.length
    || task?.savedAt || task?.lastCorrectedAt || task?.trainingStatus || task?.teamLeadReview
    || (task && task.fields.invoiceNumber !== document.number)) return null;
  const legacy = document.document_type === 'CONTRACTS' && document.document_subtype === 'SERVICE_CONTRACT'
    && document.number === 'TEST-V20-017';
  const fresh = document.document_type === 'INVOICES' && document.document_subtype === 'VAT_INVOICE'
    && document.number === '' && !document.image_url;
  if (!legacy && !fresh) return null;
  const original = { ...document, number: 'TEST-V20-017', document_type: 'INVOICES', document_subtype: 'VAT_INVOICE' };
  return { document: { ...document, number: '', document_type: 'INVOICES', document_subtype: 'VAT_INVOICE',
    status: 'Worker review', document_purpose: '',
    image_url: exampleInvoiceImage(original, 'Alice Stone') },
    task: task ? { ...task, documentType: 'VAT_INVOICE', fields: { ...task.fields, invoiceNumber: '' } } : undefined };
}

const examples = [
  { party: 'Baltic Office UAB', item: 'Office stationery', net: 186.50, qty: 5, side: 'Purchase' },
  { party: 'Amber Technology UAB', item: 'Computer accessories', net: 1458.99, qty: 3, side: 'Purchase' },
  { party: 'City Property UAB', item: 'Office rent', net: 2400, qty: 1, side: 'Purchase' },
  { party: 'Northwind Services UAB', item: 'Accounting services', net: 1250, qty: 1, side: 'Sale' },
  { party: 'Atlantic Cloud Ltd', item: 'Cloud subscription', net: 328.90, qty: 2, side: 'Purchase', currency: 'USD', vat: 0 },
  { party: 'London Software Ltd', item: 'Software licence', net: 549.99, qty: 1, side: 'Purchase', currency: 'GBP', vat: 0 },
  { party: 'River Transport UAB', item: 'Delivery service', net: 620, qty: 4, side: 'Purchase' },
  { party: 'Green Energy UAB', item: 'Electricity', net: 189.32, qty: 1, side: 'Purchase' },
  { party: 'Sunrise Projects UAB', item: 'Project advance', net: 3000, qty: 1, side: 'Sale', subtype: 'VAT_ADVANCE_INVOICE' },
  { party: 'Horizon Partners Ltd', item: 'Consulting services', net: 1845.75, qty: 5, side: 'Sale', currency: 'USD', vat: 0 },
  { party: 'Warehouse Supply UAB', item: 'Returned office equipment', net: -72.50, qty: 1, side: 'Purchase', subtype: 'CREDIT_INVOICE' },
  { party: 'Studio Partners UAB', item: 'Design services', net: 780, qty: 2, side: 'Sale', subtype: 'INVOICE' },
];

/** Synthetic fixtures only. Stable identities and separate saved tasks retain
 * normal assignment, editing, completion and review-queue behaviour. */
export function createOcrMyTaskExamples(companyId: string, owner: { email: string; fullName: string }, at: string, incomplete = true) {
  if (!companyId.trim() || !owner.email.trim() || !Number.isFinite(Date.parse(at))) throw new Error('A company, worker and valid date are required.');
  const tasks: Record<string, WorkspaceTask> = {};
  const documents = examples.map((example, index): DbDocument => {
    const sequence = String(index + 1).padStart(3, '0');
    const id = `${companyId}:${MY_TASK_EXAMPLES_BATCH}:${sequence}`;
    const number = `OCR-${sequence}`;
    const received = new Date(Date.parse(at) - index * 36e5).toISOString();
    const date = received.slice(0, 10);
    const due = new Date(Date.parse(received) + 30 * 864e5).toISOString().slice(0, 10);
    const currency = example.currency ?? 'EUR', rate = example.vat ?? 21;
    const vat = Math.round(example.net * rate) / 100;
    const total = (example.net + vat).toFixed(2);
    const expense = example.side === 'Purchase' ? '6300' : '5000';
    const line = {
      id: `${id}:line`, systemId: `OCR-${sequence}-01`, barcode: '', product: example.item,
      productGroup: index < 2 || index === 10 ? 'Products' : 'Services', unit: 'pcs', qty: String(example.qty),
      code: `ITEM-${sequence}`, price: (example.net / example.qty).toFixed(2), subtotal: example.net.toFixed(2),
      discount: '0.00', vat: vat.toFixed(2), vatPct: `${rate}%`, total,
      department: example.side === 'Sale' ? 'Sales' : 'Administration', object: '', series: 'OCR', center: 'Office',
      expense, vatClass: rate ? 'PVM1' : 'PVM5',
    };
    tasks[id] = {
      id, name: `${number}.pdf`, priority: index % 3 + 1, description: example.item,
      status: 'In Progress', createdBy: owner.fullName, assignedToEmail: owner.email.trim().toLowerCase(),
      assignedToName: owner.fullName, assignedAt: received, creationDate: received,
      documentType: 'INVOICES', sourceRunId: MY_TASK_EXAMPLES_BATCH,
      fields: { invoiceNumber: number, invoiceDate: date, dueDate: due, companyName: example.party,
        streetAddress: '', city: '', zipCode: '', phoneNumber: '', email: '', taxRate: String(rate),
        discountRate: '0', totalDiscount: '0.00', totalAmount: total },
      products: [{ id: `${id}:product`, name: example.item, description: example.item, quantity: String(example.qty), price: line.price }],
      comments: [],
    };
    const document: DbDocument = {
      id, company_id: companyId, number, file_case: `${number}.pdf`, receive_date: date,
      client_counterparty: example.party, counterparty_code: `DEMO-OCR-${sequence}`, document_type: 'INVOICES', document_subtype: example.subtype ?? 'VAT_INVOICE',
      source: index % 2 ? 'Email' : 'Upload', type: example.side, document_purpose: example.side,
      status: index % 3 === 0 ? 'Correcting' : 'Pending', document_date: date, operation_date: date,
      invoice_contract_date: date, due_end_date: due, order_no: `PO-2026-${sequence}`, valid_form: '', currency,
      amount_without_vat: example.net.toFixed(2), vat: vat.toFixed(2), total_amount: total, vat_percent: `${rate}%`,
      expense_account: expense, vat_classifier: line.vatClass, department_code: line.department,
      object_project: '', cost_center: line.center, series: 'OCR', accountable_responsible: '',
      created_by: owner.fullName, created_at: received, image_url: null, notes: '',
      line_items: [line], summary_line_items: [{ ...line }],
    };
    if (incomplete) {
      document.status = 'Worker review';
      document.image_url = exampleInvoiceImage(document, 'Alice Stone');
      const field = index % 3;
      if (field === 0) { document.number = ''; tasks[id].fields.invoiceNumber = ''; }
      if (field === 1) { document.document_date = ''; tasks[id].fields.invoiceDate = ''; }
      if (field === 2) { document.client_counterparty = ''; tasks[id].fields.companyName = ''; }
    }
    return document;
  });
  return { documents, tasks };
}

/** Upgrade only untouched synthetic examples. Never clear a value entered by a worker. */
export function missingFieldExampleUpgrade(document: DbDocument, task: WorkspaceTask | undefined, original: DbDocument,
  originalTask: WorkspaceTask, replacement: DbDocument, replacementTask: WorkspaceTask) {
  if (!task || task.savedAt || task.lastCorrectedAt || task.trainingStatus || task.teamLeadReview || document.document_deletion
    || document.ocr_approval_route || document.ocr_rerun_request || document.digitization_issues?.length
    || task.status !== originalTask.status || JSON.stringify(task.fields) !== JSON.stringify(originalTask.fields)
    || Object.keys(original).some(key => JSON.stringify(document[key as keyof DbDocument]) !== JSON.stringify(original[key as keyof DbDocument]))) return null;
  return { document: { ...document, number: replacement.number, document_date: replacement.document_date,
    client_counterparty: replacement.client_counterparty, image_url: replacement.image_url },
    task: { ...task, fields: { ...replacementTask.fields } } };
}

/** Only add missing task drafts. Never reset edits, assignments or completion. */
export function mergeOcrExampleTasks(existing: Record<string, WorkspaceTask>, additions: Record<string, WorkspaceTask>) {
  return { ...additions, ...existing };
}
