import { isSystemAdministratorRole, parseSession } from './accessControl';
import { AUTH_SESSION_KEY } from './currentUser';
import type { HelpText } from './exportHelpGuide';
import { latvianAccountingSystem } from './latvianAccountingSystems';
import { EXPORT_FORMAT_SCHEMAS } from './exportFormatSchemas';

export const HELP_CONTENT_KEY = 'finansu-harmonija:help-content:v1';
export const HELP_CONTENT_EVENT = 'finansu-harmonija:help-content-changed';
export const DEFAULT_VISIBLE_ACCOUNTING_HELP_GROUPS = ['agnum', 'bss', 'rivile', 'rivile-erp', 'site-pro', 'moneo', 'jumis', 'horizon', 'zalktis'];
export const DEFAULT_HIDDEN_HELP_GROUPS = ['apskaita5', 'business-central', 'centas', 'debetas', 'dineta', 'finvalda', 'monet', 'optimum', 'paulita', 'pragma', 'saikas', 'syrve', 'other-integrations'];
export type EditableHelpArticle = { key: string; href: string; category: string; title: HelpText; description: HelpText; body: HelpText; custom?: boolean; parentKey?: string; order?: number };
export type EditableHelpCategory = { id: string; title: HelpText; description: HelpText };
export type HelpContentState = {
  version: 1; revision: number;
  articles: Record<string, EditableHelpArticle>;
  categories?: Record<string, EditableHelpCategory>;
  visibility: Record<string, boolean>;
  history: { key: string; action: 'save' | 'show' | 'hide'; at: string; by: string }[];
};
type StorageReader = Pick<Storage, 'getItem'>;
export const emptyHelpContent = (): HelpContentState => ({ version: 1, revision: 0, articles: {}, visibility: {}, history: [] });
const groups: Record<string, string> = { 'Business Central': 'business-central', 'Debetas Excel': 'debetas', 'Finvalda Excel': 'finvalda', Pragma3: 'pragma', Pragma4: 'pragma', 'Pragma4 V2': 'pragma', 'Rivilė': 'rivile', 'Rivilė API': 'rivile', 'Rivilė ERP': 'rivile-erp', 'BSS Api': 'bss', 'Site.pro': 'site-pro' };
export function integrationHelpGroup(format: string): string {
  const group = latvianAccountingSystem(format)?.family || groups[format] || format.toLowerCase().replace(/\s+/g, '-');
  // One group governs every help surface, including direct export-field links.
  // Legacy articles stay available to administrators without appearing in customer choices.
  return Object.hasOwn(EXPORT_FORMAT_SCHEMAS, format)
    && !DEFAULT_VISIBLE_ACCOUNTING_HELP_GROUPS.includes(group)
    && !DEFAULT_HIDDEN_HELP_GROUPS.includes(group) ? 'other-integrations' : group;
}
export function helpRouteParts(href: string) {
  const hash = href.includes('#') ? href.slice(href.indexOf('#')) : href;
  const [path, query] = hash.split('?');
  return { path, params: new URLSearchParams(query) };
}
export function helpArticleKey(href: string): string {
  const { path, params } = helpRouteParts(href);
  if (path === '#help/integrations') return `integration:${params.get('integration') || 'Rivilė API'}:${params.get('topic') || 'overview'}`;
  if (path === '#help/export') {
    const raw = params.get('topic') || 'overview';
    const topic = raw === 'setup' ? 'overview' : ['Additional column settings', 'Required', 'Assign automatically', 'Default value'].includes(raw) ? 'columns' : raw;
    return `export:${params.get('format') || 'Rivilė'}:${topic}`;
  }
  if (path === '#help/organization') return `organization:${params.get('section') || 'overview'}:${params.get('topic') || 'overview'}`;
  return params.get('article') ? `article:${params.get('category') || 'system'}:${params.get('article')}` : '';
}
export function helpRouteGroup(href: string): string {
  const { path, params } = helpRouteParts(href);
  if (path === '#help/integrations' || path === '#help/export') return integrationHelpGroup(params.get(path === '#help/export' ? 'format' : 'integration') || (path === '#help/export' ? 'Rivilė' : 'Rivilė API'));
  return path === '#help/organization' ? 'system' : params.get('category') || '';
}
export function isHelpGroupVisible(group: string, state: HelpContentState) {
  return state.visibility[`category:${group}`] ?? !DEFAULT_HIDDEN_HELP_GROUPS.includes(group);
}
export function isHelpVisible(href: string, state: HelpContentState): boolean {
  const key = helpArticleKey(href), group = helpRouteGroup(href);
  if (!isHelpGroupVisible(state.articles[key]?.category || group, state)) return false;
  const visited = new Set<string>();
  let current = key;
  while (current) {
    if (visited.has(current) || state.visibility[current] === false) return false;
    visited.add(current);
    const edited = state.articles[current];
    if (edited && !isHelpGroupVisible(edited.category, state)) return false;
    current = edited?.parentKey ?? (/^(integration|organization|export):/.test(current) && !current.endsWith(':overview') ? current.slice(0, current.lastIndexOf(':') + 1) + 'overview' : '');
  }
  return true;
}
const pair = (value: unknown): value is HelpText => Array.isArray(value) && value.length === 2 && value.every(item => typeof item === 'string');
export function validHelpArticle(value: unknown): value is EditableHelpArticle {
  if (!value || typeof value !== 'object') return false;
  const article = value as EditableHelpArticle;
  return typeof article.key === 'string' && Boolean(article.key) && typeof article.category === 'string' && Boolean(article.category)
    && typeof article.href === 'string' && article.href.startsWith('./#help') && helpArticleKey(article.href) === article.key
    && pair(article.title) && pair(article.description) && pair(article.body)
    && (article.parentKey === undefined || (typeof article.parentKey === 'string' && article.parentKey !== article.key))
    && (article.order === undefined || Number.isFinite(article.order))
    && article.title.some(item => item.trim()) && article.body.some(item => item.trim())
    && article.title.every(item => item.length <= 250) && article.description.every(item => item.length <= 2000) && article.body.every(item => item.length <= 250000);
}
export function validHelpCategory(value: unknown): value is EditableHelpCategory {
  if (!value || typeof value !== 'object') return false;
  const category = value as EditableHelpCategory;
  return typeof category.id === 'string' && /^[a-z0-9-]+$/.test(category.id) && pair(category.title) && pair(category.description)
    && category.title.some(text => text.trim()) && category.title.every(text => text.length <= 250) && category.description.every(text => text.length <= 2000);
}
export function readHelpContent(storage: StorageReader): HelpContentState {
  const raw = storage.getItem(HELP_CONTENT_KEY);
  if (!raw) return emptyHelpContent();
  let value: HelpContentState;
  try { value = JSON.parse(raw); } catch { throw new Error('Help content could not be loaded. Saved data was not changed.'); }
  if (value?.version !== 1 || !Number.isSafeInteger(value.revision) || value.revision < 0 || !value.articles || typeof value.articles !== 'object'
    || !value.visibility || typeof value.visibility !== 'object' || Object.values(value.visibility).some(item => typeof item !== 'boolean')
    || Object.entries(value.articles).some(([key, article]) => !validHelpArticle(article) || article.key !== key)
    || (value.categories !== undefined && (!value.categories || typeof value.categories !== 'object' || Object.entries(value.categories).some(([key, category]) => !validHelpCategory(category) || category.id !== key)))
    || !Array.isArray(value.history)) throw new Error('Help content could not be loaded. Saved data was not changed.');
  return value;
}
export function canManageHelp(storage: StorageReader): boolean {
  try { const session = parseSession(storage.getItem(AUTH_SESSION_KEY)); return Boolean(session && !session.roleNames.includes('Inactive') && session.roleNames.some(isSystemAdministratorRole)); } catch { return false; }
}
export function saveHelpContent(storage: Pick<Storage, 'getItem' | 'setItem'>, revision: number, change: { article?: EditableHelpArticle; articles?: EditableHelpArticle[]; category?: EditableHelpCategory; visibility?: { key: string; visible: boolean } }): HelpContentState {
  if (!canManageHelp(storage)) throw new Error('Only an administrator can manage help content.');
  const current = readHelpContent(storage);
  if (current.revision !== revision) throw new Error('Help was changed in another window. Reload the list before saving.');
  if (!change.article && !change.category && !change.visibility) throw new Error('No changes to save.');
  const changedArticles = [...(change.articles || []), ...(change.article ? [change.article] : [])];
  if (changedArticles.some(article => !validHelpArticle(article))) throw new Error('Enter an article title and content within the allowed length.');
  if (change.category && !validHelpCategory(change.category)) throw new Error('Enter a category title within the allowed length.');
  const articles = { ...current.articles, ...Object.fromEntries(changedArticles.map(article => [article.key, structuredClone(article)])) };
  for (const article of changedArticles) {
    const visited = new Set([article.key]);
    let parent = article.parentKey;
    while (parent) {
      if (visited.has(parent) || (articles[parent] && articles[parent].category !== article.category)) throw new Error('Invalid parent topic.');
      visited.add(parent);
      const next = articles[parent];
      parent = next?.parentKey ?? (/^(integration|organization|export):/.test(parent) && !parent.endsWith(':overview') ? parent.slice(0, parent.lastIndexOf(':') + 1) + 'overview' : '');
    }
  }
  if (change.visibility && (!change.visibility.key || typeof change.visibility.visible !== 'boolean')) throw new Error('Invalid visibility setting.');
  const session = parseSession(storage.getItem(AUTH_SESSION_KEY))!;
  const key = change.article?.key || (change.category ? `category:${change.category.id}` : change.visibility!.key);
  const action: HelpContentState['history'][number]['action'] = change.article || change.category ? 'save' : change.visibility!.visible ? 'show' : 'hide';
  const next: HelpContentState = { ...current, revision: current.revision + 1,
    articles,
    categories: change.category ? { ...current.categories, [change.category.id]: { id: change.category.id, title: [...change.category.title], description: [...change.category.description] } } : current.categories,
    visibility: change.visibility ? { ...current.visibility, [change.visibility.key]: change.visibility.visible } : current.visibility,
    history: [...current.history, { key, action, at: new Date().toISOString(), by: session.fullName || session.email }].slice(-100),
  };
  // Write before announcing success. Quota/storage failures leave the current UI unchanged.
  storage.setItem(HELP_CONTENT_KEY, JSON.stringify(next));
  return next;
}

/** Content is rendered as text, never HTML. Only safe URLs can become links. */
export function safeHelpUrl(value: string): string | null {
  if (/^help-media:[a-f0-9-]{36}$/.test(value)) return value;
  if (/^\.\/#help(?:[/?]|$)/.test(value)) return value;
  if (/^help\/[a-zA-Z0-9._/-]+\.(?:png|jpg|jpeg|webp)$/.test(value) && !value.includes('..')) return value;
  try { const url = new URL(value); return url.protocol === 'https:' && !url.username && !url.password ? url.href : null; } catch { return null; }
}
