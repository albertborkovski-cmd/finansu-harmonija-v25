type RecordData = Record<string, unknown>;
export type DocumentHistoryReference = { documentId: string; label: string; kind: 'document' | 'storno'; available: boolean; deleted: boolean };
export type DocumentActionHistoryRow = { id: string; documentId: string; at: string; actor: string; action: string; details: string; related: DocumentHistoryReference[] };
const text = (value: unknown) => typeof value === 'string' ? value.trim() : '';
const record = (value: unknown): RecordData => value && typeof value === 'object' && !Array.isArray(value) ? value as RecordData : {};
const records = (value: unknown): RecordData[] => Array.isArray(value) ? value.map(record) : [];

function actionLabel(action: string, document: RecordData) {
  if (/^Advance employee/i.test(action)) return action;
  if (/^(delete|deleted|unconfirmed document deleted)$/i.test(action)) return 'Delete';
  if (/^(approval cancelled|cancel approval)$/i.test(action)) return 'Cancel approval';
  if (/storno|revers(al|ed)/i.test(action)) return 'Storno';
  if (document.correction_of_document_id && /created|linked to original/i.test(action)) {
    return /debit/i.test(text(document.correction_kind) || text(document.document_subtype)) ? 'Create debit note' : 'Create credit note';
  }
  return action || 'Updated';
}
const lifecycle = new Set(['Delete', 'Restore document', 'Cancel approval', 'Storno', 'Create credit note', 'Create debit note']);

/** Read-only projection of authoritative record history + its shared audit mirror.
 * Scope comes from the document record, never a link supplied by another company.
 * Existing dates/authors are not rewritten to the current viewer. */
export function buildDocumentActionHistory(documentId: string, companyId: string, documents: readonly RecordData[], history: readonly RecordData[]): DocumentActionHistoryRow[] {
  const scoped = documents.filter(row => text(row.company_id) === companyId);
  const byId = new Map(scoped.map(row => [text(row.id), row]));
  const current = byId.get(documentId);
  if (!current) return [];
  const relevant = scoped.filter(row => row.id === documentId || row.correction_of_document_id === documentId);
  const relevantIds = new Set(relevant.map(row => text(row.id)));
  const output: DocumentActionHistoryRow[] = [];
  const reference = (id: string): DocumentHistoryReference => {
    const row = byId.get(id), deleted = Boolean(row?.document_deletion);
    return { documentId: id, kind: 'document', label: row ? text(row.number) || text(row.file_case) || id : 'Unavailable document', available: Boolean(row) && !deleted, deleted };
  };
  const append = (event: RecordData, source: RecordData) => {
    const id = text(source.id), rawAction = text(event.action), action = actionLabel(rawAction, source);
    if (id !== documentId && !lifecycle.has(action)) return;
    const at = text(event.at) || text(event.created_at);
    const rawActor = text(event.actor) || text(event.user_name);
    const actor = !rawActor || rawActor.toLowerCase() === 'current user' ? 'Not recorded' : rawActor;
    const related: DocumentHistoryReference[] = [];
    if (id !== documentId) related.push(reference(id));
    const originalId = text(source.correction_of_document_id);
    if (originalId && originalId !== documentId && originalId !== id) related.push(reference(originalId));
    if (action === 'Storno') {
      const reversal = record(source.document_storno || source.accounting_storno);
      if (text(reversal.number)) related.push({ documentId: id, label: text(reversal.number), kind: 'storno', available: !source.document_deletion, deleted: Boolean(source.document_deletion) });
    }
    const details = text(event.details) || (action === 'Cancel approval'
      ? `${text(event.fromStatus) || text(event.fromAccountingStatus) || 'Approved'} → Draft${text(event.reason) ? `. ${text(event.reason)}` : ''}`
      : action === 'Delete' ? `${text(source.number) || text(source.file_case) || id} · Document deleted. Its audit history is retained.` : text(event.reason));
    output.push({ id: text(event.id) || `${id}:${action}:${at}`, documentId: id, at, actor, action, details, related });
  };
  // Authoritative events remain usable if their secondary audit-table write failed.
  for (const source of relevant) {
    for (const key of ['creation_history', 'correction_history', 'approval_cancellation_history', 'inline_edit_history', 'detail_edit_history', 'advance_employee_history', 'document_lifecycle_history']) {
      for (const event of records(source[key])) append(event, source);
    }
    for (const key of ['document_storno', 'accounting_storno']) {
      for (const event of records(record(source[key]).history)) append(event, source);
    }
    const deletion = record(source.document_deletion);
    if (text(deletion.at)) append({ ...deletion, action: 'Delete' }, source);
    // Older corrected documents may only have creation metadata.
    if (source.correction_of_document_id && !records(source.creation_history).length && !records(source.correction_history).length && text(source.created_at)) {
      append({ action: 'Corrective document created', at: source.created_at, actor: source.created_by,
        details: text(source.correction_reason) }, source);
    }
  }
  for (const event of history) {
    if (event.organization_id && event.organization_id !== companyId) continue;
    const source = byId.get(text(event.document_id));
    if (source && relevantIds.has(text(source.id))) append(event, source);
  }
  const unique = new Map<string, DocumentActionHistoryRow>();
  for (const row of output) {
    // Creation and original-link events describe one correction, even when IDs differ.
    const key = lifecycle.has(row.action) ? `${row.documentId}:${row.action}:${row.at}` : row.id;
    const previous = unique.get(key);
    if (!previous) unique.set(key, row);
    else unique.set(key, { ...previous, details: previous.details.length >= row.details.length ? previous.details : row.details,
      actor: previous.actor === 'Not recorded' ? row.actor : previous.actor,
      related: [...new Map([...previous.related, ...row.related].map(ref => [`${ref.kind}:${ref.documentId}`, ref])).values()] });
  }
  return [...unique.values()].sort((a, b) => (Date.parse(b.at) || 0) - (Date.parse(a.at) || 0) || a.id.localeCompare(b.id));
}
