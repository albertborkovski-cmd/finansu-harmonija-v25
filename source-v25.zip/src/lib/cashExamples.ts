import { blankCashDocument, cashId, emptyCash, saveCashDocument, saveCashMaster, type CashStore, type CashValidation } from './cash';

const extraTransactions = [
  ['Cash income order', 'Customer deposit for interior design', 'Baltic Interiors', 125000, true],
  ['Cash expense order', 'Courier services for invoice C-318', 'City Courier', 4850, true],
  ['Cash expense order', 'Equipment maintenance', 'Office Support', 18575, false],
] as const;

const legacyLabels: Record<string, string> = {
  'V22 sample data': 'System',
  'Sample company': 'Cash register',
  'Amber Studio (sample)': 'Amber Studio',
  'North Office (sample)': 'North Office',
  'Walk-in customer (sample)': 'Walk-in customer',
  'Office Market (sample)': 'Office Market',
  'Green Workshop (sample)': 'Green Workshop',
  'Employee (sample)': 'Laura Petrauskaitė',
  'Payment for invoice DEMO-101': 'Payment for invoice INV-101',
  'Payment for invoice DEMO-205': 'Payment for invoice EXP-205',
  'Payment for invoice DEMO-108': 'Payment for invoice INV-108',
  'Fictional V22 test record.': '',
  'V22 verification · sample cash receipt': 'Payment for accounting services',
};

/** Relabel only our known fixtures; preserve user text, amounts, IDs, numbers and statuses. */
export function normalizeCashExampleLabels(store: CashStore): CashStore {
  const label = (value: string) => legacyLabels[value] ?? value;
  return {
    ...store,
    documents: store.documents.map(row => {
      if (!row.exampleKey && row.createdBy !== 'V22 sample data' && row.notes !== 'Fictional V22 test record.' && row.purpose !== 'V22 verification · sample cash receipt') return row;
      return { ...row, exampleKey: row.exampleKey || `legacy-${row.id}`, createdBy: label(row.createdBy), approvedBy: label(row.approvedBy), counterparty: label(row.counterparty), purpose: label(row.purpose), notes: label(row.notes), lines: row.lines.map(line => ({ ...line, description: label(line.description) })) };
    }),
    audit: store.audit.map(row => row.actor === 'V22 sample data' ? { ...row, actor: 'System' } : row),
  };
}

export const canExtendCashExamples = (store: CashStore) => (store.examplesVersion || 0) < 2 && store.documents.some(row => !!row.exampleKey);

export const ALICE_CASH_EXAMPLES_VERSION = 3;
export function shouldPrepareAliceCashExamples(company: { id: string; name: string }, store: CashStore): boolean {
  return company.id === '00000000-0000-4000-8000-000000000002' && company.name === 'Alice Stone'
    && store.companyId === company.id && (store.examplesVersion || 0) < ALICE_CASH_EXAMPLES_VERSION;
}

/** One-time fixture initialization for the existing Alice Stone testing company.
 * Existing documents, assignments and numbering are never replaced. */
export function prepareAliceCashExamples(store: CashStore, validation: CashValidation, users: { id: string; name: string }[], date: string): CashStore {
  if ((store.examplesVersion || 0) >= ALICE_CASH_EXAMPLES_VERSION) return store;
  const needed = Math.max(0, 10 - store.documents.filter(row => row.kind !== 'Money receipt' && !row.inactive).length);
  let next = store;
  if (needed && !store.accounts.length && !store.documents.length && !store.people.length && !store.series.length) {
    next = createCashExamples(store.companyId, validation, users, date);
    // Preserve any retained audit trail even when the current collections are empty.
    next = { ...next, revision: store.revision + next.revision, audit: [...store.audit, ...next.audit] };
  } else if (needed) {
    const additions = createCashExamples(store.companyId, validation, users, date);
    const documents = additions.documents.filter(row => row.kind !== 'Money receipt').slice(0, needed);
    const unique = (prefix: string, used: string[]) => {
      let value = prefix, suffix = 2;
      while (used.some(existing => existing.toUpperCase() === value.toUpperCase())) value = `${prefix}-${suffix++}`;
      return value;
    };
    for (const account of additions.accounts) {
      const code = unique(account.code, next.accounts.map(row => row.code));
      next = saveCashMaster(next, 'accounts', { ...account, code, name: code === account.code ? account.name : `Cash register ${code}`, revision: 0 }, 'System', validation);
    }
    for (const person of additions.people) next = saveCashMaster(next, 'people', { ...person, revision: 0 }, 'System', validation);
    for (const series of additions.series.filter(row => documents.some(document => document.seriesId === row.id))) {
      next = saveCashMaster(next, 'series', { ...series, prefix: unique(series.prefix, next.series.map(row => row.prefix)), nextNumber: 1, revision: 0 }, 'System', validation);
    }
    for (const [index, document] of documents.entries()) {
      next = saveCashDocument(next, { ...document, number: '', revision: 0, exampleKey: `cash-visible-v3-${index}` }, document.status === 'Approved', 'System', validation, document.createdAt);
    }
  }
  return { ...next, examplesVersion: ALICE_CASH_EXAMPLES_VERSION, revision: next.revision + 1,
    audit: [...next.audit, { id: cashId(), recordId: store.companyId, action: 'Cash records prepared', actor: 'System', at: new Date().toISOString(), detail: String(needed) }] };
}

/** Extend an already initialized fixture workspace without replacing any existing record. */
export function extendCashExamples(store: CashStore, validation: CashValidation, actor: string, date: string): CashStore {
  let next = normalizeCashExampleLabels(store);
  if (!canExtendCashExamples(next)) throw new Error('The cash records are already available.');
  const expenseGl = validation.activeGlAccounts.find(code => /^6\d/.test(code)) || validation.activeGlAccounts.find(code => /^6/.test(code));
  const receivableGl = validation.activeGlAccounts.find(code => /^24/.test(code));
  if (!expenseGl || !receivableGl) throw new Error('Select correspondence accounts in the company chart of accounts.');
  let added = 0;
  for (const [index, [kind, purpose, counterparty, amountMinor, approved]] of extraTransactions.entries()) {
    if (next.documents.filter(row => row.kind !== 'Money receipt').length >= 10) break;
    if (next.documents.some(row => row.exampleKey === `cash-extra-${index}`)) continue;
    const day = Math.min(Number(date.slice(-2)), 7 + index * 2);
    const document = blankCashDocument(next, kind, actor, `${date.slice(0, 7)}-${String(day).padStart(2, '0')}`);
    document.exampleKey = `cash-extra-${index}`;
    document.counterparty = counterparty; document.purpose = purpose;
    document.lines = [{ id: cashId(), account: kind === 'Cash expense order' ? expenseGl : receivableGl, amountMinor, description: purpose, relatedDocumentId: '', relatedDocumentNumber: '' }];
    next = saveCashDocument(next, document, approved, actor, validation);
    added++;
  }
  return { ...next, examplesVersion: 2, revision: next.revision + 1, audit: [...next.audit, { id: cashId(), recordId: store.companyId, action: 'Cash records added', actor, at: new Date().toISOString(), detail: String(added) }] };
}

/** Fictional, opt-in fixtures. Never imports records from the reference production site. */
export function createCashExamples(companyId: string, validation: CashValidation, users: { id: string; name: string }[], date: string): CashStore {
  const cashGl = validation.activeGlAccounts.find(code => /^272/.test(code)) || validation.activeGlAccounts.find(code => /^27/.test(code));
  const otherGl = validation.activeGlAccounts.find(code => /^24/.test(code)) || validation.activeGlAccounts.find(code => code !== cashGl);
  const expenseGl = validation.activeGlAccounts.find(code => /^6\d/.test(code)) || validation.activeGlAccounts.find(code => /^6/.test(code)) || otherGl;
  if (!cashGl) throw new Error('The company chart of accounts needs a cash GL account (2720 or another 27… account).');
  if (!otherGl || !expenseGl) throw new Error('The company chart of accounts needs correspondence accounts for cash entries.');
  if (!users.length) throw new Error('Add an active internal user before assigning a cashier and accountant.');
  if (!validation.currencies.includes('EUR')) throw new Error('Enable EUR in Settings → General settings → Currency.');
  let store = emptyCash(companyId);
  const actor = 'System';
  const base = () => ({ id: cashId(), companyId, revision: 0, inactive: false });
  const accountId = cashId();
  store = saveCashMaster(store, 'accounts', { ...base(), id: accountId, code: 'MAIN', name: 'Main cash register', glAccount: cashGl, currency: 'EUR' }, actor, validation);
  for (const [index, role] of (['Cashier', 'Accountant'] as const).entries()) {
    const user = users[index % users.length];
    store = saveCashMaster(store, 'people', { ...base(), accountId, userId: user.id, name: user.name, role, validFrom: '2020-01-01', validTo: '' }, actor, validation);
  }
  for (const [prefix, kind] of [['KPO', 'Cash income order'], ['KIO', 'Cash expense order'], ['PPK', 'Money receipt']] as const) store = saveCashMaster(store, 'series', { ...base(), prefix, kind, nextNumber: 1, digits: 6 }, actor, validation);
  const monthStart = date.slice(0, 7) + '-01';
  const previous = new Date(`${monthStart}T12:00:00Z`); previous.setUTCDate(0);
  const openingDate = previous.toISOString().slice(0, 10);
  const rows = [
    ['Cash income order', 'Opening cash balance', 'Cash register', 150000, true],
    ['Cash income order', 'Payment for invoice INV-101', 'Amber Studio', 89419, true],
    ['Cash expense order', 'Payment for invoice EXP-205', 'North Office', 68486, true],
    ['Cash income order', 'Retail cash collection', 'Walk-in customer', 36000, true],
    ['Cash expense order', 'Office supplies', 'Office Market', 9260, true],
    ['Cash income order', 'Payment for services', 'Green Workshop', 24200, false],
    ['Cash expense order', 'Travel advance', 'Laura Petrauskaitė', 15000, false],
    ['Money receipt', 'Advance for design services', 'Amber Studio', 50000, true],
    ['Money receipt', 'Payment for invoice INV-108', 'Green Workshop', 12100, false],
  ] as const;
  rows.forEach(([kind, purpose, counterparty, amountMinor, approved], index) => {
    const day = Math.min(Number(date.slice(-2)), index);
    const document = blankCashDocument(store, kind, actor, index === 0 ? openingDate : `${date.slice(0, 7)}-${String(day).padStart(2, '0')}`);
    document.exampleKey = `cash-example-${index}`;
    document.counterparty = counterparty; document.purpose = purpose;
    document.lines = [{ id: cashId(), account: kind === 'Cash expense order' ? expenseGl : otherGl, amountMinor, description: purpose, relatedDocumentId: '', relatedDocumentNumber: '' }];
    store = saveCashDocument(store, document, approved, actor, validation, `${document.date}T10:00:00.000Z`);
  });
  return extendCashExamples(store, validation, actor, date);
}
