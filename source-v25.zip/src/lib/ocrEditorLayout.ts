export const DEFAULT_OCR_PREVIEW_WIDTH = 42.5;
export function clampOcrPreviewWidth(value: number): number {
  return Number.isFinite(value) ? Math.max(25, Math.min(70, value)) : DEFAULT_OCR_PREVIEW_WIDTH;
}
export function ocrEditorLayoutKey(email: string): string {
  return `finansu-harmonija:ocr:editor-layout:${encodeURIComponent(email.trim().toLowerCase() || 'local')}`;
}
export function loadOcrPreviewWidth(storage: Pick<Storage, 'getItem'>, key: string): number {
  try {
    const raw = storage.getItem(key);
    return raw === null ? DEFAULT_OCR_PREVIEW_WIDTH : clampOcrPreviewWidth(Number(raw));
  } catch { return DEFAULT_OCR_PREVIEW_WIDTH; }
}
