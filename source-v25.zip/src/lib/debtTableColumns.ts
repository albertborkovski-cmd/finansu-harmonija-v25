import type { ColConfig } from '../components/ColumnSettingsPanel';
import type { DebtRow } from './companyRelatedObjectData';
import { debtDirection } from './debtActions';

export const DEBT_AGING_GROUPS = ['Not overdue', '1–30 days', '31–60 days', '61–90 days', 'Over 90 days'] as const;

/** Inclusive aging buckets use the same overdue days shown in the debt list. */
export function debtAgingGroup(daysOverdue: number): typeof DEBT_AGING_GROUPS[number] | '' {
  if (!Number.isFinite(daysOverdue)) return '';
  if (daysOverdue <= 0) return DEBT_AGING_GROUPS[0];
  if (daysOverdue <= 30) return DEBT_AGING_GROUPS[1];
  if (daysOverdue <= 60) return DEBT_AGING_GROUPS[2];
  if (daysOverdue <= 90) return DEBT_AGING_GROUPS[3];
  return DEBT_AGING_GROUPS[4];
}

/** Retain personal order/visibility while making newly introduced columns available. */
export function restoreDebtColumns(defaults: ColConfig[], saved: unknown): ColConfig[] {
  if (!Array.isArray(saved)) return defaults;
  const remaining = new Map(defaults.filter(column => column.key !== 'actions').map(column => [column.key, column]));
  const result: ColConfig[] = [];
  for (const item of saved) {
    const column = item && remaining.get(item.key);
    if (!column) continue;
    result.push({ ...column,
      visible: typeof item.visible === 'boolean' ? item.visible : column.visible,
      width: Number.isFinite(item.width) && item.width >= 88 ? item.width : column.width,
    });
    remaining.delete(column.key);
  }
  return [...result, ...remaining.values(), ...defaults.filter(column => column.key === 'actions')];
}

/** Mixed debts expose direction next to the counterparty without altering other tabs. */
export function allDebtColumns(existing: ColConfig[]): ColConfig[] {
  const direction = existing.find(column => column.key === 'debtDirection');
  return existing.filter(column => column.key !== 'debtDirection').flatMap(column => [
    { ...column },
    ...(column.key === 'counterpartyName' && direction ? [{ ...direction, visible: true }] : []),
  ]);
}

/** Use the same direction for presentation, filters, sorting and debt actions. */
export function debtColumnValue(row: DebtRow, key: string): string | number {
  if (key === 'agingGroup') return debtAgingGroup(row.daysOverdue);
  if (key === 'debtDirection') {
    const direction = debtDirection(row);
    return direction === 'receivable' ? 'Receivable' : direction === 'payable' ? 'Payable' : '—';
  }
  return row[key as keyof DebtRow] ?? '';
}

/** Sort displayed money and dates by their values, not formatted text. */
export function debtColumnSortValue(row: DebtRow, key: string): string | number {
  const value = debtColumnValue(row, key);
  if (['totalAmount', 'paidAmount', 'outstandingAmount', 'daysOverdue'].includes(key)) {
    const number = Number(String(value).replace(/[\s,]/g, ''));
    return String(value).trim() && Number.isFinite(number) ? number : '';
  }
  if (['issueDate', 'dueDate', 'lastReminderDate', 'nextReminderDate'].includes(key)) {
    const text = String(value);
    const local = /^(\d{2})\.(\d{2})\.(\d{4})$/.exec(text);
    const iso = /^(\d{4})-(\d{2})-(\d{2})$/.exec(text);
    const parts = local ? [Number(local[3]), Number(local[2]), Number(local[1])] : iso ? iso.slice(1).map(Number) : null;
    if (!parts) return '';
    const [year, month, day] = parts;
    const date = new Date(Date.UTC(year, month - 1, day));
    return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day ? date.getTime() : '';
  }
  return value;
}
