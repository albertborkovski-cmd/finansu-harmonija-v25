/** Shared keyboard contract, independent of FH / OCR and of translated labels. */
export type KeyboardPopup = {
  roots: () => (HTMLElement | null | undefined)[];
  dismiss: () => void;
};

const popups: KeyboardPopup[] = [];
export function registerKeyboardPopup(popup: KeyboardPopup) {
  popups.push(popup);
  return () => { const index = popups.indexOf(popup); if (index >= 0) popups.splice(index, 1); };
}

export const MODAL_SELECTOR = '[aria-modal="true"], dialog[open], [data-keyboard-scope="modal"]';
const CONTROL_SELECTOR = 'button, input, select, textarea, a[href], area[href], summary, [tabindex], [contenteditable="true"], iframe';

export function keyboardVisible(element: HTMLElement) {
  return element.isConnected && element.getClientRects().length > 0
    && !element.closest('[hidden], [inert], [aria-hidden="true"]')
    && getComputedStyle(element).visibility !== 'hidden';
}

export function keyboardControls(root: HTMLElement): HTMLElement[] {
  const candidates = [...root.querySelectorAll<HTMLElement>(CONTROL_SELECTOR)].filter(element =>
    keyboardVisible(element) && element.tabIndex >= 0 && !element.matches(':disabled, [aria-disabled="true"]'),
  );
  // Native Tab visits only one radio in each named group.
  return candidates.filter(element => {
    if (!(element instanceof HTMLInputElement) || element.type !== 'radio' || !element.name) return true;
    const group = candidates.filter((other): other is HTMLInputElement => other instanceof HTMLInputElement
      && other.type === 'radio' && other.name === element.name && other.form === element.form);
    return element === (group.find(other => other.checked) || group[0]);
  }).sort((a, b) => (a.tabIndex > 0 ? a.tabIndex : Infinity) - (b.tabIndex > 0 ? b.tabIndex : Infinity));
}

function layerIndex(element: HTMLElement) {
  let level = 0;
  for (let node: HTMLElement | null = element; node; node = node.parentElement) {
    const value = Number.parseInt(getComputedStyle(node).zIndex, 10);
    if (Number.isFinite(value)) level = Math.max(level, value);
  }
  return level;
}

/** Explicit dialogs win over their legacy fixed overlay wrappers. */
export function keyboardModalRoots(): HTMLElement[] {
  const semantic = [...document.querySelectorAll<HTMLElement>(MODAL_SELECTOR)].filter(keyboardVisible);
  const legacy = [...document.querySelectorAll<HTMLElement>('.fixed.inset-0')].filter(root =>
    keyboardVisible(root) && !root.matches(MODAL_SELECTOR) && !root.querySelector(MODAL_SELECTOR)
    && Boolean(keyboardDismissControl(root)),
  );
  return [...semantic, ...legacy].filter(root => ![...semantic, ...legacy].some(other => other !== root && other.contains(root) && !other.matches(MODAL_SELECTOR)))
    .sort((a, b) => layerIndex(a) - layerIndex(b) || (a.contains(b) ? -1 : b.contains(a) ? 1
      : a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1));
}

/** Only existing Close/Cancel actions: never Save, Send, Delete or a form submit. */
export function keyboardDismissControl(root: HTMLElement): HTMLButtonElement | undefined {
  const buttons = [...root.querySelectorAll<HTMLButtonElement>('button')].filter(button => {
    const owner = button.closest(MODAL_SELECTOR);
    return (!owner || owner === root) && keyboardVisible(button) && !button.disabled && button.getAttribute('aria-disabled') !== 'true'
      && (button.type !== 'submit' || !button.form) && !button.closest('[role="menu"], [role="listbox"]');
  });
  return buttons.find(button => button.hasAttribute('data-keyboard-dismiss'))
    || buttons.find(button => /^(Close|Uždaryti)(\s|$)/i.test(button.getAttribute('aria-label') || ''))
    || buttons.find(button => button.dataset.buttonFamily === 'cancel' || /^(Cancel|Atšaukti)$/i.test(button.textContent?.trim() || ''));
}

function popupFor(root?: HTMLElement) {
  return [...popups].reverse().find(popup => popup.roots().some(element => element && keyboardVisible(element)
    && (!root || root.contains(element))));
}

function popupTrigger(popup: KeyboardPopup) {
  const root = popup.roots()[0];
  return root?.querySelector<HTMLElement>('[role="combobox"], [aria-expanded="true"], button:not(:disabled), input:not(:disabled)');
}

export function dismissKeyboardPopup(root?: HTMLElement) {
  const popup = popupFor(root);
  if (!popup) return false;
  // Focus first: a combobox's onFocus may open it; dismiss must be the final state.
  const trigger = popupTrigger(popup);
  if (trigger && document.activeElement !== trigger) trigger.focus({ preventScroll: true });
  popup.dismiss();
  return true;
}

export function keyboardTabTarget(controls: HTMLElement[], active: Element | null, backwards: boolean) {
  const index = controls.indexOf(active as HTMLElement);
  if (index < 0) return backwards ? controls.at(-1) : controls[0];
  return controls[(index + (backwards ? -1 : 1) + controls.length) % controls.length];
}

export function installKeyboardNavigation(requestDiscard: (close: () => void) => void) {
  const origins = new Map<HTMLElement, HTMLElement | null>();
  const dirty = new WeakSet<HTMLElement>();
  let previousRoots: HTMLElement[] = [];
  let lastFocused = document.activeElement instanceof HTMLElement ? document.activeElement : null;
  let lastTrigger = lastFocused;
  let pending = false;
  let stopped = false;
  const top = () => keyboardModalRoots().at(-1);
  const focusRoot = (root: HTMLElement) => {
    if (!root.hasAttribute('tabindex')) root.setAttribute('tabindex', '-1');
    // Focus the heading/container, not a combobox which would open on mount.
    root.focus({ preventScroll: true });
  };
  const sync = () => {
    pending = false;
    if (stopped) return;
    const roots = keyboardModalRoots();
    const newRoot = roots.at(-1);
    for (const root of roots) if (!origins.has(root)) {
      const origin = lastFocused && lastFocused !== document.body && !root.contains(lastFocused) ? lastFocused
        : lastTrigger && !root.contains(lastTrigger) ? lastTrigger : null;
      origins.set(root, origin);
    }
    const removed = previousRoots.filter(root => !roots.includes(root));
    if (removed.length) {
      const origin = origins.get(removed.at(-1)!);
      if (origin && keyboardVisible(origin) && (!newRoot || newRoot.contains(origin))) origin.focus({ preventScroll: true });
      else if (newRoot && !newRoot.contains(document.activeElement)) focusRoot(newRoot);
      removed.forEach(root => origins.delete(root));
    } else if (newRoot && !previousRoots.includes(newRoot) && !newRoot.contains(document.activeElement)) focusRoot(newRoot);
    previousRoots = roots;
  };
  const schedule = () => { if (!pending) { pending = true; queueMicrotask(sync); } };
  const observer = new MutationObserver(schedule);
  observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['aria-modal', 'hidden'] });
  const rememberTrigger = (event: Event) => {
    // Icon clicks target an SVG, not an HTMLElement.
    if (event.target instanceof Element) {
      const trigger = event.target.closest<HTMLElement>('button, a, input, [role="button"], [tabindex]');
      if (trigger) lastTrigger = trigger;
    }
  };
  const focus = () => {
    const active = document.activeElement;
    if (active instanceof HTMLElement) lastFocused = active;
    // Leaving a dropdown via Tab closes it without selecting a value or trapping focus.
    for (const popup of [...popups]) if (!popup.roots().some(root => root?.contains(active))) popup.dismiss();
  };
  const change = (event: Event) => {
    const root = top();
    if (root && event.target instanceof HTMLElement && root.contains(event.target)
      && !event.target.matches('input[type="search"], [data-keyboard-search]')) dirty.add(root);
  };
  const choose = (event: Event) => {
    if (!(event.target instanceof Element)) return;
    const control = event.target.closest<HTMLElement>('[role="option"], [role="checkbox"], [role="radio"], button[aria-pressed]');
    const root = top();
    const popup = root && popupFor(root);
    if (control && root && (root.contains(control) || popup?.roots().some(item => item?.contains(control)))
      && control.dataset.buttonFamily !== 'workspace-expand') dirty.add(root);
  };
  const consume = (event: KeyboardEvent) => { event.preventDefault(); event.stopImmediatePropagation(); };
  const key = (event: KeyboardEvent) => {
    if (event.defaultPrevented || event.isComposing || !['Escape', 'Tab'].includes(event.key)) return;
    const root = top();
    if (event.key === 'Escape') {
      window.dispatchEvent(new Event('fh:keyboard-escape'));
      if (dismissKeyboardPopup(root)) { consume(event); return; }
      // Older calendar / popup controls expose their own toggle instead of the shared hook.
      // Expanded navigation groups have no popup semantics and are deliberately excluded.
      const scope: ParentNode = root || document;
      const toggle = [...scope.querySelectorAll<HTMLButtonElement>('button[aria-haspopup][aria-expanded="true"]')]
        .reverse().find(button => keyboardVisible(button) && !button.disabled);
      if (toggle) { consume(event); toggle.focus({ preventScroll: true }); toggle.click(); return; }
      if (!root) return; // Page-level Escape (e.g. expanded workspace) retains its own handler.
      const expanded = root.querySelector<HTMLButtonElement>('[data-button-family="workspace-expand"][aria-pressed="true"]');
      if (expanded && keyboardVisible(expanded)) { consume(event); expanded.click(); return; }
      consume(event); // No bubbling through nested dialogs, including non-dismissible busy dialogs.
      const close = keyboardDismissControl(root);
      if (!close) return;
      const dismiss = () => { if (root.isConnected && !close.disabled) close.click(); };
      if (dirty.has(root)) requestDiscard(dismiss); else dismiss();
      return;
    }
    const popup = popupFor(root);
    if (!root) {
      // A portaled options menu is outside document order: return to its trigger before native Tab.
      if (popup && !popup.roots()[0]?.contains(document.activeElement)) popupTrigger(popup)?.focus({ preventScroll: true });
      popup?.dismiss();
      return;
    }
    const trigger = popup && popupTrigger(popup);
    const controls = keyboardControls(root).filter(control => !control.closest('[role="listbox"], [role="menu"]'));
    const active = popup && !popup.roots()[0]?.contains(document.activeElement) ? trigger || document.activeElement : document.activeElement;
    const target = keyboardTabTarget(controls, active, event.shiftKey);
    consume(event);
    if (target) target.focus({ preventScroll: false }); else focusRoot(root);
    popup?.dismiss();
  };
  window.addEventListener('keydown', key, true);
  document.addEventListener('pointerdown', rememberTrigger, true);
  document.addEventListener('click', rememberTrigger, true);
  document.addEventListener('click', choose, true);
  document.addEventListener('focusin', focus, true);
  document.addEventListener('input', change, true);
  document.addEventListener('change', change, true);
  sync();
  return () => {
    stopped = true; observer.disconnect();
    window.removeEventListener('keydown', key, true);
    document.removeEventListener('pointerdown', rememberTrigger, true);
    document.removeEventListener('click', rememberTrigger, true);
    document.removeEventListener('click', choose, true);
    document.removeEventListener('focusin', focus, true);
    document.removeEventListener('input', change, true);
    document.removeEventListener('change', change, true);
  };
}
