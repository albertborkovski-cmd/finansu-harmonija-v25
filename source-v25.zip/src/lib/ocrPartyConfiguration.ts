import type { OcrFieldValidationRule } from './ocrFieldValidation';
import { normalizeOcrFormRules, ocrPartyRoleKey, ocrRulePartyId, type OcrPartyBinding } from './ocrFormSchema';

type PartyPreset = { role: string; binding: OcrPartyBinding; fields: readonly string[] };
const business = ['clientCounterparty', 'counterpartyCode', 'partyVatCode', 'streetAddress', 'city', 'zipCode', 'partyCountry', 'email', 'phoneNumber', 'partyIban'];
const person = ['clientCounterparty', 'counterpartyCode', 'streetAddress', 'email', 'phoneNumber', 'partyIban'];
const preset = (role: string, fields: readonly string[], binding: OcrPartyBinding = 'independent'): PartyPreset => ({ role, fields, binding });
const invoice = [preset('Seller', business, 'seller'), preset('Buyer', business, 'buyer')];

/** Defaults are configuration data only. The renderer has no document-type branches. */
export const OCR_DOCUMENT_PARTY_PRESETS: Record<string, readonly PartyPreset[]> = {
  INVOICES: invoice, INVOICE: invoice, VAT_INVOICE: invoice, CREDIT_INVOICE: invoice, DEBIT_INVOICE: invoice,
  ADVANCE_INVOICE: invoice, VAT_ADVANCE_INVOICE: invoice, PURCHASE_SALE_AGREEMENT: invoice,
  INSURANCE_POLICY: [preset('Insurer', business), preset('Policyholder', person)],
  EMPLOYMENT_CONTRACT: [preset('Employer', business), preset('Employee', person)],
  EMPLOYMENT_CONTRACT_AMENDMENT: [preset('Employer', business), preset('Employee', person)],
  LOAN_AGREEMENT: [preset('Lender', business), preset('Borrower', business)],
  WAYBILL: [preset('Sender', business.filter(key => key !== 'partyIban')), preset('Receiver', business.filter(key => key !== 'partyIban'))],
};
const labels: Record<string, string> = { clientCounterparty: 'Name', counterpartyCode: 'Company / personal code', partyVatCode: 'VAT code',
  streetAddress: 'Address', city: 'City', zipCode: 'Postal code', partyCountry: 'Country', email: 'Email', phoneNumber: 'Phone', partyIban: 'IBAN' };

export function configuredPartyDefaults(input: readonly OcrFieldValidationRule[], documentTypes: readonly string[] = []): OcrFieldValidationRule[] {
  const rules = normalizeOcrFormRules(input);
  // Once edited/created, the complete role/field configuration is authoritative.
  if (rules.some(rule => rule.partySchemaVersion === 2 || rule.group === 'parties' && ocrRulePartyId(rule) !== 'counterparty')) return rules;
  const profile = documentTypes.map(code => OCR_DOCUMENT_PARTY_PRESETS[code.toUpperCase().replace(/[ -]+/g, '_')]).find(Boolean);
  if (!profile) return rules;
  const legacy = rules.filter(rule => rule.group === 'parties' && ocrRulePartyId(rule) === 'counterparty');
  if (!legacy.length) return rules;
  const byKey = new Map(legacy.map(rule => [rule.key, rule]));
  const remaining = rules.filter(rule => !legacy.includes(rule)).map(rule => ({ ...rule, partySchemaVersion: 2 as const }));
  const fields = profile.flatMap((party, partyIndex) => {
    const roleId = ocrPartyRoleKey(party.role);
    const keys = [...new Set([...party.fields, ...legacy.filter(rule => !business.includes(rule.key)).map(rule => rule.key)])];
    return keys.map((key, index): OcrFieldValidationRule => {
      const previous = byKey.get(key);
      return { ...(previous || { type: 'OCR', subtype: 'OCR', level: 'yellow', enabled: true }),
        key: `party_${roleId}_${key}`, label: labels[key] || previous?.label || key,
        formVersion: 1, partySchemaVersion: 2, group: 'parties', order: partyIndex * 1000 + (index + 1) * 10,
        partyRole: party.role, partyRoleId: roleId, partyBinding: party.binding, partyDataKey: key,
        // New independent roles do not invent new mandatory-field requirements.
        ...(party.binding === 'independent' ? { level: 'yellow', required: false } : { partyRequiredScope: 'counterparty' }),
        inputType: previous?.inputType || (key === 'email' ? 'email' : 'text'), options: previous?.options || [],
      };
    });
  });
  return [...remaining, ...fields];
}

/** Reassigning one field does not rename/move other roles or discard stored data. */
export function assignOcrPartyRole(draft: OcrFieldValidationRule, role: string, rules: readonly OcrFieldValidationRule[]) {
  const existing = rules.find(rule => rule.group === 'parties' && ocrPartyRoleKey(rule.partyRole || '') === ocrPartyRoleKey(role));
  return { ...draft, partyRole: role, partyRoleId: existing ? ocrRulePartyId(existing) : ocrPartyRoleKey(role),
    partyBinding: existing?.partyBinding || 'independent' as OcrPartyBinding, partyRequiredScope: undefined };
}

/** Renaming a role updates its whole block without changing stable field/party identities. */
export function applyOcrPartyFieldEdit(rules: readonly OcrFieldValidationRule[], draft: OcrFieldValidationRule): OcrFieldValidationRule[] {
  const previous = rules.find(rule => rule.key === draft.key);
  let edited = draft, next = [...rules];
  if (draft.group === 'parties') {
    const target = rules.find(rule => rule.group === 'parties' && ocrPartyRoleKey(rule.partyRole || '') === ocrPartyRoleKey(draft.partyRole || ''));
    if (previous?.group === 'parties' && (!target || ocrRulePartyId(target) === ocrRulePartyId(previous))) {
      const roleId = ocrRulePartyId(previous);
      edited = { ...draft, partyRoleId: roleId };
      next = next.map(rule => rule.group === 'parties' && ocrRulePartyId(rule) === roleId ? { ...rule, partyRoleId: roleId, partyRole: draft.partyRole } : rule);
    } else edited = assignOcrPartyRole(draft, draft.partyRole || '', rules);
  }
  return previous ? next.map(rule => rule.key === edited.key ? edited : rule) : [...next, edited];
}
