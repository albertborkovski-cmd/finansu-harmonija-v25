import { supabase, type Company } from './supabase';
import { canEditCompanySettings } from './documentEditAccess';
import { deactivateRecord, isInactiveRecord, isRecordLinked } from './recordLifecycle';
import { companyCounterpartiesKey } from './organizationDirectory';
import { getCurrentUserName } from './currentUser';
import { counterpartyDraftErrors, splitCounterpartyIbans, type CounterpartyDraft } from './companyCounterpartyImport';

export function prepareCounterpartyEdit(current: Company, draft: CounterpartyDraft, others: Company[], contacts: { email: string; phone: string }, actor: string, at: string, createId: () => string): Company {
  if (counterpartyDraftErrors([draft], others).some(errors => errors.length)) throw new Error('Correct the highlighted rows before saving.');
  const history: unknown = JSON.parse(current.counterparty_activity_log || '[]');
  const bankSource = current.counterparty_bank_accounts || '[]';
  const banks: unknown = /^[\[{]/.test(bankSource.trim()) ? JSON.parse(bankSource) : splitCounterpartyIbans(bankSource);
  if (!Array.isArray(history) || !Array.isArray(banks)) throw new Error('Could not read counterparty history. No changes were saved.');
  const accounts = splitCounterpartyIbans(draft.ibans).map((iban, index) => {
    const previous = banks.find(bank => bank && typeof bank === 'object' && String(bank.iban).replace(/\s/g, '').toUpperCase() === iban);
    return previous || { id: createId(), iban, bank: '', bankCode: '', swift: '', primary: index === 0 };
  });
  return { ...current, accounting_system_code: draft.accountingCode.trim(), company_code: draft.companyCode.trim(), vat_code: draft.vatCode.trim(), name: draft.name.trim(),
    email: contacts.email.trim(), phone: contacts.phone.trim(), counterparty_bank_accounts: JSON.stringify(accounts),
    counterparty_activity_log: JSON.stringify([...history, { date: at, user: actor, action: 'Counterparty updated' }]) };
}

async function editableCompany(companyId: string) {
  const { data, error } = await supabase.from('companies').select('*').eq('id', companyId);
  if (error) throw error;
  const company = data?.[0] as unknown as Company | undefined;
  if (!company || !canEditCompanySettings(company) || isInactiveRecord(company)) throw new Error('You do not have permission to change this organization’s counterparties.');
}
function freshRows(companyId: string, expected: Company) {
  const key = companyCounterpartiesKey(companyId);
  const rows: Company[] = JSON.parse(window.localStorage.getItem(key) || '[]');
  if (!Array.isArray(rows)) throw new Error('Could not load organization counterparties.');
  const current = rows.find(row => row.id === expected.id);
  if (!current || JSON.stringify(current) !== JSON.stringify(expected)) throw new Error('This counterparty has changed. Refresh the list and try again.');
  return { key, rows, current };
}
function persist(companyId: string, key: string, rows: Company[]) {
  window.localStorage.setItem(key, JSON.stringify(rows));
  window.dispatchEvent(new CustomEvent('counterparties-updated', { detail: { companyId } }));
}
export async function updateCompanyCounterparty(companyId: string, expected: Company, draft: CounterpartyDraft, contacts: { email: string; phone: string }) {
  await editableCompany(companyId);
  const { key, rows, current } = freshRows(companyId, expected);
  const updated = prepareCounterpartyEdit(current, draft, rows.filter(row => row.id !== current.id), contacts, getCurrentUserName(), new Date().toISOString(), () => crypto.randomUUID());
  persist(companyId, key, rows.map(row => row.id === current.id ? updated : row));
}
export async function deleteCompanyCounterparty(companyId: string, expected: Company): Promise<'deleted' | 'deactivated'> {
  await editableCompany(companyId);
  // Refresh document references before the final lifecycle check, never trust a
  // cached icon state as permission to physically remove a linked counterparty.
  const { error } = await supabase.from('documents').select('*').eq('company_id', companyId);
  if (error) throw error;
  await editableCompany(companyId);
  const { key, rows, current } = freshRows(companyId, expected);
  if (isInactiveRecord(current)) throw new Error('This counterparty is already inactive.');
  const linked = isRecordLinked(current, key);
  if (linked) {
    const history = JSON.parse(current.counterparty_activity_log || '[]');
    if (!Array.isArray(history)) throw new Error('Could not read counterparty history. No changes were saved.');
    const updated = { ...deactivateRecord(current), counterparty_activity_log: JSON.stringify([...history, { date: new Date().toISOString(), user: getCurrentUserName(), action: 'Counterparty deactivated' }]) };
    persist(companyId, key, rows.map(row => row.id === current.id ? updated : row));
  } else persist(companyId, key, rows.filter(row => row.id !== current.id));
  return linked ? 'deactivated' : 'deleted';
}
