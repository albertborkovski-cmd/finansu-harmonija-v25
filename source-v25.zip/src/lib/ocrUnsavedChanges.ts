import type { WorkspaceTask } from '../components/WorkspaceView';
export const OCR_BEFORE_NAVIGATE = 'finansu-harmonija:ocr:before-navigate';
/** Ignore timers and workflow metadata; only user-editable corrections are dirty. */
export function ocrCorrectionSnapshot(task: WorkspaceTask): string {
  return JSON.stringify({ fields: task.fields, products: task.products, documentType: task.documentType,
    ocrFieldValues: task.ocrFieldValues, ocrParties: task.ocrParties, accounting: task.accounting,
    documentMappings: task.documentMappings, documentStructure: task.documentStructure,
    advanceEmployeeId: task.advanceEmployeeId, advanceEmployee: task.advanceEmployee });
}
