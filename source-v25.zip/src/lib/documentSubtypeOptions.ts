export type DocumentTypeReference = { code: string; fullName: string; parentCode: string; status: string; previousNames?: string[] };

/** OCR Administration is the single source of document type/subtype choices. */
export function documentSubtypeOptions(records: readonly DocumentTypeReference[], type: string) {
  const selected = records.find(record => record.code === type);
  const parentCode = selected?.parentCode || selected?.code || type;
  const parent = records.find(record => record.code === parentCode && !record.parentCode);
  if (!parent || parent.status.toLowerCase() !== 'active') return [];
  return records.filter(record => record.parentCode === parentCode && record.status.toLowerCase() === 'active')
    .map(record => ({ value: record.code, label: record.fullName || record.code }));
}

export function validateDocumentSubtype(records: readonly DocumentTypeReference[], type: string, subtype: string) {
  if (subtype && !documentSubtypeOptions(records, type).some(option => option.value === subtype))
    throw new Error('Select a subtype belonging to the selected document type.');
}
