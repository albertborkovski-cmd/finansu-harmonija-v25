import { parseSession } from './accessControl';
import { AUTH_SESSION_KEY } from './currentUser';
import { COMPANY_EXPORT_FORMATS } from './companyDigitizationSettings';
import type { Company, DbDocument } from './supabase';

export type ProfileOcrSettings = {
  version: 1;
  api: { enabled: boolean; name: string; uploadDocuments: boolean; readResults: boolean };
  general: { documentAccess: 'restricted' | 'link'; digitization: 'summary' | 'detailed'; splitDocuments: boolean; rejectDuplicates: boolean; rejectNonInvoices: boolean; exportFormat: string };
  gdrive: { importFolder: string; importUrl: string; sharedDriveId: string; archiveFolder: string; includeSubfolders: boolean };
};
export const profileOcrSettingsKey = (email: string) => `finansu-harmonija-v24:profile-ocr:v1:${email.trim().toLowerCase()}`;
export function defaultProfileOcrSettings(): ProfileOcrSettings {
  return { version: 1, api: { enabled: false, name: 'FH integration', uploadDocuments: true, readResults: false }, general: { documentAccess: 'restricted', digitization: 'summary', splitDocuments: true, rejectDuplicates: true, rejectNonInvoices: false, exportFormat: '' },
    gdrive: { importFolder: 'Finansų harmonija', importUrl: '', sharedDriveId: '', archiveFolder: 'Finansų harmonija', includeSubfolders: true } };
}
function ownProfile(storage: Pick<Storage, 'getItem'>, email: string) {
  const session = parseSession(storage.getItem(AUTH_SESSION_KEY));
  if (!email.trim() || session?.email.trim().toLowerCase() !== email.trim().toLowerCase() || session.roleNames.includes('Inactive')) throw new Error('Only your own profile settings can be changed.');
}
/** Only configuration, never API keys, OAuth tokens or a claimed connection state. */
export function normalizeProfileOcrSettings(raw: unknown): ProfileOcrSettings {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new Error('Could not read profile OCR settings.');
  const value = raw as ProfileOcrSettings;
  if (value.version !== 1 || !value.general || !value.gdrive) throw new Error('Could not read profile OCR settings.');
  const g = value.general, d = value.gdrive;
  const api = value.api ?? defaultProfileOcrSettings().api;
  if ([api.enabled, api.uploadDocuments, api.readResults].some(item => typeof item !== 'boolean') || typeof api.name !== 'string' || api.name.length > 120) throw new Error('Select valid API settings.');
  if (api.enabled && (!api.name.trim() || (!api.uploadDocuments && !api.readResults))) throw new Error('Enter an API key name and select at least one permission.');
  if (!['restricted', 'link'].includes(g.documentAccess) || !['summary', 'detailed'].includes(g.digitization)
    || [g.splitDocuments, g.rejectDuplicates, g.rejectNonInvoices, d.includeSubfolders].some(item => typeof item !== 'boolean')
    || (g.exportFormat !== '' && !COMPANY_EXPORT_FORMATS.includes(g.exportFormat as typeof COMPANY_EXPORT_FORMATS[number]))) throw new Error('Select a valid settings option.');
  const text = (input: unknown) => { if (typeof input !== 'string' || input.length > 1000) throw new Error('One of the values is too long.'); return input.trim(); };
  const importUrl = text(d.importUrl);
  if (importUrl) {
    try { const url = new URL(importUrl); if (url.protocol !== 'https:' || url.hostname !== 'drive.google.com' || url.username || url.password) throw Error(); }
    catch { throw new Error('Enter a Google Drive folder URL beginning with https://drive.google.com/.'); }
  }
  return { version: 1, api: { enabled: api.enabled, name: api.name.trim(), uploadDocuments: api.uploadDocuments, readResults: api.readResults }, general: { documentAccess: g.documentAccess, digitization: g.digitization, splitDocuments: g.splitDocuments, rejectDuplicates: g.rejectDuplicates, rejectNonInvoices: g.rejectNonInvoices, exportFormat: g.exportFormat },
    gdrive: { importFolder: text(d.importFolder), importUrl, sharedDriveId: text(d.sharedDriveId), archiveFolder: text(d.archiveFolder), includeSubfolders: d.includeSubfolders } };
}
export function readProfileOcrSettings(storage: Pick<Storage, 'getItem'>, email: string) {
  ownProfile(storage, email);
  const raw = storage.getItem(profileOcrSettingsKey(email));
  if (!raw) return defaultProfileOcrSettings();
  try { return normalizeProfileOcrSettings(JSON.parse(raw)); }
  catch { throw new Error('Could not read profile OCR settings.'); }
}
export function saveProfileOcrSettings(storage: Pick<Storage, 'getItem' | 'setItem'>, email: string, section: 'general' | 'gdrive' | 'api', values: ProfileOcrSettings['general'] | ProfileOcrSettings['gdrive'] | ProfileOcrSettings['api']) {
  ownProfile(storage, email);
  const next = normalizeProfileOcrSettings({ ...readProfileOcrSettings(storage, email), [section]: values });
  storage.setItem(profileOcrSettingsKey(email), JSON.stringify(next));
  return next;
}

/** Permission-filtered client companies only; current month and five previous months. */
export function profileDocumentStatistics(companies: Company[], documents: DbDocument[], now = new Date()) {
  const months = Array.from({ length: 6 }, (_, index) => {
    const date = new Date(now.getFullYear(), now.getMonth() - 5 + index, 1);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
  });
  const entries = companies.filter(company => company.is_organization_client !== false).map(company => ({ id: company.id, name: company.name, code: company.company_code || '', counts: months.map(() => 0) }));
  const byId = new Map(entries.map(entry => [entry.id, entry]));
  const seen = new Set<string>();
  for (const doc of documents) {
    if (seen.has(doc.id) || doc.entry_method === 'manual' || doc.document_deletion) continue;
    seen.add(doc.id);
    const entry = byId.get(doc.company_id || ''), month = String(doc.document_date || '').slice(0, 7), index = months.indexOf(month);
    if (entry && index >= 0) entry.counts[index]++;
  }
  return { months, entries };
}
