export type OcrHandwriting = 'full' | 'partial' | 'none';
export type HandwritingSource = { ocr_handwriting?: unknown; ocr_multiple_documents?: unknown; ocr_poor_quality?: boolean; ocr_quality_review_required?: boolean };
export type DocumentStructureDecision = { choice: 'single' | 'split'; at: string; actor: string };

export function multipleDocumentsFilterValue(source?: HandwritingSource | null): 'Yes' | 'No' | 'Not checked' {
  return source?.ocr_multiple_documents === true ? 'Yes' : source?.ocr_multiple_documents === false ? 'No' : 'Not checked';
}
export const MULTIPLE_DOCUMENTS_FILTER = { key: 'multipleDocuments', label: 'Multiple documents suspected', options: ['Yes', 'No', 'Not checked'] };
export function requiresDocumentStructureReview(document: { ocr_multiple_documents?: unknown; ocr_document_structure?: DocumentStructureDecision }) {
  return document.ocr_multiple_documents === true && document.ocr_document_structure?.choice !== 'single';
}

/** Explicit OCR metadata only: filenames, notes and missing fields are not evidence. */
export function ocrHandwriting(source?: HandwritingSource | null): OcrHandwriting | undefined {
  const value = source?.ocr_handwriting;
  return value === 'full' || value === 'partial' || value === 'none' ? value : undefined;
}

export function isHandwrittenDocument(source?: HandwritingSource | null): boolean {
  const value = ocrHandwriting(source);
  return value === 'full' || value === 'partial';
}

export function handwritingFilterValue(source?: HandwritingSource | null): 'Yes' | 'No' | 'Not checked' {
  const value = ocrHandwriting(source);
  return value === undefined ? 'Not checked' : value === 'none' ? 'No' : 'Yes';
}

export const HANDWRITING_FILTER = {
  key: 'handwritten', label: 'Handwritten', options: ['Yes', 'No', 'Not checked'],
};
