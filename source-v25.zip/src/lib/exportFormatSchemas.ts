import type { AdditionalDocumentColumn } from './documentAdditionalColumns';

export type ExportField = { key: string; label: string; type: 'text' | 'password' | 'checkbox' | 'select' | 'number'; options?: readonly string[]; defaultValue?: string | boolean; help?: string };
export type ExportSection = { title: string; fields: ExportField[] };
export type ExportColumn = { key: string; label: string; sourceKey?: AdditionalDocumentColumn };
export type ExportFormatSchema = { sections: ExportSection[]; columns: ExportColumn[]; assignmentStage?: boolean; createCompanies?: boolean; createProducts?: boolean; exportImmediately?: boolean };
const text = (key: string, label: string, help?: string): ExportField => ({ key, label, type: 'text', help });
const secret = (key = 'apiKey', label = 'API key'): ExportField => ({ key, label, type: 'password' });
const check = (key: string, label: string): ExportField => ({ key, label, type: 'checkbox' });
const section = (title: string, ...fields: ExportField[]): ExportSection => ({ title, fields });
const column = (key: string, label: string, sourceKey?: AdditionalDocumentColumn): ExportColumn => ({ key, label, sourceKey });
const department = column('departmentCode', 'Department', 'departmentCode');
const object = column('objectProject', 'Object', 'objectProject');
const project = column('objectProject', 'Project', 'objectProject');
const expense = column('expenseAccount', 'Expense code', 'expenseAccount');
const vat = column('vatClassifier', 'VAT classifier', 'vatClassifier');
const vatCode = column('vatClassifier', 'VAT code', 'vatClassifier');
const warehouse = column('warehouse', 'Warehouse');
const documentWarehouse = column('documentWarehouse', 'Document warehouse');
const lineWarehouse = column('lineWarehouse', 'Line warehouse');
const type = column('type', 'Type');
const correspondence = column('correspondence', 'Correspondence');
const accountable = column('accountableResponsible', 'Accountable person', 'accountableResponsible');
const basicColumns = [expense, vat];
const basic = (): ExportFormatSchema => ({ sections: [], columns: basicColumns });
const jumisFields: ExportField[] = [
  { key: 'jumisDocumentBlock', label: 'Jumis document structure', type: 'select', options: ['StoreDoc', 'FinancialDoc'], defaultValue: 'StoreDoc' },
  text('debitAccount', 'Debit GL account'), text('creditAccount', 'Credit GL account'),
];
const ignoreNonPositive = check('ignoreNonPositive', 'Ignore lines with an amount of zero or less');
const creditDirection = section('Credit invoice settings',
  check('reverseSummaryCreditDirection', 'Switch summary credit invoice direction (purchase ↔ sale)'),
  check('reverseDetailedCreditDirection', 'Switch detailed credit invoice direction (purchase ↔ sale)'));
const rivileSections = [
  section('Item settings', text('itemAccountLinkCode', 'Item account link code'), text('itemType', 'Item type')),
  section('Payment account codes', text('salesPaymentAccount', 'Sales payment account code'), text('purchasePaymentAccount', 'Purchase payment account code')),
  section('Operation type',
    { key: 'salesOperation', label: 'Sales operation type', type: 'select', options: ['Waybill', 'Order', 'Reservation', 'Offer'], defaultValue: 'Waybill' },
    { key: 'purchaseOperation', label: 'Purchase operation type', type: 'select', options: ['Waybill', 'Order', 'Offer'], defaultValue: 'Waybill' }),
];
const rivileColumns = [department, object, column('series', 'Series', 'series'), column('costCenter', 'Center', 'costCenter'), accountable,
  column('productGroup', 'Product group', 'productGroup'), column('note', 'Note', 'note'), expense, vat];

/** Field structure observed in the export-format selector. No production values are included. */
export const EXPORT_FORMAT_SCHEMAS: Record<string, ExportFormatSchema> = {
  Agnum: { sections: [section('Agnum settings', text('itemAccountCode', 'Item account code'), check('fillRegistrationNumber', 'Fill the document registration number during export'))], columns: [documentWarehouse, lineWarehouse, column('group', 'Group'), object, expense, vat] },
  Apskaita5: basic(),
  BSS: { sections: [], columns: [column('taxCode', 'Tax code'), warehouse, department, expense, vat] },
  'BSS Api': { sections: [section('BSS API', text('username', 'Username'), secret(), text('portfolio', 'Portfolio name'), text('serverUrl', 'Server URL')),
    section('BSS API V2 (optional)', text('v2Url', 'API URL'), text('v2Username', 'User'), secret('v2Password', 'Password'), text('environmentId', 'Environment ID'), text('companyId', 'Company ID'))],
    columns: [documentWarehouse, lineWarehouse, department, project, accountable, expense, column('taxCode', 'Tax code')] },
  'Business Central': { sections: [section('Business Central API', text('apiUrl', 'API URL'), text('authorizationUrl', 'Authorization URL'), text('clientId', 'Client ID'), secret('clientSecret', 'Client secret')),
    section('Counterparty templates', ...['LT', 'EU', 'Non-EU'].flatMap((region, index) => [text(`buyerTemplate${index}`, `${region} buyer template code`), text(`supplierTemplate${index}`, `${region} supplier template code`)])),
    section('Item settings', text('genProdPostingGroup', 'Item Gen. Prod. Posting Group'), text('vatProdPostingGroup', 'Item VAT Prod. Posting Group'), text('inventoryPostingGroup', 'Item Inventory Posting Group'))],
    columns: [department, project, column('assetUnitCode', 'Asset unit code'), vatCode, expense] },
  'Būtent': { sections: [section('Export settings', ignoreNonPositive)], columns: [warehouse, column('operation', 'Operation'), column('cost', 'Cost'), expense, vat] },
  'Būtent kiekinis': { sections: [section('Export settings', ignoreNonPositive)], columns: [warehouse, column('operation', 'Operation'), column('cost', 'Cost'), expense, vat] },
  Centas: { sections: [section('Item settings', text('itemDebit', 'Item debit account'), text('itemCredit', 'Item credit account'), text('itemRevenue', 'Item revenue account'))], columns: [warehouse, object, expense, vat] },
  CSV: basic(),
  Debetas: { sections: [section('Debetas settings', text('branch', 'Branch', 'Branch through which files are uploaded.'), text('credit', 'Credit'))], columns: [department, object, column('expenseArticle', 'Expense article'), column('accountableResponsible', 'Materially responsible person', 'accountableResponsible'), expense, vat] },
  'Debetas Excel': { sections: [section('Debetas settings', text('branch', 'Branch', 'Branch through which files are uploaded.'), text('credit', 'Credit'))], columns: [department, object, expense, vat] },
  Dineta: { sections: [section('Dineta connection', text('serverUrl', 'Server URL'), text('username', 'Username'), secret('password', 'Password')),
    section('Accounting templates', text('purchaseGlTemplate', 'Purchase GL template'), text('salesGlTemplate', 'Sales GL template'))], columns: [warehouse, expense, vat] },
  Directo: { sections: [section('Directo API', secret('purchaseApiKey', 'Purchases API key'), secret('salesApiKey', 'Sales API key'))], columns: [warehouse, vatCode, expense], assignmentStage: true },
  Euroskaita: { sections: [], columns: [type, warehouse, expense, vat] },
  Excel: basic(),
  Finvalda: { sections: [section('Item settings', text('itemKind', 'New item kind'))], columns: [warehouse, type, column('journal', 'Journal'), expense, vat] },
  'Finvalda Excel': { sections: [], columns: [vatCode, type, expense] },
  iSAF: basic(),
  Json: { sections: [], columns: [department, object, expense, vat] },
  Lobasoft: basic(),
  Monet: { sections: [section('Monet settings', text('identificationCode', 'Identification code'))], columns: [vatCode, correspondence, expense], assignmentStage: true },
  Odoo: { sections: [section('Odoo connection', text('apiUrl', 'API URL'), text('clientId', 'Client ID'), secret('clientPassword', 'Client password or API key')),
    section('Odoo settings', text('defaultProductName', 'Default product name'), text('payableAccount', 'Payable account code'))], columns: [vatCode, expense] },
  Optimum: { sections: [section('Optimum API', secret()), section('Optimum settings', text('inputVatAccount', 'Input VAT GL account'), text('newSupplierGroup', 'New supplier group'),
    text('newCustomerGroup', 'New customer group'), text('newProductGroup', 'New product group'), text('newProductType', 'New product type'),
    { key: 'newProductVatRate', label: 'New product VAT rate', type: 'number' }, { key: 'maxProductCodeLength', label: 'Maximum product code length', type: 'number' },
    check('importAttachments', 'Import attachments during export'), ignoreNonPositive)],
    columns: [warehouse, column('division', 'Division'), column('projectManagerCode', 'Suggested project manager code'), column('projectCode', 'Project code'), column('batchNumber', 'Batch number'), column('batchDivisor', 'Batch divisor'), expense, vat] },
  Paulita: basic(),
  Pragma3: { sections: [section('Pragma3 settings', text('credit', 'Credit'), text('debit', 'Debit')), creditDirection], columns: [warehouse, correspondence, column('documentProject', 'Document project'), column('lineProject', 'Line project'), column('expenseAccount', 'Pragma item', 'expenseAccount'), vat] },
  Pragma4: { sections: [creditDirection], columns: [warehouse, correspondence, column('expenseAccount', 'Pragma item', 'expenseAccount'), vat] },
  'Pragma4 V2': { sections: [], columns: [warehouse, correspondence, column('expenseAccount', 'Item', 'expenseAccount'), vat] },
  'Rivilė': { sections: rivileSections, columns: rivileColumns },
  'Rivilė API': { sections: [section('Rivilė API', { ...secret(), help: 'Contact Rivilė to create an API key and enter it here.' }), rivileSections[0],
    section('Expense update settings', check('updateProducts', 'Automatically update products'), check('updateServices', 'Automatically update services'), check('updateCodes', 'Automatically update codes'), check('postInRivile', 'Automatically post the document in Rivilė')),
    ...rivileSections.slice(1)], columns: rivileColumns, assignmentStage: true, createCompanies: true, createProducts: true, exportImmediately: true },
  'Rivilė ERP': { sections: [section('Rivilė ERP API', secret())], columns: [department, object, expense, vat], assignmentStage: true, createCompanies: true, createProducts: true },
  Roda: { sections: [], columns: [department, object, expense, vat] },
  Saikas: { sections: [section('Saikas accounts', text('purchaseAccount', 'Purchase account'), text('purchaseVatAccount', 'Purchase VAT GL account'), text('salesAccount', 'Sales account'), text('salesVatAccount', 'Sales VAT GL account'))], columns: [department, expense, vat] },
  'Site.pro': { sections: [section('Site.pro API', secret()), section('Credit invoice settings', check('negativeSummaryCredit', 'Export summary credit invoices with negative amounts'), check('negativeQuantityCredit', 'Export quantity credit invoices with negative amounts')),
    section('Employee', text('employeeName', 'Employee full name'))], columns: [documentWarehouse, lineWarehouse, column('operation', 'Operation'), column('annotation', 'Annotation'), column('vatRegister', 'VAT register'), expense, vat], assignmentStage: true, createProducts: true },
  StandardERP: { sections: [], columns: [warehouse, expense, vat] },
  Syrve: { sections: [section('Syrve connection', text('apiUrl', 'API URL'), text('username', 'Username'), secret('password', 'Password')),
    section('Item settings', check('externalRawMaterialsOnly', 'Search items only among external raw materials'), check('recalculateItemQuantity', 'Recalculate item quantity using the Syrve item card'))],
    columns: [warehouse, column('concept', 'Concept'), expense, column('invoiceNumber', 'Invoice number')], createProducts: true, exportImmediately: true },
  'UCS StoreHouse v4': { sections: [section('Export delivery', text('exportEmail', 'Email address for exported documents'))], columns: [expense, department] },
  Uniconta: basic(),
  XML: { sections: [], columns: [department, object, expense, vat] },
  'MONEO Excel': { sections: [section('MONEO import', { key: 'invoiceDetail', label: 'Invoice detail', type: 'select', options: ['summary', 'detailed'], defaultValue: 'detailed' })], columns: [expense, vat] },
  'MONEO API': { sections: [section('MONEO API', text('apiUrl', 'API URL'), text('compuid', 'MONEO company ID (compuid)'), secret('moneoApiKey'))], columns: [expense, vat] },
  'Jumis Excel': { sections: [section('Jumis import', ...jumisFields, { key: 'excelStructure', label: 'Excel structure', type: 'select', options: ['structured', 'simplified'], defaultValue: 'structured', help: 'Use the structured workbook for documents with multiple lines.' })], columns: [department, warehouse, expense, vat] },
  'Jumis XML': { sections: [section('Jumis import', ...jumisFields)], columns: [department, warehouse, expense, vat] },
  'Jumis API': { sections: [section('Jumis API', text('apiUrl', 'API URL'), text('database', 'Database'), text('username', 'Username'), secret('sqlPassword', 'Jumis special SQL password'), secret('jumisApiKey')), section('Jumis import', ...jumisFields)], columns: [department, warehouse, expense, vat] },
  'Horizon Peppol XML': { sections: [section('Horizon import', text('documentTypeCode', 'Destination document type code'))], columns: [department, object, expense, vat] },
  'Horizon API': { sections: [section('Horizon REST', text('apiUrl', 'API URL'), text('horizonWebUser', 'Horizon WEB user'), secret('horizonPassword', 'Horizon WEB password'), text('documentTypeCode', 'Destination document type code'))], columns: [department, object, expense, vat] },
  'Zalktis XML': { sections: [], columns: [expense, vat] },
  'Zalktis Accounting XML': { sections: [section('Zalktis accounting', text('debitAccount', 'Debit GL account'), text('creditAccount', 'Credit GL account'))], columns: [expense, vat] },
};

export const COMMON_EXPORT_SECTIONS: ExportSection[] = [
  section('Individual buyer code', { key: 'individualBuyerCode', label: 'Code assignment', type: 'select', options: ['unique', 'fixed'], defaultValue: 'unique' }, text('fixedBuyerCode', 'Fixed buyer code')),
  section('Primary line code', { key: 'primaryLineCode', label: 'Primary line code', type: 'select', options: ['barcode', 'code'], defaultValue: 'barcode' }),
];
export function exportSchema(format: string): ExportFormatSchema {
  return Object.prototype.hasOwnProperty.call(EXPORT_FORMAT_SCHEMAS, format) ? EXPORT_FORMAT_SCHEMAS[format] : basic();
}
export function exportSections(format: string): ExportSection[] {
  const schema = exportSchema(format);
  return [...schema.sections, ...COMMON_EXPORT_SECTIONS,
    ...(schema.assignmentStage ? [section('Automatic additional column assignment', { key: 'additionalColumnsAt', label: 'Assignment stage', type: 'select', options: ['digitization', 'export'], defaultValue: 'digitization' })] : []),
    section('Other settings', { key: 'vatSeparation', label: 'VAT separation', type: 'select', options: ['automatic', 'separate-non-payers', 'include-payers'], defaultValue: 'automatic' },
      check('foreignVatAsCompanyCode', 'Use VAT number as company code for foreign companies'), check('dueDateFromInvoiceDate', 'Use invoice date as due date if no due date is specified'),
      ...(schema.createCompanies ? [check('createCompaniesOnExport', 'Create new companies during export')] : []),
      ...(schema.createProducts ? [check('createProductsOnExport', 'Create new products during export')] : []),
      ...(schema.exportImmediately ? [check('exportAfterDigitization', 'Export invoices immediately after digitization')] : []))];
}
export const EXPORT_OPTION_LABELS: Record<string, string> = { StoreDoc: 'Stock / trading documents (StoreDoc)', FinancialDoc: 'Financial operations (FinancialDoc)', structured: 'Structured workbook (multiple lines)', simplified: 'Simplified workbook (one line)', summary: 'Summary', detailed: 'Detailed lines', unique: 'Unique value per person', fixed: 'Fixed value', barcode: 'Barcode', code: 'Code', digitization: 'During digitization', export: 'During export', automatic: 'Automatic', 'separate-non-payers': 'Separate invoice VAT for non-VAT payers', 'include-payers': 'Do not separate invoice VAT for VAT payers' };
