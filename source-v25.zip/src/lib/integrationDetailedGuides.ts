import type { HelpText } from './exportHelpGuide';
import type { IntegrationArticle } from './integrationHelp';
import type { IntegrationHelpExample, IntegrationHelpSection, IntegrationHelpTopic } from './integrationHelpTopics';

// The Agnum procedure was supplied by the user. FH steps refer to our UI;
// example identifiers below are illustrative, never production defaults.
export const AGNUM_INVOICE_GUIDE: IntegrationHelpTopic = {
  id: 'invoice-import', sourceArticleIds: [7128078],
  title: ['Exporting invoices from FH and importing into Agnum: totals and quantities', 'Sąskaitų eksportavimas iš FH ir importavimas į Agnum: suminis ir kiekinis'],
  description: ['Follow the complete route from the processed invoice to XML import, accounting scheme assignment and result verification in Agnum.', 'Visa eiga nuo suskaitmenintos sąskaitos iki XML importo, apskaitos schemos priskyrimo ir rezultato patikrinimo Agnum.'],
  sections: [
    {
      title: ['1. Choose totals or quantity import', '1. Pasirinkite suminį arba kiekinį importą'], system: 'Agnum',
      paragraphs: [['Both purchase and sales invoices can be imported. Choose the method according to the detail needed in accounting, not merely according to how many lines the PDF contains.', 'Galima importuoti tiek pirkimo, tiek pardavimo sąskaitas. Būdą pasirinkite pagal apskaitoje reikalingą detalumą, ne vien pagal PDF matomų eilučių skaičių.']],
      table: {
        headers: [['Method', 'Būdas'], ['What is transferred', 'Kas perkeliama'], ['Agnum checkbox', 'Agnum varnelė']],
        rows: [
          [['Totals', 'Suminis'], ['Invoice totals; the accounting scheme is selected in Agnum.', 'Sąskaitos sumos; apskaitos schema parenkama Agnum.'], ['Importuoti sumine išraiška: checked', 'Importuoti sumine išraiška: pažymėta']],
          [['Quantities / lines', 'Kiekinis / su eilutėmis'], ['Digitized lines, quantities and assigned product / service codes.', 'Suskaitmenintos eilutės, kiekiai ir priskirti prekių / paslaugų kodai.'], ['Importuoti sumine išraiška: unchecked', 'Importuoti sumine išraiška: nepažymėta']],
        ],
      },
      example: { title: ['Example: the same invoice, two methods', 'Pavyzdys: ta pati sąskaita, du būdai'], paragraphs: [
        ['Invoice AG-2026-001 contains 2 items at EUR 50 and 1 service at EUR 100. Net amount: EUR 200; VAT at 21%: EUR 42; total: EUR 242.', 'Sąskaitoje AG-2026-001 yra 2 prekės po 50 EUR ir 1 paslauga už 100 EUR. Be PVM – 200 EUR; 21 % PVM – 42 EUR; iš viso – 242 EUR.'],
        ['Totals import uses these invoice amounts. Quantity import must also preserve both lines: product code, quantity 2, unit price 50; service code, quantity 1, unit price 100. The invoice total remains EUR 242 in either method.', 'Suminis importas naudoja sąskaitos sumas. Kiekinis papildomai išsaugo abi eilutes: prekės kodą, kiekį 2, kainą 50; paslaugos kodą, kiekį 1, kainą 100. Abiem būdais bendra sąskaitos suma lieka 242 EUR.'],
      ] },
    },
    {
      title: ['2. Check the invoice and codes in FH', '2. Patikrinkite sąskaitą ir kodus FH'], system: 'FH',
      steps: [
        ['Open All Documents → Documents and select the organization whose accounting you are managing. The invoice must have completed OCR processing and have no unresolved issue blocking export.', 'Atverkite Visi dokumentai → Dokumentai ir pasirinkite organizaciją, kurios apskaitą tvarkote. Sąskaita turi būti apdorota OCR, be neišspręstos klaidos, blokuojančios eksportą.'],
        ['Open the organization gear → Documents & digitization setup. Select Agnum. Review the item account code and registration-number option; save the settings for this organization.', 'Atverkite organizacijos dantratį → Dokumentų ir skaitmeninimo nustatymai. Pasirinkite Agnum. Patikrinkite prekės sąskaitos kodą bei registracijos numerio parinktį ir išsaugokite šios organizacijos nustatymus.'],
        ['In the document check purchase / sale direction, number, dates, counterparty, currency and all three amounts against the original. Select the VAT classifier that corresponds to the transaction.', 'Dokumente sutikrinkite pirkimo / pardavimo kryptį, numerį, datas, kontrahentą, valiutą ir visas tris sumas su originalu. Pasirinkite operacijai tinkantį PVM klasifikatorių.'],
        ['For quantity import, review every digitized line and assign the receiving product or service code in Expense. Import the code directory first if the required values are missing.', 'Kiekiniam importui peržiūrėkite kiekvieną suskaitmenintą eilutę ir lauke Išlaida priskirkite gavėjo prekės arba paslaugos kodą. Jei pasirinkimų nėra, pirmiausia įkelkite kodų sąrašą.'],
        ['Where applicable, check warehouse, group and object. FH exposes document / line warehouse defaults in Additional column settings; it does not yet have a separate Agnum warehouse picker on every document.', 'Kai taikoma, patikrinkite sandėlį, grupę ir objektą. FH Papildomų stulpelių nustatymuose pateikia dokumento / eilutės sandėlio numatytąsias reikšmes; atskiro Agnum sandėlio pasirinkimo kiekviename dokumente dar nėra.'],
      ],
      links: [
        { topic: 'item-codes', label: ['How to import product and service codes from Agnum', 'Kaip iš Agnum įkelti prekių ir paslaugų kodus'] },
        { topic: 'warehouses', label: ['Where to find and enter warehouse codes', 'Kur rasti ir įrašyti sandėlių kodus'] },
        { topic: 'configuration', label: ['Agnum settings and field descriptions', 'Agnum nustatymai ir laukų paaiškinimai'] },
      ],
    },
    {
      title: ['3. Export the selected invoices and unpack the files', '3. Eksportuokite pažymėtas sąskaitas ir išskleiskite failus'], system: 'FH',
      steps: [
        ['Mark the required invoices in Documents. Use Export selected documents and select Agnum. File download is separate from Send to accounting.', 'Dokumentų sąraše varnelėmis pažymėkite reikiamas sąskaitas. Rinkitės Eksportuoti pažymėtus dokumentus ir Agnum. Failo atsisiuntimas yra atskiras nuo Siųsti į apskaitos sistemą.'],
        ['For a real Agnum import you need compatible invoice XML. The current FH export is a preview with importReady=false, not an import-certified Agnum file. Use the following Agnum steps only with a validated production file.', 'Tikram Agnum importui reikia suderinamo sąskaitų XML. Dabartinis FH eksportas yra peržiūra su importReady=false, ne importui patvirtintas Agnum failas. Toliau aprašytus Agnum veiksmus atlikite tik su patikrintu produkciniu failu.'],
        ['If the validated export arrives as ZIP, unpack it first: Windows → right-click → Extract all; macOS → double-click the ZIP. Open the extracted folder, not the archive itself.', 'Jei patikrintas eksportas pateiktas ZIP archyvu, pirmiausia jį išskleiskite: Windows → dešinysis pelės mygtukas → Išskleisti viską; macOS → dukart spustelėkite ZIP. Atverkite išskleistą aplanką, ne patį archyvą.'],
        ['Keep purchase and sales files separate. Select the purchase XML in the purchase import and the sales XML in the sales import. Renaming a JSON or ZIP extension to XML does not convert its contents.', 'Pirkimų ir pardavimų failus atskirkite. Pirkimų importe rinkitės pirkimų XML, pardavimų importe – pardavimų XML. JSON ar ZIP plėtinio pakeitimas į XML duomenų nekonvertuoja.'],
      ],
    },
    {
      title: ['4. Import purchase invoices in Agnum', '4. Importuokite pirkimo sąskaitas į Agnum'], system: 'Agnum',
      steps: [
        ['In the intended Agnum company open Dokumentai → Pajamavimai → Atidėjimai → Importas iš XML.', 'Reikiamoje Agnum įmonėje atverkite Dokumentai → Pajamavimai → Atidėjimai → Importas iš XML.'],
        ['For totals import, check Importuoti sumine išraiška. For detailed quantities and item lines, leave this option unchecked.', 'Suminėms sąskaitoms pažymėkite Importuoti sumine išraiška. Jei importuojate kiekius ir prekių eilutes, varnelę nuimkite.'],
        ['Select the extracted purchase XML file and click Nuskaityti failą. Review the loaded invoice numbers, quantities and amounts.', 'Pasirinkite išskleistą pirkimų XML failą ir spauskite Nuskaityti failą. Peržiūrėkite nuskaitytus sąskaitų numerius, kiekius ir sumas.'],
        ['Use Patikrinti and Importuoti, or the combined Patikrinti ir importuoti action. If validation reports errors, resolve them before importing again.', 'Rinkitės Patikrinti ir Importuoti arba bendrą Patikrinti ir importuoti veiksmą. Jei tikrinimas nurodo klaidų, pašalinkite jas prieš pakartotinį importą.'],
      ],
      links: [{ topic: 'duplicate-control', label: ['Check for an existing invoice before repeating the import', 'Kaip patikrinti dublikatą prieš kartojant importą'] }],
    },
    {
      title: ['5. Import sales invoices in Agnum', '5. Importuokite pardavimo sąskaitas į Agnum'], system: 'Agnum',
      steps: [
        ['Open Dokumentai → Pardavimai → Išankstinės sąskaitos → Importas iš XML in the same intended company.', 'Reikiamoje įmonėje atverkite Dokumentai → Pardavimai → Išankstinės sąskaitos → Importas iš XML.'],
        ['Check Importuoti sumine išraiška for summarized invoices; uncheck it when importing item quantities and lines.', 'Suminėms sąskaitoms pažymėkite Importuoti sumine išraiška; importuojant kiekius ir eilutes – nuimkite.'],
        ['Choose the sales XML, then Nuskaityti failą. Do not select the purchase file simply because the invoice numbers look similar.', 'Pasirinkite pardavimų XML ir spauskite Nuskaityti failą. Nesirinkite pirkimų failo vien todėl, kad sąskaitų numeriai panašūs.'],
        ['Run Patikrinti and Importuoti, or Patikrinti ir importuoti. Check the result for each imported document, not just whether the dialog closed.', 'Vykdykite Patikrinti ir Importuoti arba Patikrinti ir importuoti. Patikrinkite kiekvieno dokumento rezultatą, ne vien tai, ar užsidarė langas.'],
      ],
    },
    {
      title: ['6. Assign a scheme and post one invoice', '6. Priskirkite schemą ir perkelkite vieną sąskaitą'], system: 'Agnum',
      paragraphs: [['Import and posting are two different steps. In the deferred-document list, set the date filter to include the imported invoices before searching for them.', 'Importas ir perkėlimas į apskaitą – du skirtingi veiksmai. Atidėtų dokumentų sąraše nustatykite laikotarpį, apimantį importuotas sąskaitas.']],
      steps: [
        ['Open the invoice in the deferred-document list and check its number and counterparty.', 'Atidėtų dokumentų sąraše atverkite sąskaitą ir sutikrinkite jos numerį bei kontrahentą.'],
        ['Select the accounting scheme appropriate to that transaction. A purchase scheme should not be reused for an unrelated sales transaction.', 'Pasirinkite tai operacijai tinkamą apskaitos schemą. Pirkimo schemos netaikykite nesusijusiai pardavimo operacijai.'],
        ['Check Perkelti, then click Išsaugoti. Check the resulting accounting entry in Agnum.', 'Pažymėkite Perkelti ir spauskite Išsaugoti. Agnum patikrinkite sukurtą apskaitos įrašą.'],
      ],
    },
    {
      title: ['7. Assign a scheme to multiple invoices', '7. Priskirkite schemą kelioms sąskaitoms'], system: 'Agnum',
      steps: [
        ['In Agnum open the gear in the top toolbar and choose Atidėtų dokumentų perkėlimas.', 'Viršutinėje Agnum juostoje paspauskite dantratį ir pasirinkite Atidėtų dokumentų perkėlimas.'],
        ['Enable Automatiškai perkelti pagal schemą and choose the scheme to apply. Check the applicable documents and period before starting.', 'Pažymėkite Automatiškai perkelti pagal schemą ir pasirinkite taikomą schemą. Prieš pradėdami patikrinkite apimamų dokumentų ir laikotarpio pasirinkimą.'],
        ['Click Pradėti. Review the posting result and handle rejected documents individually; do not assume every invoice succeeded.', 'Spauskite Pradėti. Peržiūrėkite perkėlimo rezultatą, o atmestus dokumentus tikrinkite atskirai – nelaikykite visų sąskaitų sėkmingai perkeltomis.'],
      ],
    },
    {
      title: ['8. Verify the final result', '8. Patikrinkite galutinį rezultatą'], system: 'Agnum',
      steps: [
        ['Search by invoice number and counterparty. Compare net, VAT and total amounts and currency with the original; for quantities, also compare each code, quantity and price.', 'Ieškokite pagal sąskaitos numerį ir kontrahentą. Su originalu sutikrinkite sumą be PVM, PVM, bendrą sumą ir valiutą; kiekiniu atveju – dar kiekvieną kodą, kiekį ir kainą.'],
        ['Confirm that the intended scheme was applied and the document was posted. A downloaded XML or an FH Exported label alone does not confirm Agnum posting.', 'Įsitikinkite, kad pritaikyta tinkama schema ir dokumentas perkeltas. Vien atsisiųstas XML ar FH žyma Eksportuota Agnum perkėlimo nepatvirtina.'],
        ['For AG-2026-001 in the example, the final total must remain EUR 242. If an import result is uncertain, look for this invoice before another attempt to avoid a duplicate.', 'Pavyzdžio AG-2026-001 galutinė suma turi likti 242 EUR. Jei importo rezultatas neaiškus, prieš kartodami ieškokite šios sąskaitos, kad nesukurtumėte dublikato.'],
      ],
      links: [{ topic: 'workflow-and-checks', label: ['Export result, errors and safe retry', 'Eksporto rezultatas, klaidos ir saugus pakartojimas'] }, { topic: 'duplicate-control', label: ['Agnum duplicate control', 'Agnum dublikatų kontrolė'] }],
    },
  ],
  note: ['FH currently provides export settings and a file preview, not a verified production Agnum adapter. These instructions distinguish the current FH interface from the Agnum procedure for a compatible production XML.', 'Dabartinėje FH versijoje yra eksporto nustatymai ir failo peržiūra, bet ne patikrintas produkcinis Agnum adapteris. Instrukcijoje atskirta dabartinė FH sąsaja ir Agnum eiga su suderinamu produkciniu XML.'],
  screenshot: { file: 'export-agnum.jpg', caption: ['FH organization export settings with Agnum selected.', 'FH organizacijos eksporto nustatymai pasirinkus Agnum.'] },
};

// Provider connectivity facts are checked against the official GAMA API,
// Gateway installation, response and good-practice guides. FH steps below
// describe this frontend; they never ask the user to enter production secrets.
const rivileGatewaySections: IntegrationHelpSection[] = [
  {
    title: ['1. Understand the connection', '1. Kaip veikia ryšys'], system: 'Rivilė GAMA',
    paragraphs: [['In a connected installation, the FH server adapter sends a request to Rivilė API. Manorivile-Gateway provides the route to the configured GAMA database. An API key authorizes access; it does not install the Gateway or select a database by guessing its name.', 'Prijungtoje sistemoje FH serverio adapteris siunčia užklausą į Rivilė API. Manorivile-Gateway perduoda ją sukonfigūruotai GAMA duomenų bazei. API raktas leidžia autorizuoti prieigą, bet neįdiegia Gateway ir neatspėja reikiamos bazės.']],
    table: {
      headers: [['Component', 'Dalis'], ['Purpose', 'Kam skirta'], ['Who verifies it', 'Kas patikrina']],
      rows: [
        [['API service and key', 'API paslauga ir raktas'], ['Access granted for the intended integration.', 'Suteikta prieiga reikiamai integracijai.'], ['Rivilė representative / administrator.', 'Rivilės atstovas / administratorius.']],
        [['Gateway', 'Gateway'], ['A running service that can reach GAMA.', 'Veikianti tarnyba, pasiekianti GAMA.'], ['The server administrator.', 'Serverio administratorius.']],
        [['Database', 'Duomenų bazė'], ['The company that receives the invoice.', 'Įmonė, į kurią patenka sąskaita.'], ['Administrator together with the accountant.', 'Administratorius kartu su buhalteriu.']],
        [['FH codes', 'FH kodai'], ['Supplier, item, VAT and allocation references.', 'Tiekėjo, prekės, PVM ir paskirstymo atitikmenys.'], ['The accountant.', 'Buhalteris.']],
      ],
    },
  },
  {
    title: ['2. Enable access on the Rivilė side', '2. Prieiga Rivilės pusėje'], system: 'Rivilė GAMA',
    steps: [
      ['Arrange the API service with Rivilė or its representative. Confirm the intended company, database name, base currency and database technology; use the identifiers from your installation, not example values.', 'Su Rivile ar jos atstovu suderinkite API paslaugą. Patvirtinkite įmonę, duomenų bazės vardą, bazinę valiutą bei bazės technologiją; naudokite savo diegimo identifikatorius, ne pavyzdines reikšmes.'],
      ['The administrator installs Gateway on a computer with access to the database and configures its connection. They verify that the service is running and the required network routes are available. The accountant does not enter database credentials into a help page.', 'Administratorius įdiegia Gateway kompiuteryje, pasiekiančiame bazę, ir sukonfigūruoja ryšį. Jis patikrina, ar tarnyba veikia ir tinklo ryšys leidžiamas. Buhalteris duomenų bazės prisijungimų į pagalbos puslapį neveda.'],
      ['Use a separate key for the integration where possible. Keep secrets in the connected server’s approved secret storage, not in email, screenshots, invoice notes or copied spreadsheets.', 'Integracijai naudokite atskirą raktą. Slaptus duomenis laikykite prijungto serverio patvirtintoje saugykloje, ne laiškuose, ekrano nuotraukose, sąskaitos pastaboje ar skaičiuoklėje.'],
    ],
  },
  {
    title: ['3. Select the matching FH organization and codes', '3. FH pasirinkite įmonę ir kodus'], system: 'FH',
    steps: [
      ['Open All Documents → Documents → select the organization → gear → Documents & digitization setup. Select Rivilė API, not the Rivilė file format or Rivilė ERP.', 'Atverkite Visi dokumentai → Dokumentai → pasirinkite organizaciją → dantratis → Dokumentų ir skaitmeninimo nustatymai. Rinkitės Rivilė API, ne Rivilė failo formatą ir ne Rivilė ERP.'],
      ['Confirm the displayed database belongs to this company. The database name is an identifier, not an API key. This frontend does not validate a real secret or connect to Gateway; use non-secret placeholders when reviewing the form.', 'Patikrinkite, ar rodoma duomenų bazė priklauso šiai įmonei. Bazės vardas yra identifikatorius, ne API raktas. Šis frontend netikrina tikro rakto ir nejungiasi prie Gateway; formos peržiūrai naudokite ne slaptus vietaženklius.'],
      ['Load the company’s customer and item / service codes, then assign the document VAT and required dimensions. A successful connection does not supply missing invoice allocations.', 'Įkelkite šios įmonės klientų bei prekių / paslaugų kodus, dokumentui priskirkite PVM ir privalomas dimensijas. Veikiantis ryšys neužpildo trūkstamo sąskaitos paskirstymo.'],
      ['Review automatic posting separately from automatic export. Keep these choices deliberate: the receiving system can create a document before it is posted to accounting.', 'Atskirai peržiūrėkite automatinį perkėlimą ir automatinį eksportą. Parinktis nustatykite sąmoningai: gavėjo sistemoje dokumentas gali būti sukurtas dar neperkeltas į apskaitą.'],
    ],
    links: [
      { topic: 'configuration', label: ['All Rivilė API settings explained', 'Visų Rivilė API nustatymų paaiškinimai'] },
      { topic: 'code-list', label: ['Import item and expense codes', 'Prekių ir išlaidų kodų įkėlimas'] },
      { topic: 'customer-list', label: ['Import customer identifiers', 'Klientų identifikatorių įkėlimas'] },
      { topic: 'automatic-export', label: ['Automatic export and posting', 'Automatinis eksportas ir perkėlimas'] },
    ],
  },
  {
    title: ['4. Read the response before retrying', '4. Prieš kartodami perskaitykite atsakymą'], system: 'Rivilė GAMA',
    paragraphs: [['In a production integration, inspect both the HTTP result and any document / line error in the response. A connection error and an invalid invoice require different corrections.', 'Produkciniame perdavime tikrinkite HTTP rezultatą ir atsakyme pateiktą dokumento ar eilutės klaidą. Ryšio gedimas ir netinkami sąskaitos duomenys taisomi skirtingai.']],
    table: {
      headers: [['Result', 'Rezultatas'], ['Meaning', 'Reikšmė'], ['Next check', 'Ką tikrinti']],
      rows: [
        [['401', '401'], ['Authorization was rejected.', 'Prieiga nepatvirtinta.'], ['Key, expiry and API address; do not change invoice amounts.', 'Raktą, jo galiojimą ir API adresą; nekeisti sąskaitos sumų.']],
        [['502', '502'], ['Gateway connection problem.', 'Gateway ryšio problema.'], ['Service and connectivity with the administrator.', 'Tarnybą bei ryšį su administratoriumi.']],
        [['504 / timeout', '504 / laukimo laiko pabaiga'], ['The reply did not arrive in time.', 'Atsakymas negautas laiku.'], ['Look for the invoice in GAMA before another attempt.', 'Prieš kartojant ieškoti sąskaitos GAMA.']],
        [['207 / partial result', '207 / dalinis rezultatas'], ['Some operations or lines need review.', 'Reikia patikrinti dalį operacijų ar eilučių.'], ['Identify the failed part; do not resend successful documents.', 'Nustatyti nepavykusią dalį; nekartoti sėkmingų dokumentų.']],
        [['Document validation error', 'Dokumento duomenų klaida'], ['The receiver rejected a field or reference.', 'Gavėjas atmetė lauką arba atitikmenį.'], ['The exact person, department, quantity or other reported field.', 'Tikslų nurodytą asmenį, padalinį, kiekį ar kitą lauką.']],
      ],
    },
    links: [{ topic: 'gateway-unavailable', label: ['Gateway unavailable: checks', 'Kai Gateway nepasiekiamas'] }, { topic: 'missing-person', label: ['Missing person code', 'Kai nerastas asmens kodas'] }, { topic: 'invalid-quantity', label: ['Invalid quantity', 'Kai netinkamas kiekis'] }],
  },
  {
    title: ['5. Verify a single invoice end to end', '5. Patikrinkite vieną sąskaitą nuo pradžios iki galo'], system: 'FH',
    steps: [
      ['Once a production adapter is connected, choose one invoice with verified supplier, lines and VAT. Send it once and retain its response / receiving identifier.', 'Prijungus produkcinį adapterį pasirinkite vieną sąskaitą su patikrintu tiekėju, eilutėmis bei PVM. Siųskite vieną kartą ir išsaugokite atsakymą / gavėjo identifikatorių.'],
      ['In GAMA search the intended company by document number and counterparty. Compare direction, dates, currency, net, VAT and total; verify whether posting occurred as intended.', 'GAMA reikiamoje įmonėje ieškokite pagal numerį ir kontrahentą. Sutikrinkite kryptį, datas, valiutą, sumą be PVM, PVM bei bendrą sumą; patikrinkite, ar perkėlimas įvyko taip, kaip nustatyta.'],
      ['Only after a successful comparison apply the same configuration to a batch. A success label in the current frontend is not a real GAMA receipt.', 'Tik sėkmingai sutikrinę taikykite tuos pačius nustatymus paketui. Dabartinio frontend sėkmės žyma nėra tikras GAMA gavimo patvirtinimas.'],
    ],
  },
];

const codeExample: IntegrationHelpExample = {
  title: ['Example: two codes pasted from Excel', 'Pavyzdys: du iš Excel įklijuoti kodai'],
  code: '00015\tOffice supplies\nS-002\tAccounting service',
  paragraphs: [
    ['The gap between the code and name is a TAB. Both codes are text: keep the zeros in 00015. The examples are not real accounting codes; replace them with values from your receiving company.', 'Tarp kodo ir pavadinimo yra TAB. Abu kodai – tekstas: išsaugokite 00015 pradžios nulius. Tai ne tikri apskaitos kodai – naudokite savo gavėjo įmonės reikšmes.'],
    ['In the import preview expect two rows, not one long value. After import, select the correct code and type on the invoice. Importing this directory does not automatically assign it to previously saved invoices.', 'Įkėlimo peržiūroje turi būti dvi eilutės, ne viena ilga reikšmė. Įkėlę sąskaitoje pasirinkite tinkamą kodą bei tipą. Registro įkėlimas savaime nepriskiria kodų anksčiau išsaugotoms sąskaitoms.'],
  ],
};

const example = (title: HelpText, ...paragraphs: HelpText[]): IntegrationHelpExample => ({ title, paragraphs });
const exampleTitle: HelpText = ['Worked example', 'Praktinis pavyzdys'];

// These examples explain FH fields and checks, not undocumented provider commands.
const formatExamples: Record<string, HelpText> = {
  Agnum: ['For a EUR 242 invoice (net 200 + VAT 42), choose totals for a scheme-based import or quantities to retain item codes. Both methods must preserve the same total.', '242 EUR sąskaitai (200 be PVM + 42 PVM) rinkitės suminį importą su schema arba kiekinį su prekių kodais. Abiem būdais bendra suma turi sutapti.'],
  Apskaita5: ['For invoice P-001, select the actual service code and VAT classifier from the receiving company. A label such as Office supplies is not a substitute for the catalog identifier.', 'Sąskaitai P-001 pasirinkite gavėjo įmonės paslaugos kodą ir PVM klasifikatorių. Pavadinimas Kanceliarinės prekės nepakeičia katalogo identifikatoriaus.'],
  BSS: ['A spreadsheet has Document No., Date and Amount columns. Select a BSS template mapped to those columns. Loading a different template can place the amount in the wrong field even if the file opens.', 'Skaičiuoklėje yra Dokumento Nr., Data ir Suma. Rinkitės šiems stulpeliams pritaikytą BSS šabloną. Kitas šablonas gali sumą priskirti netinkamam laukui, nors failas atsidaro.'],
  'BSS Api': ['If the server belongs to environment A, the environment ID and company ID must also belong to A. An API v2 password is not the same setting as the original API key.', 'Jei serveris priklauso aplinkai A, aplinkos ID bei įmonės ID taip pat turi būti iš A. API v2 slaptažodis nėra tas pats nustatymas kaip pirmos versijos API raktas.'],
  'Business Central': ['Use placeholders when discussing configuration: https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token. The invoice endpoint must reference the same tenant, environment and company, plus the installed invoice extension.', 'Aptariant konfigūraciją naudokite vietaženklius: https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token. Sąskaitų adresas turi nurodyti tą patį nuomininką, aplinką, įmonę ir įdiegtą sąskaitų plėtinį.'],
  Būtent: ['An invoice has a positive EUR 100 line and a EUR −10 discount line. Before enabling Ignore non-positive amounts, check that the discount is not lost and the actual EUR 90 net total is preserved.', 'Sąskaitoje yra 100 EUR eilutė ir −10 EUR nuolaidos eilutė. Prieš įjungdami neteigiamų sumų praleidimą patikrinkite, kad nuolaida nedingtų ir liktų faktinė 90 EUR suma be PVM.'],
  'Būtent kiekinis': ['Two items at EUR 50 must retain quantity 2 and unit price 50. Replacing the line with quantity 1 at EUR 100 preserves the total but changes stock quantities.', 'Dvi prekės po 50 EUR turi išlaikyti kiekį 2 ir kainą 50. Pakeitus į kiekį 1 ir kainą 100 suma sutaps, bet pasikeis sandėlio kiekis.'],
  Centas: ['If a EUR invoice imports but a USD invoice fails, inspect the USD currency and invoice-date rate in Centas before changing the invoice. Do not replace USD with EUR to bypass the error.', 'Jei EUR sąskaita priimama, o USD – ne, Centas patikrinkite USD valiutą ir sąskaitos datos kursą. Nekeiskite USD į EUR vien tam, kad apeitumėte klaidą.'],
  CSV: ['Code 00015 must remain text; 2026-11-20 must remain the invoice date. Agree whether 121.00 is written with a dot or comma and whether the file separator is a comma, semicolon or TAB.', 'Kodas 00015 turi likti tekstas, o 2026-11-20 – sąskaitos data. Suderinkite, ar 121,00 rašoma su kableliu ar tašku ir ar failo skirtukas – kablelis, kabliataškis ar TAB.'],
  Debetas: ['Branch A and expense article IT are different dimensions. Put each receiving code in its corresponding field; entering the branch name in the expense field does not create a mapping.', 'Filialas A ir išlaidų straipsnis IT yra skirtingos dimensijos. Kiekvieną gavėjo kodą įrašykite jo lauke; filialo pavadinimas išlaidų lauke atitikmens nesukuria.'],
  'Debetas Excel': ['If the receiving template expects expense code before VAT classifier, keep that order. The generic Excel option and Debetas Excel are not interchangeable just because both use spreadsheet software.', 'Jei gavėjo šablone išlaidų kodas yra prieš PVM klasifikatorių, išlaikykite tokią tvarką. Bendras Excel ir Debetas Excel nėra tapatūs vien todėl, kad abu naudojami skaičiuoklėje.'],
  Dineta: ['Use the purchase GL template for P-001 and the sales template for S-001. A working server address cannot correct a template or warehouse belonging to another company.', 'P-001 taikykite pirkimų DK šabloną, S-001 – pardavimų. Veikiantis serverio adresas neištaiso kitai įmonei priklausančio šablono ar sandėlio kodo.'],
  Directo: ['A purchase key may be valid while sales access is absent. Check the key for the actual direction; do not paste the purchase key into both fields without provider confirmation.', 'Pirkimų raktas gali galioti, nors pardavimų prieigos nėra. Tikrinkite konkrečios krypties raktą; be tiekėjo patvirtinimo nedėkite pirkimų rakto į abu laukus.'],
  Euroskaita: ['When a document has type SERVICE and warehouse MAIN, confirm both identifiers in the receiving company. An invoice type name displayed in FH does not automatically define a Euroskaita operation code.', 'Kai dokumento tipas SERVICE, o sandėlis MAIN, patvirtinkite abu identifikatorius gavėjo įmonėje. FH rodomas tipo pavadinimas automatiškai neapibrėžia Euroskaita operacijos kodo.'],
  Excel: ['Before import, compare one row: invoice P-001, net 100, VAT 21, total 121 EUR. If the receiver combines net and VAT into one field, fix the column mapping rather than changing the invoice values.', 'Prieš importą sutikrinkite vieną eilutę: P-001, be PVM 100, PVM 21, iš viso 121 EUR. Jei gavėjas sumą ir PVM priskiria vienam laukui, taisykite stulpelių atitikmenis, ne sąskaitos reikšmes.'],
  Finvalda: ['A saved service code and a warehouse code must exist in the selected Finvalda company. Check the VA import parameters when the correct invoice arrives with an incorrect department or employee.', 'Paslaugos ir sandėlio kodai turi egzistuoti pasirinktoje Finvalda įmonėje. Jei teisinga sąskaita gauna netinkamą padalinį ar darbuotoją, tikrinkite VA importo parametrus.'],
  'Finvalda Excel': ['Use a small spreadsheet with one purchase and one sale to verify type, expense and VAT columns. A file intended for the regular Finvalda importer is not automatically the Excel template.', 'Vienos pirkimo ir vienos pardavimo sąskaitos skaičiuokle patikrinkite tipo, išlaidų bei PVM stulpelius. Įprastam Finvalda importui skirtas failas savaime nėra Excel šablonas.'],
  iSAF: ['A sales invoice and a purchase invoice may both total EUR 121 but belong to different registers. Preserve direction, VAT classifier and document facts; exporting a preview does not submit either register.', 'Pardavimo ir pirkimo sąskaitos gali abi būti po 121 EUR, bet priklausyti skirtingiems registrams. Išlaikykite kryptį, PVM klasifikatorių ir faktinius duomenis; peržiūros eksportas registro nepateikia.'],
  Json: ['Treat invoice number 00015 as a string, not the number 15. Keep recognized lines separate from accounting allocations. A JSON filename is not an API endpoint or a transmission receipt.', 'Sąskaitos numerį 00015 laikykite tekstu, ne skaičiumi 15. Atpažintas eilutes atskirkite nuo apskaitinių paskirstymų. JSON failo pavadinimas nėra API adresas ar perdavimo patvirtinimas.'],
  Lobasoft: ['For P-001, record the recipient-required expense and VAT codes, then compare one exported document with the agreed Lobasoft sample. Without that sample, do not assume generic JSON is importable.', 'P-001 priskirkite gavėjui reikalingus išlaidų bei PVM kodus ir palyginkite eksportą su suderintu Lobasoft pavyzdžiu. Neturint pavyzdžio negalima laikyti bendro JSON tinkamu importui.'],
  Monet: ['Use the identification code for company A together with company A correspondence codes. A code copied from company B can refer to a different integration even if both companies use Monet.', 'Įmonės A identifikavimo kodą naudokite su įmonės A korespondencijos kodais. Iš įmonės B nukopijuota reikšmė gali nurodyti kitą integraciją, nors abi naudoja Monet.'],
  Odoo: ['An API URL must correspond to the agreed invoice adapter. Check the company, default product and payable account before sending a purchase; an ordinary Odoo login URL does not define that adapter.', 'API adresas turi atitikti suderintą sąskaitų adapterį. Prieš pirkimo perdavimą patikrinkite įmonę, numatytąją prekę ir mokėtinų sumų sąskaitą; įprastas Odoo prisijungimo adresas adapterio neapibrėžia.'],
  Optimum: ['For a service invoice, match the Service type to the receiving card. If Account.AccountId is empty, inspect the actual input VAT account; do not substitute a random GL code.', 'Paslaugos sąskaitoje Paslaugos tipą suderinkite su gavėjo kortele. Jei Account.AccountId tuščias, tikrinkite tikrą gautino PVM sąskaitą, neįrašykite atsitiktinio DK kodo.'],
  Paulita: ['Export one purchase P-001 with its assigned expense code and compare the receiving totals with the original. Before a larger batch, confirm the XML specification accepted by your Paulita version.', 'Eksportuokite vieną pirkimą P-001 su išlaidų kodu ir sutikrinkite gavėjo sumas su originalu. Prieš didesnį paketą patvirtinkite jūsų Paulita versijai tinkamą XML specifikaciją.'],
  Pragma3: ['Check an ordinary invoice and a credit invoice separately. A direction-switch setting changes how the credit is represented; do not enable it solely to remove a minus sign from the original.', 'Atskirai patikrinkite įprastą ir kreditinę sąskaitą. Krypties pakeitimo nustatymas keičia kredito pateikimą; neįjunkite jo vien tam, kad panaikintumėte originale esantį minusą.'],
  Pragma4: ['A supplier exists under accounting code T-015 but the document carries a company registration code. Resolve the supplier mapping instead of creating a duplicate card with the same name.', 'Tiekėjas egzistuoja apskaitos kodu T-015, o dokumente yra įmonės registracijos kodas. Suderinkite tiekėjo atitikmenį, nekurkite kitos kortelės tokiu pačiu pavadinimu.'],
  'Pragma4 V2': ['If the receiver requests V2, test with that exact template. Matching totals in a Pragma4 preview do not prove that its structure also fits Pragma4 V2.', 'Jei gavėjui reikia V2, tikrinkite būtent tą šabloną. Sutampančios Pragma4 peržiūros sumos neįrodo, kad jos struktūra tinka Pragma4 V2.'],
  Rivilė: ['For a purchase with a new supplier and product, the compatible production package is imported in dependency order: client, product, then purchase. Do not import only the last file.', 'Pirkimui su nauju tiekėju ir preke suderinamas produkcinis paketas importuojamas pagal priklausomybes: klientas, prekė, tada pirkimas. Neįkelkite vien paskutinio failo.'],
  'Rivilė API': ['Creating a document and posting it are separate outcomes. If automatic posting is disabled, a successfully created invoice still needs the agreed posting step in Rivilė.', 'Dokumento sukūrimas ir perkėlimas – atskiri rezultatai. Jei automatinis perkėlimas išjungtas, sukurtai sąskaitai vis dar reikia sutarto perkėlimo veiksmo Rivilėje.'],
  'Rivilė ERP': ['Use the ERP company key and ERP item codes. GAMA Gateway credentials and a similarly named GAMA product are not interchangeable with ERP identifiers.', 'Naudokite ERP įmonės raktą ir ERP prekių kodus. GAMA Gateway prisijungimai bei panašiai pavadinta GAMA prekė nėra tapatūs ERP identifikatoriams.'],
  Roda: ['A document may need both department ADMIN and project P-01. Check them as separate dimensions, then compare the file against the receiving Roda import definition.', 'Dokumentui gali reikėti padalinio ADMIN ir projekto P-01. Tikrinkite juos kaip atskiras dimensijas, tada palyginkite failą su gavėjo Roda importo aprašu.'],
  Saikas: ['For a purchase of EUR 100 + VAT 21, check the purchase account and purchase VAT account separately. The corresponding sales mappings must not be used simply because the totals match.', '100 EUR + 21 EUR PVM pirkimui atskirai tikrinkite pirkimų bei pirkimų PVM sąskaitas. Pardavimų atitikmenys netinka vien todėl, kad sumos vienodos.'],
  'Site.pro': ['If stock was received on 20 November but the sale is dated 19 November, inspect the receiving stock records and original dates. Do not change the invoice date merely to remove a stock error.', 'Jei atsargos gautos lapkričio 20 d., o pardavimo data – 19 d., tikrinkite gavėjo atsargų įrašus ir pirmines datas. Nekeiskite sąskaitos datos vien tam, kad dingtų sandėlio klaida.'],
  StandardERP: ['Confirm whether the receiving import expects an item code and warehouse on each line. A generic file with a total of EUR 121 is not sufficient evidence that the stock allocation is correct.', 'Patvirtinkite, ar gavėjo importas tikisi prekės ir sandėlio kodo kiekvienoje eilutėje. Bendras failas su 121 EUR suma neįrodo, kad atsargų paskirstymas teisingas.'],
  Syrve: ['For 4 packages containing 0.5 kg each, the stock quantity is 2 kg. Verify the unit conversion and SKU, but keep the invoice total unchanged.', 'Jei yra 4 pakuotės po 0,5 kg, atsargų kiekis – 2 kg. Tikrinkite vienetų santykį ir SKU, bet nekeiskite sąskaitos bendros sumos.'],
  'UCS StoreHouse v4': ['The receiving email address and stock codes serve different purposes. Confirm both the mailbox for delivery and the recipient-compatible attachment structure before configuring automatic delivery.', 'Gavėjo el. paštas ir atsargų kodai atlieka skirtingas funkcijas. Prieš automatinį siuntimą patvirtinkite ir pašto dėžutę, ir gavėjui tinkamą priedo struktūrą.'],
  Uniconta: ['Check that the configured API URL and key refer to the intended company. A valid login does not establish which expense or VAT code should be used for P-001.', 'Patikrinkite, ar API adresas bei raktas skirti reikiamai įmonei. Galiojantis prisijungimas nenustato, kokį išlaidų ar PVM kodą priskirti P-001.'],
  XML: ['An XML document can be well-formed but still fail import because a required supplier code is absent. Validate against the receiving schema, not only whether the file opens in a browser.', 'XML gali būti sintaksiškai taisyklingas, bet netikti importui, nes nėra privalomo tiekėjo kodo. Tikrinkite pagal gavėjo schemą, ne vien tai, ar failas atsidaro naršyklėje.'],
  email: ['A message from supplier@example.com may contain invoices for two different organizations. The sender identifies the source; each invoice still needs its own correct organization assignment.', 'Laiške iš supplier@example.com gali būti dviejų organizacijų sąskaitos. Siuntėjas apibūdina šaltinį, o kiekvienai sąskaitai vis tiek reikia tinkamos organizacijos.'],
  'google-drive': ['Use a source folder such as /Invoices/Incoming and a different archive folder. A processed file remaining in the incoming folder should not be uploaded manually again without checking its record.', 'Naudokite šaltinio aplanką, pavyzdžiui, /Invoices/Incoming, ir kitą archyvo aplanką. Įvesties aplanke likusio apdoroto failo nekelkite ranka pakartotinai nepatikrinę jo įrašo.'],
  sharepoint: ['A site URL, a document library and a folder path are three different values. Access to the SharePoint home page does not prove access to /Shared Documents/Invoices.', 'Svetainės adresas, dokumentų biblioteka ir aplanko kelias – trys skirtingos reikšmės. Prieiga prie SharePoint pradžios neįrodo prieigos prie /Shared Documents/Invoices.'],
  'fh-api': ['One request identifier should refer to one intended upload. Retrying a timed-out upload without checking its result risks creating a second document. The present frontend does not provide a live API endpoint.', 'Vienas užklausos identifikatorius turi reikšti vieną numatytą įkėlimą. Kartojant užklausą nepatikrinus rezultato galima sukurti antrą dokumentą. Dabartinis frontend tikro API adreso nesuteikia.'],
  dropbox: ['Dropbox shown in a document Source column only describes origin. It is not evidence of an active connector. Until the connector exists, use the available manual upload without pretending a folder is being monitored.', 'Dropbox dokumento Šaltinio stulpelyje tik nurodo kilmę, ne veikiančią jungtį. Kol jungties nėra, naudokite esamą rankinį įkėlimą, nelaikydami aplanko automatiškai stebimu.'],
};

const codeTopics = /(?:item-codes|product-codes|service-codes|code-list|customer-list|departments|departments-objects|accountable-persons|codes-and-nomenclature|code-synchronization)$/;
const errorTopics = /^(?:missing-|unknown-|invalid-|wrong-|duplicate-|zero-price|number-pattern|service-unit-cost|gateway-unavailable|buyer-supplier-type|product-not-found|item-date-conflict|currencies)/;

const topicExamples: Record<string, HelpText> = {
  'gateway-api': ['A configuration points to database COMPANY_A while the invoice belongs to company B. Even a valid key must not be treated as permission to post there. Correct the company / database mapping before sending; if a timeout occurred, first check whether the invoice was already received.', 'Nustatymuose nurodyta bazė COMPANY_A, o sąskaita priklauso įmonei B. Net galiojantis raktas nereiškia, kad ten reikia ją registruoti. Prieš siųsdami sutvarkykite įmonės ir bazės atitikmenį; jei buvo laukimo klaida, pirmiausia patikrinkite, ar sąskaita jau negauta.'],
  warehouses: ['If the receiving warehouse code is WH-01 and its name is Main warehouse, use the required identifier WH-01. A warehouse address, display name and code are not interchangeable.', 'Jei gavėjo sandėlio kodas WH-01, o pavadinimas Pagrindinis sandėlis, naudokite reikiamą identifikatorių WH-01. Sandėlio adresas, pavadinimas ir kodas nėra tapatūs.'],
  'duplicate-control': ['The same supplier issued AG-001 for EUR 121. Downloading that invoice twice does not create a second purchase. Compare supplier, number and amount before deciding whether another import is needed.', 'Tas pats tiekėjas išrašė AG-001 už 121 EUR. Dukart atsisiuntus sąskaitą neatsiranda antras pirkimas. Prieš kitą importą palyginkite tiekėją, numerį ir sumą.'],
  'tax-codes': ['The invoice shows 21% VAT, but the receiving identifier could be a configured code such as VAT_STD. Do not enter 21 instead of the code unless that is the actual receiving identifier.', 'Sąskaitoje nurodyta 21 % PVM, bet gavėjo identifikatorius gali būti, pavyzdžiui, VAT_STD. Vietoj kodo nerašykite 21, nebent būtent toks yra tikras gavėjo identifikatorius.'],
  'zero-price': ['A genuinely free sample has quantity 1 and price 0. Check the receiving card’s free-supply rule; changing its price to EUR 0.01 would falsify the original invoice.', 'Tikras nemokamas pavyzdys turi kiekį 1 ir kainą 0. Patikrinkite gavėjo kortelės nemokamo tiekimo taisyklę; pakeitus kainą į 0,01 EUR nebeatitiktų originalo.'],
  'original-document': ['Imported totals can be visible while the original-file link is unavailable. Check the file link and access separately; do not import the same accounting record again just to reopen its PDF.', 'Importuotos sumos gali matytis, nors originalo nuoroda neveikia. Atskirai tikrinkite failo nuorodą ir prieigą; neimportuokite apskaitos įrašo pakartotinai vien dėl PDF peržiūros.'],
  'duplicate-counterparties': ['Two cards have the same name but different codes: T-001 and company code 123456789. Compare the company identifier and existing transactions before changing the mapping; a matching name alone is insufficient.', 'Dviejų kortelių pavadinimas vienodas, bet kodai skiriasi: T-001 ir įmonės kodas 123456789. Prieš keisdami atitikmenį palyginkite įmonės identifikatorių ir operacijas; vien pavadinimo nepakanka.'],
  'missing-related-data': ['An address says Latvia but the receiving country directory has no LV entry. Resolve the correct country reference; replacing Latvia with Lithuania would hide the error with wrong data.', 'Adrese nurodyta Latvija, bet gavėjo šalių registre nėra LV. Sutvarkykite tikros šalies atitikmenį; pakeitus Latviją į Lietuvą klaida būtų paslėpta neteisingais duomenimis.'],
  'number-pattern': ['The original number is INV/2026/001 while a configured pattern allows digits only. Review the receiving pattern; do not silently turn the legal number into 2026001.', 'Originalo numeris INV/2026/001, o nustatytas šablonas leidžia tik skaitmenis. Tikrinkite gavėjo šabloną; nepaverskite tikro numerio į 2026001.'],
  'missing-vat-account': ['The invoice has VAT 21, but the configured input VAT GL account is absent in this company. The VAT amount is not the problem: correct the account reference.', 'Sąskaitoje PVM suma 21, bet nustatytos gautino PVM DK sąskaitos šios įmonės plane nėra. Problema ne PVM suma – taisykite sąskaitos atitikmenį.'],
  'duplicate-record': ['A code collision and a duplicate invoice require different corrections. If invoice P-001 is absent but item code 00 already exists, resolve the item mapping instead of renumbering P-001.', 'Kodų sutapimas ir sąskaitos dublikatas taisomi skirtingai. Jei P-001 nėra, bet prekės kodas 00 jau egzistuoja, taisykite prekės atitikmenį, nepernumeruokite P-001.'],
  'missing-employee': ['The integration user exists, but its linked employee code EMP-01 does not. The administrator must resolve the identity mapping; another person with a similar name is not a valid substitute.', 'Integracijos naudotojas yra, bet jo susieto darbuotojo kodo EMP-01 nėra. Administratorius turi sutvarkyti tapatybės atitikmenį; panašaus vardo asmuo netinka kaip pakaitalas.'],
  'service-unit-cost': ['An accounting service is assigned a Product type even though its receiving card is a service. Correct the type mapping; do not change quantity or invoice price to hide the mismatch.', 'Buhalterinei paslaugai priskirta Prekė, nors gavėjo kortelė yra paslauga. Taisykite tipo atitikmenį, ne kiekį ar sąskaitos kainą.'],
  'unknown-supplier': ['The XML refers to supplier T-015. Check whether that exact supplier exists and is included in the import dependencies before retrying the invoice.', 'XML nurodo tiekėją T-015. Prieš kartodami sąskaitą patikrinkite, ar būtent toks tiekėjas yra ir ar jo įrašas įtrauktas į importui reikalingus duomenis.'],
  'new-customer': ['A new customer has a company code but no accounting card. Search by company code first; only create a genuinely missing card through the approved receiving workflow.', 'Naujas klientas turi įmonės kodą, bet nėra apskaitos kortelės. Pirmiausia ieškokite pagal įmonės kodą; tikrai trūkstamą kortelę kurkite sutartu gavėjo procesu.'],
  'operation-codes': ['A purchase receipt and a sales invoice may use different operation codes. Check the code required for this direction instead of applying one default to both.', 'Pirkimo gavimas ir pardavimo sąskaita gali naudoti skirtingus operacijų kodus. Patikrinkite konkrečios krypties kodą, netaikykite vienos reikšmės abiem.'],
  concepts: ['A restaurant concept C-01 and warehouse WH-01 are separate references. Store each in its own field; changing the warehouse does not select the concept.', 'Restorano koncepcija C-01 ir sandėlis WH-01 – atskiri atitikmenys. Įrašykite juos atskiruose laukuose; pakeitus sandėlį koncepcija neparenkama.'],
  'batch-warehouse': ['One invoice contains goods for WH-01 and WH-02. A single default cannot correctly describe both destinations; check the receiving line-level allocation before applying a bulk value.', 'Vienoje sąskaitoje yra prekių WH-01 ir WH-02 sandėliams. Viena numatytoji reikšmė negali teisingai aprašyti abiejų; prieš masinį priskyrimą tikrinkite eilučių paskirstymą.'],
  'product-not-found': ['SKU 00015 exists in the receiving system but is excluded by a selection filter. Check both the exact code and the filter before creating a second item.', 'SKU 00015 gavėjo sistemoje egzistuoja, bet jį paslepia filtras. Prieš kurdami antrą prekę patikrinkite ir tikslų kodą, ir filtrą.'],
  'expense-allocation': ['The supplier product code SUP-88 can map to your expense code IT-SVC. Retain the original description while assigning the receiving accounting code.', 'Tiekėjo prekės kodas SUP-88 gali būti priskirtas jūsų išlaidų kodui IT-SVC. Išlaikykite originalų aprašymą, o apskaitai pasirinkite gavėjo kodą.'],
  'products-services': ['The same visible name, Delivery, may exist as both a Service and a Code. Select the matching receiving card type, not simply the first matching name.', 'Tas pats pavadinimas Pristatymas gali egzistuoti kaip Paslauga ir Kodas. Rinkitės gavėjo kortelės tipą, ne pirmą sutampantį pavadinimą.'],
  'new-item-settings': ['A new product uses the configured account link, whereas an existing product already has its own card settings. Do not assume changing the default rewrites every existing product.', 'Nauja prekė naudoja nustatytą sąskaitų ryšį, o esama jau turi savo kortelės nustatymus. Nelaikykite numatytosios reikšmės pakeitimo visų prekių perrašymu.'],
  'automatic-export': ['An invoice with a missing required department must not bypass validation merely because automatic export is enabled. Resolve the missing allocation before any real automated transmission.', 'Sąskaita be privalomo padalinio neturi apeiti validacijos vien dėl automatinio eksporto. Prieš tikrą automatinį perdavimą užpildykite trūkstamą paskirstymą.'],
  'payments-persons': ['An employee-paid invoice needs the correct accountable-person code and payment account. Assigning a person alone is not a bank payment or confirmation that a debt has been settled.', 'Darbuotojo apmokėtai sąskaitai reikia teisingo atskaitingo asmens kodo ir apmokėjimo sąskaitos. Vien asmens priskyrimas nėra banko mokėjimas ar skolos padengimo patvirtinimas.'],
  series: ['If the series is INV and number is 001, check the agreed receiving representation. Avoid producing INVINV001 by repeating the prefix in two mapped fields.', 'Kai serija INV, o numeris 001, patikrinkite sutartą gavėjo pateikimą. Nekartokite priešdėlio dviejuose laukuose, kad nesusidarytų INVINV001.'],
  'missing-person': ['A person named Jonas is visible in FH, but the receiving system expects code EMP-02. The name is not enough: resolve the code against the correct person card.', 'FH matomas Jonas, bet gavėjas tikisi kodo EMP-02. Vardo nepakanka: sutikrinkite kodą su reikiama asmens kortele.'],
  'department-company-id': ['A department was copied from company A while the integration points to B. Verify company and database identity before editing the invoice allocation.', 'Padalinys nukopijuotas iš įmonės A, o integracija nukreipta į B. Prieš keisdami sąskaitos paskirstymą patikrinkite įmonės ir bazės tapatybę.'],
  'wrong-import-command': ['A file ending in .xml is not an EIP file. Renaming it to .eip does not convert the schema; use the matching validated file and import action.', 'Failas su .xml plėtiniu nėra EIP. Pervadinus į .eip schema nepasikeičia; naudokite suderintą failą ir jam skirtą importo veiksmą.'],
  'missing-department': ['The default department code is absent from the company directory. Select an existing department matching the transaction, not an arbitrary code that merely passes validation.', 'Numatytojo padalinio kodo nėra įmonės registre. Rinkitės operaciją atitinkantį egzistuojantį padalinį, ne atsitiktinį kodą tik validacijai apeiti.'],
  'invalid-quantity': ['The source quantity is 1.5 but the receiving unit accepts only whole units. Review unit precision; changing the invoice quantity to 2 would alter the transaction.', 'Originalo kiekis 1,5, bet gavėjo vienetas priima tik sveikus kiekius. Tikrinkite vieneto tikslumą; pakeitus kiekį į 2 pasikeistų operacija.'],
  'gateway-unavailable': ['Several invoices fail with the same connection message. Check the shared connection before changing each invoice. A timeout can occur after the receiver has already created a record.', 'Kelios sąskaitos gauna tą pačią ryšio klaidą. Prieš taisydami kiekvieną dokumentą tikrinkite bendrą jungtį. Laukimo laikas gali baigtis ir po įrašo sukūrimo gavėjo sistemoje.'],
  'buyer-supplier-type': ['The counterparty is configured only as a buyer but the document is a purchase. Confirm the actual supplier relationship and receiving card permissions.', 'Kontrahentas nustatytas tik kaip pirkėjas, o dokumentas – pirkimas. Patvirtinkite tikrą tiekėjo ryšį ir gavėjo kortelės leidimus.'],
  'change-customer-code': ['Changing T-001 to T-002 must preserve links to existing documents. Confirm the receiving update procedure; creating another same-name card is not a safe code migration.', 'Keičiant T-001 į T-002 reikia išlaikyti ryšius su esamais dokumentais. Patvirtinkite gavėjo keitimo tvarką; kita to paties pavadinimo kortelė nėra saugus kodo perkėlimas.'],
  'foreign-currency': ['For USD 100 + USD 21 VAT, retain USD 121 as the source total. Review the accounting conversion separately; do not relabel the invoice EUR without conversion.', '100 USD + 21 USD PVM sąskaitoje išlaikykite 121 USD originalo sumą. Apskaitos perskaičiavimą tikrinkite atskirai; nekeiskite valiutos į EUR be perskaičiavimo.'],
  'code-synchronization': ['A new barcode can refer to an existing product code. Verify the alternative-code mapping before creating another product; directory refresh and invoice export are different actions.', 'Naujas barkodas gali priklausyti esamam prekės kodui. Prieš kurdami kitą prekę patikrinkite alternatyvaus kodo atitikmenį; registro atnaujinimas ir sąskaitos eksportas – skirtingi veiksmai.'],
};

function directoryExample(topicId: string): IntegrationHelpExample {
  if (topicId === 'customer-list') return {
    title: ['Example: counterparty import columns', 'Pavyzdys: kontrahento įkėlimo stulpeliai'],
    code: 'T-001\t123456789\tLT123456789\tExample company\t',
    paragraphs: [
      ['Column order: accounting code, company code, VAT code, name, IBAN. The fifth value is optional. Use real verified company identifiers, not these illustrative numbers.', 'Stulpelių tvarka: apskaitos kodas, įmonės kodas, PVM kodas, pavadinimas, IBAN. Penkta reikšmė neprivaloma. Naudokite tikrus patikrintus identifikatorius, ne šiuos pavyzdinius skaičius.'],
      ['Paste into Counterparties → Import from Excel, not the two-column expense importer. Check the preview for duplicate companies before saving.', 'Įklijuokite Kontrahentai → Įkelti iš Excel, ne į dviejų stulpelių išlaidų importą. Prieš išsaugodami peržiūroje patikrinkite pasikartojančias įmones.'],
    ],
  };
  if (/departments|accountable-persons/.test(topicId)) return {
    title: ['Example: identifier and display name', 'Pavyzdys: identifikatorius ir rodomas pavadinimas'],
    code: topicId === 'accountable-persons' ? 'EMP-01\tJonas Jonaitis' : 'ADMIN\tAdministration\nSALES\tSales department',
    paragraphs: [['Paste code and name into the corresponding directory. A person goes into Accountable persons, a department into Departments. Do not treat either as an expense or product code.', 'Kodą ir pavadinimą įklijuokite į atitinkamą registrą. Asmuo keliamas į Atskaitingus asmenis, padalinys – į Padalinius. Nei vieno nelaikykite išlaidų ar prekės kodu.']],
  };
  return codeExample;
}

function practicalSection(article: IntegrationArticle, topic: IntegrationHelpTopic): IntegrationHelpSection {
  const codes = codeTopics.test(topic.id);
  const error = errorTopics.test(topic.id);
  const detail = topicExamples[topic.id] || formatExamples[article.id];
  return {
    title: error ? ['Correction and result', 'Korekcija ir rezultatas'] : ['Example and expected result', 'Pavyzdys ir laukiamas rezultatas'], system: 'FH',
    example: codes ? directoryExample(topic.id) : example(exampleTitle, detail),
    steps: codes ? [
      ['Open the appropriate organization directory, not a different company’s list. Verify the code in the parsed preview and save it only once.', 'Atverkite reikiamos organizacijos registrą, ne kitos įmonės sąrašą. Kodą patikrinkite įklijuotų duomenų peržiūroje ir išsaugokite vieną kartą.'],
      ['Open one invoice and select the imported value. Check its stored code, type and VAT mapping before assigning the same value to more documents.', 'Atverkite vieną sąskaitą ir pasirinkite įkeltą reikšmę. Prieš taikydami daugiau dokumentų patikrinkite išsaugotą kodą, tipą bei PVM atitikmenį.'],
    ] : error ? [
      ['Record the exact rejected document and error text. Follow the provider check above; changing unrelated invoice fields will not resolve the reported cause.', 'Užfiksuokite atmestą dokumentą ir tikslų klaidos tekstą. Atlikite aukščiau nurodytą konkrečios sistemos patikrinimą; kitų sąskaitos laukų keitimas priežasties neišsprendžia.'],
      ['If the source invoice was read incorrectly, send Report issue. If the source is correct, correct the receiving setting or code mapping with its administrator.', 'Jei sąskaitos originalas nuskaitytas neteisingai, rinkitės Pranešti apie klaidą. Jei faktai teisingi, su administratoriumi taisykite gavėjo nustatymą arba kodų atitikmenį.'],
      ['Before a real retry, search the destination by number and counterparty. Retry only the failed invoice after fixing the cause and compare the resulting amounts.', 'Prieš tikrą pakartojimą gavėjo sistemoje ieškokite pagal numerį ir kontrahentą. Pašalinę priežastį kartokite tik nepavykusią sąskaitą ir sutikrinkite gautas sumas.'],
    ] : [
      ['Use one document to verify the chosen settings. Compare the original, FH fields and receiving record; a saved setting alone is not a successful transfer.', 'Pasirinktus nustatymus tikrinkite vienu dokumentu. Palyginkite originalą, FH laukus ir gavėjo įrašą; vien išsaugotas nustatymas nėra sėkmingas perdavimas.'],
      [article.group === 'collection' ? 'Expected result with a connected service: one received file, a visible source and processing status. If absent, check source permissions before uploading it again.' : 'Expected result with a production adapter: one invoice in the intended company, correct codes, currency and amounts. Check posting separately from receipt.', article.group === 'collection' ? 'Laukiamas rezultatas prijungus tarnybą: vienas gautas failas su matomu šaltiniu ir apdorojimo būsena. Jei jo nėra, prieš kartodami tikrinkite šaltinio prieigos teises.' : 'Laukiamas rezultatas su produkciniu adapteriu: viena sąskaita reikiamoje įmonėje su teisingais kodais, valiuta ir sumomis. Perkėlimą į apskaitą tikrinkite atskirai nuo gavimo.'],
    ],
  };
}

/** Internal links always point to existing topics of the same integration. */
export function enrichIntegrationTopics(article: IntegrationArticle, topics: IntegrationHelpTopic[]): IntegrationHelpTopic[] {
  return topics.map(topic => {
    const others = topics.filter(other => other.id !== topic.id);
    const related = others.map(other => ({ topic: other.id, label: other.title }));
    const sourceSections = ['Rivilė', 'Rivilė API'].includes(article.id) && topic.id === 'gateway-api' ? rivileGatewaySections : topic.sections;
    const sections = sourceSections.map(section => ({ ...section }));
    if (article.id !== 'Agnum' || topic.id !== 'invoice-import') sections.push(practicalSection(article, topic));
    // Context links alongside steps as well as the complete related-topic list.
    if (!sections[0].links && others.length) sections[0].links = others
      .filter(other => topic.id === 'configuration' ? other.id !== 'workflow-and-checks' : other.id === 'configuration' || codeTopics.test(other.id))
      .slice(0, 4).map(other => ({ topic: other.id, label: other.title }));
    return { ...topic, sections, related };
  });
}
