import type { ColConfig } from '../components/ColumnSettingsPanel';
import type { WorkspaceTask } from '../components/WorkspaceView';
import type { DbDocument } from './supabase';

export type OcrTaskPriority = 'High' | 'Normal' | 'Low';

export const OCR_TASK_PRIORITY_STYLES: Record<OcrTaskPriority, string> = {
  High: 'bg-[#FFF0F0] text-[#B42318]',
  Normal: 'bg-[#E6F2F6] text-[#007EA7]',
  Low: 'bg-[#F0F3F6] text-[#52667D]',
};

/** Saved OCR tasks use 1 = High, 2 = Normal, 3 = Low; legacy 0 is unset. */
export function ocrTaskPriority(value: unknown): OcrTaskPriority {
  const normalized = String(value ?? '').trim().toLowerCase();
  if (normalized === '1' || normalized === 'high') return 'High';
  if (normalized === '3' || normalized === 'low') return 'Low';
  return 'Normal';
}

export function ocrTaskPriorityRank(value: unknown): number {
  return { High: 0, Normal: 1, Low: 2 }[ocrTaskPriority(value)];
}

function timestamp(value?: string): number | undefined {
  if (!value?.trim()) return undefined;
  const localized = value.trim().match(/^(\d{2})[./](\d{2})[./](\d{4})$/);
  const parsed = Date.parse(localized ? `${localized[3]}-${localized[2]}-${localized[1]}` : value);
  return Number.isFinite(parsed) ? parsed : undefined;
}

/** Editing, reassignment and work-log updates must not reset an existing wait. */
export function ocrTaskWaitingSince(document: Partial<DbDocument>, task?: Partial<WorkspaceTask>): number {
  // Prefer the original receipt timestamp: the first saved editor draft may be newer.
  for (const value of [document.created_at, task?.creationDate, document.receive_date]) {
    const parsed = timestamp(value);
    if (parsed !== undefined) return parsed;
  }
  // Unknown dates follow dated tasks; never imply an infinitely old task.
  return Number.MAX_SAFE_INTEGER;
}

export function sortOcrTaskQueue<T extends { id: string; priority: string; waitingSince: number }>(
  rows: readonly T[], direction: 'asc' | 'desc' = 'asc',
): T[] {
  return [...rows].sort((left, right) =>
    (ocrTaskPriorityRank(left.priority) - ocrTaskPriorityRank(right.priority)) * (direction === 'asc' ? 1 : -1)
    || left.waitingSince - right.waitingSince
    || left.id.localeCompare(right.id, undefined, { numeric: true }));
}

/** Add Priority once without resetting users' widths, order or hidden columns. */
export function myTaskPriorityColumns(columns: readonly ColConfig[]): ColConfig[] {
  const existing = columns.find(column => column.key === 'priority');
  if (!existing) return [{ key: 'priority', label: 'Priority', width: 125, visible: true }, ...columns];
  return columns.filter(column => column.key !== 'priority' || column === existing)
    .map(column => column.key === 'priority' ? { ...column, label: 'Priority' } : column);
}
