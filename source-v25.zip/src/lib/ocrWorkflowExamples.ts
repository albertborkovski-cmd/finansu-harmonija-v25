import type { DbDocument, Company } from './supabase';
import type { WorkspaceTask } from '../components/WorkspaceView';
import type { OcrHandwriting } from './ocrHandwriting';

export const OCR_WORKFLOW_EXAMPLES_BATCH = 'v25-ocr-workflow-pdf-v1';
export const OCR_WORKFLOW_SUPPLIER_CODE = 'FH-TEST-SUPPLIER';

type Scenario = {
  file: string; title: string; help: string; pages: number; missing: (keyof DbDocument)[];
  handwriting?: OcrHandwriting; multiple?: boolean; twoInvoices?: boolean; mergePart?: 1 | 2;
  unreadable?: boolean; priority: number;
};

/** These are intentional OCR results, not a claim that a live OCR engine read the files. */
export const OCR_WORKFLOW_SCENARIOS: readonly Scenario[] = [
  { file: 'OCR-QA-SPLIT-01.pdf', title: 'Du dokumentai viename PDF', pages: 4, multiple: true, twoInvoices: true, missing: ['number'], priority: 1,
    help: 'Skaidyti: pirma sąskaita 1–2 psl., antra 3–4 psl. Patvirtinus sukuriamos OCR užklausos ir atidaroma kita užduotis.' },
  { file: 'OCR-QA-SPLIT-02.pdf', title: 'Abu geltoni įspėjimai', pages: 4, multiple: true, twoInvoices: true, handwriting: 'partial', missing: ['document_date'], priority: 1,
    help: 'Matomi „Rašyta ranka“ ir „Galimai keli dokumentai“. Skaidyti 1–2 ir 3–4 puslapius; palyginti ranka įrašytą datą.' },
  { file: 'OCR-QA-SINGLE-03.pdf', title: 'Viena sąskaita su priedu', pages: 2, multiple: true, missing: [], priority: 2,
    help: 'Peržiūrėti abu puslapius. Tai viena sąskaita ir jos priedas: pasirinkti „Vienas dokumentas“, išsaugoti sprendimą.' },
  { file: 'OCR-QA-MERGE-A.pdf', title: 'Sujungimas: sąskaitos pirmas puslapis', pages: 1, mergePart: 1, missing: ['total_amount'], priority: 1,
    help: 'Sujungti su OCR-QA-MERGE-B.pdf. Tvarka: A, tada B. B faile yra sąskaitos tęsinys ir bendra suma.' },
  { file: 'OCR-QA-MERGE-B.pdf', title: 'Sujungimas: sąskaitos tęsinys', pages: 1, mergePart: 2, missing: ['number'], priority: 1,
    help: 'Tai OCR-QA-MERGE-A.pdf tęsinys. Jungimo peržiūroje patikrinti puslapių tvarką A → B.' },
  { file: 'OCR-QA-NUMBER-06.pdf', title: 'Nenuskaitytas dokumento numeris', pages: 1, missing: ['number'], priority: 2,
    help: 'Numeris originale yra, bet OCR laukas tuščias. Įrašyti numerį iš originalo ir užbaigti dokumentą.' },
  { file: 'OCR-QA-DATE-07.pdf', title: 'Nenuskaityta dokumento data', pages: 1, missing: ['document_date'], priority: 2,
    help: 'Užpildyti raudonai pažymėtą datą pagal PDF. Stebėti, kaip dingsta privalomo lauko įspėjimas.' },
  { file: 'OCR-QA-SUPPLIER-08.pdf', title: 'Nenuskaityti kontrahento rekvizitai', pages: 1, missing: ['client_counterparty', 'counterparty_code'], priority: 1,
    help: 'Pagal originalą įrašyti kontrahento pavadinimą ir kodą. Jei rekvizitų nustatyti nepavyksta, perduoti komandos vadovui.' },
  { file: 'OCR-QA-VAT-09.pdf', title: 'Trūksta PVM sumos ir tarifo', pages: 1, missing: ['vat', 'vat_percent'], priority: 2,
    help: 'Palyginti PVM sumą ir tarifą su PDF; užpildyti abu privalomus laukus. Tuščia reikšmė nėra 0.' },
  { file: 'OCR-QA-TOTAL-10.pdf', title: 'Nenuskaitytos sąskaitos sumos', pages: 1, missing: ['amount_without_vat', 'total_amount'], priority: 2,
    help: 'Sutikrinti eilutes, PVM ir bendrą sumą originale. Užpildyti sumą be PVM ir bendrą sumą; patikrinti jų tarpusavio atitikimą.' },
  { file: 'OCR-QA-TYPE-11.pdf', title: 'Neatpažintas dokumento tipas', pages: 1, missing: ['document_type', 'document_subtype'], priority: 1,
    help: 'Parinkti sukonfigūruotą dokumento subtipą arba „Siųsti komandos vadovui“ pasirinkti neaiškaus / nepalaikomo tipo priežastį.' },
  { file: 'OCR-QA-RETURN-12.pdf', title: 'Neįskaitomas ir nepilnas originalas', pages: 1, unreadable: true, missing: ['number', 'document_date', 'client_counterparty', 'counterparty_code'], priority: 1,
    help: 'Grąžinimo scenarijus: „Grąžinti dokumentą“ → „Neįskaitomas dokumentas“ arba „Nepilnas dokumentas“. Tikrinti būseną Atmesta įkeltuose dokumentuose.' },
  { file: 'OCR-QA-HAND-13.pdf', title: 'Ranka papildyta sąskaita', pages: 2, handwriting: 'partial', missing: ['currency'], priority: 3,
    help: 'Tik vienas geltonas įspėjimas – „Rašyta ranka“. Patikrinti ranka įrašytus duomenis ir trūkstamą valiutą.' },
  { file: 'OCR-QA-OPERATION-14.pdf', title: 'Trūksta operacijos datos', pages: 1, missing: ['operation_date'], priority: 3,
    help: 'Užpildyti operacijos datą. Šiuo pavyzdžiu taip pat galima tikrinti žemo prioriteto rikiavimą ir „Kitas failas“ eigą.' },
];

export function ocrWorkflowExampleSupplier(companyId: string, at: string): Company {
  return { id: `${companyId}:${OCR_WORKFLOW_EXAMPLES_BATCH}:supplier`, name: 'FH Test Supplier UAB',
    company_code: OCR_WORKFLOW_SUPPLIER_CODE, vat_code: 'LT-TEST-ONLY', accounting_system_code: 'FH-QA',
    company_status: 'Active', client_since: new Date(at).getFullYear(), action_required: 0,
    counterparty_created_by: 'V25 synthetic OCR examples', counterparty_created_at: at };
}

/** Actual multipage PDFs with frozen source facts. Corrections never regenerate the original. */
export async function createOcrWorkflowExamples(companyId: string, organization: string,
  owner: { email: string; fullName: string }, at: string) {
  if (!companyId.trim() || !owner.email.trim() || !Number.isFinite(Date.parse(at))) throw new Error('A company, worker and valid date are required.');
  const { PDFDocument, StandardFonts, rgb } = await import('pdf-lib');
  const supplier = ocrWorkflowExampleSupplier(companyId, at);
  const documents: DbDocument[] = [], tasks: Record<string, WorkspaceTask> = {};
  for (const [index, scenario] of OCR_WORKFLOW_SCENARIOS.entries()) {
    const id = `${companyId}:${OCR_WORKFLOW_EXAMPLES_BATCH}:${index + 1}`;
    const received = new Date(Date.parse(at) - (index + 1) * 36e5).toISOString();
    const date = new Date(Date.parse(at) - 864e5).toISOString().slice(0, 10);
    const due = new Date(Date.parse(`${date}T00:00:00Z`) + 30 * 864e5).toISOString().slice(0, 10);
    const number = scenario.mergePart ? 'FH-QA-MERGE-2026' : `FH-QA-${String(index + 1).padStart(3, '0')}`;
    const lines = [{ product: 'Office equipment setup', qty: '2', price: '75.00', subtotal: '150.00', vat: '31.50', total: '181.50' },
      { product: 'Technical support', qty: '3', price: '50.00', subtotal: '150.00', vat: '31.50', total: '181.50' }]
      .map((line, i) => ({ ...line, id: `${id}:line:${i + 1}`, barcode: '', code: `QA-${i + 1}`, productGroup: 'Services', unit: 'pcs',
        discount: '0.00', vatPct: '21%', department: '', object: '', series: 'QA', center: '', expense: '6300', vatClass: 'PVM1' }));
    const original: DbDocument = { id, company_id: companyId, number, file_case: scenario.file, receive_date: date,
      client_counterparty: supplier.name, counterparty_id: supplier.id, counterparty_code: OCR_WORKFLOW_SUPPLIER_CODE,
      document_type: 'INVOICES', document_subtype: 'VAT_INVOICE', document_purpose: 'Purchase', type: 'Purchase',
      source: 'Upload', entry_method: 'ocr', status: 'Worker review', document_date: date, operation_date: date,
      invoice_contract_date: date, due_end_date: due, valid_form: '', order_no: `QA-ORDER-${index + 1}`, currency: 'EUR',
      amount_without_vat: '300.00', vat: '63.00', total_amount: '363.00', vat_percent: '21%',
      expense_account: '6300', vat_classifier: 'PVM1', department_code: '', object_project: '', cost_center: '', series: 'QA', accountable_responsible: '',
      created_by: 'V25 synthetic OCR workflow examples', created_at: received, image_url: null,
      notes: `TESTINIS DOKUMENTAS – NE MOKĖJIMUI. ${scenario.title}. ${scenario.help}`,
      line_items: lines, summary_line_items: lines.map(line => ({ ...line })),
      ocr_handwriting: scenario.handwriting || 'none', ocr_multiple_documents: Boolean(scenario.multiple) };

    const pdf = await PDFDocument.create();
    pdf.setTitle(scenario.file); pdf.setAuthor('Finansu harmonija - synthetic test data');
    pdf.setSubject('Synthetic invoice for OCR workflow testing. Not for accounting or payment.');
    const font = await pdf.embedFont(StandardFonts.Helvetica), bold = await pdf.embedFont(StandardFonts.HelveticaBold);
    const pen = await pdf.embedFont(StandardFonts.CourierOblique);
    const ink = rgb(0.06, 0.14, 0.23), muted = rgb(0.40, 0.50, 0.59), accent = rgb(0, 0.49, 0.65), pale = rgb(0.91, 0.96, 0.98);
    const ascii = (value: string) => value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\x20-\x7E]/g, '-');
    for (let pageNumber = 1; pageNumber <= scenario.pages; pageNumber++) {
      const page = pdf.addPage([595, 842]);
      const pageInInvoice = scenario.mergePart || (scenario.twoInvoices ? (pageNumber - 1) % 2 + 1 : pageNumber);
      const totalInvoicePages = scenario.twoInvoices || scenario.mergePart ? 2 : scenario.pages;
      const documentNumber = `${number}${scenario.twoInvoices ? pageNumber <= 2 ? '-A' : '-B' : ''}`;
      const text = (value: string, x: number, y: number, size = 11, heavy = false) =>
        page.drawText(ascii(value), { x, y, size, font: heavy ? bold : font, color: ink });
      const rule = (y: number) => page.drawLine({ start: { x: 40, y }, end: { x: 555, y }, thickness: 0.7, color: rgb(0.81, 0.88, 0.93) });
      page.drawRectangle({ x: 40, y: 765, width: 38, height: 38, color: accent });
      page.drawText('FH', { x: 47, y: 777, size: 19, font: bold, color: rgb(1, 1, 1) });
      text('Finansu harmonija', 90, 786, 19, true);
      page.drawText('TEST DOCUMENT - NOT FOR PAYMENT', { x: 90, y: 769, size: 9, font, color: muted });
      rule(749);
      text(pageInInvoice === 1 ? 'VAT INVOICE' : 'INVOICE CONTINUATION / ANNEX', 40, 713, 20, true);
      text(documentNumber, 40, 685, 15, true);
      text(`Document date: ${date}`, 365, 717); text(`Due date: ${due}`, 365, 697);
      text('SELLER', 40, 641, 10, true); text('BUYER', 320, 641, 10, true);
      text(supplier.name, 40, 618, 13, true); text(organization.slice(0, 28), 320, 618, 13, true);
      text(`Company code: ${OCR_WORKFLOW_SUPPLIER_CODE}`, 40, 598, 9); text('Company code: FH-TEST-BUYER', 320, 598, 9);
      text('VAT code: LT-TEST-ONLY', 40, 581, 9); text('Test address 2, Vilnius', 320, 581, 9);
      text('Test address 1, Vilnius', 40, 564, 9);
      page.drawRectangle({ x: 40, y: 514, width: 515, height: 31, color: pale });
      text('Description', 50, 526, 10, true); text('Qty', 340, 526, 10, true); text('Unit price', 390, 526, 10, true); text('Net, EUR', 480, 526, 10, true);
      lines.forEach((line, i) => { const y = 491 - i * 40;
        text(line.product, 50, y); text(line.qty, 348, y); text(line.price, 405, y); text(line.subtotal, 491, y); rule(y - 17);
      });
      if (!(scenario.mergePart === 1)) {
        text('Amount without VAT', 320, 385); text(original.amount_without_vat, 493, 385, 11, true);
        text('VAT (21%)', 320, 363); text(original.vat, 499, 363);
        page.drawRectangle({ x: 308, y: 311, width: 247, height: 36, color: pale });
        text('TOTAL, EUR', 320, 324, 12, true); text(original.total_amount, 483, 324, 14, true);
      } else text('Total is on the continuation page (file B).', 40, 365, 11, true);
      if (scenario.handwriting) page.drawText(`Checked by hand: ${date} / EUR`, { x: 55, y: 272, size: 13, font: pen, color: rgb(0.12, 0.30, 0.57) });
      if (scenario.unreadable) {
        for (const [x, y, width, height] of [[39, 676, 220, 23], [362, 707, 190, 19], [39, 559, 250, 74]]) {
          page.drawRectangle({ x, y, width, height, color: rgb(0.83, 0.84, 0.85) });
          for (let k = 0; k < 6; k++) page.drawLine({ start: { x, y: y + k * height / 6 }, end: { x: x + width, y: y + (k + 1) * height / 6 }, thickness: 2, color: rgb(0.7, 0.71, 0.72) });
        }
        text('Damaged source: key invoice details cannot be read.', 40, 244, 10, true);
      }
      rule(217); text(`TEST SCENARIO: ${ascii(scenario.title)}`, 40, 197, 10, true);
      const words = ascii(scenario.help).split(' '); let line = '', y = 178;
      for (const word of words) { const candidate = `${line} ${word}`.trim();
        if (font.widthOfTextAtSize(candidate, 10) > 510) { text(line, 40, y, 10); y -= 15; line = word; } else line = candidate;
      }
      if (line) text(line, 40, y, 10);
      text('Synthetic source facts. Extracted fields intentionally contain omissions.', 40, 105, 9);
      text(`Invoice page ${pageInInvoice} of ${totalInvoicePages} | ${documentNumber}`, 40, 75, 10, true);
      rule(59); text(scenario.file, 40, 40, 9); text(`PDF page ${pageNumber} / ${scenario.pages}`, 465, 40, 9);
    }
    original.image_url = await pdf.saveAsBase64({ dataUri: true });
    const document = { ...original };
    for (const key of scenario.missing) Object.assign(document, { [key]: '' });
    // Keep the identified directory entry for an editable accounting context, but
    // deliberately omit its extracted code in the missing-supplier scenario.
    const task: WorkspaceTask = { id, name: scenario.file, priority: scenario.priority, description: scenario.title,
      status: 'In Progress', createdBy: owner.fullName, assignedToEmail: owner.email.trim().toLowerCase(), assignedToName: owner.fullName,
      assignedAt: received, creationDate: received, sourceRunId: OCR_WORKFLOW_EXAMPLES_BATCH, documentType: document.document_subtype || '',
      fields: { invoiceNumber: document.number, invoiceDate: document.document_date, dueDate: document.due_end_date,
        companyName: document.client_counterparty, streetAddress: '', city: '', zipCode: '', phoneNumber: '', email: '',
        taxRate: document.vat_percent.replace('%', ''), discountRate: '0', totalDiscount: '0.00', totalAmount: document.total_amount },
      ocrFieldValues: { operationDate: document.operation_date, amountWithoutVat: document.amount_without_vat, vat: document.vat, currency: document.currency },
      accounting: { companyId, companyName: organization, documentId: id, documentName: scenario.file, supplierKey: supplier.id,
        supplierName: document.client_counterparty, supplierCode: document.counterparty_code, vatRate: document.vat_percent,
        expenseAccount: '6300', vatClassifier: 'PVM1' },
      products: lines.map(line => ({ id: line.id, name: line.product, description: '', quantity: line.qty, price: line.price })), comments: [] };
    if (scenario.missing.includes('vat_percent')) {
      document.line_items = lines.map(line => ({ ...line, vatPct: '' }));
      document.summary_line_items = lines.map(line => ({ ...line, vatPct: '' }));
    }
    documents.push(document); tasks[id] = task;
  }
  return { documents, tasks, supplier };
}
