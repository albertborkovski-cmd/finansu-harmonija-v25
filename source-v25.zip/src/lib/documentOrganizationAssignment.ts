import { documentDetailSnapshot } from './documentDetailEditing';
import { documentEditStateError, type InlineDocumentSource } from './documentInlineEditing';

export const NO_BUYER_FILTER = '__no_buyer__';

/** Organization selection never filters by processing/accounting status. */
export function matchesDocumentOrganization(companyId: string | null | undefined, selection: readonly string[] | null) {
  return selection === null || selection.includes(companyId?.trim() || NO_BUYER_FILTER);
}

export function documentOrganizationSnapshot(document: Record<string, unknown>) {
  return JSON.stringify({ companyId: document.company_id ?? '', updatedAt: document.updated_at ?? '',
    content: documentDetailSnapshot(document), deletion: document.document_deletion ?? null,
    issues: document.digitization_issues ?? [], route: document.ocr_approval_route ?? null,
    rerun: document.ocr_rerun_request ?? null });
}

export function prepareDocumentOrganizationAssignment(document: InlineDocumentSource, organizationId: string, expected: string, allowed: boolean) {
  if (!allowed) throw new Error('You do not have permission to assign this organization.');
  if (!organizationId.trim()) throw new Error('Select an organization.');
  if (String(document.company_id ?? '').trim()) throw new Error('The document already has an organization. Refresh before continuing.');
  const stateError = documentEditStateError(document);
  if (stateError) throw new Error(stateError);
  if (documentOrganizationSnapshot(document) !== expected) throw new Error('The document changed. Reopen it before saving your changes.');
  return { company_id: organizationId,
    // Assigning a missing organization is not accounting approval or OCR completion.
    ...(String(document.status ?? '').trim().toLowerCase() === 'organization not identified' ? { status: 'Processing' } : {}) };
}
