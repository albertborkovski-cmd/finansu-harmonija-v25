import { useId, useState } from 'react';
import { Star, Loader2, FileText, Users, List } from 'lucide-react';
import { translateUi as uiText } from '../i18n/language';
import { setOrganizationClientStatus, type Company } from '../lib/supabase';
import { canChangeOrganizationClient } from '../lib/documentEditAccess';
import type { OrganizationDirectoryEntry } from '../lib/organizationDirectory';
import { isInactiveRecord } from '../lib/recordLifecycle';
import GlJournalDialog from './GlJournalDialog';
import OrganizationDigitizationSetup from './OrganizationDigitizationSetup';
import OrganizationReferenceLists from './OrganizationReferenceLists';
import { PageActionButton } from './PageHeader';
import { ADDITIONAL_CODE_SECTIONS } from '../lib/organizationAdditionalCodes';
import OrganizationAdditionalCodes from './OrganizationAdditionalCodes';
import OrganizationSettingsHelpLink from './OrganizationSettingsHelpLink';

const SETTINGS_SECTIONS = [
  { key: 'digitization', label: 'Documents & digitization setup', icon: FileText },
  { key: 'counterparties', label: 'Counterparties', icon: Users },
  ...ADDITIONAL_CODE_SECTIONS.map(section => ({ key: section.key, label: section.label, icon: List })),
  { key: 'expenses', label: 'Expenses', icon: List },
] as const;
type SettingsSection = typeof SETTINGS_SECTIONS[number]['key'];

export default function OrganizationDirectorySettings({ entry, onClose, onUpdated }: {
  entry: OrganizationDirectoryEntry; onClose: () => void; onUpdated: (company: Company) => void;
}) {
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [section, setSection] = useState<SettingsSection>('digitization');
  const [counterpartyEditing, setCounterpartyEditing] = useState(false);
  const [visitedSections, setVisitedSections] = useState<Set<SettingsSection>>(() => new Set(['digitization']));
  const sectionId = useId();
  const selectSection = (next: SettingsSection) => {
    setSection(next);
    setVisitedSections(previous => previous.has(next) ? previous : new Set([...previous, next]));
  };
  const allowed = !isInactiveRecord(entry) && canChangeOrganizationClient(entry.organizationId ? entry : undefined);
  const toggle = async () => {
    if (saving) return;
    setSaving(true); setError('');
    try { onUpdated(await setOrganizationClientStatus(entry.id, !entry.isOrganizationClient, entry.isOrganizationClient)); }
    catch (reason) { setError(reason instanceof Error ? reason.message : 'The changes could not be saved.'); }
    finally { setSaving(false); }
  };
  const clientControl = <div className="rounded-lg border border-[#D3E1EC] bg-white p-3">
    <div className="flex items-center gap-2.5">
      <button type="button" aria-label={uiText('Organization client')} title={uiText(entry.isOrganizationClient ? 'Unmark as organization client' : 'Mark as organization client')}
        aria-pressed={entry.isOrganizationClient} disabled={saving || !allowed} onClick={() => void toggle()}
        className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-md border bg-white transition-colors disabled:cursor-not-allowed disabled:opacity-40 ${entry.isOrganizationClient ? 'border-[#007EA7] text-[#007EA7]' : 'border-[#D3E1EC] text-[#7288A3] hover:border-[#007EA7] hover:text-[#007EA7]'}`}>
        {saving ? <Loader2 size={18} className="animate-spin" /> : <Star size={18} fill={entry.isOrganizationClient ? 'currentColor' : 'none'} />}
      </button>
      <p className="min-w-0 text-[12px] font-semibold leading-[18px] text-[#10233A]">{uiText(entry.isOrganizationClient ? 'Organization client' : 'Counterparty')}</p>
      <OrganizationSettingsHelpLink topic="client" label="Organization client" />
    </div>
    <p className="mt-2 text-[11px] leading-[17px] text-[#7288A3]">{uiText('Starred clients appear first in the organization list.')}</p>
    {error && <p role="alert" className="mt-2 text-[12px] text-[#B42318]">{uiText(error)}</p>}
  </div>;
  return <GlJournalDialog title="Organization settings" subtitle={entry.name} onClose={onClose} workspace={Boolean(entry.organizationId)}>
    {entry.organizationId ? <div className="flex min-h-0 w-full min-w-0 flex-1" data-organization-settings-workspace>
      <aside className="flex min-h-0 w-[170px] shrink-0 flex-col gap-4 overflow-hidden border-r border-[#D3E1EC] bg-[#F7FAFC] p-3 sm:w-[248px] sm:p-4">
        <div className="shrink-0" data-organization-client-control>{clientControl}</div>
        <div role="tablist" aria-orientation="vertical" aria-label={uiText('Organization settings sections')} className="flex min-h-0 flex-1 flex-col gap-1.5 overflow-y-auto">
        {SETTINGS_SECTIONS.map((item, index) => <div key={item.key}>{item.key === ADDITIONAL_CODE_SECTIONS[0]?.key && <h4 className="px-3 pb-2 pt-4 text-[11px] font-semibold uppercase tracking-wide text-[#7288A3]">{uiText('Additional columns')}</h4>}<div className="relative"><button type="button" role="tab" id={`${sectionId}-${item.key}`} aria-controls={`${sectionId}-${item.key}-panel`}
          aria-selected={section === item.key} tabIndex={section === item.key ? 0 : -1} onClick={() => selectSection(item.key)}
          onKeyDown={event => {
            if (!['ArrowUp', 'ArrowDown', 'Home', 'End'].includes(event.key)) return;
            event.preventDefault();
            const next = event.key === 'Home' ? 0 : event.key === 'End' ? SETTINGS_SECTIONS.length - 1 : (index + (event.key === 'ArrowUp' ? -1 : 1) + SETTINGS_SECTIONS.length) % SETTINGS_SECTIONS.length;
            selectSection(SETTINGS_SECTIONS[next].key); document.getElementById(`${sectionId}-${SETTINGS_SECTIONS[next].key}`)?.focus();
          }}
          className={`flex min-h-[42px] w-full shrink-0 items-center gap-2.5 rounded-lg border py-2.5 pl-3 pr-8 text-left text-[13px] font-semibold leading-5 transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#007EA7] ${section === item.key ? 'border-[#D3E1EC] bg-[#E5EDF9] text-[#007EA7]' : 'border-transparent text-[#7288A3] hover:bg-[#EDF3F8] hover:text-[#10233A]'}`}>
          <item.icon size={17} className="shrink-0" aria-hidden="true" /><span>{uiText(item.label)}</span>
        </button><div className="absolute right-1.5 top-3"><OrganizationSettingsHelpLink section={item.key} label={item.label} /></div></div></div>)}
        </div>
      </aside>
      <div className="flex min-h-0 min-w-0 flex-1 flex-col px-4 pb-4 pt-5 sm:px-6">
        <div role="tabpanel" id={`${sectionId}-digitization-panel`} aria-labelledby={`${sectionId}-digitization`} hidden={section !== 'digitization'} className="h-full min-h-0 min-w-0 flex-1">
          <div className="flex h-full min-h-0 flex-col gap-4">
          <h3 className="flex min-h-8 shrink-0 items-center text-[16px] font-semibold leading-6 text-[#10233A]">{uiText('Documents & digitization setup')}</h3>
          <OrganizationDigitizationSetup key={entry.organizationId} company={entry} onClose={onClose} onUpdated={onUpdated} />
          </div>
        </div>
        <div role="tabpanel" id={`${sectionId}-counterparties-panel`} aria-labelledby={`${sectionId}-counterparties`} hidden={section !== 'counterparties'} className="h-full min-h-0 min-w-0 flex-1">
          {visitedSections.has('counterparties') && <div className="flex h-full min-h-0 flex-col">
            <div className={`min-h-0 flex-1 ${counterpartyEditing ? '' : 'pb-5'}`}><OrganizationReferenceLists key={`${entry.organizationId}:counterparties`} companyId={entry.organizationId} kind="counterparties" onEditingChange={setCounterpartyEditing} /></div>
            {!counterpartyEditing && <div className="flex min-h-[60px] shrink-0 items-center justify-end border-t border-[#D3E1EC] pt-4"><PageActionButton onClick={onClose}>{uiText('Close')}</PageActionButton></div>}
          </div>}
        </div>
        {[...ADDITIONAL_CODE_SECTIONS.map(item => item.key), 'expenses' as const].map(kind => <div key={kind} role="tabpanel" id={`${sectionId}-${kind}-panel`} aria-labelledby={`${sectionId}-${kind}`} hidden={section !== kind} className="h-full min-h-0 min-w-0 flex-1">
          {visitedSections.has(kind) && <OrganizationAdditionalCodes key={`${entry.organizationId}:${kind}`} companyId={entry.organizationId!} section={kind} onUpdated={onUpdated} onClose={onClose} />}
        </div>)}
      </div>
    </div>
      : <div className="space-y-5">{clientControl}<section className="rounded-lg border border-[#D3E1EC] p-4">
        <dl className="grid grid-cols-1 gap-4 text-[12px] sm:grid-cols-2">
          {[["Name", entry.name], ["Company code", entry.company_code], ["VAT code", entry.vat_code], ["Email", entry.email]].map(([label, value]) =>
            <div key={label}><dt className="mb-1 text-[#7288A3]">{uiText(label || '')}</dt><dd className="break-words font-medium text-[#10233A]">{value || '—'}</dd></div>)}
        </dl>
        <p className="mt-4 border-t border-[#E5EDF9] pt-3 text-[12px] leading-5 text-[#7288A3]">{uiText('Mark this counterparty with a star to create its organization profile. Existing documents and counterparty records will not be moved or changed.')}</p>
      </section></div>}
  </GlJournalDialog>;
}
