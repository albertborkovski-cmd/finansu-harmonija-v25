import { useEffect, useId, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';
import { assignDocumentAdvanceEmployee, supabase, type DbDocument } from '../lib/supabase';
import { isPurchaseInvoice } from '../lib/invoiceAdvanceEmployee';
import { translateUi as t } from '../i18n/language';
import { CancelButton, SaveButton } from './ScopedActionButtons';
import AdvanceEmployeeSelect from './AdvanceEmployeeSelect';

export default function AssignAdvanceEmployeeDialog({ companyId, ids, onClose, onSaved }: {
  companyId: string; ids: string[]; onClose: () => void; onSaved: (documents: DbDocument[]) => void;
}) {
  const titleId = useId(), root = useRef<HTMLDivElement>(null), pending = useRef(false);
  const [documents, setDocuments] = useState<DbDocument[]>([]), [employee, setEmployee] = useState('');
  const [loading, setLoading] = useState(true), [busy, setBusy] = useState(false), [error, setError] = useState('');
  const snapshots = useRef<Record<string, string>>({});
  const selectionKey = [...ids].sort().join('|');
  useEffect(() => {
    let active = true;
    const previous = document.activeElement as HTMLElement | null;
    root.current?.focus();
    void (async () => {
      try {
        const result = await supabase.from('documents').select('*').eq('company_id', companyId);
        if (result.error) throw new Error('Could not load the selected documents.');
        const selected = (result.data || []).filter(row => ids.includes(String(row.id)));
        if (selected.length !== new Set(ids).size || selected.some(row => !isPurchaseInvoice(row))) throw new Error('Select purchase invoices from one company only.');
        if (active) { snapshots.current = Object.fromEntries(selected.map(row => [String(row.id), JSON.stringify(row)])); setDocuments(selected as unknown as DbDocument[]); }
      } catch (cause) { if (active) setError(cause instanceof Error ? cause.message : 'Could not load the selected documents.'); }
      finally { if (active) setLoading(false); }
    })();
    return () => { active = false; if (previous?.isConnected) previous.focus(); };
  }, [companyId, selectionKey]);
  const close = () => { if (!pending.current) onClose(); };
  const save = async () => {
    if (pending.current || loading || !employee || !documents.length) return;
    pending.current = true; setBusy(true); setError('');
    try { const saved = await assignDocumentAdvanceEmployee(companyId, documents.map(row => row.id), employee, snapshots.current); onSaved(saved); onClose(); }
    catch (cause) { setError(cause instanceof Error ? cause.message : 'Could not assign the Advance employee.'); }
    finally { pending.current = false; setBusy(false); }
  };
  return createPortal(<div className="fixed inset-0 z-[5400] flex items-center justify-center bg-[#10233A]/30 p-4 font-montserrat" onMouseDown={event => { if (event.target === event.currentTarget) close(); }}>
    <div ref={root} tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby={titleId} onKeyDown={event => {
      if (event.key === 'Escape' && !document.querySelector('[role="listbox"]')) { event.stopPropagation(); close(); }
      if (event.key === 'Tab') {
        const controls = [...root.current!.querySelectorAll<HTMLElement>('button:not(:disabled), input:not(:disabled)')].filter(node => node.getClientRects().length);
        if (event.shiftKey && document.activeElement === controls[0]) { event.preventDefault(); controls.at(-1)?.focus(); }
        else if (!event.shiftKey && document.activeElement === controls.at(-1)) { event.preventDefault(); controls[0]?.focus(); }
      }
    }} className="flex max-h-[90vh] w-full max-w-[640px] flex-col overflow-hidden rounded-xl border border-[#D3E1EC] bg-white shadow-xl">
      <header className="flex items-center justify-between border-b border-[#D3E1EC] px-6 py-4"><h2 id={titleId} className="text-[18px] font-semibold text-[#10233A]">{t('Assign advance employee')}</h2><button aria-label={t('Close')} onClick={close} disabled={busy} className="rounded p-1 text-[#7288A3] hover:text-[#007EA7]"><X size={19}/></button></header>
      <div className="space-y-4 overflow-y-auto px-6 py-5">
        <div><p className="mb-1.5 text-[12px] font-medium text-[#7288A3]">{t('Advance employee')} *</p><AdvanceEmployeeSelect companyId={companyId} value={employee} onChange={setEmployee} disabled={busy || loading}/></div>
        <p className="text-[12px] leading-5 text-[#7288A3]">{t('Selected purchase invoices become Advance invoice. Original GL postings stay unchanged. Different accounts are transferred only for the reconciled amount.')}</p>
        <div className="max-h-48 overflow-y-auto rounded-lg border border-[#D3E1EC]">{loading ? <p className="p-3 text-[12px]">{t('Loading…')}</p> : documents.map(row => <div key={row.id} className="flex justify-between gap-3 border-b border-[#E5EDF9] px-3 py-2 text-[12px] last:border-0"><span className="font-medium">{row.number || row.file_case || row.id}</span><span className="text-[#7288A3]">{t(row.advance_employee_reversal ? 'Opposite GL entry already created' : 'GL transfer on reconciliation')}</span></div>)}</div>
        {error && <p role="alert" className="rounded-md bg-[#FFF0F0] p-3 text-[12px] text-[#B42318]">{t(error)}</p>}
      </div>
      <footer className="flex justify-end gap-3 border-t border-[#D3E1EC] px-6 py-4"><CancelButton onClick={close}/><SaveButton onClick={() => void save()} disabled={busy || loading || !employee || !documents.length}>{t('Assign')}</SaveButton></footer>
    </div>
  </div>, document.body);
}
