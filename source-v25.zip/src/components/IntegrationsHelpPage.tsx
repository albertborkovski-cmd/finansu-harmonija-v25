import { ArrowLeft, BookOpen, Search } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { useLanguage, translateUi as t } from '../i18n/language';
import { INTEGRATION_ARTICLES as ALL_INTEGRATIONS, integrationArticle } from '../lib/integrationHelp';
import { integrationHelpHref } from './IntegrationHelpLink';
import { integrationTopic, integrationTopics } from '../lib/integrationHelpTopics';
import IntegrationHelpTopics from './IntegrationHelpTopics';
import { useHelpContent } from './HelpContentProvider';
import { isHelpVisible } from '../lib/helpContent';

export default function IntegrationsHelpPage() {
  const lt = useLanguage() === 'lt', lang = lt ? 1 : 0;
  const { state } = useHelpContent();
  const INTEGRATION_ARTICLES = useMemo(() => ALL_INTEGRATIONS.filter(item => isHelpVisible(integrationHelpHref(item.id), state)).map(item => ({
    ...item,
    visibleTopics: integrationTopics(item.id).filter(topic => isHelpVisible(integrationHelpHref(item.id, topic.id), state)),
  })), [state]);
  const [query, setQuery] = useState('');
  const params = new URLSearchParams(window.location.hash.split('?')[1] || '');
  const article = integrationArticle(params.get('integration'));
  const topicId = params.get('topic');
  const sectionId = params.get('section');
  const topics = integrationTopics(article.id).filter(item => isHelpVisible(integrationHelpHref(article.id, item.id), state));
  const topic = integrationTopic(article.id, topicId);
  const filtered = INTEGRATION_ARTICLES.filter(item => `${item.name[lang]} ${item.summary[lang]} ${item.visibleTopics.map(topic => `${topic.title[lang]} ${topic.description[lang]}`).join(' ')}`.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase()));
  useEffect(() => { document.title = `Finansų harmonija · ${lt ? 'Integracijos' : 'Integrations'} · ${article.name[lang]}${topic ? ` · ${topic.title[lang]}` : ''}`; }, [article, topic, lang, lt]);
  useEffect(() => {
    const section = sectionId && document.getElementById(`help-section-${sectionId}`);
    if (section) section.scrollIntoView({ block: 'start' });
    else window.scrollTo(0, 0);
  }, [article.id, topicId, sectionId]);
  return <main className="min-h-screen bg-[#F5F8FB] p-4 font-montserrat text-[#10233A] sm:p-8">
    <div className="mx-auto max-w-6xl">
      <a href="./#help" className="mb-4 inline-flex items-center gap-2 text-[12px] font-medium text-[#007EA7]"><ArrowLeft size={15} />{lt ? 'Pagalbos centras' : 'Help centre'}</a>
      <header className="mb-5 flex items-center gap-3"><BookOpen size={24} className="text-[#007EA7]" /><div><p className="text-[12px] font-medium text-[#7288A3]">Finansų harmonija · {t('Help')}</p><h1 className="text-[22px] font-semibold">{lt ? 'Integracijos' : 'Integrations'}</h1></div></header>
      <div className="grid items-start gap-5 md:grid-cols-[255px_minmax(0,1fr)]">
        <nav aria-label={lt ? 'Integracijų sąrašas' : 'Integration catalog'} className="rounded-xl border border-[#D3E1EC] bg-white p-3 md:sticky md:top-5">
          <label className="mb-3 flex items-center gap-2 rounded-lg border border-[#D3E1EC] px-3 py-2 focus-within:border-[#007EA7]"><Search size={16} className="shrink-0 text-[#7288A3]" /><input aria-label={lt ? 'Ieškoti integracijos' : 'Search integrations'} placeholder={lt ? 'Ieškoti integracijos' : 'Search integrations'} value={query} onChange={event => setQuery(event.target.value)} className="min-w-0 w-full bg-transparent text-[12px] outline-none" /></label>
          <div className="max-h-[65vh] space-y-4 overflow-y-auto pr-1">
            {(['collection', 'accounting'] as const).map(group => <section key={group}><h2 className="px-3 pb-2 pt-1 text-[11px] font-semibold uppercase tracking-wide text-[#7288A3]">{group === 'collection' ? (lt ? 'Dokumentų surinkimas' : 'Document collection') : (lt ? 'Apskaitos sistemos ir formatai' : 'Accounting systems & formats')} <span className="font-normal">({INTEGRATION_ARTICLES.filter(item => item.group === group).length})</span></h2>{filtered.filter(item => item.group === group).map(item => <div key={item.id}><a href={integrationHelpHref(item.id)} aria-current={article.id === item.id && !topic ? 'page' : undefined} className={`flex items-center justify-between gap-2 rounded-md px-3 py-2 text-[13px] font-medium leading-5 focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#007EA7] ${article.id === item.id ? 'bg-[#E5EDF9] text-[#007EA7]' : 'text-[#526B86] hover:bg-[#F2F6FA]'}`}>{item.name[lang]}{item.visibleTopics.length > 0 && <span className="text-[11px] text-[#7288A3]">{item.visibleTopics.length}</span>}</a>{article.id === item.id && topics.length > 0 && <ul className="my-2 ml-4 border-l border-[#D3E1EC] pl-3">{topics.map(child => <li key={child.id}><a href={integrationHelpHref(item.id, child.id)} aria-current={topic?.id === child.id ? 'page' : undefined} className={`relative block rounded-md px-2 py-2 text-[11px] leading-5 focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#007EA7] before:absolute before:-left-[16px] before:top-4 before:h-[5px] before:w-[5px] before:rounded-full ${topic?.id === child.id ? 'bg-[#F0F7FB] font-semibold text-[#007EA7] before:bg-[#007EA7]' : 'text-[#7288A3] before:bg-[#D3E1EC] hover:bg-[#F5F8FB]'}`}>{child.title[lang]}</a></li>)}</ul>}</div>)}</section>)}
            {filtered.length === 0 && <p role="status" className="px-3 text-[12px] text-[#7288A3]">{lt ? 'Integracijų nerasta.' : 'No integrations found.'}</p>}
          </div>
        </nav>
        <div className="min-w-0 space-y-5">
          <IntegrationHelpTopics integration={article.id} topicId={topicId} lt={lt} />
        </div>
      </div>
    </div>
  </main>;
}
