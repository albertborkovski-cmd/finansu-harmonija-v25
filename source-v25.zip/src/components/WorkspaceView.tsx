import { translateStatus as statusText } from '../i18n/language';
import { translateUi as uiText } from '../i18n/language';
import { useEffect, useRef, useState, type CSSProperties } from 'react';
import { clampOcrPreviewWidth, loadOcrPreviewWidth, ocrEditorLayoutKey } from '../lib/ocrEditorLayout';
import { OCR_BEFORE_NAVIGATE, ocrCorrectionSnapshot } from '../lib/ocrUnsavedChanges';
import { focusOcrValidationTarget } from '../lib/ocrValidationNavigation';
import {
  ArrowLeft,
  AlertCircle,
  AlertTriangle,
  Clock3,
  FileText,
  MessageSquare,
  MoreHorizontal,
  X,
} from 'lucide-react';
import { PageActionButton, PageHeader } from './PageHeader';
import WorkspaceExpandButton from './WorkspaceExpandButton';
import useWorkspaceExpansion from '../hooks/useWorkspaceExpansion';
import OcrBreadcrumb from './OcrBreadcrumb';
import SearchableSelect from './SearchableSelect';
import OcrConfiguredFields, { type OcrConfiguredControl } from './OcrConfiguredFields';
import { OCR_WORKSPACE_FIELD_KEYS, OCR_LINE_FIELD_KEYS, configuredOcrParties, ocrPartyIsCounterparty, ocrRulePartyId, ocrSavedPartyId, type OcrDocumentParty } from '../lib/ocrFormSchema';
import { updateOcrEditorValue } from '../lib/ocrFormValues';
import { documentPurposeCatalogOptions } from '../lib/documentPurposeCatalog';
import { documentTypeCatalogOptions, documentTypeCatalogSelection } from '../lib/documentTypeCatalog';
import AdvanceEmployeeSelect from './AdvanceEmployeeSelect';
import { isPurchaseInvoice } from '../lib/invoiceAdvanceEmployee';
import { loadOrganizationReferenceRecords } from './OrganizationReferenceValuesView';
import { recordWorkspaceHumanCorrection } from './workspaceHumanMetricsStore';
import { ProcessedDocumentsTable, type ReviewDocumentReference } from './OcrProcessedDocumentsView';
import HandwrittenDocumentBadge from './HandwrittenDocumentBadge';
import OcrRecognitionWarnings from './OcrRecognitionWarnings';
import OcrPdfSplitDialog from './OcrPdfSplitDialog';
import OcrPdfMergeDialog from './OcrPdfMergeDialog';
import { useDropdownDismiss } from './useDropdownDismiss';
import type { PdfPageGroup, PdfMergeSource, PdfMergePage } from '../lib/ocrPdfSplit';
import { isHandwrittenDocument, requiresDocumentStructureReview, type DocumentStructureDecision } from '../lib/ocrHandwriting';
import { usePersistentState } from '../hooks/usePersistentState';
import { recordOcrDocumentWorkTime } from './ocrDocumentWorkTimeStore';
import { supabase, completeOcrReview, handoffOcrWorkerDocument, saveOcrDocumentStructure, splitOcrDocument, mergeOcrDocuments, applyDocumentDetailEdit, applyDocumentIssueAction, type Company, type DbDocument } from '../lib/supabase';
import { handoffDraft, prepareWorkerHandoff, type WorkerHandoffAction, type WorkerHandoffDecision, type WorkerHandoffInput } from '../lib/ocrWorkerHandoff';
import { ocrWorkflowSnapshot } from '../lib/ocrCompletion';
import GeneralLedgerAccountSelect from './GeneralLedgerAccountSelect';
import { loadVatClassifications } from './VatClassificationsView';
import { documentLearningContext, suggestDocumentAccounting, type DocumentLearningContext } from '../lib/ocrLearningStore';
import { normalizeVatRate } from '../lib/ocrLearning';
import { getCurrentUserIdentity } from '../lib/currentUser';
import SendToTeamLeadDialog from './SendToTeamLeadDialog';
import { DocumentConversationPanel } from './DocumentChatDialog';
import type { DocumentIssue } from '../lib/documentIssues';
import { documentDetailSnapshot } from '../lib/documentDetailEditing';
import { loadIssueCorrectionDraft, ocrIssueCorrectionPatch, saveIssueCorrectionDraft } from '../lib/ocrIssueCorrection';
import { canReviewDocumentIssues } from '../lib/documentIssueAccess';
import DocumentFileViewer from './DocumentFileViewer';
import DocumentPreviewControls from './DocumentPreviewControls';
import { clampPreviewZoom, documentPreviewKind, documentPreviewLayout, documentPreviewPoint, rotatePreview, type PreviewFit } from '../lib/documentPreview';
import { requestTeamLeadReview, saveTeamLeadReviewTask, TEAM_LEAD_QUEUE_KEY, updateTeamLeadReview } from '../lib/ocrTeamLeadReview';
import { loadOcrFieldValidationRules, OCR_FIELD_VALIDATION_CHANGED_EVENT } from '../lib/ocrFieldValidation';
import { evaluateOcrDocumentAutomation, automationRulesForDocumentTypes } from '../lib/ocrAutomationDocument';
import { loadAutomationStore, OCR_AUTOMATION_CHANGED, type AutomationResult } from '../lib/ocrAutomationRules';
import { hasOcrValue, isRecognizedOcrDocumentType, missingOcrRequiredFields, ocrCompletionPatch, ocrDocumentPartyPurpose } from '../lib/ocrRequiredFields';
import { ocrRoutingTypeCodes } from '../lib/ocrApprovalRouting';
import { AUTH_SESSION_KEY } from '../lib/currentUser';
import { canEditMenu, parseSession } from '../lib/accessControl';
import { loadSavedReviewDocumentTask } from '../lib/ocrReviewDocuments';

type TaskStatus = 'Available' | 'In Progress' | 'Completed';
type TaskTab = 'extracted' | 'chat';

export interface ProductLine {
  id: string;
  name: string;
  description: string;
  quantity: string;
  price: string;
  ocrValues?: Record<string, string>;
}

type ProductFieldKey = 'name' | 'description' | 'quantity' | 'price';

interface WorkspaceFields {
  invoiceNumber: string;
  invoiceDate: string;
  dueDate: string;
  companyName: string;
  streetAddress: string;
  city: string;
  zipCode: string;
  phoneNumber: string;
  email: string;
  taxRate: string;
  discountRate: string;
  totalDiscount: string;
  totalAmount: string;
}

interface WorkspaceComment {
  id: string;
  author: string;
  text: string;
  createdAt: string;
}

interface DocumentTextMapping {
  text: string;
  texts?: string[];
  color: string;
  softColor: string;
  targetLabel: string;
}

export interface WorkspaceTask {
  ocrFieldValues?: Record<string, string>;
  ocrParties?: OcrDocumentParty[];
  advanceEmployeeId?: string;
  advanceEmployee?: string;
  id: string;
  name: string;
  priority: number;
  description: string;
  status: TaskStatus;
  createdBy: string;
  assignedToEmail?: string;
  assignedToName?: string;
  assignedAt?: string;
  creationDate: string;
  documentType: string;
  sourceRunId: string;
  humanCorrected?: boolean;
  trainingStatus?: 'Confirmed';
  trainingConfirmedAt?: string;
  teamLeadReview?: { status: 'Pending' | 'Approved'; requestedAt: string; comment?: string; reason?: string; requestedBy?: string; requestedByEmail?: string };
  workerHandoff?: WorkerHandoffDecision;
  documentStructure?: DocumentStructureDecision;
  teamLeadReviewHistory?: NonNullable<WorkspaceTask['teamLeadReview']>[];
  ocrRunRequest?: { id: string; requestedAt: string; status: 'Pending integration' };
  correctionCount?: number;
  lastCorrectedAt?: string;
  savedAt?: string;
  editStartedAt?: string;
  remainingTimeSeconds?: number;
  correctionDurationSeconds?: number;
  originalFields?: WorkspaceFields;
  originalProducts?: ProductLine[];
  documentMappings?: Record<string, DocumentTextMapping>;
  accounting?: DocumentLearningContext;
  fields: WorkspaceFields;
  products: ProductLine[];
  comments: WorkspaceComment[];
}

const CORRECTION_TIME_SECONDS = 30 * 60;
const reviewDateValue = (value: string) => {
  const date = value.trim();
  const localized = date.match(/^(\d{2})[./](\d{2})[./](\d{4})$/);
  const iso = localized ? `${localized[3]}-${localized[2]}-${localized[1]}` : date;
  const parsed = new Date(`${iso}T00:00:00Z`);
  return /^\d{4}-\d{2}-\d{2}$/.test(iso) && Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === iso ? iso : '';
};

const EMPTY_FIELDS: WorkspaceFields = {
  invoiceNumber: 'B34870642',
  invoiceDate: '2020-08-27',
  dueDate: '2020-10-27',
  companyName: 'CME Group Inc.',
  streetAddress: '85155 Dayton Point',
  city: 'Ponta do Sol',
  zipCode: '27717',
  phoneNumber: '+62 (865) 917-9478',
  email: 'fmedicine@gmail.com',
  taxRate: '1.00',
  discountRate: '15.00',
  totalDiscount: '528.58',
  totalAmount: '2995.31',
};

const SAMPLE_PRODUCTS: ProductLine[] = [
  { id: 'product-1', name: 'Seabream whole farmed', description: 'Cloud food lake red foodlia', quantity: '18.00', price: '110.00' },
  { id: 'product-2', name: 'Oil', description: 'Energy red boost healthy', quantity: '15.00', price: '61.00' },
  { id: 'product-3', name: 'Lamb', description: 'Smack healthy vibe organic reservation organic', quantity: '18.00', price: '33.00' },
];

const REQUIRED_LABELS: Array<[keyof WorkspaceFields, string]> = [
  ['invoiceNumber', 'Invoice Number'],
  ['invoiceDate', 'Invoice Date'],
  ['dueDate', 'Due Date'],
  ['companyName', 'Company Name'],
  ['totalAmount', 'Total Amount'],
];

const fieldDisplayName = (key: keyof WorkspaceFields) =>
  key.replace(/([A-Z])/g, ' $1').replace(/^./, character => character.toUpperCase());

function StatusBadge({ status }: { status: TaskStatus }) {
  const colors = status === 'Completed'
    ? { background: '#EAF8F1', color: '#18794E' }
    : status === 'In Progress'
      ? { background: '#FFF5DF', color: '#9A6700' }
      : { background: '#E5EDF9', color: '#4F6783' };

  return (
    <span className="inline-flex h-6 items-center rounded px-2 font-montserrat text-[12px] font-medium" style={colors}>
      {statusText(status)}
    </span>
  );
}

const FIELD_META: Record<keyof WorkspaceFields, { number: number; color: string; soft: string }> = {
  invoiceNumber: { number: 1, color: '#79B8F3', soft: '#E2F1FF' },
  invoiceDate: { number: 2, color: '#F28DB8', soft: '#FFE1EE' },
  dueDate: { number: 3, color: '#C68BDE', soft: '#F2DFF9' },
  companyName: { number: 4, color: '#D9C944', soft: '#FFF8BE' },
  streetAddress: { number: 5, color: '#5EC8CE', soft: '#D8F4F5' },
  city: { number: 6, color: '#EF8B8B', soft: '#FFE0E0' },
  zipCode: { number: 7, color: '#E7B45B', soft: '#FFEDCB' },
  phoneNumber: { number: 8, color: '#9B8DE5', soft: '#E7E2FF' },
  email: { number: 9, color: '#6CA8E8', soft: '#DFEDFF' },
  taxRate: { number: 10, color: '#62B982', soft: '#DDF4E5' },
  discountRate: { number: 11, color: '#B69284', soft: '#EDDFDA' },
  totalDiscount: { number: 12, color: '#63B7C2', soft: '#D9F0F3' },
  totalAmount: { number: 13, color: '#62B66D', soft: '#DFF3E2' },
};

const PRODUCT_FIELD_META: Record<ProductFieldKey, { label: string; color: string; soft: string }> = {
  name: { label: 'Name', color: '#5B8DEF', soft: '#DCEBFF' },
  description: { label: 'Description', color: '#D6A83D', soft: '#FFF0C7' },
  quantity: { label: 'Quantity', color: '#A56BD6', soft: '#EEDAFF' },
  price: { label: 'Unit cost', color: '#E27777', soft: '#FFD6D6' },
};
function HighlightedDocumentText({
  value,
  mapping,
}: {
  value: string;
  mapping?: DocumentTextMapping;
}) {
  if (!mapping?.text) return <>{value}</>;
  const mappedTexts = (mapping.texts?.length ? mapping.texts : [mapping.text])
    .map(text => text.trim())
    .filter(Boolean);
  const lowerValue = value.toLocaleLowerCase();
  const ranges = mappedTexts
    .map(text => {
      const start = lowerValue.indexOf(text.toLocaleLowerCase());
      return start < 0 ? null : { start, end: start + text.length };
    })
    .filter((range): range is { start: number; end: number } => Boolean(range))
    .sort((left, right) => left.start - right.start)
    .filter((range, index, allRanges) => index === 0 || range.start >= allRanges[index - 1].end);
  if (ranges.length === 0) return <>{value}</>;

  const content: React.ReactNode[] = [];
  let cursor = 0;
  ranges.forEach((range, index) => {
    if (range.start > cursor) content.push(value.slice(cursor, range.start));
    content.push(
      <mark
        key={`${range.start}-${range.end}-${index}`}
        title={`Mapped to ${mapping.targetLabel}`}
        className="rounded-sm px-0.5 text-inherit"
        style={{ backgroundColor: mapping.softColor, boxShadow: `inset 0 -2px 0 ${mapping.color}` }}
      >
        {value.slice(range.start, range.end)}
      </mark>,
    );
    cursor = range.end;
  });
  if (cursor < value.length) content.push(value.slice(cursor));
  return (
    <>{content}</>
  );
}

function documentTextValue(children: React.ReactNode): string {
  if (Array.isArray(children)) return children.map(documentTextValue).join('');
  if (typeof children === 'string' || typeof children === 'number') return String(children);
  return '';
}

function MappedFormField({
  fieldKey,
  label,
  labelAdornment,
  value,
  required,
  type = 'text',
  active,
  compact,
  onSelect,
  onChange,
}: {
  fieldKey: keyof WorkspaceFields;
  label: string;
  labelAdornment?: React.ReactNode;
  value: string;
  required?: boolean;
  type?: string;
  active: boolean;
  compact?: boolean;
  onSelect: () => void;
  onChange: (value: string) => void;
}) {
  const meta = FIELD_META[fieldKey];
  if (compact) return <label className="ocr-party-control" onClick={onSelect}>
    <span>{uiText(label)}{required && <span className="ml-1 text-[#D64545]">*</span>}{labelAdornment}</span>
    <input type={type} aria-label={uiText(label)} aria-invalid={Boolean(required && !value.trim())}
      value={value} onFocus={onSelect} onChange={event => onChange(event.target.value)}
      className={`h-8 min-w-0 w-full rounded border px-2 text-[12px] text-[#10233A] outline-none focus:border-[#007EA7] ${active ? 'ring-1 ring-[#007EA7]/20' : ''} ${required && !value.trim() ? 'border-[#E65050] bg-[#FFF0F0]' : 'border-[#D3E1EC] bg-white'}`} />
    <span aria-label={`${uiText('Original document mapping')} ${meta.number}`} data-tooltip={`${uiText('Original document mapping')} ${meta.number}`}
      data-ocr-source-mapping className="flex h-5 w-5 items-center justify-center rounded text-[10px] font-semibold text-white" style={{ backgroundColor: meta.color }}>{meta.number}</span>
  </label>;
  return (
    <div
      className={`overflow-hidden rounded-lg border bg-white transition-all ${active ? 'shadow-[0_0_0_2px_rgba(0,126,167,0.18)]' : ''}`}
      style={{ borderColor: active ? '#007EA7' : '#D3E1EC' }}
      onClick={onSelect}
    >
      <div className="flex h-8 items-center justify-between bg-[#F2F7FC] px-3">
        <span className="flex min-w-0 items-center gap-2 font-montserrat text-[12px] font-semibold text-[#10233A]">
          {uiText(label)}{required && <span className="ml-1 text-[#D64545]">*</span>}
          {labelAdornment}
        </span>
        <span aria-label={`${uiText('Original document mapping')} ${meta.number}`} data-ocr-source-mapping className="flex h-5 min-w-5 items-center justify-center rounded-full px-1.5 font-montserrat text-[11px] font-semibold text-white" style={{ backgroundColor: meta.color }}>
          {meta.number}
        </span>
      </div>
      <div className="flex items-center gap-2 p-2">
        <span aria-hidden="true" className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded bg-[#F2F7FC] font-montserrat text-[14px] font-semibold text-[#7288A3]">Tᵀ</span>
        <input
          type={type}
          aria-label={uiText(label)}
          aria-invalid={Boolean(required && !value.trim())}
          value={value}
          onFocus={onSelect}
          onChange={event => onChange(event.target.value)}
          className={`h-8 min-w-0 flex-1 rounded border px-2 font-montserrat text-[13px] text-[#10233A] outline-none transition-colors focus:border-[#007EA7] ${required && !value.trim() ? 'border-[#E65050] bg-[#FFF0F0]' : 'border-[#D3E1EC] bg-white'}`}
        />
      </div>
    </div>
  );
}

function DocumentAnnotation({
  fieldKey,
  activeField,
  plain = false,
  mapping,
  children,
}: {
  fieldKey: keyof WorkspaceFields;
  activeField: string;
  onSelect: (key: string) => void;
  plain?: boolean;
  mapping?: DocumentTextMapping;
  children: React.ReactNode;
}) {
  const value = documentTextValue(children);
  const sourceId = `field:${fieldKey}`;
  if (plain) return <span className="cursor-text" data-ocr-id={sourceId} data-ocr-value={value}><HighlightedDocumentText value={value} mapping={mapping} /></span>;
  const meta = FIELD_META[fieldKey];
  const active = activeField === fieldKey;
  return (
    <span
      className={`relative inline-flex cursor-text items-center rounded px-1 py-0.5 text-left transition-all ${active ? 'z-20 scale-[1.04] shadow-[0_0_0_3px_#007EA7,0_0_0_6px_rgba(255,255,255,0.9)]' : ''}`}
      style={{ backgroundColor: meta.soft }}
    >
      <span data-ocr-id={sourceId} data-ocr-value={value}><HighlightedDocumentText value={value} mapping={mapping} /></span>
      <span className="absolute -right-2.5 -top-2.5 flex h-5 min-w-5 items-center justify-center rounded-full px-1 font-montserrat text-[9px] font-bold text-white" style={{ backgroundColor: meta.color }}>
        {meta.number}
      </span>
    </span>
  );
}

function MappedProductField({
  product,
  index,
  fieldKey,
  active,
  onSelect,
  onChange,
  label,
  required: configuredRequired,
}: {
  product: ProductLine;
  index: number;
  fieldKey: ProductFieldKey;
  active: boolean;
  onSelect: () => void;
  onChange: (value: string) => void;
  label?: string;
  required?: boolean;
}) {
  const meta = PRODUCT_FIELD_META[fieldKey];
  const required = configuredRequired ?? (fieldKey === 'name' || fieldKey === 'price');
  return (
    <label
      className={`block overflow-hidden rounded-lg border bg-white transition-all ${active ? 'shadow-[0_0_0_2px_rgba(0,126,167,0.16)]' : ''}`}
      style={{ borderColor: active ? '#007EA7' : '#D3E1EC' }}
      onClick={onSelect}
    >
      <span className="flex h-7 items-center justify-between bg-[#F2F7FC] px-2.5">
        <span className="font-montserrat text-[11px] font-semibold text-[#10233A]">
          {label || meta.label}{required && <span className="ml-1 text-[#D64545]">*</span>}
        </span>
        <span aria-label={`${uiText('Original document mapping')} ${index + 1}`} data-ocr-source-mapping className="flex h-5 min-w-5 items-center justify-center rounded-full px-1 font-montserrat text-[10px] font-bold text-white" style={{ backgroundColor: meta.color }}>
          {index + 1}
        </span>
      </span>
      {fieldKey === 'description' ? (
        <textarea
          aria-label={`Product ${index + 1} description`}
          value={product.description}
          rows={2}
          onFocus={onSelect}
          onChange={event => onChange(event.target.value)}
          className="min-h-[54px] w-full resize-none border-0 bg-white px-2.5 py-2 font-montserrat text-[12px] leading-4 text-[#10233A] outline-none"
        />
      ) : (
        <input
          aria-label={`Product ${index + 1} ${fieldKey === 'price' ? 'price' : fieldKey}`}
          value={product[fieldKey]}
          inputMode={fieldKey === 'price' || fieldKey === 'quantity' ? 'decimal' : undefined}
          onFocus={onSelect}
          onChange={event => onChange(event.target.value)}
          className="h-9 w-full border-0 bg-white px-2.5 font-montserrat text-[12px] text-[#10233A] outline-none"
        />
      )}
    </label>
  );
}

function ProductDocumentAnnotation({
  productId,
  fieldKey,
  index,
  activeProductField,
  plain = false,
  mapping,
  children,
}: {
  productId: string;
  fieldKey: ProductFieldKey;
  index: number;
  activeProductField: string;
  onSelect: (key: string) => void;
  plain?: boolean;
  mapping?: DocumentTextMapping;
  children: React.ReactNode;
}) {
  const value = documentTextValue(children) || '—';
  const sourceId = `product:${productId}:${fieldKey}`;
  if (plain) return <span className="cursor-text" data-ocr-id={sourceId} data-ocr-value={value}><HighlightedDocumentText value={value} mapping={mapping} /></span>;
  const meta = PRODUCT_FIELD_META[fieldKey];
  const key = `${productId}:${fieldKey}`;
  const active = activeProductField === key;
  return (
    <span
      className={`relative inline-flex max-w-full cursor-text items-center rounded px-1 py-0.5 text-left transition-all ${active ? 'z-10 shadow-[0_0_0_2px_#007EA7]' : ''}`}
      style={{ backgroundColor: meta.soft }}
    >
      <span className="truncate" data-ocr-id={sourceId} data-ocr-value={value}><HighlightedDocumentText value={value} mapping={mapping} /></span>
      <span className="absolute -right-2.5 -top-2.5 flex h-5 min-w-5 items-center justify-center rounded-full px-1 font-montserrat text-[9px] font-bold text-white" style={{ backgroundColor: meta.color }}>
        {index + 1}
      </span>
    </span>
  );
}

function InvoicePreview({
  fields,
  products,
  activeField,
  activeProductField,
  onSelectField,
  onSelectProductField,
  trainingMode = false,
  onAreaExtract,
  onTextExtract,
  documentMappings = {},
}: {
  fields: WorkspaceFields;
  products: ProductLine[];
  activeField: string;
  activeProductField: string;
  onSelectField: (key: string) => void;
  onSelectProductField: (key: string) => void;
  trainingMode?: boolean;
  onAreaExtract?: () => void;
  onTextExtract?: (value: string, sourceId: string) => void;
  documentMappings?: Record<string, DocumentTextMapping>;
}) {
  const articleRef = useRef<HTMLElement>(null);
  const viewportRef = useRef<HTMLDivElement>(null);
  const [available, setAvailable] = useState({ width: 680, height: 900 });
  const [size, setSize] = useState({ width: 680, height: 900 });
  const [zoom, setZoom] = useState(1);
  const [fit, setFit] = useState<PreviewFit>('width');
  const [rotation, setRotation] = useState(0);
  const [expanded, setExpanded] = useState(false);
  const [selection, setSelection] = useState<{ startX: number; startY: number; x: number; y: number } | null>(null);
  const layout = documentPreviewLayout(size, available, rotation, fit, zoom);
  const scale = layout.scale;
  useEffect(() => {
    const viewport = viewportRef.current, article = articleRef.current;
    if (!viewport || !article) return;
    const measure = () => {
      setAvailable({ width: viewport.clientWidth, height: viewport.clientHeight });
      setSize({ width: article.offsetWidth, height: article.offsetHeight });
    };
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(viewport); observer.observe(article);
    return () => observer.disconnect();
  }, []);
  useEffect(() => {
    if (!expanded) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && !(event.target instanceof Element && event.target.closest('[role="dialog"]'))) {
        event.preventDefault(); event.stopPropagation(); setExpanded(false);
      }
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [expanded]);

  const pointerPosition = (event: React.PointerEvent<HTMLElement>) => {
    const bounds = articleRef.current?.getBoundingClientRect();
    if (!bounds) return { x: 0, y: 0 };
    return documentPreviewPoint(event.clientX - bounds.left, event.clientY - bounds.top, size, scale, rotation);
  };

  const wordAtPoint = (targetElement: HTMLElement | null, clientX: number, clientY: number) => {
    const valueElement = targetElement?.closest<HTMLElement>('[data-ocr-id]');
    const sourceValue = valueElement?.dataset.ocrValue?.trim();
    if (!valueElement || !sourceValue) return '';
    const bounds = valueElement.getBoundingClientRect();
    const rawRatio = rotation === 90 ? (clientY - bounds.top) / bounds.height
      : rotation === 270 ? (bounds.bottom - clientY) / bounds.height
      : rotation === 180 ? (bounds.right - clientX) / bounds.width : (clientX - bounds.left) / bounds.width;
    const ratio = Number.isFinite(rawRatio) ? Math.min(0.999, Math.max(0, rawRatio)) : 0;
    const characterIndex = Math.floor(ratio * sourceValue.length);
    const words = Array.from(sourceValue.matchAll(/\S+/g));
    const selectedWord = words.find(match => {
      const start = match.index ?? 0;
      return characterIndex >= start && characterIndex < start + match[0].length;
    }) ?? words.reduce((nearest, match) => {
      if (!nearest) return match;
      const nearestDistance = Math.abs((nearest.index ?? 0) - characterIndex);
      const currentDistance = Math.abs((match.index ?? 0) - characterIndex);
      return currentDistance < nearestDistance ? match : nearest;
    }, words[0]);
    return selectedWord?.[0] ?? sourceValue;
  };

  const copyNativeSelection = (target: EventTarget | null, fallbackClientX?: number, fallbackClientY = 0) => {
    window.setTimeout(() => {
      const browserSelection = window.getSelection();
      const selectedText = browserSelection?.toString().replace(/\s+/g, ' ').trim();
      const targetElement = target instanceof HTMLElement ? target : null;
      const anchorElement = browserSelection?.anchorNode instanceof HTMLElement
        ? browserSelection.anchorNode
        : browserSelection?.anchorNode?.parentElement;
      const valueElement = targetElement?.closest<HTMLElement>('[data-ocr-id]')
        ?? anchorElement?.closest<HTMLElement>('[data-ocr-id]');
      const sourceId = valueElement?.dataset.ocrId;
      const sourceValue = valueElement?.dataset.ocrValue?.trim();
      const fallbackWord = fallbackClientX === undefined ? '' : wordAtPoint(targetElement, fallbackClientX, fallbackClientY);
      const extractedText = selectedText || fallbackWord;
      if (!extractedText) return;
      const mappedText = sourceValue && extractedText.toLocaleLowerCase().includes(sourceValue.toLocaleLowerCase())
        ? sourceValue
        : extractedText;
      if (sourceId) onTextExtract?.(mappedText, sourceId);
    }, 0);
  };

  return (
    <div className={`${expanded ? 'fixed inset-4 z-[5000] rounded-xl border border-[#D3E1EC] shadow-xl' : 'relative h-full min-h-0'} flex flex-col overflow-hidden bg-[#F0F7FA]`}>
      <div className="shrink-0 border-b border-[#D3E1EC] bg-white p-2"><DocumentPreviewControls scale={scale} expanded={expanded} onZoom={value => { setZoom(clampPreviewZoom(value)); setFit('manual'); }} onFit={setFit} onRotate={direction => setRotation(value => rotatePreview(value, direction))} onExpand={() => setExpanded(value => !value)} /></div>
      <div ref={viewportRef} tabIndex={0} aria-label={uiText("Scrollable document preview")} data-preview-viewport data-preview-zoom={scale} data-preview-rotation={rotation} className="min-h-0 flex-1 overflow-auto overscroll-contain p-4">
      <div className="relative mx-auto" style={{ width: layout.width, height: layout.height }}>
      <article
        ref={articleRef}
        className={`absolute left-1/2 top-1/2 min-h-[900px] w-[680px] bg-white px-14 py-12 text-[#222222] shadow-sm selection:bg-[#BFDFFF] selection:text-[#10233A] ${trainingMode ? 'cursor-crosshair' : ''}`}
        style={{ transform: `translate(-50%, -50%) rotate(${rotation}deg) scale(${scale})` }}
        aria-label={trainingMode ? uiText('Invoice document training canvas') : uiText('Uploaded invoice with OCR annotations')}
        onPointerDown={trainingMode ? event => {
          if (event.detail > 1) return;
          const textTarget = event.target instanceof HTMLElement
            ? event.target.closest('[data-ocr-id]')
            : null;
          if (textTarget) return;
          const point = pointerPosition(event);
          event.currentTarget.setPointerCapture(event.pointerId);
          setSelection({ startX: point.x, startY: point.y, x: point.x, y: point.y });
        } : undefined}
        onPointerMove={trainingMode ? event => {
          if (!selection) return;
          const point = pointerPosition(event);
          setSelection(current => current ? { ...current, x: point.x, y: point.y } : current);
        } : undefined}
        onPointerUp={trainingMode ? event => {
          if (!selection) return;
          const point = pointerPosition(event);
          const width = Math.abs(point.x - selection.startX);
          const height = Math.abs(point.y - selection.startY);
          setSelection(null);
          if (width >= 8 && height >= 8) onAreaExtract?.();
        } : undefined}
        onMouseUp={event => copyNativeSelection(event.target)}
        onDoubleClick={event => copyNativeSelection(event.target, event.clientX, event.clientY)}
      >
        {trainingMode && selection && (
          <div
            aria-label={uiText("Selected document area")}
            className="pointer-events-none absolute z-30 border-2 border-dashed border-[#007EA7] bg-[#007EA7]/10"
            style={{
              left: Math.min(selection.startX, selection.x),
              top: Math.min(selection.startY, selection.y),
              width: Math.abs(selection.x - selection.startX),
              height: Math.abs(selection.y - selection.startY),
            }}
          />
        )}
        <div className="flex justify-end font-montserrat text-[10px]">
          <span>I.N.: </span>
          <DocumentAnnotation plain={trainingMode} fieldKey="invoiceNumber" activeField={activeField} onSelect={onSelectField} mapping={documentMappings['field:invoiceNumber']}>{fields.invoiceNumber}</DocumentAnnotation>
        </div>
        <div className="mt-8 flex items-start justify-between">
          <div>
            <h2 className="font-montserrat text-[34px] font-medium tracking-wide">{uiText("INVOICE")}</h2>
            <div className="mt-6 flex gap-7 font-montserrat text-[10px]">
              <div><p className="mb-1 font-semibold uppercase text-[#7288A3]">{uiText("Date of issue")}</p><DocumentAnnotation plain={trainingMode} fieldKey="invoiceDate" activeField={activeField} onSelect={onSelectField} mapping={documentMappings['field:invoiceDate']}>{fields.invoiceDate}</DocumentAnnotation></div>
              <div><p className="mb-1 font-semibold uppercase text-[#7288A3]">{uiText("Due date")}</p><DocumentAnnotation plain={trainingMode} fieldKey="dueDate" activeField={activeField} onSelect={onSelectField} mapping={documentMappings['field:dueDate']}>{fields.dueDate}</DocumentAnnotation></div>
            </div>
          </div>
          <div className="flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-[#28B7D8] via-[#007EA7] to-[#63B342] text-[18px] font-bold text-white shadow-md">{uiText("FH")}</div>
        </div>
        <div className="mt-7 grid grid-cols-2 gap-12 font-montserrat text-[10px] leading-5">
          <div>
            <p className="font-semibold uppercase text-[#7288A3]">{uiText("Billed to")}</p>
            <p><DocumentAnnotation plain={trainingMode} fieldKey="companyName" activeField={activeField} onSelect={onSelectField} mapping={documentMappings['field:companyName']}>{fields.companyName}</DocumentAnnotation></p>
            <p><DocumentAnnotation plain={trainingMode} fieldKey="streetAddress" activeField={activeField} onSelect={onSelectField} mapping={documentMappings['field:streetAddress']}>{fields.streetAddress}</DocumentAnnotation></p>
            <p><DocumentAnnotation plain={trainingMode} fieldKey="city" activeField={activeField} onSelect={onSelectField} mapping={documentMappings['field:city']}>{fields.city}</DocumentAnnotation>{' '}<DocumentAnnotation plain={trainingMode} fieldKey="zipCode" activeField={activeField} onSelect={onSelectField} mapping={documentMappings['field:zipCode']}>{fields.zipCode}</DocumentAnnotation></p>
          </div>
          <div>
            <p className="text-[14px] font-medium">{uiText("Chicago Park City Group")}</p><p>{uiText("9 Birchwood Alley")}</p><p>{uiText("Chicago, 964785")}</p>
            <p><DocumentAnnotation plain={trainingMode} fieldKey="phoneNumber" activeField={activeField} onSelect={onSelectField} mapping={documentMappings['field:phoneNumber']}>{fields.phoneNumber}</DocumentAnnotation></p>
            <p><DocumentAnnotation plain={trainingMode} fieldKey="email" activeField={activeField} onSelect={onSelectField} mapping={documentMappings['field:email']}>{fields.email}</DocumentAnnotation></p><p>{uiText("https://parkcity.com")}</p>
          </div>
        </div>
        <div className="mt-10 font-montserrat text-[10px]">
          <div className="grid grid-cols-[1fr_92px_70px_82px] border-b-2 border-black pb-1 font-semibold uppercase text-[#7288A3]"><span>{uiText("Description")}</span><span>{uiText("Unit cost")}</span><span>{uiText("Qty")}</span><span className="text-right">{uiText("Amount")}</span></div>
          {products.slice(0, 3).map((product, index) => (
            <div key={product.id} className="grid min-h-[62px] grid-cols-[1fr_92px_70px_82px] items-start border-b border-[#333333] py-2.5">
              <div className="flex min-w-0 flex-col items-start gap-1 pr-5">
                <ProductDocumentAnnotation plain={trainingMode} productId={product.id} fieldKey="name" index={index} activeProductField={activeProductField} onSelect={onSelectProductField} mapping={documentMappings[`product:${product.id}:name`]}>{product.name}</ProductDocumentAnnotation>
                <ProductDocumentAnnotation plain={trainingMode} productId={product.id} fieldKey="description" index={index} activeProductField={activeProductField} onSelect={onSelectProductField} mapping={documentMappings[`product:${product.id}:description`]}>{product.description}</ProductDocumentAnnotation>
              </div>
              <div><ProductDocumentAnnotation plain={trainingMode} productId={product.id} fieldKey="price" index={index} activeProductField={activeProductField} onSelect={onSelectProductField} mapping={documentMappings[`product:${product.id}:price`]}>${product.price}</ProductDocumentAnnotation></div>
              <div><ProductDocumentAnnotation plain={trainingMode} productId={product.id} fieldKey="quantity" index={index} activeProductField={activeProductField} onSelect={onSelectProductField} mapping={documentMappings[`product:${product.id}:quantity`]}>{product.quantity}</ProductDocumentAnnotation></div>
              <span className="text-right">${(Number(product.quantity || 0) * Number(product.price || 0)).toFixed(2)}</span>
            </div>
          ))}
          {[1, 2, 3].map(line => <div key={line} className="h-8 border-b border-[#A1B6C6]" />)}
        </div>
        <div className="mt-8 grid grid-cols-[1fr_180px] gap-8 font-montserrat">
          <div><p className="text-[9px] font-semibold uppercase text-[#7288A3]">{uiText("Invoice total")}</p><p className="text-[27px]">$ {fields.totalAmount}</p></div>
          <div className="space-y-2 text-[9px]">
            <div className="flex justify-between"><strong>{uiText("SUBTOTAL")}</strong><span>$ 3489.00</span></div>
            <div className="flex justify-between"><strong>{uiText("DISCOUNT RATE")}</strong><DocumentAnnotation plain={trainingMode} fieldKey="discountRate" activeField={activeField} onSelect={onSelectField} mapping={documentMappings['field:discountRate']}>{fields.discountRate}%</DocumentAnnotation></div>
            <div className="flex justify-between"><strong>{uiText("DISCOUNT")}</strong><DocumentAnnotation plain={trainingMode} fieldKey="totalDiscount" activeField={activeField} onSelect={onSelectField} mapping={documentMappings['field:totalDiscount']}>$ {fields.totalDiscount}</DocumentAnnotation></div>
            <div className="flex justify-between"><strong>{uiText("TAX RATE")}</strong><DocumentAnnotation plain={trainingMode} fieldKey="taxRate" activeField={activeField} onSelect={onSelectField} mapping={documentMappings['field:taxRate']}>{fields.taxRate}%</DocumentAnnotation></div>
            <div className="flex justify-between border-t border-[#D3E1EC] pt-2 text-[11px]"><strong>{uiText("TOTAL")}</strong><DocumentAnnotation plain={trainingMode} fieldKey="totalAmount" activeField={activeField} onSelect={onSelectField} mapping={documentMappings['field:totalAmount']}>$ {fields.totalAmount}</DocumentAnnotation></div>
          </div>
        </div>
        <div className="mt-10 font-montserrat text-[9px]"><strong className="block uppercase text-[#7288A3]">{uiText("Terms")}</strong>{uiText("Please pay within 30 days. Products have 5-year warranty.")}</div>
      </article>
      </div>
      </div>
    </div>
  );
}

function WorkspaceTaskDetail({
  task,
  onBack,
  onUpdate,
  sequentialMode = false,
  queuePosition = 1,
  queueTotal = 1,
  onContinue,
  onComplete,
  trainingMode = false,
  onNextFile,
  workElapsedSeconds,
  readOnly = false,
  sourceUrl,
  viewNotice,
  validationDocument,
  reportedIssue,
  onSaveIssue,
  teamLead = false,
  onSplit,
  onMerge,
  exportFormat,
}: {
  task: WorkspaceTask;
  exportFormat?: string;
  onBack: () => void;
  onUpdate: (task: WorkspaceTask, returnToList?: boolean) => void | Promise<void>;
  sequentialMode?: boolean;
  queuePosition?: number;
  queueTotal?: number;
  onContinue?: (task: WorkspaceTask) => void;
  onComplete: (task: WorkspaceTask) => void | Promise<void>;
  trainingMode?: boolean;
  onNextFile?: (task: WorkspaceTask) => void | Promise<void>;
  workElapsedSeconds?: number;
  readOnly?: boolean;
  sourceUrl?: string;
  viewNotice?: string;
  validationDocument?: DbDocument;
  reportedIssue?: DocumentIssue;
  onSaveIssue?: (task: WorkspaceTask, finish: boolean, note: string) => Promise<void>;
  teamLead?: boolean;
  onSplit?: (task: WorkspaceTask, groups: PdfPageGroup[], requestId: string) => Promise<void>;
  onMerge?: (task: WorkspaceTask, sources: PdfMergeSource[], pages: PdfMergePage[], filename: string, requestId: string) => Promise<void>;
}) {
  const [draft, setDraft] = useState<WorkspaceTask>(task);
  const savedCorrections = useRef(ocrCorrectionSnapshot(task));
  const dirtyCorrections = useRef(false);
  dirtyCorrections.current = !readOnly && ocrCorrectionSnapshot(draft) !== savedCorrections.current;
  const confirmDiscard = () => !dirtyCorrections.current || window.confirm(uiText('You have unsaved corrections. Continuing may discard them. Continue without saving?'));
  const guardedBack = () => { if (confirmDiscard()) onBack(); };
  useEffect(() => {
    const unload = (event: BeforeUnloadEvent) => {
      if (!dirtyCorrections.current) return;
      event.preventDefault(); event.returnValue = '';
    };
    const navigate = (event: Event) => { if (!confirmDiscard()) event.preventDefault(); };
    window.addEventListener('beforeunload', unload);
    window.addEventListener(OCR_BEFORE_NAVIGATE, navigate);
    return () => { window.removeEventListener('beforeunload', unload); window.removeEventListener(OCR_BEFORE_NAVIGATE, navigate); };
  }, []);
  const workspaceRef = useRef<HTMLDivElement>(null);
  const panelsRef = useRef<HTMLDivElement>(null);
  const layoutKey = ocrEditorLayoutKey(getCurrentUserIdentity().email);
  const [previewWidth, setPreviewWidth] = useState(() => loadOcrPreviewWidth(localStorage, layoutKey));
  const previewWidthRef = useRef(previewWidth);
  const [resizingPanels, setResizingPanels] = useState(false);
  const resizePanels = (value: number, save = false) => {
    const next = clampOcrPreviewWidth(value);
    previewWidthRef.current = next;
    setPreviewWidth(next);
    if (save) {
      try { localStorage.setItem(layoutKey, String(next)); } catch { /* Layout remains usable without storage. */ }
    }
  };
  const [workspaceExpanded, setWorkspaceExpanded] = useState(false);
  useWorkspaceExpansion(workspaceExpanded, workspaceRef.current, setWorkspaceExpanded);
  const [, refreshValidation] = useState(0);
  useEffect(() => {
    const refresh = () => refreshValidation(value => value + 1);
    window.addEventListener(OCR_FIELD_VALIDATION_CHANGED_EVENT, refresh);
    window.addEventListener(OCR_AUTOMATION_CHANGED, refresh);
    window.addEventListener('organization-reference-updated', refresh);
    window.addEventListener('finansu-harmonija:settings-data-changed', refresh);
    window.addEventListener('storage', refresh);
    return () => {
      window.removeEventListener(OCR_FIELD_VALIDATION_CHANGED_EVENT, refresh);
      window.removeEventListener(OCR_AUTOMATION_CHANGED, refresh);
      window.removeEventListener('organization-reference-updated', refresh);
      window.removeEventListener('finansu-harmonija:settings-data-changed', refresh);
      window.removeEventListener('storage', refresh);
    };
  }, []);
  const [handoffAction, setHandoffAction] = useState<WorkerHandoffAction | null>(null);
  const [showSplitDialog, setShowSplitDialog] = useState(false);
  const [showMergeDialog, setShowMergeDialog] = useState(false), [fileMenuOpen, setFileMenuOpen] = useState(false);
  const fileMenuRef = useRef<HTMLDivElement>(null);
  useDropdownDismiss(fileMenuOpen, fileMenuRef, () => setFileMenuOpen(false));
  const canSendToTeamLead = trainingMode && !teamLead && !readOnly && !reportedIssue && draft.teamLeadReview?.status !== 'Pending' && validationDocument?.status.toLowerCase() === 'worker review';
  const canReturnDocument = canSendToTeamLead && validationDocument?.status.toLowerCase() === 'worker review';
  const typeCatalog = loadOrganizationReferenceRecords('Document type');
  const documentTypeOptions = documentTypeCatalogOptions(typeCatalog);
  const documentTypeValue = documentTypeCatalogSelection({ document_type: draft.documentType }, typeCatalog);
  const originalDocumentRef = useRef({
    taskId: task.id,
    fields: { ...(task.originalFields ?? task.fields) },
    products: (task.originalProducts ?? task.products).map(product => ({ ...product })),
  });
  if (originalDocumentRef.current.taskId !== task.id) {
    originalDocumentRef.current = {
      taskId: task.id,
      fields: { ...(task.originalFields ?? task.fields) },
      products: (task.originalProducts ?? task.products).map(product => ({ ...product })),
    };
  }
  const [activeTab, setActiveTab] = useState<TaskTab>('extracted');
  const [chatVisited, setChatVisited] = useState(false);
  const [correctionNote, setCorrectionNote] = useState('');
  const [issueSaveError, setIssueSaveError] = useState('');
  const [showValidation, setShowValidation] = useState(true);
  const [savedMessage, setSavedMessage] = useState('');
  const [saving, setSaving] = useState(false);
  const issueSavingRef = useRef(false);
  const vatOptions = loadVatClassifications().filter(item => item.active).map(item => ({ value: item.code, label: `${item.code} — ${item.description}` }));
  if (draft.accounting?.vatClassifier && !vatOptions.some(item => item.value === draft.accounting?.vatClassifier)) {
    vatOptions.unshift({ value: draft.accounting.vatClassifier, label: draft.accounting.vatClassifier });
  }
  const [activeField, setActiveField] = useState<keyof WorkspaceFields | ''>(trainingMode ? '' : 'invoiceNumber');
  const [activeProductField, setActiveProductField] = useState('');
  const [remainingTime, setRemainingTime] = useState(() => {
    if (!task.editStartedAt) return task.remainingTimeSeconds ?? CORRECTION_TIME_SECONDS;
    const elapsed = Math.floor((Date.now() - new Date(task.editStartedAt).getTime()) / 1000);
    return Math.max(0, CORRECTION_TIME_SECONDS - elapsed);
  });
  const [timerRunning, setTimerRunning] = useState(!readOnly && !trainingMode && task.status !== 'Completed');

  useEffect(() => {
    setDraft(task);
    savedCorrections.current = ocrCorrectionSnapshot(task);
    dirtyCorrections.current = false;
    const elapsed = task.editStartedAt
      ? Math.floor((Date.now() - new Date(task.editStartedAt).getTime()) / 1000)
      : 0;
    setRemainingTime(Math.max(0, task.editStartedAt ? CORRECTION_TIME_SECONDS - elapsed : task.remainingTimeSeconds ?? CORRECTION_TIME_SECONDS));
    setTimerRunning(!readOnly && !trainingMode && task.status !== 'Completed');
  }, [task, trainingMode, readOnly]);

  useEffect(() => {
    if (!timerRunning) return;
    const startedAt = task.editStartedAt ? new Date(task.editStartedAt).getTime() : Date.now();
    const timer = window.setInterval(() => {
      const elapsed = Math.floor((Date.now() - startedAt) / 1000);
      const nextRemaining = Math.max(0, CORRECTION_TIME_SECONDS - elapsed);
      setRemainingTime(nextRemaining);
      if (nextRemaining === 0) setTimerRunning(false);
    }, 1000);
    return () => window.clearInterval(timer);
  }, [task.editStartedAt, timerRunning]);

  const formattedRemainingTime = `${String(Math.floor(remainingTime / 60)).padStart(2, '0')}:${String(remainingTime % 60).padStart(2, '0')}`;

  const basicMissingFields = REQUIRED_LABELS
    .filter(([key]) => !draft.fields[key].trim())
    .map(([, label]) => label);
  const completionDocument = validationDocument && { ...validationDocument, ...ocrCompletionPatch(draft, typeCatalog, validationDocument) };
  const completionRules = loadOcrFieldValidationRules({ documentTypes: ocrRoutingTypeCodes(completionDocument || { document_type: draft.documentType }, typeCatalog) });
  let automationWarnings: AutomationResult['warnings'] = [];
  if (completionDocument && trainingMode && !readOnly) {
    try {
      automationWarnings = evaluateOcrDocumentAutomation(completionDocument, completionRules,
        ocrRoutingTypeCodes(completionDocument, typeCatalog), automationRulesForDocumentTypes(loadAutomationStore(true).rules, typeCatalog)).warnings;
    } catch {
      automationWarnings = [{ ruleId: 'invalid-rule-store', fieldKey: '', message: 'Document rules could not be read. Ask an administrator to review the rule configuration.' }];
    }
  }
  const invalidDocumentType = !draft.documentType.trim() || Boolean(completionDocument && !isRecognizedOcrDocumentType(completionDocument, typeCatalog));
  const missingFields = [...new Set([...(completionDocument ? missingOcrRequiredFields(completionDocument, completionRules) : basicMissingFields),
    ...(completionDocument && requiresDocumentStructureReview(completionDocument) ? ['Review all pages: select Single document or request Split documents'] : []),
    ...(invalidDocumentType ? ['Document type'] : [])])];
  const missingProducts = !completionDocument && draft.products.some(product => !product.name.trim() || !product.price.trim());
  const canComplete = draft.status === 'In Progress' && missingFields.length === 0 && !missingProducts && !automationWarnings.length;
  const navigateValidation = (label?: string) => {
    setActiveTab('extracted');
    requestAnimationFrame(() => {
      const root = panelsRef.current;
      if (!root) return;
      if (label) focusOcrValidationTarget(root, label);
      else {
        const preview = root.querySelector<HTMLElement>('[data-preview-viewport]');
        preview?.focus({ preventScroll: true });
        preview?.scrollIntoView({ block: 'center', behavior: 'smooth' });
      }
    });
  };

  const selectedConfiguredControl = useRef<OcrConfiguredControl | null>(null);
  useEffect(() => { selectedConfiguredControl.current = null; }, [task.id]);
  const selectMappedField = (key: keyof WorkspaceFields) => {
    setActiveField(key);
    setActiveProductField('');
  };

  const selectProductField = (key: string) => {
    setActiveProductField(key);
    setActiveField('');
  };

  const acceptTask = () => {
    const next = { ...draft, status: 'In Progress' as TaskStatus };
    setDraft(next);
    onUpdate(next);
    setSavedMessage('Task accepted. You can now update and complete it.');
  };

  const saveHumanCorrection = () => {
    if (trainingMode) {
      onUpdate(draft);
      setSavedMessage('Document training mappings saved successfully.');
      return;
    }
    const savedAt = new Date().toISOString();
    const next: WorkspaceTask = {
      ...draft,
      status: 'In Progress',
      humanCorrected: true,
      correctionCount: (draft.correctionCount ?? 0) + 1,
      lastCorrectedAt: savedAt,
      remainingTimeSeconds: remainingTime,
      correctionDurationSeconds: CORRECTION_TIME_SECONDS - remainingTime,
    };
    setDraft(next);
    recordWorkspaceHumanCorrection(next.id, next.sourceRunId);
    if (sequentialMode && onContinue) {
      onContinue(next);
      return;
    }
    onUpdate(next);
    setSavedMessage(`OCR corrections saved. Human processed documents for ${next.sourceRunId} were updated.`);
  };

  const saveDraftInPlace = async () => {
    if (saving || readOnly) return;
    setSaving(true);
    const next: WorkspaceTask = { ...draft, status: 'In Progress', trainingStatus: undefined,
      editStartedAt: draft.editStartedAt || new Date().toISOString() };
    try {
      await onUpdate(next, false);
      savedCorrections.current = ocrCorrectionSnapshot(next);
      dirtyCorrections.current = false;
      setDraft(next);
      setSavedMessage(uiText('Changes saved.'));
    } catch (error) {
      setSavedMessage(error instanceof Error ? error.message : uiText('Unable to save corrections.'));
    } finally { setSaving(false); }
  };

  const saveAndOpenNextFile = async () => {
    if (!trainingMode || saving) return;
    if (missingFields.length > 0 || missingProducts || automationWarnings.length > 0) {
      setShowValidation(true);
      setSavedMessage('Complete the missing required fields and document lines before confirming this document.');
      return;
    }
    const confirmedAt = new Date().toISOString();
    const confirmed: WorkspaceTask = {
      ...draft,
      status: 'Completed',
      humanCorrected: true,
      correctionCount: (draft.correctionCount ?? 0) + 1,
      lastCorrectedAt: confirmedAt,
      trainingStatus: 'Confirmed',
      trainingConfirmedAt: confirmedAt,
    };
    setSaving(true);
    try {
      if (onNextFile) await onNextFile(confirmed);
      else {
        await onUpdate(confirmed);
        onBack();
      }
    } catch (error) {
      setSavedMessage(error instanceof Error ? error.message : 'The document or its learning history could not be saved. Your corrections remain here; please try again.');
    } finally { setSaving(false); }
  };

  const runDocumentOcr = async () => {
    if (!confirmDiscard()) return;
    const next: WorkspaceTask = {
      ...draft,
      status: 'In Progress',
      trainingStatus: undefined,
      trainingConfirmedAt: undefined,
      ocrRunRequest: {
        id: crypto.randomUUID(),
        requestedAt: new Date().toISOString(),
        status: 'Pending integration',
      },
    };
    try {
      await onUpdate(next);
      setDraft(next);
      onBack();
    } catch {
      setSavedMessage('Could not save the OCR rerun request. Your corrections remain in this form. Please try again.');
    }
  };

  const sendToTeamLead = async (values: WorkerHandoffInput) => {
    if (!canSendToTeamLead) return;
    const next = prepareWorkerHandoff(draft, handoffAction || 'escalate', values, getCurrentUserIdentity());
    if (onNextFile) await onNextFile(next);
    else {
      await onUpdate(next);
      onBack();
    }
  };

  const completeTask = () => {
    if (!canComplete) {
      setShowValidation(true);
      return;
    }
    const next = {
      ...draft,
      status: 'Completed' as TaskStatus,
      humanCorrected: true,
      correctionCount: (draft.correctionCount ?? 0) + 1,
      lastCorrectedAt: new Date().toISOString(),
      remainingTimeSeconds: remainingTime,
      correctionDurationSeconds: CORRECTION_TIME_SECONDS - remainingTime,
    };
    setTimerRunning(false);
    recordWorkspaceHumanCorrection(next.id, next.sourceRunId);
    onComplete(next);
  };

  const saveIssue = async (finish: boolean) => {
    if (issueSavingRef.current || saving || !onSaveIssue || readOnly) return;
    issueSavingRef.current = true;
    setSaving(true); setIssueSaveError('');
    try { await onSaveIssue(draft, finish, correctionNote); if (!finish) setSavedMessage(uiText('Changes saved.')); }
    catch (error) { setIssueSaveError(uiText(error instanceof Error ? error.message : 'Unable to save corrections.')); }
    finally { issueSavingRef.current = false; setSaving(false); }
  };

  const applyTrainingSelection = () => {
    if (activeField) {
      const extractedValue = EMPTY_FIELDS[activeField];
      setDraft(current => ({ ...current, fields: { ...current.fields, [activeField]: extractedValue } }));
      setSavedMessage(`Selected document area assigned to ${fieldDisplayName(activeField)}.`);
      return;
    }
    if (activeProductField) {
      const [productId, productField] = activeProductField.split(':') as [string, ProductFieldKey];
      const sourceProduct = SAMPLE_PRODUCTS.find(product => product.id === productId);
      if (sourceProduct) {
        setDraft(current => ({
          ...current,
          products: current.products.map(product => product.id === productId ? { ...product, [productField]: sourceProduct[productField] } : product),
        }));
        setSavedMessage(`Selected document area assigned to product ${productField}.`);
      }
      return;
    }
    setSavedMessage('Select a field first, then drag over its value in the document.');
  };

  const applySelectedDocumentText = (selectedText: string, sourceId: string) => {
    if (readOnly) return;
    if (selectedConfiguredControl.current) {
      const control = selectedConfiguredControl.current;
      if (control.rule.inputType === 'select' || control.rule.inputType === 'boolean') return;
      control.onChange(selectedText.trim());
      setSavedMessage(`Selected document text copied to ${uiText(control.rule.label)}.`);
      return;
    }
    if (activeField) {
      const meta = FIELD_META[activeField];
      const targetLabel = fieldDisplayName(activeField);
      setDraft(current => ({
        ...(() => {
          const existing = current.documentMappings?.[sourceId];
          const previousTexts = existing?.targetLabel === targetLabel
            ? (existing.texts?.length ? existing.texts : [existing.text])
            : [];
          const normalizedSelection = selectedText.trim();
          const alreadyIncluded = previousTexts.some(text =>
            text.toLocaleLowerCase().includes(normalizedSelection.toLocaleLowerCase()),
          );
          const nextTexts = alreadyIncluded
            ? previousTexts
            : [
                ...previousTexts.filter(text =>
                  !normalizedSelection.toLocaleLowerCase().includes(text.toLocaleLowerCase()),
                ),
                normalizedSelection,
              ];
          const combinedValue = nextTexts.join(' ').replace(/\s+/g, ' ').trim();
          const purpose = ocrDocumentPartyPurpose(completionDocument);
          const partyRule = completionRules.find(rule => rule.group === 'parties' && ocrPartyIsCounterparty(rule, purpose)
            && OCR_WORKSPACE_FIELD_KEYS[(rule.partyDataKey || rule.key) as keyof typeof OCR_WORKSPACE_FIELD_KEYS] === activeField);
          const parties = configuredOcrParties(completionRules.filter(rule => rule.group === 'parties'), current.ocrParties || completionDocument?.ocr_parties, current.id, purpose);
          const party = partyRule && parties.find(item => ocrSavedPartyId(item) === ocrRulePartyId(partyRule));
          const updated = party && partyRule ? updateOcrEditorValue(current, partyRule, combinedValue, { party, primary: true, purpose }, parties) : current;
          return {
            ...updated,
            fields: { ...current.fields, [activeField]: combinedValue },
            documentMappings: {
              ...current.documentMappings,
              [sourceId]: {
                text: combinedValue,
                texts: nextTexts,
                color: meta.color,
                softColor: meta.soft,
                targetLabel,
              },
            },
          };
        })(),
      }));
      setSavedMessage(`Selected document text copied to ${targetLabel}.`);
      return;
    }
    if (activeProductField) {
      const [productId, productField] = activeProductField.split(':') as [string, ProductFieldKey];
      const meta = PRODUCT_FIELD_META[productField];
      const targetLabel = `Product ${meta.label}`;
      setDraft(current => ({
        ...(() => {
          const existing = current.documentMappings?.[sourceId];
          const previousTexts = existing?.targetLabel === targetLabel
            ? (existing.texts?.length ? existing.texts : [existing.text])
            : [];
          const normalizedSelection = selectedText.trim();
          const alreadyIncluded = previousTexts.some(text =>
            text.toLocaleLowerCase().includes(normalizedSelection.toLocaleLowerCase()),
          );
          const nextTexts = alreadyIncluded
            ? previousTexts
            : [
                ...previousTexts.filter(text =>
                  !normalizedSelection.toLocaleLowerCase().includes(text.toLocaleLowerCase()),
                ),
                normalizedSelection,
              ];
          const combinedValue = nextTexts.join(' ').replace(/\s+/g, ' ').trim();
          return {
            ...current,
            products: current.products.map(product => product.id === productId ? { ...product, [productField]: combinedValue } : product),
            documentMappings: {
              ...current.documentMappings,
              [sourceId]: {
                text: combinedValue,
                texts: nextTexts,
                color: meta.color,
                softColor: meta.soft,
                targetLabel,
              },
            },
          };
        })(),
      }));
      setSavedMessage(`Selected document text copied to product ${PRODUCT_FIELD_META[productField].label}.`);
      return;
    }
    setSavedMessage('Select a field on the right first, then double-click text in the document.');
  };

  const renderConfiguredControl = ({ rule, scope, value, required, onChange, compact }: OcrConfiguredControl) => {
    if (scope.line) {
      const key = OCR_LINE_FIELD_KEYS[rule.key as keyof typeof OCR_LINE_FIELD_KEYS];
      if (!key || ['select', 'boolean', 'date', 'email'].includes(rule.inputType || '')) return null;
      const index = draft.products.findIndex(line => line.id === scope.line!.id);
      return <MappedProductField product={scope.line} index={index} fieldKey={key} label={uiText(rule.label)} required={required}
        active={activeProductField === `${scope.line.id}:${key}`} onSelect={() => selectProductField(`${scope.line!.id}:${key}`)} onChange={onChange} />;
    }
    if (scope.party && (!scope.primary || !ocrPartyIsCounterparty(rule, scope.purpose))) return null;
    if (rule.key === 'documentType') return <div className={`space-y-2 rounded-lg border p-3 ${invalidDocumentType ? 'border-[#E65050] bg-[#FFF0F0]' : 'border-[#D3E1EC] bg-white'}`}>
      <p className="text-[12px] font-semibold text-[#10233A]">{uiText('Document type')}<span className="ml-1 text-[#D64545]">*</span></p>
      <SearchableSelect ariaLabel={uiText('Document type')} value={documentTypeValue} options={documentTypeOptions} localizeOptions portalMenu disabled={readOnly}
        onChange={onChange} className="h-10 rounded-lg border border-[#D3E1EC] bg-white px-3 pr-9 text-[12px] text-[#10233A]" />
      {invalidDocumentType && <p role="alert" className="text-[12px] text-[#D92D20]">{uiText('Select a valid document type from the configured list.')}</p>}
    </div>;
    const mapped = OCR_WORKSPACE_FIELD_KEYS[(scope.party ? rule.partyDataKey || rule.key : rule.key) as keyof typeof OCR_WORKSPACE_FIELD_KEYS];
    if (mapped && !['select', 'boolean', 'textarea'].includes(rule.inputType || '')) return <MappedFormField fieldKey={mapped} label={uiText(rule.label)}
      labelAdornment={rule.key === 'number' ? <HandwrittenDocumentBadge document={validationDocument} /> : undefined}
      required={required} value={value} compact={compact} type={rule.inputType === 'date' || rule.inputType === 'email' ? rule.inputType : 'text'}
      active={activeField === mapped} onSelect={() => selectMappedField(mapped)} onChange={onChange} />;
    if (rule.key === 'advanceEmployee' && validationDocument?.company_id) return <div className="space-y-2"><p className="text-[12px] font-medium">{uiText(rule.label)}</p>
      <AdvanceEmployeeSelect companyId={validationDocument.company_id} value={value} label={draft.advanceEmployee || validationDocument.advance_employee} onChange={onChange} disabled={readOnly} /></div>;
    if (rule.key === 'documentPurpose') return <div className="space-y-2"><p className="text-[12px] font-medium">{uiText(rule.label)}{required && <span className="ml-1 text-[#D64545]">*</span>}</p>
      <SearchableSelect ariaLabel={uiText(rule.label)} value={value} options={documentPurposeCatalogOptions()} localizeOptions disabled={readOnly} placeholder="—" portalMenu onChange={onChange}
        className={`h-10 rounded-lg border px-3 pr-9 text-[12px] ${required && !hasOcrValue(value) ? 'border-[#E65050] bg-[#FFF0F0]' : 'border-[#D3E1EC] bg-white'}`} /></div>;
    if (rule.key === 'glAccount' && draft.accounting) return <div className="space-y-1.5"><label className="block text-[12px] font-medium">{uiText('Expense account')}</label>
      <GeneralLedgerAccountSelect value={value} companyId={draft.accounting.companyId} formField ariaLabel={uiText('Learned expense account')} onChange={onChange} />
      {draft.accounting.explanations?.expense_account && <p className="text-[11px] leading-5 text-[#7288A3]">{draft.accounting.explanations.expense_account}</p>}</div>;
    if (rule.key === 'vatClassifier') return <div className="space-y-1.5"><label className="block text-[12px] font-medium">{uiText(rule.label)}</label>
      <SearchableSelect ariaLabel={uiText('Learned VAT classifier')} value={value} options={vatOptions} placeholder={uiText('Select VAT classifier')} onChange={onChange} disabled={readOnly}
        className="h-10 rounded-lg border border-[#D3E1EC] bg-white px-3 pr-9 text-[12px] text-[#10233A]" portalMenu />
      {draft.accounting?.explanations?.vat_classifier && <p className="text-[11px] leading-5 text-[#7288A3]">{draft.accounting.explanations.vat_classifier}</p>}</div>;
    return null;
  };

  return (
    <div ref={workspaceRef} data-ocr-editor-workspace className={`ocr-document-editor flex min-h-full min-w-0 flex-col gap-6 bg-white ${readOnly ? 'px-6 py-8 lg:px-10' : 'px-[72px] py-14'}`}>
      <PageHeader
        title={workspaceExpanded ? draft.name : readOnly ? uiText('View document') : trainingMode ? uiText('Document training') : uiText('Human task')}
        leading={
          <button type="button" aria-label={trainingMode ? uiText('Back to Documents') : uiText('Back to Workspace')} onClick={guardedBack} className="text-[#7288A3] transition-colors hover:text-[#007EA7]">
            <ArrowLeft size={20} />
          </button>
        }
        actions={
          <>
            {readOnly ? <PageActionButton onClick={onBack}>{uiText("Close")}</PageActionButton> : <>
            {workElapsedSeconds !== undefined && (
              <div className="mr-2 flex h-8 items-center gap-2 rounded-md border border-[#D3E1EC] bg-[#F8FDFF] px-3 font-montserrat" title={uiText("Time spent editing this document in the current session")}>
                <Clock3 size={15} className="text-[#007EA7]" />
                <span className="text-[12px] font-medium text-[#7288A3]">{uiText("Working time")}</span>
                <span aria-label={uiText("Current document working time")} className="min-w-[58px] text-right text-[13px] font-semibold tabular-nums text-[#10233A]">
                  {`${String(Math.floor(workElapsedSeconds / 3600)).padStart(2, '0')}:${String(Math.floor((workElapsedSeconds % 3600) / 60)).padStart(2, '0')}:${String(workElapsedSeconds % 60).padStart(2, '0')}`}
                </span>
              </div>
            )}
            {!trainingMode && <div className="mr-2 flex h-8 items-center gap-2 rounded-md border border-[#D3E1EC] bg-[#F8FDFF] px-3 font-montserrat">
              <span className="text-[12px] font-medium text-[#7288A3]">{uiText("Remaining time")}</span>
              <span aria-label={uiText("Remaining correction time")} className={`min-w-[44px] text-right text-[13px] font-semibold tabular-nums ${remainingTime <= 300 ? 'text-[#D64545]' : 'text-[#10233A]'}`}>{formattedRemainingTime}</span>
            </div>}
            {!trainingMode && draft.status === 'Available' && <PageActionButton onClick={acceptTask}>{uiText("Accept task")}</PageActionButton>}
            {trainingMode && sourceUrl && <PageActionButton
              disabled={saving || !onMerge || validationDocument?.status !== 'Worker review' || documentPreviewKind(sourceUrl, draft.name) !== 'pdf'}
              onClick={() => setShowMergeDialog(true)} ariaHasPopup="dialog"
            >{uiText('Merge documents')}</PageActionButton>}
            {reportedIssue ? <>
              <PageActionButton disabled={saving || !onSaveIssue || ['Resolved', 'Awaiting OCR'].includes(reportedIssue.status)} onClick={() => void saveIssue(false)}>{uiText('Save')}</PageActionButton>
              <PageActionButton disabled={saving || !onSaveIssue || ['Resolved', 'Awaiting OCR'].includes(reportedIssue.status)} onClick={() => void saveIssue(true)}>{uiText(saving ? 'Saving…' : 'Fix issue & send to OCR')}</PageActionButton>
            </> : <>
            {trainingMode ? <PageActionButton onClick={runDocumentOcr}>{uiText("Run")}</PageActionButton> : draft.status === 'In Progress' && <PageActionButton onClick={saveHumanCorrection}>{uiText("Save")}</PageActionButton>}
            {canSendToTeamLead && <PageActionButton onClick={() => setHandoffAction('escalate')}>{uiText("Send to team lead")}</PageActionButton>}
            {canReturnDocument && <PageActionButton onClick={() => setHandoffAction('return')}>{uiText("Return document")}</PageActionButton>}
            {trainingMode && !teamLead && <PageActionButton onClick={() => void saveDraftInPlace()} disabled={saving}>{uiText('Save')}</PageActionButton>}
            {trainingMode && <PageActionButton className={!teamLead ? 'ocr-worker-primary-action' : ''} onClick={saveAndOpenNextFile} disabled={saving}>{saving ? uiText('Saving…') : onNextFile ? uiText('Save and next file') : uiText('Confirm & finish')}</PageActionButton>}
            {!trainingMode && draft.status !== 'Completed' && <PageActionButton onClick={completeTask} disabled={!canComplete}>{uiText("Complete task")}</PageActionButton>}
            </>}
            </>}
            <WorkspaceExpandButton expanded={workspaceExpanded} onClick={() => setWorkspaceExpanded(value => !value)} />
          </>
        }
      />


      <div data-system-breadcrumb className="flex flex-wrap items-center gap-2 font-montserrat text-[12px] text-[#7288A3]">
        <button type="button" onClick={guardedBack} className="hover:text-[#007EA7]">{trainingMode ? uiText('Document sets / Documents') : uiText('Workspace')}</button>
        <span>/</span>
        <span className="max-w-[680px] truncate text-[#10233A]">{draft.name}</span>
        {trainingMode && (queueTotal > 1 || readOnly) && (
          <span className="rounded-full bg-[#E5EDF9] px-2.5 py-1 font-semibold text-[#7288A3]">{uiText("File ")}{queuePosition}{uiText(" of ")}{queueTotal}</span>
        )}
        {!trainingMode && <StatusBadge status={draft.status} />}
      </div>

      {reportedIssue && <section data-ocr-editor-context aria-label={uiText('Reported issue for correction')} className="rounded-lg border border-[#B8D7E5] bg-[#F0FAFD] px-4 py-3 font-montserrat">
        <div className="flex flex-wrap items-center justify-between gap-2"><h2 className="flex items-center gap-2 text-[13px] font-semibold text-[#10233A]"><MessageSquare size={16} className="text-[#007EA7]" />{uiText('Reported issue')}</h2><p className="text-[11px] text-[#7288A3]">{reportedIssue.createdBy} · {new Date(reportedIssue.createdAt).toLocaleString()}</p></div>
        <p className="mt-2 max-h-40 overflow-y-auto whitespace-pre-wrap break-words text-[13px] leading-5 text-[#10233A]">{reportedIssue.message}</p>
        {!readOnly && <label className="mt-3 block text-xs text-[#7288A3]">{uiText('Correction note (optional)')}<textarea value={correctionNote} onChange={event => setCorrectionNote(event.target.value)} rows={2} maxLength={5000} disabled={saving} className="mt-1 w-full rounded-md border border-[#D3E1EC] bg-white p-2 text-[#10233A] outline-none focus:border-[#007EA7]" /></label>}
      </section>}
      {issueSaveError && <p role="alert" className="text-sm text-[#B42318]">{issueSaveError}</p>}
      {(draft.teamLeadReview?.comment || draft.teamLeadReview?.reason) && !reportedIssue && <section data-ocr-editor-context aria-label={uiText("Worker comment")} className="rounded-lg border border-[#B8D7E5] bg-[#F0FAFD] px-4 py-3 font-montserrat">
        <div className="flex flex-wrap items-center justify-between gap-2"><h2 className="flex items-center gap-2 text-[13px] font-semibold text-[#10233A]"><MessageSquare size={16} className="text-[#007EA7]" />{uiText("Worker comment")}</h2>
          <p className="text-[11px] text-[#7288A3]">{draft.teamLeadReview.requestedBy || draft.teamLeadReview.requestedByEmail || uiText('Worker')} · {new Date(draft.teamLeadReview.requestedAt).toLocaleString()}</p></div>
        {draft.teamLeadReview.reason && <p className="mt-2 text-[13px] font-semibold text-[#10233A]">{uiText(draft.teamLeadReview.reason)}</p>}
        {draft.teamLeadReview.comment && <p className="mt-2 max-h-40 overflow-y-auto whitespace-pre-wrap break-words text-[13px] leading-5 text-[#10233A]">{draft.teamLeadReview.comment}</p>}
      </section>}
      {readOnly && viewNotice && <p className="rounded-lg border border-[#D3E1EC] bg-[#F8FDFF] px-4 py-3 font-montserrat text-[12px] text-[#7288A3]">{viewNotice}</p>}
      {trainingMode && ((!readOnly && !reportedIssue) || automationWarnings.length > 0 || isHandwrittenDocument(validationDocument) || validationDocument?.ocr_multiple_documents || validationDocument?.ocr_poor_quality || validationDocument?.ocr_quality_review_required) && <section className="rounded-lg border border-[#B8D7E5] bg-[#F0FAFD] px-4 py-3">
        <h2 className="mb-2 text-[13px] font-semibold text-[#10233A]">{uiText('Document validation & recommendations')}</h2>
        {automationWarnings.map(warning => <p key={`${warning.ruleId}:${warning.fieldKey}`} className="mb-2 flex items-start gap-2 rounded-md border border-[#F2D58D] bg-[#FFF9E8] px-3 py-2 font-montserrat text-[12px] leading-5 text-[#805C13]">
          <AlertTriangle size={16} className="mt-0.5 shrink-0" aria-hidden="true" />
          <button type="button" onClick={() => navigateValidation(completionRules.find(field => field.key === warning.fieldKey)?.label)} className="text-left underline decoration-dotted underline-offset-2 hover:decoration-solid">
            {warning.fieldKey && <strong>{uiText(completionRules.find(field => field.key === warning.fieldKey)?.label || warning.fieldKey)}: </strong>}{warning.message.startsWith('Expected value: ') ? `${uiText('Expected value')}: ${warning.message.slice('Expected value: '.length)}` : uiText(warning.message)}
          </button>
        </p>)}
        <OcrRecognitionWarnings document={validationDocument} decision={draft.documentStructure} busy={saving} onNavigate={() => navigateValidation()} onChange={readOnly ? undefined : choice => {
          if (choice === 'split') { setShowSplitDialog(true); return; }
          setDraft(current => ({ ...current, documentStructure: { choice, at: new Date().toISOString(), actor: getCurrentUserIdentity().fullName } }));
        }}
          onSave={readOnly ? undefined : async () => { setSaving(true); try { await onUpdate(draft); setSavedMessage(uiText('Document structure decision saved.')); } catch (error) { setSavedMessage(error instanceof Error ? error.message : uiText('Could not save the document. Please try again.')); } finally { setSaving(false); } }} />
      {!readOnly && !reportedIssue && (
        <div data-ocr-editor-context className="font-montserrat">
          {missingFields.length > 0 && <div className="mt-2 text-[12px] leading-5">
            <p className="flex items-start gap-2 text-[#B42318]"><AlertCircle size={16} aria-hidden="true" className="mt-0.5 shrink-0" /><span><strong>{uiText("Issue:")}</strong>{uiText(" Required information is missing or invalid: ")}{missingFields.map((label, index) => <span key={label}>{index > 0 && ', '}<button type="button" onClick={() => navigateValidation(label)} className="rounded-sm text-left underline decoration-dotted underline-offset-2 hover:decoration-solid">{uiText(label)}</button></span>)}.</span></p>
            <p className="text-[#7288A3]"><span className="font-semibold">{uiText("Recommendation:")}</span>{' '}<button type="button" onClick={() => navigateValidation(invalidDocumentType ? 'Document type' : missingFields[0])} className="rounded-sm text-left underline decoration-dotted underline-offset-2 hover:decoration-solid">{uiText(invalidDocumentType ? 'Select a valid document type from the configured list.' : 'Compare the highlighted fields with the original and complete the missing values.')}</button></p>
          </div>}
          {missingProducts && <div className="mt-2 text-[12px] leading-5">
            <p className="flex items-start gap-2 text-[#B42318]"><AlertCircle size={16} aria-hidden="true" className="mt-0.5 shrink-0" /><span><strong>{uiText("Issue:")}</strong><button type="button" onClick={() => navigateValidation(completionRules.find(rule => rule.group === 'lines')?.label)} className="rounded-sm text-left underline decoration-dotted underline-offset-2 hover:decoration-solid">{uiText(" One or more document lines are missing a product name or price.")}</button></span></p>
            <p className="text-[#7288A3]"><span className="font-semibold">{uiText("Recommendation:")}</span>{uiText(" Compare each document line with the original and fill in the missing product name or price before saving.")}</p>
          </div>}
          {missingFields.length === 0 && !missingProducts && !automationWarnings.length && <div className="mt-2 text-[12px] leading-5 text-[#7288A3]">
            <p>{uiText("No missing required fields detected.")}</p>
            <p><span className="font-semibold">{uiText("Recommendation:")}</span>{uiText(" Compare the extracted invoice number, dates, counterparty, amounts and document lines with the original. Correct any differences and save the document.")}</p>
          </div>}
        </div>
      )}</section>}

      {sequentialMode && (
        <div className="flex items-center justify-between rounded-lg border border-[#B8D7E5] bg-[#F0FAFD] px-4 py-3 font-montserrat">
          <div>
            <p className="text-[13px] font-semibold text-[#10233A]">{uiText("OCR human correction queue")}</p>
            <p className="text-[12px] text-[#7288A3]">{uiText("After Save, the next document opens automatically.")}</p>
          </div>
          <span className="rounded-full bg-[#007EA7] px-3 py-1 text-[12px] font-semibold text-white">{queuePosition} / {queueTotal}</span>
        </div>
      )}

      {!trainingMode && showValidation && (missingFields.length > 0 || missingProducts) && (
        <div role="alert" className="rounded-lg border border-[#F0C2C2] bg-[#FFF5F5] px-4 py-3 font-montserrat text-[13px] text-[#A23B3B]">
          {missingFields.map(label => <p key={label}>{uiText("The ")}{uiText(label)}{uiText(" is required.")}</p>)}
          {missingProducts && <p>{uiText("The Product Name and Price are required.")}</p>}
        </div>
      )}
      {savedMessage && (
        <div role="status" className="flex items-center justify-between rounded-lg bg-[#EAF8F1] px-4 py-3 font-montserrat text-[13px] text-[#18794E]">
          <span>{savedMessage}</span>
          <button type="button" aria-label={uiText("Close message")} onClick={() => setSavedMessage('')}><X size={16} /></button>
        </div>
      )}

      <div ref={panelsRef} data-ocr-editor-panels style={{ '--ocr-preview-width': `${previewWidth}fr`, '--ocr-fields-width': `${100 - previewWidth}fr` } as CSSProperties}
        className="relative grid min-h-0 shrink-0 overflow-hidden rounded-xl border border-[#D3E1EC] bg-white h-[120dvh] grid-cols-1 grid-rows-[minmax(0,1fr)_minmax(0,1fr)] xl:h-[max(420px,calc(100dvh-96px))] xl:grid-cols-[minmax(0,var(--ocr-preview-width))_12px_minmax(0,var(--ocr-fields-width))] xl:grid-rows-[minmax(0,1fr)]">
        {resizingPanels && <div className="absolute inset-0 z-40 cursor-col-resize" />}
        <section className="flex min-h-0 min-w-0 flex-col overflow-hidden border-r border-[#D3E1EC]">
          {trainingMode && !readOnly && sourceUrl && <div className="flex shrink-0 items-center justify-between border-b border-[#E5EDF9] px-3 py-2 text-xs text-[#7288A3]">
            <span>{uiText('Original document')}</span><div ref={fileMenuRef} className="relative"><button type="button" aria-label={uiText('Document actions')} aria-expanded={fileMenuOpen} aria-haspopup="menu" onClick={() => setFileMenuOpen(value => !value)} className="rounded-md p-1 text-[#007EA7] hover:bg-[#EAF4F8]"><MoreHorizontal size={20} /></button>
              {fileMenuOpen && <div role="menu" className="absolute right-0 top-full z-50 min-w-[180px] rounded-lg border border-[#D3E1EC] bg-white p-1 shadow-lg">
                <button type="button" role="menuitem" disabled={!onSplit || documentPreviewKind(sourceUrl, draft.name) !== 'pdf'} onClick={() => { setFileMenuOpen(false); setShowSplitDialog(true); }} className="block w-full rounded px-3 py-2 text-left hover:bg-[#EAF4F8] disabled:opacity-40">{uiText('Split documents')}</button>
              </div>}
            </div>
          </div>}
          {sourceUrl ? <DocumentFileViewer url={sourceUrl} kind={documentPreviewKind(sourceUrl, draft.name)} filename={draft.name} embedded onTextExtract={readOnly ? undefined : applySelectedDocumentText} /> : <>
          {readOnly ? <div aria-label={uiText("Original document preview")} className="min-h-0 flex-1 overflow-auto bg-[#F2F7FC]">
            <div className="flex h-full min-h-[320px] flex-col items-center justify-center gap-3 p-8 text-center font-montserrat text-[13px] text-[#7288A3]"><FileText size={32} /><span className="font-medium text-[#10233A]">{draft.name}</span><p>{uiText("Original file is not available. Saved document data is shown on the right.")}</p></div>
          </div> : <InvoicePreview
            fields={originalDocumentRef.current.fields}
            products={originalDocumentRef.current.products}
            activeField={activeField}
            activeProductField={activeProductField}
            onSelectField={key => selectMappedField(key as keyof WorkspaceFields)}
            onSelectProductField={selectProductField}
            trainingMode={trainingMode}
            onAreaExtract={applyTrainingSelection}
            onTextExtract={applySelectedDocumentText}
            documentMappings={draft.documentMappings}
          />}
          </>}
        </section>

        <div role="separator" aria-label={uiText('Resize document and information panels')} aria-orientation="vertical"
          aria-valuemin={25} aria-valuemax={70} aria-valuenow={Math.round(previewWidth)} tabIndex={0}
          className="relative z-50 hidden touch-none cursor-col-resize items-center justify-center bg-[#F2F7FC] outline-none hover:bg-[#D3E1EC] focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-[#007EA7] xl:flex"
          onPointerDown={event => { if (event.button !== 0) return; event.preventDefault(); event.currentTarget.setPointerCapture(event.pointerId); setResizingPanels(true); }}
          onPointerMove={event => {
            if (!event.currentTarget.hasPointerCapture(event.pointerId)) return;
            const bounds = panelsRef.current?.getBoundingClientRect();
            if (bounds && bounds.width > 12) resizePanels((event.clientX - bounds.left - 6) / (bounds.width - 12) * 100);
          }}
          onPointerUp={event => { if (!event.currentTarget.hasPointerCapture(event.pointerId)) return; resizePanels(previewWidthRef.current, true); event.currentTarget.releasePointerCapture(event.pointerId); setResizingPanels(false); }}
          onPointerCancel={() => { resizePanels(previewWidthRef.current, true); setResizingPanels(false); }}
          onLostPointerCapture={() => setResizingPanels(false)}
          onKeyDown={event => {
            const next = event.key === 'ArrowLeft' ? previewWidth - 2 : event.key === 'ArrowRight' ? previewWidth + 2 : event.key === 'Home' ? 25 : event.key === 'End' ? 70 : null;
            if (next === null) return; event.preventDefault(); resizePanels(next, true);
          }}><span aria-hidden="true" className="h-12 w-1 rounded-full bg-[#7288A3]" /></div>

        <section className="flex min-h-0 min-w-0 flex-col overflow-hidden">
          <div className="flex h-14 shrink-0 items-end gap-8 border-b border-[#D3E1EC] px-6">
            <button
              type="button"
              onClick={() => setActiveTab('extracted')}
              className={`flex h-14 items-center border-b-2 font-montserrat text-[13px] font-semibold ${activeTab === 'extracted' ? 'border-[#007EA7] text-[#007EA7]' : 'border-transparent text-[#7288A3]'}`}
            >{uiText("EXTRACTED DATA")}</button>
            <button
              type="button"
              onClick={() => { setActiveTab('chat'); setChatVisited(true); }}
              className={`flex h-14 items-center gap-2 border-b-2 font-montserrat text-[13px] font-semibold ${activeTab === 'chat' ? 'border-[#007EA7] text-[#007EA7]' : 'border-transparent text-[#7288A3]'}`}
            ><MessageSquare size={15} />{uiText('Chat')}
            </button>
          </div>

          <div className={activeTab === 'extracted' ? 'flex min-h-0 flex-1 flex-col' : 'hidden'}>
            <div tabIndex={0} aria-label={uiText("Document information extraction")} className="min-h-0 flex-1 overflow-y-auto overscroll-contain p-4 xl:p-5">
              <h2 className="mb-4 font-montserrat text-[15px] font-semibold leading-5 text-[#10233A]">{uiText('Document information extraction')}</h2>
              <fieldset disabled={readOnly} className="min-w-0">
                <OcrConfiguredFields rules={completionRules.filter(rule => rule.key !== 'advanceEmployee' || Boolean(validationDocument?.company_id && isPurchaseInvoice(completionDocument as unknown as Record<string, unknown>)))}
                  key={draft.id} draft={draft} document={completionDocument} setDraft={setDraft} readOnly={readOnly} renderControl={renderConfiguredControl} exportFormat={exportFormat} onSelectControl={control => { selectedConfiguredControl.current = control; }} />
              </fieldset>
            </div>
          </div>
          {chatVisited && <div className={activeTab === 'chat' ? 'min-h-0 flex-1 overflow-auto p-4' : 'hidden'}>
            {validationDocument?.company_id ? <DocumentConversationPanel documentId={validationDocument.id} companyId={validationDocument.company_id} side="worker" initialIssueId={reportedIssue?.id} active={activeTab === 'chat'} />
              : <p className="text-sm text-[#7288A3]">{uiText('Assign an organization to open the document conversation.')}</p>}
            {!!draft.comments.length && <details className="mt-4 text-xs text-[#7288A3]"><summary>{uiText('Previous comments')}</summary>{draft.comments.map(item => <article key={item.id} className="mt-2 rounded-md bg-[#F8FDFF] p-3"><p>{item.author} · {item.createdAt}</p><p className="mt-1 whitespace-pre-wrap text-[#10233A]">{item.text}</p></article>)}</details>}
          </div>}
        </section>
      </div>
      {handoffAction && canSendToTeamLead && <SendToTeamLeadDialog action={handoffAction} documentName={draft.name} onClose={() => setHandoffAction(null)} onSend={sendToTeamLead} />}
      {showSplitDialog && !readOnly && onSplit && <OcrPdfSplitDialog url={sourceUrl || ''} filename={draft.name} onClose={() => setShowSplitDialog(false)} onSplit={(groups, requestId) => onSplit(draft, groups, requestId)} />}
      {showMergeDialog && !readOnly && onMerge && validationDocument?.company_id && <OcrPdfMergeDialog documentId={validationDocument.id} companyId={validationDocument.company_id} onClose={() => setShowMergeDialog(false)} onMerge={(sources, pages, filename, requestId) => onMerge(draft, sources, pages, filename, requestId)} />}
    </div>
  );
}

export function WorkspaceDocumentEditor({
  documentName,
  documentId,
  savedTask,
  filePosition = 1,
  fileTotal = 1,
  onBack,
  onSave,
  onNextFile,
  readOnly = false,
  companyId,
  viewNotice,
  reportedIssueId,
  onIssueFixed,
  teamLead = false,
}: {
  documentName: string;
  documentId?: string;
  savedTask?: WorkspaceTask;
  filePosition?: number;
  fileTotal?: number;
  onBack: () => void;
  onSave?: (task: WorkspaceTask) => void | Promise<void>;
  onNextFile?: () => void | Promise<void>;
  readOnly?: boolean;
  companyId?: string;
  viewNotice?: string;
  reportedIssueId?: string;
  onIssueFixed?: (document: DbDocument) => void | Promise<void>;
  teamLead?: boolean;
}) {
  const [workElapsedSeconds, setWorkElapsedSeconds] = useState(0);
  const workSegmentStartedAt = useRef(Date.now());
  const committedSeconds = useRef(0);
  const closed = useRef(false);

  useEffect(() => {
    if (readOnly) return;
    workSegmentStartedAt.current = Date.now();
    committedSeconds.current = 0;
    closed.current = false;
    setWorkElapsedSeconds(0);
    const timer = window.setInterval(() => {
      setWorkElapsedSeconds(committedSeconds.current + Math.floor((Date.now() - workSegmentStartedAt.current) / 1000));
    }, 1000);
    return () => window.clearInterval(timer);
  }, [documentId, documentName, readOnly]);

  const commitWorkTime = () => {
    if (readOnly) return;
    const segmentSeconds = Math.max(1, Math.round((Date.now() - workSegmentStartedAt.current) / 1000));
    recordOcrDocumentWorkTime(documentId ?? documentName, documentName, segmentSeconds);
    committedSeconds.current += segmentSeconds;
    workSegmentStartedAt.current = Date.now();
    setWorkElapsedSeconds(committedSeconds.current);
  };

  useEffect(() => () => {
    if (!readOnly && !closed.current) {
      const segmentSeconds = Math.floor((Date.now() - workSegmentStartedAt.current) / 1000);
      if (segmentSeconds > 0) recordOcrDocumentWorkTime(documentId ?? documentName, documentName, segmentSeconds);
      closed.current = true;
    }
  }, [documentId, documentName, readOnly]);

  const [initialTask] = useState(() => savedTask ?? (documentId && reportedIssueId ? loadIssueCorrectionDraft(documentId.replace(/^document-set-/, ''), reportedIssueId, companyId, localStorage) : undefined));
  const [documentTask, setDocumentTask] = useState<WorkspaceTask>(() => initialTask ?? ({
    id: `document-set-${documentId ?? documentName}`,
    name: documentName,
    priority: 0,
    description: `Document from TeamLead / Document sets: ${documentName}`,
    status: 'In Progress',
    createdBy: 'Document set',
    ...(!readOnly ? { assignedToEmail: getCurrentUserIdentity().email, assignedToName: getCurrentUserIdentity().fullName, assignedAt: new Date().toISOString() } : {}),
    creationDate: new Date().toLocaleString('lt-LT'),
    documentType: 'IDP Sample Invoice',
    sourceRunId: 'DOCUMENT-SET',
    editStartedAt: new Date().toISOString(),
    fields: readOnly ? Object.fromEntries(Object.keys(EMPTY_FIELDS).map(key => [key, ''])) as unknown as WorkspaceFields : { ...EMPTY_FIELDS },
    products: readOnly ? [] : SAMPLE_PRODUCTS.map(product => ({ ...product })),
    originalFields: readOnly ? undefined : { ...EMPTY_FIELDS },
    originalProducts: readOnly ? [] : SAMPLE_PRODUCTS.map(product => ({ ...product })),
    comments: [],
  }));

  const [loadingAccounting, setLoadingAccounting] = useState(Boolean(documentId));
  const [accountingLoadError, setAccountingLoadError] = useState('');
  const [sourceUrl, setSourceUrl] = useState<string>();
  const [validationDocument, setValidationDocument] = useState<DbDocument>();
  const [exportFormat, setExportFormat] = useState<string>();
  const issueSource = useRef<DbDocument>();
  const [hasSavedDraft] = useState(Boolean(initialTask));
  useEffect(() => {
    let cancelled = false;
    if (!documentId) return;
    setLoadingAccounting(true);
    void (async () => {
      try {
        let query = supabase.from('documents').select('*').eq('id', documentId.replace(/^document-set-/, ''));
        if (companyId) query = query.eq('company_id', companyId);
        const result = await query;
        if (result.error) throw result.error;
        const document = result.data?.[0] as unknown as DbDocument | undefined;
        if ((!document && !hasSavedDraft) || (reportedIssueId && !document?.digitization_issues?.some(issue => issue.id === reportedIssueId))) throw new Error('Source document unavailable');
        if (!cancelled && document) { setSourceUrl(document.image_url || undefined); setValidationDocument(document); issueSource.current = document; }
        const companyResult = document?.company_id ? await supabase.from('companies').select('*').eq('id', document.company_id) : undefined;
        if (companyResult?.error) throw companyResult.error;
        const organization = companyResult?.data?.[0] as unknown as Company | undefined;
        if (!cancelled) setExportFormat(organization?.primary_export_format);
        const context = document && await documentLearningContext(document, organization);
        if (readOnly && document && !document.company_id && !hasSavedDraft) throw new Error('Document company context unavailable');
        if (!cancelled && document) setDocumentTask(previous => {
          const recovered = handoffDraft(document, hasSavedDraft ? previous : undefined);
          const current = recovered || previous;
          const hasDraft = hasSavedDraft || Boolean(recovered);
          const accounting = !context ? undefined : current.accounting?.documentId === context.documentId && !reportedIssueId ? { ...context, ...current.accounting,
            supplierCode: current.accounting.supplierCode ?? context.supplierCode } : readOnly || reportedIssueId ? context : suggestDocumentAccounting(context);
          const fields = { ...current.fields, ...Object.fromEntries(Object.entries(OCR_WORKSPACE_FIELD_KEYS)
            .filter(([key]) => document.ocr_values?.[key] !== undefined).map(([key, field]) => [field, document.ocr_values![key]])), invoiceNumber: document.number || '',
            invoiceDate: reviewDateValue(document.document_date || ''), dueDate: reviewDateValue(document.due_end_date || ''),
            companyName: document.client_counterparty || '', taxRate: normalizeVatRate(document.vat_percent || ''),
            totalAmount: document.total_amount };
          const products = !hasDraft || reportedIssueId ? (document.line_items ?? []).map(line => ({ id: line.id, name: line.product,
            description: line.description ?? '', price: line.price, quantity: line.qty, ocrValues: line.ocr_values })) : current.products;
          return { ...current, accounting, products, documentStructure: current.documentStructure || document.ocr_document_structure, originalProducts: !hasDraft ? products.map(line => ({ ...line })) : current.originalProducts,
            ocrFieldValues: !reportedIssueId && hasDraft ? current.ocrFieldValues : document.ocr_values,
            ocrParties: !reportedIssueId && hasDraft ? current.ocrParties ?? document.ocr_parties : document.ocr_parties,
            advanceEmployeeId: current.advanceEmployeeId ?? document.advance_employee_id, advanceEmployee: current.advanceEmployee ?? document.advance_employee, documentType: !hasDraft ? document.document_subtype || document.document_type || '' : current.documentType,
            fields: !reportedIssueId && hasDraft ? current.fields : fields,
            originalFields: hasDraft ? current.originalFields : fields };
        });
      } catch { if (!cancelled) setAccountingLoadError(readOnly ? 'This source document is not available in the selected company. No replacement document has been opened.' : 'Accounting information could not be loaded. Reopen this document to retry.'); }
      finally { if (!cancelled) setLoadingAccounting(false); }
    })();
    return () => { cancelled = true; };
  }, [documentId, hasSavedDraft, companyId, readOnly, reportedIssueId]);

  const saveDocumentTask = async (nextTask: WorkspaceTask) => {
    if (readOnly) return;
    const completing = nextTask.status === 'Completed';
    // A configured type may have Insurer/Policyholder or other roles instead of an
    // invoice supplier. Identity comes from the source document, not a party field.
    const completionTarget = validationDocument?.company_id
      ? { documentId: validationDocument.id, companyId: validationDocument.company_id }
      : nextTask.accounting;
    if (completing && documentId && !completionTarget)
      throw new Error('The source document is no longer available in this company.');
    if (!nextTask.assignedToEmail) {
      const identity = getCurrentUserIdentity();
      nextTask = { ...nextTask, assignedToEmail: identity.email, assignedToName: identity.fullName, assignedAt: new Date().toISOString() };
    }
    if (completing && completionTarget) {
      const latestResult = await supabase.from('documents').select('*').eq('id', completionTarget.documentId).eq('company_id', completionTarget.companyId);
      const latest = latestResult.data?.[0] as unknown as DbDocument | undefined;
      if (latestResult.error || !latest) throw new Error('The source document is no longer available in this company.');
      const catalog = loadOrganizationReferenceRecords('Document type');
      const completionPatch = ocrCompletionPatch(nextTask, catalog, latest);
      const completedDocument = { ...latest, ...completionPatch };
      const missing = missingOcrRequiredFields(completedDocument, loadOcrFieldValidationRules({ documentTypes: ocrRoutingTypeCodes(completedDocument, catalog) }));
      if (missing.length) throw new Error(`Complete required fields before approval: ${missing.join(', ')}.`);
      const session = parseSession(localStorage.getItem(AUTH_SESSION_KEY));
      const storedTask = loadSavedReviewDocumentTask({ id: latest.id, companyId: latest.company_id }, localStorage);
      const latestTask = latest.ocr_rerun_request && (!storedTask?.savedAt || storedTask.savedAt < latest.ocr_rerun_request.requestedAt) ? undefined : storedTask;
      const existingReview = latestTask?.teamLeadReview || documentTask.teamLeadReview;
      const canApprove = session && (existingReview?.status === 'Pending' ? canEditMenu(session, 'ocr-ml')
        : canEditMenu(session, 'ocr-workspace') || canEditMenu(session, 'ocr-review-approve-documents'));
      if (!canApprove)
        throw new Error('You do not have permission to approve this OCR document.');
      const supplierName = nextTask.fields.companyName.trim();
      const supplierChanged = supplierName.toLocaleLowerCase() !== (latest.client_counterparty || '').trim().toLocaleLowerCase();
      const context = nextTask.accounting ? { ...nextTask.accounting, vatRate: nextTask.fields.taxRate, supplierName,
        supplierKey: supplierChanged ? `name:${supplierName.toLocaleLowerCase()}` : nextTask.accounting.supplierKey } : undefined;
      const savedDocument = await completeOcrReview(completionTarget.documentId, completionTarget.companyId, { ...completionPatch,
        ...(context ? { expense_account: context.expenseAccount, vat_classifier: context.vatClassifier, vat_percent: context.vatRate } : {}),
        number: nextTask.fields.invoiceNumber, document_date: nextTask.fields.invoiceDate, due_end_date: nextTask.fields.dueDate,
        total_amount: nextTask.fields.totalAmount, client_counterparty: supplierName,
        ...(supplierChanged ? { counterparty_id: '' } : {}) }, ocrWorkflowSnapshot(latest));
      nextTask = { ...nextTask, accounting: context, ...(existingReview ? { teamLeadReview: existingReview } : {}) };
      if (savedDocument.ocr_approval_route?.destination === 'TeamLead') {
        nextTask = requestTeamLeadReview(nextTask, 'Approval routing: TeamLead approval is required for this organization / document type.', getCurrentUserIdentity());
      } // The shared completion boundary learns the saved document, not this potentially stale editor context.
      window.dispatchEvent(new CustomEvent('finansu-harmonija:data-changed'));
    }
    if (!completing && nextTask.workerHandoff && nextTask.workerHandoff.id !== documentTask.workerHandoff?.id) {
      const source = validationDocument;
      if (!source?.company_id) throw new Error('The source document is no longer available.');
      const saved = await handoffOcrWorkerDocument(source.id, source.company_id, nextTask, ocrWorkflowSnapshot(source));
      setValidationDocument(saved);
    } else if (!completing && nextTask.documentStructure && nextTask.documentStructure.at !== documentTask.documentStructure?.at) {
      const source = validationDocument;
      if (!source?.company_id) throw new Error('The source document is no longer available.');
      const saved = await saveOcrDocumentStructure(source.id, source.company_id, nextTask, ocrWorkflowSnapshot(source));
      setValidationDocument(saved);
    }
    nextTask = { ...updateTeamLeadReview(nextTask), savedAt: new Date().toISOString() };
    try {
      await onSave?.(nextTask);
      if (nextTask.teamLeadReview) {
        saveTeamLeadReviewTask(nextTask, localStorage);
        window.dispatchEvent(new CustomEvent('finansu-harmonija:persistent-state-changed', { detail: { storageKey: TEAM_LEAD_QUEUE_KEY } }));
      }
    } catch (error) {
      // A handoff's canonical document already contains the complete recoverable draft.
      // Secondary list-cache failure must not invite another workflow transition.
      if (!nextTask.workerHandoff || nextTask.workerHandoff.id === documentTask.workerHandoff?.id) throw error;
    }
    setDocumentTask(nextTask);
    commitWorkTime();
  };

  const closeEditor = () => {
    commitWorkTime();
    closed.current = true;
    onBack();
  };

  const saveIssueTask = async (nextTask: WorkspaceTask, finish: boolean, note: string) => {
    const original = issueSource.current;
    if (readOnly || !reportedIssueId || !original?.company_id || !canReviewDocumentIssues()) throw new Error('You do not have permission to correct this issue.');
    const latest = await supabase.from('documents').select('*').eq('id', original.id).eq('company_id', original.company_id);
    const issue = (latest.data?.[0] as unknown as DbDocument | undefined)?.digitization_issues?.find(item => item.id === reportedIssueId);
    if (latest.error || !issue || ['Resolved', 'Awaiting OCR'].includes(issue.status)) throw new Error('This issue is no longer available for correction. Refresh the list.');
    const saved = await applyDocumentDetailEdit(original.id, original.company_id, ocrIssueCorrectionPatch(nextTask, original, loadOrganizationReferenceRecords('Document type')),
      documentDetailSnapshot(original as unknown as Record<string, unknown>), 'Worker saved document issue corrections.');
    issueSource.current = saved.document;
    setValidationDocument(saved.document);
    setDocumentTask(saveIssueCorrectionDraft(nextTask, original.id, reportedIssueId, localStorage));
    if (finish) {
      const queued = await applyDocumentIssueAction(original.id, original.company_id, { type: 'resolve', issueId: reportedIssueId,
        note: note.trim() || 'Worker corrections completed. Return the document to OCR for reprocessing.' });
      commitWorkTime(); closed.current = true;
      if (onIssueFixed) await onIssueFixed(queued); else onBack();
    }
  };

  if (loadingAccounting || accountingLoadError) return <div className="p-8 font-montserrat text-[13px] text-[#7288A3]"><p role="status">{accountingLoadError || uiText('Loading document…')}</p>{accountingLoadError && <PageActionButton onClick={closeEditor}>{uiText("Back")}</PageActionButton>}</div>;

  return (
    <WorkspaceTaskDetail
      task={documentTask}
      exportFormat={exportFormat}
      onBack={closeEditor}
      onUpdate={saveDocumentTask}
      onComplete={saveDocumentTask}
      onMerge={readOnly ? undefined : async (task, sources, pages, filename, requestId) => {
        const source = validationDocument;
        if (!source?.company_id) throw new Error('The source document is no longer available.');
        await mergeOcrDocuments(source.id, source.company_id, task, sources, pages, filename, requestId);
        commitWorkTime();
        if (onNextFile) await onNextFile(); else closeEditor();
      }}
      onSplit={readOnly ? undefined : async (task, groups, requestId) => {
        const source = validationDocument;
        if (!source?.company_id) throw new Error('The source document is no longer available.');
        await splitOcrDocument(source.id, source.company_id, task, groups, requestId, ocrWorkflowSnapshot(source));
        commitWorkTime();
        if (onNextFile) await onNextFile(); else closeEditor();
      }}
      onNextFile={onNextFile ? async nextTask => {
        await saveDocumentTask(nextTask);
        await onNextFile();
      } : undefined}
      queuePosition={filePosition}
      queueTotal={fileTotal}
      trainingMode
      teamLead={teamLead}
      readOnly={readOnly}
      sourceUrl={sourceUrl}
      viewNotice={viewNotice}
      validationDocument={validationDocument}
      reportedIssue={validationDocument?.digitization_issues?.find(issue => issue.id === reportedIssueId)}
      onSaveIssue={reportedIssueId ? saveIssueTask : undefined}
      workElapsedSeconds={readOnly ? undefined : workElapsedSeconds}
    />
  );
}

export default function WorkspaceView({ onCompleteToCompany }: {
  onCompleteToCompany?: (task: WorkspaceTask) => void | Promise<void>;
}) {
  const [selectedDocumentName, setSelectedDocumentName] = useState<string | null>(null);
  const [documentQueue, setDocumentQueue] = useState<ReviewDocumentReference[]>([]);
  const [documentIndex, setDocumentIndex] = useState(-1);
  const [notice, setNotice] = useState('');
  const [workspaceHeaderActions, setWorkspaceHeaderActions] = useState<HTMLDivElement | null>(null);
  const [savedDocumentTasks, setSavedDocumentTasks] = usePersistentState<Record<string, WorkspaceTask>>(
    'finansu-harmonija:v12:workspace:review-document-tasks',
    {},
  );

  if (selectedDocumentName) {
    const currentDocument = documentQueue[documentIndex];
    const documentId = currentDocument?.id ?? selectedDocumentName;
    const hasNextFile = documentIndex >= 0 && documentIndex < documentQueue.length - 1;
    return (
      <WorkspaceDocumentEditor
        key={documentId}
        documentName={selectedDocumentName}
        documentId={documentId}
        savedTask={savedDocumentTasks[documentId]}
        filePosition={documentIndex + 1}
        fileTotal={documentQueue.length}
        onSave={async (task) => {
          setSavedDocumentTasks((current) => ({ ...current, [documentId]: task }));
          // A linked document keeps its existing company and is updated in place by the editor.
          if (!task.accounting) await onCompleteToCompany?.(task);
        }}
        onNextFile={hasNextFile ? () => {
          const nextIndex = documentIndex + 1;
          const nextDocument = documentQueue[nextIndex];
          setDocumentIndex(nextIndex);
          setSelectedDocumentName(nextDocument.name);
        } : undefined}
        onBack={() => {
          setSelectedDocumentName(null);
          setDocumentQueue([]);
          setDocumentIndex(-1);
        }}
      />
    );
  }

  return (
    <div className="relative flex min-h-full min-w-0 flex-col gap-8 bg-white px-4 py-14 sm:px-8 lg:px-[72px]">
      <PageHeader title={uiText("Workspace")} actions={<div ref={setWorkspaceHeaderActions} className="flex items-center" />} />
      <OcrBreadcrumb items={["Workspace"]} />
      <ProcessedDocumentsTable
        embedded
        showAllDocuments
        selectable
        importActionContainer={workspaceHeaderActions}
        selectionActionVariant="run"
        onImportDocuments={async (selectedDocuments) => {
          const result = await supabase
            .from('documents')
            .update({ status: 'Accepted' })
            .in('id', selectedDocuments.map((document) => document.id));
          if (result.error) {
            setNotice(`Documents could not be processed: ${result.error.message}`);
            return;
          }
          window.dispatchEvent(new CustomEvent('finansu-harmonija:data-changed'));
          setNotice(`${selectedDocuments.length} document${selectedDocuments.length === 1 ? '' : 's'} processed and approved.`);
        }}
        onEditDocument={(document, index, documents) => {
          setDocumentQueue(documents);
          setDocumentIndex(index);
          setSelectedDocumentName(document.name);
        }}
        onRunDocument={async (document) => {
          const result = await supabase
            .from('documents')
            .update({ status: 'Processing' })
            .eq('id', document.id);
          if (result.error) {
            setNotice(`${document.name} could not be started: ${result.error.message}`);
            return;
          }
          window.dispatchEvent(new CustomEvent('finansu-harmonija:data-changed'));
          setNotice(`${document.name} started.`);
        }}
      />
      {notice && <div role="status" className="fixed bottom-6 right-6 z-[240] rounded-lg bg-[#E7F7EF] px-5 py-3 font-montserrat text-[13px] font-semibold text-[#237A50] shadow-lg">{notice}</div>}
    </div>
  );
}
