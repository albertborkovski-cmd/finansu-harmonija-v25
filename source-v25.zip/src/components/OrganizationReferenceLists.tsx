import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ChevronDown, ChevronLeft, ChevronRight, ClipboardPaste, Download, Loader2, Pencil, Plus } from 'lucide-react';
import { translateUi as t } from '../i18n/language';
import { supabase, type Company } from '../lib/supabase';
import { canEditCompanySettings, canViewCompanyDocuments } from '../lib/documentEditAccess';
import { isInactiveRecord, isRecordLinked } from '../lib/recordLifecycle';
import { loadOrganizationCounterparties, organizationLedgerRows } from '../lib/organizationReferenceLists';
import { loadCompanyGeneralLedgerRegister, type LedgerAccount } from './GeneralLedgerView';
import OcrSearchField from './OcrSearchField';
import RefreshAllButton from './RefreshAllButton';
import HorizontalTableScrollbar from './HorizontalTableScrollbar';
import { PageActionButton } from './PageHeader';
import CompanyExpenseCodeEditor from './CompanyExpenseCodeEditor';
import CompanyCounterpartyEditor from './CompanyCounterpartyEditor';
import { counterpartyIbans, COUNTERPARTY_LABELS } from '../lib/companyCounterpartyImport';
import { companyCounterpartiesKey } from '../lib/organizationDirectory';
import { deleteCompanyCounterparty } from '../lib/companyCounterpartyActions';
import { RowDeleteButton } from './DeleteButtons';
import GlJournalDialog from './GlJournalDialog';
import ColumnSettingsPanel, { type ColConfig } from './ColumnSettingsPanel';
import { ColumnSettingsButton } from './ScopedActionButtons';
import { usePersistentState } from '../hooks/usePersistentState';
import { ResizeHandle, useColumnResize } from './useColumnResize';
import OrganizationSettingsHelpLink from './OrganizationSettingsHelpLink';

const COUNTERPARTY_COLUMNS: ColConfig[] = [
  { key: 'name', label: 'Name', width: 240, visible: true },
  { key: 'accounting_system_code', label: 'Accounting system code', width: 160, visible: true },
  { key: 'company_code', label: 'Company code', width: 140, visible: true },
  { key: 'vat_code', label: 'VAT code', width: 160, visible: true },
  { key: 'iban', label: 'IBAN', width: 240, visible: true },
  { key: 'email', label: 'Email', width: 220, visible: true },
  { key: 'phone', label: 'Phone', width: 150, visible: true },
  { key: 'status', label: 'Status', width: 120, visible: true },
];

export default function OrganizationReferenceLists({ companyId, kind, onEditingChange }: { companyId: string; kind: 'ledger' | 'counterparties'; onEditingChange?: (editing: boolean) => void }) {
  const [accounts, setAccounts] = useState<LedgerAccount[]>([]), [counterparties, setCounterparties] = useState<Company[]>([]);
  const [template, setTemplate] = useState(''), [query, setQuery] = useState('');
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true), [error, setError] = useState('');
  const [canEdit, setCanEdit] = useState(false), [editor, setEditor] = useState<'manual' | 'excel' | null>(null);
  const [savedCount, setSavedCount] = useState(0);
  const [exporting, setExporting] = useState(false);
  const [editingCompany, setEditingCompany] = useState<Company>();
  const [deleting, setDeleting] = useState<{ row: Company; linked: boolean }>();
  const [deletingBusy, setDeletingBusy] = useState(false), [deleteError, setDeleteError] = useState('');
  const [columns, setColumns] = usePersistentState<ColConfig[]>(`finansu-harmonija:v23:counterparty-columns:${companyId}`, COUNTERPARTY_COLUMNS);
  const [showColumns, setShowColumns] = useState(false), [page, setPage] = useState(0);
  const visibleColumns = columns.filter(column => column.visible);
  const { startResize } = useColumnResize(columns, setColumns, `organization-counterparties:${companyId}`);
  const counterpartySourceKey = companyCounterpartiesKey(companyId);
  const edit = (mode: 'manual' | 'excel' | null) => { setEditor(mode); onEditingChange?.(mode !== null); };
  const request = useRef(0), scroll = useRef<HTMLDivElement>(null);
  const refresh = useCallback(async () => {
    const version = ++request.current; setLoading(true);
    try {
      const { data, error } = await supabase.from('companies').select('*').eq('id', companyId);
      if (error) throw error;
      const company = data?.[0] as unknown as Company | undefined;
      if (!company || !canViewCompanyDocuments(company)) throw new Error('You do not have access to this organization.');
      const nextAccounts = kind === 'ledger' ? loadCompanyGeneralLedgerRegister(companyId, company.general_ledger) : [];
      const nextCounterparties = kind === 'counterparties' ? loadOrganizationCounterparties(companyId) : [];
      if (version !== request.current) return;
      setAccounts(nextAccounts); setCounterparties(nextCounterparties); setTemplate(company.general_ledger || ''); setError('');
      setCanEdit(canEditCompanySettings(company) && !isInactiveRecord(company));
    } catch (reason) {
      if (version !== request.current) return;
      setAccounts([]); setCounterparties([]); setCanEdit(false); setError(reason instanceof Error ? reason.message : 'Could not load organization lists.');
    } finally { if (version === request.current) setLoading(false); }
  }, [companyId, kind]);
  useEffect(() => {
    void refresh();
    const events = ['storage', 'counterparties-updated', 'company-general-ledger-updated', 'finansu-harmonija:settings-data-changed', 'finansu-harmonija:data-changed'];
    const changed = (event: Event) => {
      if (event.type === 'storage' && ![null, counterpartySourceKey, 'finansu-harmonija-v4:data:companies', ...(kind === 'ledger' ? [`finansu-harmonija:v12:company-general-ledger:${companyId}`, 'finansu-harmonija:v7:general-ledger-templates'] : [])].includes((event as StorageEvent).key)) return;
      const detail = (event as CustomEvent<{ companyId?: string; table?: string }>).detail;
      if (detail?.companyId && detail.companyId !== companyId) return;
      if (event.type === 'finansu-harmonija:data-changed' && detail?.table !== 'companies') return;
      void refresh();
    };
    events.forEach(event => window.addEventListener(event, changed));
    return () => { ++request.current; events.forEach(event => window.removeEventListener(event, changed)); };
  }, [refresh, counterpartySourceKey, companyId, kind]);
  const ledgerRows = useMemo(() => organizationLedgerRows(accounts, collapsed, query), [accounts, collapsed, query]);
  const filteredCounterparties = useMemo(() => {
    const needle = query.trim().toLocaleLowerCase();
    return counterparties.filter(row => !needle || [row.accounting_system_code, row.name, row.company_code, row.vat_code, row.email, row.phone, ...counterpartyIbans(row)].some(value => String(value || '').toLocaleLowerCase().includes(needle)));
  }, [counterparties, query]);
  const ledger = kind === 'ledger', count = ledger ? ledgerRows.length : filteredCounterparties.length;
  const headers = ledger ? ['GL account', 'Name', 'Type', 'Alternative codes', 'Account type', 'Cost center', 'Status'] : [...visibleColumns.map(column => column.label), ''];
  const pageCount = Math.max(1, Math.ceil(filteredCounterparties.length / 20)), safePage = Math.min(page, pageCount - 1);
  const counterpartyRows = useMemo(() => filteredCounterparties.slice(safePage * 20, (safePage + 1) * 20), [filteredCounterparties, safePage]);
  const linkedIds = useMemo(() => new Set(counterpartyRows.filter(row => isRecordLinked(row, counterpartySourceKey)).map(row => row.id)), [counterpartyRows, counterpartySourceKey]);
  useEffect(() => { setPage(0); }, [query, companyId]);
  const confirmDelete = async () => {
    if (!deleting || deletingBusy) return;
    setDeletingBusy(true); setDeleteError('');
    try { await deleteCompanyCounterparty(companyId, deleting.row); setDeleting(undefined); await refresh(); }
    catch (reason) { setDeleteError(reason instanceof Error ? reason.message : 'Could not save the companies.'); }
    finally { setDeletingBusy(false); }
  };
  const exportCounterparties = async () => {
    if (loading || exporting || !filteredCounterparties.length) return;
    setExporting(true); setError('');
    try {
      const XLSX = await import('xlsx');
      const sheet = XLSX.utils.aoa_to_sheet([COUNTERPARTY_LABELS.map(label => t(label)), ...filteredCounterparties.map(row =>
        [row.accounting_system_code || '', row.company_code || '', row.vat_code || '', row.name, counterpartyIbans(row).join('; ')])]);
      sheet['!cols'] = [{ wch: 25 }, { wch: 20 }, { wch: 22 }, { wch: 40 }, { wch: 55 }];
      const book = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(book, sheet, 'Counterparties');
      XLSX.writeFile(book, `counterparties-${companyId.replace(/[^a-zA-Z0-9_-]/g, '_')}.xlsx`);
    } catch { setError('Could not export the counterparties.'); }
    finally { setExporting(false); }
  };
  if (ledger && editor) return <CompanyExpenseCodeEditor companyId={companyId} templateName={template} accounts={accounts} mode={editor} canEdit={canEdit}
    onCancel={() => edit(null)} onSaved={count => { edit(null); setSavedCount(count); setQuery(''); void refresh(); }} />;
  if (!ledger && editor) return <CompanyCounterpartyEditor key={editingCompany?.id || editor} companyId={companyId} existing={counterparties} mode={editor} canEdit={canEdit} editingCompany={editingCompany}
    onCancel={() => { edit(null); setEditingCompany(undefined); }} onSaved={count => { edit(null); setEditingCompany(undefined); setSavedCount(count); void refresh(); }} />;
  return <section className="flex h-full min-h-0 min-w-0 flex-col gap-4 font-montserrat" aria-label={t(ledger ? 'Chart of accounts' : 'Counterparties')}>
    <header className="flex min-h-8 shrink-0 flex-wrap items-center justify-between gap-3" data-organization-reference-header>
      <div className="flex items-center gap-2"><h3 className="text-[16px] font-semibold leading-6 text-[#10233A]">{t(ledger ? 'Chart of accounts' : 'Counterparties')}</h3>{!ledger && <OrganizationSettingsHelpLink section="counterparties" label="Counterparties" />}</div>
      <div className="ml-auto flex min-w-0 flex-wrap items-center justify-end gap-2">
        {ledger && <><PageActionButton disabled={loading || !canEdit} icon={<Plus size={15} />} onClick={() => { setSavedCount(0); edit('manual'); }}>{t('New expense')}</PageActionButton>
          <PageActionButton disabled={loading || !canEdit} icon={<ClipboardPaste size={15} />} onClick={() => { setSavedCount(0); edit('excel'); }}>{t('Import from Excel')}</PageActionButton></>}
        {!ledger && <><PageActionButton disabled={loading || !canEdit} icon={<Plus size={15} />} onClick={() => { setSavedCount(0); setEditingCompany(undefined); edit('manual'); }}>{t('Add company')}</PageActionButton>
          <PageActionButton disabled={loading || !canEdit} icon={<ClipboardPaste size={15} />} onClick={() => { setSavedCount(0); setEditingCompany(undefined); edit('excel'); }}>{t('Import from Excel')}</PageActionButton></>}
      </div>
    </header>
    <div className="flex min-h-8 shrink-0 flex-wrap items-center justify-between gap-3">
      <OcrSearchField value={query} onChange={setQuery} ariaLabel={t(ledger ? 'Search general ledger accounts' : 'Search counterparties')} />
      <div className="ml-auto flex shrink-0 items-center gap-4">
        {!ledger && <><button type="button" data-button-family="export" title={t('Export')} aria-label={t('Export')} disabled={loading || exporting || !count} onClick={() => void exportCounterparties()} className="flex h-4 w-4 items-center justify-center text-[#7288A3] transition-colors hover:text-[#007EA7] disabled:opacity-40">{exporting ? <Loader2 size={16} className="animate-spin" /> : <Download size={16} />}</button><ColumnSettingsButton onClick={() => setShowColumns(true)} /></>}
        <RefreshAllButton disabled={loading} onRefresh={refresh} />
      </div>
    </div>
    {ledger && <div className="flex shrink-0 items-center gap-2 text-[12px] text-[#7288A3]"><span>{template ? `${template} · ` : ''}{count} {t('records')}</span></div>}
    {savedCount > 0 && <div className="shrink-0 text-[12px] text-[#7288A3]">
      <span role="status" className="text-[#007EA7]">{t(ledger ? 'Codes saved' : 'Saved')}: {savedCount}{ledger ? `. ${t('Available in the Expense account selection.')}` : ''}</span></div>
    }
    {error && <p role="alert" className="text-[12px] text-[#B42318]">{t(error)}</p>}
    <div ref={scroll} className="min-h-0 flex-1 overflow-auto [scrollbar-gutter:stable]">
      <table className={`w-full border-separate border-spacing-x-0 border-spacing-y-0.5 text-left font-montserrat text-[12px] leading-[18px] ${ledger ? '' : 'organization-counterparties-table table-fixed'}`} style={{ minWidth: ledger ? 760 : visibleColumns.reduce((width, column) => width + column.width, 88) }}>
        {!ledger && <colgroup>{visibleColumns.map(column => <col key={column.key} style={{ width: column.width }} />)}<col /></colgroup>}
        <thead className="sticky top-0 z-10 bg-white text-[#10233A]"><tr>{headers.map((label, index) => <th key={label} scope="col" className={`h-10 px-3 pb-3 pt-1 font-medium ${!label ? 'system-table-row-actions w-[88px] min-w-[88px]' : ''}`}>
          {label ? <span className="flex items-center gap-1 pr-2"><span className="truncate" title={t(label)}>{t(label)}</span>{!ledger && <OrganizationSettingsHelpLink section="counterparties" topic={['name', 'accountingCode', 'companyCode', 'vatCode', 'ibans', 'email', 'phone', 'status'][COUNTERPARTY_COLUMNS.findIndex(column => column.key === visibleColumns[index]?.key)]} label={label} />}</span> : <span className="sr-only">{t('Actions')}</span>}
          {!ledger && visibleColumns[index] && <ResizeHandle onMouseDown={event => startResize(columns.findIndex(column => column.key === visibleColumns[index].key), event)} />}
        </th>)}</tr></thead>
        <tbody>
          {loading ? <tr><td colSpan={headers.length} className="p-8 text-center text-[#7288A3]"><Loader2 size={18} className="mx-auto animate-spin" aria-label={t('Loading…')} /></td></tr>
            : !count ? <tr><td colSpan={headers.length} className="p-8 text-center text-[#7288A3]">{t(query ? 'No matching records.' : ledger ? 'No general ledger accounts available.' : 'No counterparties assigned to this organization.')}</td></tr>
            : ledger ? ledgerRows.map(({ account, depth, hasChildren }) => <tr key={account.id} data-record-inactive={!account.active || undefined} className="border-b border-[#E5EDF9] last:border-b-0 hover:bg-[#F2F7FC]">
              <td className="whitespace-nowrap px-4 py-2.5"><div className="flex items-center gap-1.5" style={{ paddingLeft: Math.min(depth, 8) * 16 }}>
                {hasChildren ? <button type="button" className="flex h-6 w-6 shrink-0 items-center justify-center rounded text-[#7288A3] hover:bg-[#E5EDF9] hover:text-[#007EA7]" disabled={Boolean(query.trim())}
                  aria-label={`${t(collapsed.has(account.id) && !query.trim() ? 'Expand' : 'Collapse')} ${account.code}`} aria-expanded={!collapsed.has(account.id) || Boolean(query.trim())}
                  onClick={() => setCollapsed(previous => { const next = new Set(previous); if (next.has(account.id)) next.delete(account.id); else next.add(account.id); return next; })}>
                  {collapsed.has(account.id) && !query.trim() ? <ChevronRight size={14} /> : <ChevronDown size={14} />}
                </button> : <span className="h-6 w-6 shrink-0" />}<span className="font-medium">{account.code}</span>
              </div></td><td className="min-w-[260px] px-4 py-2.5">{account.name}</td><td className="px-4 py-2.5">{account.expenseType ? t(account.expenseType) : '—'}</td><td className="max-w-[200px] truncate px-4 py-2.5" title={account.alternativeCodes?.join(', ')}>{account.alternativeCodes?.join(', ') || '—'}</td><td className="px-4 py-2.5">{t(account.type)}</td><td className="px-4 py-2.5">{account.costCenter || '—'}</td><td className="px-4 py-2.5">{t(account.active ? 'Active' : 'Inactive')}</td>
            </tr>) : counterpartyRows.map((row, index) => <tr key={row.id} data-record-inactive={isInactiveRecord(row) || undefined} className={`h-10 text-[#10233A] transition-colors ${index % 2 === 0 ? 'bg-[#F8FDFF]' : 'bg-white'} hover:bg-[#E7F4F9]`}>
              {visibleColumns.map(column => {
                const value = column.key === 'iban' ? counterpartyIbans(row).join('; ') : column.key === 'status' ? t(isInactiveRecord(row) ? 'Inactive' : 'Active') : String(row[column.key as keyof Company] || '');
                return <td key={column.key} className="px-3 py-1.5 first:rounded-l-lg"><span className="block truncate" style={{ maxWidth: column.width - 24 }} title={value || undefined}>{value || '—'}</span></td>;
              })}
              <td className="system-table-row-actions rounded-r-lg px-3 py-1.5"><div className="flex items-center justify-end gap-1.5">
                <button type="button" data-button-family="row-edit" title={t('Edit counterparty')} aria-label={`${t('Edit counterparty')}: ${row.name}`} disabled={!canEdit || loading} onClick={() => { setSavedCount(0); setEditingCompany(row); edit('manual'); }} className="flex h-7 w-7 shrink-0 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] transition-colors hover:border-[#007EA7] hover:text-[#007EA7] disabled:cursor-not-allowed disabled:opacity-40"><Pencil size={14} /></button>
                <RowDeleteButton label={`${t('Delete')}: ${row.name}`} title={t('Delete')} linked={linkedIds.has(row.id)} inactive={isInactiveRecord(row)} disabled={!canEdit || loading} onDelete={() => { setDeleteError(''); setDeleting({ row, linked: isRecordLinked(row, counterpartySourceKey) }); }} />
              </div></td>
            </tr>)}
        </tbody>
      </table>
    </div>
    <HorizontalTableScrollbar scrollRef={scroll} fixed={false} expandable={false} />
    {!ledger && <div className="flex h-8 shrink-0 items-center justify-between gap-3 text-[12px] text-[#7288A3]" data-counterparty-pagination><span>{count} {t('records')}</span><div className="flex items-center gap-3"><PageActionButton iconOnly ariaLabel={t('Previous page')} icon={<ChevronLeft size={15} />} disabled={safePage === 0} onClick={() => setPage(value => Math.max(0, value - 1))}>{t('Previous')}</PageActionButton><span className="tabular-nums">{safePage + 1} / {pageCount}</span><PageActionButton iconOnly ariaLabel={t('Next page')} icon={<ChevronRight size={15} />} disabled={safePage + 1 >= pageCount} onClick={() => setPage(safePage + 1)}>{t('Next')}</PageActionButton></div></div>}
    {showColumns && <div className="fixed inset-0 z-[260]"><ColumnSettingsPanel columns={columns} defaultColumns={COUNTERPARTY_COLUMNS} onSave={setColumns} onClose={() => setShowColumns(false)} /></div>}
    {deleting && <GlJournalDialog title={deleting.linked ? 'Deactivate' : 'Delete'} subtitle={deleting.row.name} overlayZIndex={270} onClose={() => { if (!deletingBusy) setDeleting(undefined); }} footer={<><PageActionButton disabled={deletingBusy} onClick={() => setDeleting(undefined)}>{t('Cancel')}</PageActionButton><PageActionButton disabled={deletingBusy} onClick={() => void confirmDelete()}>{t(deleting.linked ? 'Deactivate' : 'Delete')}</PageActionButton></>}>
      <p className="text-[14px] leading-6">{t(deleting.linked ? 'Linked records are preserved. This counterparty will remain visible as inactive.' : 'Delete this counterparty from this organization?')}</p>
      {deleteError && <p role="alert" className="mt-3 text-[12px] text-[#B42318]">{t(deleteError)}</p>}
    </GlJournalDialog>}
  </section>;
}
