import { lazy, Suspense, type ReactNode } from 'react';
import { HelpContentProvider } from './HelpContentProvider';
import HelpContentBoundary from './HelpContentBoundary';

const HelpAdministration = lazy(() => import('./HelpAdministration'));
export default function HelpContentRoot({ route, children }: { route: string; children: ReactNode }) {
  return <HelpContentProvider>{route.startsWith('#help/admin') ? <Suspense fallback={<div role="status" className="p-8">…</div>}><HelpAdministration key={route} /></Suspense> : <HelpContentBoundary route={route}>{children}</HelpContentBoundary>}</HelpContentProvider>;
}
