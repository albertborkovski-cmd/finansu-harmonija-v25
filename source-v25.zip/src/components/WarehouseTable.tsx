import { translateUi as uiText, useLanguage } from '../i18n/language';
import { useMemo, useRef, useState, type ReactNode } from 'react';
import { Check, Download, Printer } from 'lucide-react';
import { usePersistentState } from '../hooks/usePersistentState';
import { toggleFilteredSelection } from '../lib/tableSelection';
import { TABLE_BATCH_SIZE } from '../lib/tablePaging';
import { warehousePdf } from '../lib/warehouseExport';
import ColumnSettingsPanel, { type ColConfig } from './ColumnSettingsPanel';
import ColumnSortButton, { useMultiColumnSort } from './ColumnSortButton';
import { ColumnSettingsButton } from './ScopedActionButtons';
import OcrSearchField from './OcrSearchField';
import SystemAddFilters from './SystemAddFilters';
import RefreshAllButton from './RefreshAllButton';
import HorizontalTableScrollbar from './HorizontalTableScrollbar';
import TablePagination from './TablePagination';
import { ResizeHandle, useColumnResize } from './useColumnResize';

export type WarehouseTableRow = { id: string; inactive?: boolean; [key: string]: string | number | boolean | undefined };
export function WarehouseCheck({ checked, onChange, label, mixed = false }: { checked: boolean; onChange: () => void; label: string; mixed?: boolean }) {
  return <button type="button" role="checkbox" aria-checked={mixed ? 'mixed' : checked} aria-label={uiText(label)} onClick={onChange} className={`flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-[6px] border ${checked || mixed ? 'border-[#007EA7] bg-[#007EA7] text-white' : 'border-[#A1B6C6] bg-white'}`}>{checked ? <Check size={12} strokeWidth={2.5} /> : mixed ? <span className="h-px w-2 bg-white" /> : null}</button>;
}
const csvCell = (value: unknown) => `"${String(value ?? '').replace(/^[=+@-]/, "'$&").replace(/"/g, '""')}"`;
function exportRows(name: string, columns: ColConfig[], rows: WarehouseTableRow[]) {
  const csv = '\uFEFF' + [columns.map(column => csvCell(column.label)).join(','), ...rows.map(row => columns.map(column => csvCell(row[column.key])).join(','))].join('\r\n');
  const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  const link = document.createElement('a'); link.href = url; link.download = `${name}.csv`; link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
const originalValueLabel = (_key: string, value: string) => value;
export default function WarehouseTable({ scope, title, rows, defaults, renderCell, valueLabel = originalValueLabel, actions, actionColumnWidth = 174, toolbar, onRefresh, onPrint, printLabel, selected, onSelectedChange, showSelectionSummary = true, emptyMessage = 'No records match these filters.' }: {
  scope: string; title: string; rows: WarehouseTableRow[]; defaults: ColConfig[];
  renderCell?: (row: WarehouseTableRow, key: string) => ReactNode;
  valueLabel?: (key: string, value: string) => string;
  actions?: (row: WarehouseTableRow) => ReactNode; toolbar?: ReactNode; onRefresh: () => void;
  actionColumnWidth?: number;
  selected: Set<string>; onSelectedChange: (ids: Set<string>) => void; emptyMessage?: string;
  showSelectionSummary?: boolean;
  onPrint?: () => void; printLabel?: string;
}) {
  const language = useLanguage();
  const [query, setQuery] = useState('');
  const [keys, setKeys] = useState<string[]>([]);
  const [values, setValues] = useState<Record<string, string[]>>({});
  const [columns, setColumns] = usePersistentState<ColConfig[]>(`${scope}:columns`, defaults);
  const [showColumns, setShowColumns] = useState(false);
  const [page, setPage] = useState(1);
  const [exportError, setExportError] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);
  const { startResize } = useColumnResize(columns, setColumns);
  const filtered = useMemo(() => rows.filter(row => (!query.trim() || defaults.some(column => [String(row[column.key] ?? ''), valueLabel(column.key, String(row[column.key] ?? ''))].some(label => label.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase())))) && keys.every(key => !values[key]?.length || values[key].includes(String(row[key] ?? '—')))), [rows, query, keys, values, defaults, valueLabel, language]);
  const filterColumns = useMemo(() => defaults.map(column => ({ key: column.key, label: column.label, options: [...new Set(rows.map(row => String(row[column.key] ?? '—')))], optionLabels: Object.fromEntries(rows.map(row => { const value = String(row[column.key] ?? '—'); return [value, valueLabel(column.key, value)]; })) })), [defaults, rows, valueLabel, language]);
  const { sortedRows, directionFor, changeSort } = useMultiColumnSort(filtered, (row, key: string) => row[key] as string | number);
  const visible = columns.filter(column => column.visible);
  const actionsWidth = actions ? actionColumnWidth : 0;
  const gridTemplateColumns = `42px ${visible.map(column => `${column.width}px`).join(' ')} minmax(${actionsWidth}px,1fr)`;
  const minWidth = 42 + visible.reduce((sum, column) => sum + column.width, 0) + actionsWidth;
  const allChecked = filtered.length > 0 && filtered.every(row => selected.has(row.id));
  const safePage = Math.min(page, Math.max(1, Math.ceil(sortedRows.length / TABLE_BATCH_SIZE)));
  return <>
    <div className="flex min-h-8 shrink-0 flex-wrap items-center justify-between gap-2">
      <div className="flex min-w-0 flex-wrap items-center gap-1.5 [&>.system-add-filters]:min-w-0 [&>.system-add-filters]:shrink [&>.system-add-filters]:flex-wrap">
        <OcrSearchField value={query} ariaLabel={`${uiText('Search')} · ${title}`} onChange={value => { setQuery(value); setPage(1); }} />
        <SystemAddFilters columns={filterColumns} activeKeys={keys} values={values} onActiveKeysChange={setKeys} onValuesChange={setValues} />
      </div>
      <div className="ml-auto flex shrink-0 flex-wrap items-center justify-end gap-4">
        {toolbar}
        <div data-table-workspace-tools role="group" className="flex h-7 shrink-0 items-center gap-4" aria-label={`${title} table tools`}>
          <ColumnSettingsButton onClick={() => setShowColumns(true)} />
          <button type="button" data-button-family="export" aria-label={uiText("EXPORT")} title={uiText("EXPORT")} onClick={() => exportRows(title, visible, sortedRows)} className="flex h-4 w-4 shrink-0 items-center justify-center text-[#7288A3] transition-colors hover:text-[#007EA7] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#007EA7]"><Download size={16} /></button>
          <button type="button" aria-label={uiText(printLabel || `Print ${title}`)} title={uiText(printLabel || 'PRINT')} className="flex h-4 w-4 shrink-0 items-center justify-center text-[#7288A3] transition-colors hover:text-[#007EA7] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#007EA7]" onClick={() => { if (onPrint) { onPrint(); return; } void warehousePdf(title, visible.map(column => column.label), sortedRows.map(row => visible.map(column => String(row[column.key] ?? '—')))).catch(() => setExportError('The PDF could not be generated.')); }}><Printer size={16} className="shrink-0" /></button>
          <RefreshAllButton onRefresh={onRefresh} />
        </div>
      </div>
    </div>
    {showSelectionSummary && selected.size > 0 && <div className="flex shrink-0 items-center gap-3 text-[11px] text-[#7288A3]"><span>{selected.size}{uiText(" selected")}</span><button className="text-[#007EA7] hover:underline" onClick={() => onSelectedChange(new Set())}>{uiText("Clear selection")}</button></div>}
    {exportError && <p role="alert" className="text-[12px] text-red-700">{uiText(exportError)}</p>}
    <div ref={scrollRef} role="region" tabIndex={0} aria-label={`${title} records`} className="min-h-0 flex-1 overflow-auto overscroll-contain scrollbar-hide">
      <div role="table" aria-label={uiText(title)} style={{ minWidth }} className="w-full font-montserrat text-[12px] leading-[18px]">
        <div role="row" className="system-table-header-row sticky top-0 z-10 mb-1 grid h-9 border-b border-[#E5EDF9] bg-white font-medium" style={{ gridTemplateColumns }}>
          <div role="columnheader" className="system-table-select-cell"><WarehouseCheck label={`Select all filtered ${title}`} checked={allChecked} mixed={!allChecked && filtered.some(row => selected.has(row.id))} onChange={() => onSelectedChange(toggleFilteredSelection(selected, filtered.map(row => row.id)))} /></div>
          {visible.map(column => <div role="columnheader" aria-sort={directionFor(column.key) === 'asc' ? 'ascending' : directionFor(column.key) === 'desc' ? 'descending' : 'none'} key={column.key} className="relative flex min-w-0 items-start gap-1.5 px-3"><span className="min-w-0 truncate" title={uiText(column.label)}>{uiText(column.label)}</span><ColumnSortButton columnLabel={uiText(column.label)} direction={directionFor(column.key)} onDirectionChange={direction => changeSort(column.key, direction)} /><ResizeHandle onMouseDown={event => startResize(columns.findIndex(row => row.key === column.key), event)} /></div>)}
          <div role="columnheader" className="system-table-row-actions"><span className="sr-only">{uiText("Actions")}</span></div>
        </div>
        {sortedRows.slice(0, safePage * TABLE_BATCH_SIZE).map((row, index) => <div key={row.id} role="row" data-record-inactive={row.inactive || undefined} className={`mb-0.5 grid h-10 items-center rounded-lg font-normal ${selected.has(row.id) ? 'bg-[#E5EDF9]' : index % 2 ? 'bg-white' : 'bg-[#F8FDFF]'} transition-colors hover:bg-[#E7F4F9]`} style={{ gridTemplateColumns }}>
          <div role="cell" className="pl-3"><WarehouseCheck label={`Select ${String(row.number ?? row.name ?? row.code ?? row.id)}`} checked={selected.has(row.id)} onChange={() => onSelectedChange(toggleFilteredSelection(selected, [row.id]))} /></div>
          {visible.map(column => <div key={column.key} role="cell" className="min-w-0 truncate px-3" title={valueLabel(column.key, String(row[column.key] ?? ''))}>{renderCell?.(row, column.key) ?? valueLabel(column.key, String(row[column.key] ?? '—'))}</div>)}
          <div role="cell" className="system-table-row-actions flex items-center justify-end gap-2 px-3">{actions?.(row)}</div>
        </div>)}
        {!filtered.length && <div className="py-14 text-center text-[13px] text-[#7288A3]">{uiText(emptyMessage)}</div>}
      </div>
    </div>
    <HorizontalTableScrollbar scrollRef={scrollRef} />
    <TablePagination currentPage={safePage} totalPages={Math.max(1, Math.ceil(sortedRows.length / TABLE_BATCH_SIZE))} itemCount={sortedRows.length} onPageChange={setPage} scrollRef={scrollRef} />
    {showColumns && <ColumnSettingsPanel columns={columns} defaultColumns={defaults} onSave={next => { setColumns(next); setShowColumns(false); }} onClose={() => setShowColumns(false)} />}
  </>;
}
