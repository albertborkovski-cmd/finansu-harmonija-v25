import { useCallback, useEffect, useId, useRef, useState } from 'react';
import { Check, CheckCheck, Loader2, MessageSquare, Send } from 'lucide-react';
import { translateUi as t, useLanguage } from '../i18n/language';
import { getCurrentUserIdentity } from '../lib/currentUser';
import { canUseIssueConversation } from '../lib/documentIssueAccess';
import { issueConversationMessages, unreadIssueMessages, type IssueConversationSide } from '../lib/documentIssueConversation';
import type { DocumentIssue } from '../lib/documentIssues';
import { applyDocumentIssueConversation, supabase, type Company, type DbDocument } from '../lib/supabase';

/** Shared by the accountant's report dialog and the Worker's document editor. */
export default function DocumentIssueConversation({ documentId, companyId, issueId, side = 'accountant', readOnly = false, active = true, fillHeight = false }: {
  documentId: string; companyId: string; issueId: string; side?: IssueConversationSide; readOnly?: boolean; active?: boolean; fillHeight?: boolean;
}) {
  const language = useLanguage();
  const inputId = useId();
  const [issue, setIssue] = useState<DocumentIssue | null>(null);
  const [canSend, setCanSend] = useState(false);
  const [draft, setDraft] = useState('');
  const [error, setError] = useState('');
  const [loadError, setLoadError] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [focusVersion, setFocusVersion] = useState(0);
  const request = useRef(0);
  const sendingRef = useRef(false);
  const readingRef = useRef(false);
  const pending = useRef<{ id: string; text: string } | null>(null);
  const viewport = useRef<HTMLDivElement>(null);
  const nearBottom = useRef(true);
  const identity = getCurrentUserIdentity();
  const load = useCallback(async () => {
    const version = ++request.current;
    try {
      const [documents, companies] = await Promise.all([
        supabase.from('documents').select('*').eq('id', documentId),
        supabase.from('companies').select('*').eq('id', companyId),
      ]);
      if (documents.error || companies.error) throw new Error('Unable to load the issue conversation.');
      const document = documents.data?.[0] as unknown as DbDocument | undefined;
      const company = companies.data?.[0] as unknown as Company | undefined;
      if (!document || document.company_id !== companyId || !company || !canUseIssueConversation(company, side))
        throw new Error('You do not have access to this issue conversation.');
      const current = document.digitization_issues?.find(item => item.id === issueId);
      if (!current) throw new Error('This reported issue is no longer available.');
      if (version !== request.current) return;
      setIssue(current); setCanSend(canUseIssueConversation(company, side, true)); setLoadError('');
    } catch (reason) {
      if (version !== request.current) return;
      setIssue(null); setCanSend(false); setLoadError(reason instanceof Error ? reason.message : 'Unable to load the issue conversation.');
    } finally { if (version === request.current) setLoading(false); }
  }, [documentId, companyId, issueId, side]);
  useEffect(() => {
    void load();
    const refresh = (event: Event) => {
      const detail = (event as CustomEvent).detail;
      if (event.type === 'document-issues-changed' && detail?.documentId !== documentId) return;
      void load();
    };
    const focus = () => { setFocusVersion(value => value + 1); void load(); };
    window.addEventListener('document-issues-changed', refresh);
    window.addEventListener('finansu-harmonija:data-changed', refresh);
    window.addEventListener('storage', refresh);
    window.addEventListener('focus', focus);
    document.addEventListener('visibilitychange', focus);
    const timer = window.setInterval(() => { if (document.visibilityState === 'visible') void load(); }, 8000);
    return () => {
      ++request.current;
      window.removeEventListener('document-issues-changed', refresh);
      window.removeEventListener('finansu-harmonija:data-changed', refresh);
      window.removeEventListener('storage', refresh);
      window.removeEventListener('focus', focus);
      document.removeEventListener('visibilitychange', focus);
      window.clearInterval(timer);
    };
  }, [load, documentId]);
  const unreadIds = issue ? unreadIssueMessages(issue, identity.email, side).map(message => message.id).join(',') : '';
  useEffect(() => {
    if (!active || !unreadIds || readingRef.current || document.visibilityState !== 'visible' || !document.hasFocus()) return;
    readingRef.current = true;
    let saved = false;
    void applyDocumentIssueConversation(documentId, companyId, { type: 'read', issueId, side, messageIds: unreadIds.split(',') })
      .then(async () => { await load(); saved = true; })
      .catch(reason => setError(reason instanceof Error ? reason.message : 'Unable to update read receipts.'))
      .finally(() => { readingRef.current = false; if (saved) setFocusVersion(value => value + 1); });
  }, [documentId, companyId, issueId, side, unreadIds, focusVersion, load, active]);
  const lastMessageId = issue?.messages?.at(-1)?.id || issue?.id;
  useEffect(() => {
    if (nearBottom.current && viewport.current) viewport.current.scrollTop = viewport.current.scrollHeight;
  }, [lastMessageId]);
  const send = async () => {
    if (!draft.trim() || !issue || !canSend || readOnly || sendingRef.current) return;
    sendingRef.current = true; setSending(true); setError('');
    const text = draft.trim();
    if (!pending.current || pending.current.text !== text) pending.current = { id: crypto.randomUUID(), text };
    try {
      const saved = await applyDocumentIssueConversation(documentId, companyId, { type: 'reply', issueId, side,
        messageId: pending.current.id, text });
      setIssue(saved.digitization_issues?.find(item => item.id === issueId) ?? null);
      setDraft(''); pending.current = null; nearBottom.current = true;
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Unable to send the message. Your text has been kept.'); }
    finally { sendingRef.current = false; setSending(false); }
  };
  const disabled = readOnly || !canSend || issue?.status === 'Resolved';
  return <section aria-label={t('Issue conversation')} className={`${fillHeight ? 'flex min-h-0 flex-1 flex-col' : ''} overflow-hidden rounded-xl border border-[#D3E1EC] bg-white font-montserrat text-[12px] text-[#10233A]`}>
    <div className="flex shrink-0 items-center gap-2 border-b border-[#E5EDF9] px-4 py-3"><MessageSquare size={17} className="text-[#007EA7]" />
      <h3 className="font-semibold">{t('Issue conversation')}</h3><span className="ml-auto text-[11px] text-[#7288A3]">{t('Accountant')} ↔ {t('Worker')}</span></div>
    <div ref={viewport} role="log" aria-label={t('Issue messages')} aria-live="polite" aria-relevant="additions" className={`flex ${fillHeight ? 'min-h-0 flex-1' : 'max-h-[340px] min-h-[130px]'} flex-col gap-4 overflow-y-auto overscroll-contain bg-[#FAFCFE] p-4`}
      onScroll={() => { const el = viewport.current; if (el) nearBottom.current = el.scrollHeight - el.scrollTop - el.clientHeight < 48; }}>
      {loading && <p className="text-[#7288A3]">{t('Loading messages…')}</p>}
      {issue && issueConversationMessages(issue).map(message => {
        const outgoing = Boolean(identity.email && message.authorEmail.toLowerCase() === identity.email.toLowerCase());
        const seen = message.readBy?.some(reader => reader.side !== message.authorSide);
        return <article key={message.id} className={`flex w-full flex-col ${outgoing ? 'items-end' : 'items-start'}`}>
          <p className="mb-1 flex max-w-[90%] flex-wrap items-baseline gap-x-2 px-1"><span className="font-semibold">{message.author}</span><span className="text-[11px] text-[#7288A3]">{t(message.authorSide === 'worker' ? 'Worker' : 'Accountant')}</span></p>
          <div className={`max-w-[90%] whitespace-pre-wrap break-words rounded-xl px-4 py-2.5 text-[12px] leading-5 text-[#183047] ${outgoing ? 'bg-[#EDF6F8]' : 'border border-[#DCE7EF] bg-[#FCFDFE]'}`}>{message.text}</div>
          <div className="mt-1 flex items-center gap-2 px-1 text-[10px] text-[#8FA6B8]"><time dateTime={message.sentAt}>{new Date(message.sentAt).toLocaleString(language === 'lt' ? 'lt-LT' : 'en-GB', { dateStyle: 'short', timeStyle: 'short' })}</time>
            {outgoing && !message.id.startsWith('report:') && <span title={t(seen ? 'Message read' : 'Sent')} aria-label={t(seen ? 'Message read' : 'Sent')} className={seen ? 'text-[#007EA7]' : ''}>{seen ? <CheckCheck size={14} /> : <Check size={14} />}</span>}</div>
        </article>;
      })}
    </div>
    {(loadError || error) && <p role="alert" className="px-4 pb-3 text-[#B42318]">{t(loadError || error)}</p>}
    {issue?.status === 'Resolved' ? <p className="border-t border-[#E5EDF9] px-4 py-3 text-[#7288A3]">{t('This issue is fixed. Report a new issue to start another conversation.')}</p>
      : <form onSubmit={event => { event.preventDefault(); void send(); }} className="shrink-0 border-t border-[#E5EDF9] p-3">
        <div className="flex items-end gap-2.5"><label className="sr-only" htmlFor={inputId}>{t('Message to Worker / accountant')}</label>
          <textarea id={inputId} rows={2} maxLength={5000} value={draft} disabled={disabled || sending} onChange={event => setDraft(event.target.value)}
            onKeyDown={event => { if (event.key === 'Enter' && !event.shiftKey && !event.nativeEvent.isComposing) { event.preventDefault(); void send(); } }}
            placeholder={t(side === 'worker' ? 'Ask the accountant for clarification…' : 'Reply to Worker or add more details…')}
            className="min-h-[60px] min-w-0 flex-1 resize-y rounded-lg border border-[#CEDDE8] bg-white p-3 text-[12px] leading-5 text-[#183047] outline-none placeholder:text-[#A8BCCB] focus:border-[#007EA7] focus:ring-2 focus:ring-[#DDF1F6] disabled:bg-[#F7FAFC] disabled:opacity-60" />
          <button type="submit" disabled={disabled || sending || !draft.trim()} aria-label={t('Send message')} title={t('Send message')} className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-[#CEDDE8] bg-white text-[#7288A3] hover:border-[#9EB5C6] hover:bg-[#F7FAFC] hover:text-[#007EA7] active:border-[#007EA7] active:bg-[#007EA7] active:text-white disabled:cursor-not-allowed disabled:opacity-40">{sending ? <Loader2 size={17} className="animate-spin" /> : <Send size={17} strokeWidth={1.7} />}</button>
        </div><p className="mt-2 text-[10px] text-[#8FA6B8]">{t(disabled ? 'You have view-only access to this conversation.' : 'Enter to send · Shift + Enter for a new line')}</p>
      </form>}
  </section>;
}
