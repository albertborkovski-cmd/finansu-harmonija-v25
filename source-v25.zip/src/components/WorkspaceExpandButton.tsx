import { translateUi as uiText } from '../i18n/language';
import { Maximize2, Minimize2 } from 'lucide-react';

export default function WorkspaceExpandButton({ expanded, onClick }: { expanded: boolean; onClick: () => void }) {
  return <button type="button" data-button-family="workspace-expand"
    aria-label={expanded ? uiText('Exit full screen') : uiText('Expand workspace')}
    aria-pressed={expanded}
    title={expanded ? uiText('Exit full screen (Esc)') : uiText('Expand workspace')}
    onClick={onClick}
    className="flex h-4 w-4 shrink-0 items-center justify-center text-[#7288A3] transition-colors hover:text-[#007EA7] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#007EA7]">
    {expanded ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
  </button>;
}
