import { translateUi as uiText } from '../i18n/language';
import { useCallback, useEffect, useLayoutEffect, useRef, useState, type RefObject } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import useAppTableFooterPosition from '../hooks/useAppTableFooterPosition';
import useFrozenTableHeaders from '../hooks/useFrozenTableHeaders';
import TableWorkspaceExpand from './TableWorkspaceExpand';
import { horizontalScrollbarGeometry, observeHorizontalTableScroll, type HorizontalScrollbarGeometry } from '../lib/horizontalTableScroll';

interface HorizontalTableScrollbarProps {
  scrollRef?: RefObject<HTMLElement>;
  className?: string;
  fixed?: boolean;
  expandable?: boolean;
  /** Embedded form tables retain their CSS height instead of filling the workspace. */
  viewportSizing?: 'available' | 'content';
}

/**
 * Shared system horizontal table scrollbar.
 *
 * Main application tables use the same viewport slot as All Documents.
 * Dialogs and other fixed overlays automatically fall back to
 * their local document flow in useAppTableFooterPosition.
 */
export default function HorizontalTableScrollbar({ scrollRef, className = '', fixed = true, expandable = true, viewportSizing = 'available' }: HorizontalTableScrollbarProps) {
  const rootRef = useRef<HTMLDivElement>(null);
  useFrozenTableHeaders(scrollRef, rootRef, viewportSizing);
  const trackRef = useRef<HTMLDivElement>(null);
  const [geometry, setGeometry] = useState(() => horizontalScrollbarGeometry({ scrollWidth: 0, clientWidth: 0, scrollLeft: 0 }, 0));
  const binding = useRef<{ viewport: HTMLElement; track: HTMLElement; dispose: () => void }>();
  const [dragging, setDragging] = useState(false);
  const dragPointer = useRef<number | null>(null);
  const dragStartX = useRef(0);
  const dragStartScroll = useRef(0);
  const calculatedFixedPosition = useAppTableFooterPosition(rootRef, 28, Infinity, fixed, scrollRef);
  const fixedPosition = fixed ? calculatedFixedPosition : undefined;

  const getViewport = useCallback(() => scrollRef?.current ?? rootRef.current?.previousElementSibling as HTMLElement | null, [scrollRef]);
  const applyGeometry = useCallback((next: HorizontalScrollbarGeometry) => {
    setGeometry(previous => Object.keys(next).every(key => previous[key as keyof typeof next] === next[key as keyof typeof next]) ? previous : next);
  }, []);

  // A stable ref object may point to a different table after loading or switching tabs.
  useLayoutEffect(() => {
    const viewport = getViewport(), track = trackRef.current;
    if (binding.current?.viewport === viewport && binding.current?.track === track) return;
    binding.current?.dispose(); binding.current = undefined;
    if (viewport && track) binding.current = { viewport, track, dispose: observeHorizontalTableScroll(viewport, track, applyGeometry) };
  });
  useEffect(() => () => { binding.current?.dispose(); binding.current = undefined; }, []);

  const { ratio } = geometry;
  const canScroll = geometry.maximum > 0 && geometry.trackWidth > 0;
  const atStart = !canScroll || ratio <= 0.001;
  const atEnd = !canScroll || ratio >= 0.999;

  const scrollByStep = (direction: -1 | 1) => {
    const element = getViewport();
    element?.scrollBy({ left: direction * Math.max(200, (element?.clientWidth ?? 0) * 0.55), behavior: 'smooth' });
  };

  const moveFromPointer = (clientX: number) => {
    const element = getViewport();
    const track = trackRef.current;
    if (!element || !track || !canScroll) return;
    const rect = track.getBoundingClientRect();
    const current = horizontalScrollbarGeometry(element, track.clientWidth);
    const nextRatio = Math.min(1, Math.max(0, (clientX - rect.left - current.thumbWidth / 2) / Math.max(1, current.travel)));
    element.scrollLeft = nextRatio * current.maximum;
    applyGeometry(horizontalScrollbarGeometry(element, track.clientWidth));
  };

  const startDrag = (event: React.PointerEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    const element = getViewport();
    if (!element || !canScroll) return;
    dragStartX.current = event.clientX;
    dragStartScroll.current = element.scrollLeft;
    dragPointer.current = event.pointerId;
    setDragging(true);
    event.currentTarget.setPointerCapture(event.pointerId);
  };

  const drag = (event: React.PointerEvent<HTMLDivElement>) => {
    const element = getViewport();
    const track = trackRef.current;
    if (dragPointer.current !== event.pointerId || !element || !track) return;
    const current = horizontalScrollbarGeometry(element, track.clientWidth);
    element.scrollLeft = dragStartScroll.current + ((event.clientX - dragStartX.current) / Math.max(1, current.travel)) * current.maximum;
    applyGeometry(horizontalScrollbarGeometry(element, track.clientWidth));
  };

  const endDrag = () => { dragPointer.current = null; setDragging(false); };
  const onKeyDown = (event: React.KeyboardEvent<HTMLDivElement>) => {
    const element = getViewport();
    if (!element || !canScroll || !['ArrowLeft', 'ArrowRight', 'Home', 'End', 'PageUp', 'PageDown'].includes(event.key)) return;
    event.preventDefault();
    if (event.key === 'Home') element.scrollLeft = 0;
    else if (event.key === 'End') element.scrollLeft = element.scrollWidth - element.clientWidth;
    else scrollByStep(event.key === 'ArrowLeft' || event.key === 'PageUp' ? -1 : 1);
    if (trackRef.current) applyGeometry(horizontalScrollbarGeometry(element, trackRef.current.clientWidth));
  };

  return (
    <div
      ref={rootRef}
      style={fixedPosition}
      data-table-scrollbar={fixedPosition ? 'fixed' : 'local'}
      className={`shared-table-scrollbar relative isolate ${fixedPosition ? 'shared-table-scrollbar--fixed z-30' : viewportSizing === 'content' ? 'z-20' : 'sticky bottom-0 left-0 z-20 mt-auto'} mx-auto flex min-h-11 w-full max-w-[1384px] flex-shrink-0 items-center gap-2 bg-white px-1 pb-3 pt-2 ${className}`}
      aria-label={uiText("Horizontal table scroll")}
    >
      {expandable && <TableWorkspaceExpand scrollRef={scrollRef} scrollbarRef={rootRef} />}
      <button type="button" aria-label={uiText("Scroll table left")} disabled={atStart} onClick={() => scrollByStep(-1)} className="system-scrollbar-arrow flex h-5 w-5 flex-shrink-0 items-center justify-center rounded-full bg-white transition-colors disabled:cursor-not-allowed">
        <ChevronLeft size={12} />
      </button>
      <div ref={trackRef} role="scrollbar" aria-label={uiText('Horizontal table scroll')} tabIndex={canScroll ? 0 : -1} aria-orientation="horizontal" aria-disabled={!canScroll} aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(ratio * 100)} onKeyDown={onKeyDown} onPointerDown={(event) => moveFromPointer(event.clientX)} className={`system-scrollbar-track relative h-2 flex-1 touch-none rounded-full focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#007EA7] ${canScroll ? 'cursor-pointer' : 'cursor-default'}`}>
        <div data-dragging={dragging} onPointerDown={startDrag} onPointerMove={drag} onPointerUp={endDrag} onPointerCancel={endDrag} onLostPointerCapture={endDrag} className={`system-scrollbar-thumb absolute top-px h-[6px] touch-none rounded-full ${canScroll ? (dragging ? 'cursor-grabbing' : 'cursor-grab') : 'cursor-default'}`} style={{ width: geometry.trackWidth ? geometry.thumbWidth : '100%', left: geometry.thumbLeft }} />
      </div>
      <button type="button" aria-label={uiText("Scroll table right")} disabled={atEnd} onClick={() => scrollByStep(1)} className="system-scrollbar-arrow flex h-5 w-5 flex-shrink-0 items-center justify-center rounded-full bg-white transition-colors disabled:cursor-not-allowed">
        <ChevronRight size={12} />
      </button>
    </div>
  );
}
