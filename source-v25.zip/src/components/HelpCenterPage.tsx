import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, ArrowRight, BookOpen, Building2, ChevronDown, ChevronRight, Code2, FileText, Globe2, Layers3, Search, ShieldCheck, UploadCloud, X, Workflow, MessagesSquare } from 'lucide-react';
import { useLanguage } from '../i18n/language';
import { HELP_FEATURED as BASE_FEATURED, helpCenterHref, searchHelp, type HelpCategory, type HelpEntry } from '../lib/helpCenterCatalog';
import { visibleHelpCategories } from '../lib/helpEditorialCatalog';
import { useHelpContent } from './HelpContentProvider';
import HelpUserGuide from './HelpUserGuide';
import { helpArticleKey } from '../lib/helpContent';

const icons = { system: Building2, security: ShieldCheck, browser: Globe2, api: Code2, collection: UploadCloud, integration: Layers3, workflow: Workflow, communication: MessagesSquare };
const focus = 'focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#007EA7]';
function TopicNavigation({ entries, lang, current, parent = '' }: { entries: HelpEntry[]; lang: 0 | 1; current?: string; parent?: string }) {
  const keys = new Set(entries.map(entry => helpArticleKey(entry.href)));
  const children = entries.filter(entry => (entry.parentKey && keys.has(entry.parentKey) ? entry.parentKey : '') === parent);
  return <ul className="my-1 ml-3 border-l border-[#D3E1EC] pl-2">{children.map(entry => <li key={entry.href}><a href={entry.href} aria-current={current === entry.id ? 'page' : undefined} className={`block rounded-md px-2 py-2 text-[11px] leading-5 hover:bg-[#F3F8FB] ${current === entry.id ? 'font-semibold text-[#007EA7]' : 'text-[#7288A3]'} ${focus}`}>{entry.title[lang] || entry.title[1 - lang]}</a>{entries.some(child => child.parentKey === helpArticleKey(entry.href)) && <TopicNavigation entries={entries} lang={lang} current={current} parent={helpArticleKey(entry.href)} />}</li>)}</ul>;
}
function EntryList({ entries, lang }: { entries: HelpEntry[]; lang: 0 | 1 }) {
  return <ul className="divide-y divide-[#E5EDF9] rounded-xl border border-[#D3E1EC] bg-white">{entries.map(entry => <li key={entry.id}><a href={entry.href} className={`group flex items-start gap-3 px-5 py-4 transition-colors hover:bg-[#F3F8FB] ${focus}`}>
    <FileText size={18} className="mt-1 shrink-0 text-[#7288A3]" aria-hidden="true" />
    <span className="min-w-0 flex-1"><span className="block text-[14px] font-semibold leading-6 text-[#10233A] group-hover:text-[#007EA7]">{entry.title[lang]}</span><span className="mt-1 block text-[12px] leading-5 text-[#7288A3]">{entry.description[lang]}</span></span><ChevronRight size={17} className="mt-1 shrink-0 text-[#7288A3]" aria-hidden="true" />
  </a></li>)}</ul>;
}
function CategoryCard({ category, lang }: { category: HelpCategory; lang: 0 | 1 }) {
  const Icon = icons[category.icon];
  return <a href={helpCenterHref(category.id)} className={`group flex min-h-[196px] flex-col rounded-xl border border-[#D3E1EC] bg-white p-5 transition-colors hover:border-[#7AB5CC] hover:bg-[#F8FCFD] ${focus}`}>
    <span className="mb-4 flex h-10 w-10 items-center justify-center rounded-lg bg-[#EAF4F9] text-[#007EA7]"><Icon size={22} aria-hidden="true" /></span>
    <h3 className="text-[14px] font-semibold leading-6 group-hover:text-[#007EA7]">{category.title[lang]}</h3><p className="mt-1 text-[12px] leading-5 text-[#7288A3]">{category.description[lang]}</p>
    <span className="mt-auto flex items-center justify-between pt-4 text-[11px] font-medium text-[#7288A3]"><span>{lang ? 'Temų' : 'Articles'}: {category.entries.length}</span><ArrowRight size={15} className="text-[#007EA7]" aria-hidden="true" /></span>
  </a>;
}

export default function HelpCenterPage() {
  const lt = useLanguage() === 'lt', lang = lt ? 1 : 0;
  const { state } = useHelpContent();
  const HELP_CATEGORIES = visibleHelpCategories(state);
  const HELP_FEATURED = BASE_FEATURED.flatMap(item => HELP_CATEGORIES.flatMap(category => category.entries).filter(entry => entry.href === item.href));
  const params = new URLSearchParams(window.location.hash.split('?')[1] || '');
  const categoryId = params.get('category'), articleId = params.get('article');
  const category = HELP_CATEGORIES.find(item => item.id === categoryId);
  const article = category?.entries.find(item => item.id === articleId && item.paragraphs);
  const [query, setQuery] = useState('');
  const [expanded, setExpanded] = useState<string[]>(category ? [category.id] : []);
  const [mobileMenu, setMobileMenu] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const main = useRef<HTMLElement>(null);
  const results = searchHelp(query, lang, HELP_CATEGORIES);
  const pageTitle = `${article?.title[lang] || category?.title[lang] || (lt ? 'Pagalbos centras' : 'Help centre')} · Finansų harmonija`;
  useEffect(() => {
    document.title = pageTitle;
    window.scrollTo(0, 0);
  }, [pageTitle]);
  useEffect(() => {
    const keydown = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); input.current?.focus(); }
    };
    window.addEventListener('keydown', keydown);
    return () => window.removeEventListener('keydown', keydown);
  }, []);
  return <div className="min-h-screen bg-[#F7FAFC] font-montserrat text-[#10233A]">
    <a href="#help-main" onClick={event => { event.preventDefault(); main.current?.focus(); main.current?.scrollIntoView(); }} className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-3 focus:z-[100] focus:rounded focus:bg-white focus:p-3">{lt ? 'Pereiti prie turinio' : 'Skip to content'}</a>
    <header className="sticky top-0 z-20 flex h-16 items-center justify-between gap-4 border-b border-[#D3E1EC] bg-white px-5 pr-[120px] sm:px-7 sm:pr-[180px]">
      <a href={helpCenterHref()} className={`flex items-center gap-2.5 ${focus}`}><BookOpen size={24} className="text-[#007EA7]" aria-hidden="true" /><span className="text-[13px] font-semibold sm:text-[15px]">Finansų harmonija<span className="ml-2 hidden border-l border-[#D3E1EC] pl-2 font-normal text-[#7288A3] sm:inline">{lt ? 'Pagalba' : 'Help'}</span></span></a>
      <button type="button" onClick={() => input.current?.focus()} className={`hidden items-center gap-2 rounded-lg border border-[#D3E1EC] px-3 py-1.5 text-[12px] text-[#7288A3] md:flex ${focus}`}><Search size={14} aria-hidden="true" />{lt ? 'Ieškoti' : 'Search'}<kbd className="ml-5 text-[10px]">⌘ / Ctrl K</kbd></button>
    </header>
    <div className="mx-auto grid max-w-[1600px] lg:grid-cols-[260px_minmax(0,1fr)]">
      <aside className="border-b border-[#D3E1EC] bg-white lg:sticky lg:top-16 lg:h-[calc(100vh-64px)] lg:border-b-0 lg:border-r">
        <button type="button" aria-expanded={mobileMenu} aria-controls="help-category-navigation" onClick={() => setMobileMenu(value => !value)} className={`flex w-full items-center justify-between px-5 py-3 text-[13px] font-semibold lg:hidden ${focus}`}>{lt ? 'Pagalbos temos' : 'Help categories'}<ChevronDown size={16} aria-hidden="true" /></button>
        <nav id="help-category-navigation" aria-label={lt ? 'Pagalbos temos' : 'Help categories'} className={`${mobileMenu ? 'block' : 'hidden'} max-h-[60vh] overflow-y-auto p-3 lg:block lg:max-h-full lg:py-5`}>
          {HELP_CATEGORIES.map(item => { const Icon = icons[item.icon], open = expanded.includes(item.id); return <div key={item.id} className="mb-0.5">
            <div className={`flex items-center rounded-lg ${category?.id === item.id ? 'bg-[#E5EDF9] text-[#007EA7]' : 'text-[#526B86] hover:bg-[#F3F8FB]'}`}>
              <a href={helpCenterHref(item.id)} aria-current={category?.id === item.id && !article ? 'page' : undefined} className={`flex min-w-0 flex-1 items-start gap-2.5 px-3 py-2.5 text-[12px] font-medium leading-5 ${focus}`}><Icon size={17} className="mt-0.5 shrink-0" aria-hidden="true" />{item.title[lang]}</a>
              <button type="button" aria-expanded={open} aria-controls={`help-nav-${item.id}`} aria-label={`${open ? (lt ? 'Suskleisti' : 'Collapse') : (lt ? 'Išskleisti' : 'Expand')} ${item.title[lang]}`} onClick={() => setExpanded(current => open ? current.filter(id => id !== item.id) : [...current, item.id])} className={`mr-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-md hover:bg-[#E5EDF9] ${focus}`}>{open ? <ChevronDown size={14} /> : <ChevronRight size={14} />}</button>
            </div>
            {open && <div id={`help-nav-${item.id}`}><TopicNavigation entries={item.entries} lang={lang} current={article?.id} /></div>}
          </div>; })}
        </nav>
      </aside>
      <main ref={main} tabIndex={-1} id="help-main" className="min-w-0 scroll-mt-16 px-5 py-8 outline-none sm:px-8 lg:px-10 lg:py-10">
        <div className="mx-auto max-w-[1020px]">
          {(category || article) && <nav aria-label={lt ? 'Kelias' : 'Breadcrumb'} className="mb-6 flex flex-wrap items-center gap-2 text-[12px] text-[#7288A3]"><a href={helpCenterHref()} className={`text-[#007EA7] ${focus}`}>{lt ? 'Pagalbos centras' : 'Help centre'}</a><ChevronRight size={13} /><a href={helpCenterHref(category!.id)} className={`text-[#007EA7] ${focus}`}>{category!.title[lang]}</a>{article && <><ChevronRight size={13} /><span>{article.title[lang]}</span></>}</nav>}
          <h1 className={`font-semibold tracking-[-0.03em] ${category ? 'text-[27px] leading-9' : 'max-w-[650px] text-[32px] leading-[1.25] sm:text-[38px]'}`}>{article?.title[lang] || category?.title[lang] || (lt ? 'Patarimai ir atsakymai iš Finansų harmonijos komandos' : 'Advice and answers from the Finansų harmonija team')}</h1>
          <p className="mt-3 max-w-[700px] text-[13px] leading-6 text-[#7288A3]">{article?.description[lang] || category?.description[lang] || (lt ? 'Raskite instrukcijas pagal darbo etapą arba naudojamą apskaitos sistemą.' : 'Find instructions by workflow stage or accounting system.')}</p>
          <div role="search" className="mb-8 mt-6 max-w-[660px]">
            <label className="flex h-12 items-center gap-3 rounded-xl border border-[#C4D8E6] bg-white px-4 shadow-sm focus-within:border-[#007EA7] focus-within:ring-2 focus-within:ring-[#007EA7]/10"><Search size={18} className="shrink-0 text-[#7288A3]" aria-hidden="true" /><input ref={input} value={query} onChange={event => setQuery(event.target.value)} onKeyDown={event => { if (event.key === 'Escape') setQuery(''); }} aria-label={lt ? 'Ieškoti pagalbos straipsnių' : 'Search help articles'} placeholder={lt ? 'Ieškokite straipsnių, sistemų ar klaidų…' : 'Search articles, systems or errors…'} className="min-w-0 flex-1 bg-transparent text-[13px] outline-none placeholder:text-[#8CA1B4]" />{query && <button type="button" onClick={() => { setQuery(''); input.current?.focus(); }} aria-label={lt ? 'Išvalyti paiešką' : 'Clear search'} className={`rounded p-1 text-[#7288A3] ${focus}`}><X size={16} /></button>}</label>
          </div>
          {query.trim() ? <section aria-label={lt ? 'Paieškos rezultatai' : 'Search results'}><p role="status" className="mb-4 text-[12px] text-[#7288A3]">{lt ? 'Rasta temų' : 'Articles found'}: {results.length}</p>{results.length ? <EntryList entries={results.map(result => ({ ...result.entry, id: result.entry.href, description: [result.category.title[0] + ' · ' + result.entry.description[0], result.category.title[1] + ' · ' + result.entry.description[1]] }))} lang={lang} /> : <div className="rounded-xl border border-[#D3E1EC] bg-white p-7 text-[13px] text-[#7288A3]">{lt ? 'Pagal šią užklausą temų nerasta. Pabandykite sistemos pavadinimą, lauko vardą arba klaidos kodą.' : 'No matching articles. Try a system name, field name or error code.'}</div>}</section>
            : article ? <article className="rounded-xl border border-[#D3E1EC] bg-white p-6 sm:p-8">{article.guide ? <HelpUserGuide guide={article.guide} lang={lang} /> : article.paragraphs!.map(paragraph => <p key={paragraph[0]} className="mb-5 text-[14px] leading-7 text-[#526B86] last:mb-0">{paragraph[lang]}</p>)}<a href={helpCenterHref(category!.id)} className={`mt-7 inline-flex items-center gap-2 text-[12px] font-semibold text-[#007EA7] ${focus}`}><ArrowLeft size={14} />{lt ? 'Visos skilties temos' : 'All category articles'}</a></article>
              : category ? <EntryList entries={category.entries} lang={lang} />
                : <><section aria-labelledby="featured-help-heading" className="mb-10"><h2 id="featured-help-heading" className="mb-4 text-[16px] font-semibold">{lt ? 'Nuo ko pradėti' : 'Start here'}</h2><EntryList entries={HELP_FEATURED} lang={lang} /></section><section aria-labelledby="help-collections-heading"><h2 id="help-collections-heading" className="mb-5 text-[21px] font-semibold">{lt ? 'Kategorijos' : 'Collections'}</h2><div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{HELP_CATEGORIES.map(item => <CategoryCard key={item.id} category={item} lang={lang} />)}</div></section></>}
          <footer className="mt-12 border-t border-[#D3E1EC] py-6 text-[12px] text-[#7288A3]">Finansų harmonija · {lt ? 'Pagalbos centras' : 'Help centre'}</footer>
        </div>
      </main>
    </div>
  </div>;
}
