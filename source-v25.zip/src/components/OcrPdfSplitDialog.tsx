import { useEffect, useId, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Plus, Scissors, X } from 'lucide-react';
import { translateUi as uiText } from '../i18n/language';
import DocumentFileViewer from './DocumentFileViewer';
import { readPdfSource, splitPdfSource, validatePdfPageGroups, type PdfPageGroup } from '../lib/ocrPdfSplit';

export default function OcrPdfSplitDialog({ url, filename, onClose, onSplit }: {
  url: string; filename: string; onClose: () => void; onSplit: (groups: PdfPageGroup[], requestId: string) => Promise<void>;
}) {
  const titleId = useId(), requestId = useRef(crypto.randomUUID()), pending = useRef(false);
  const [count, setCount] = useState(0), [groups, setGroups] = useState<PdfPageGroup[]>([]);
  const [error, setError] = useState(''), [busy, setBusy] = useState(false);
  const [parts, setParts] = useState<{ name: string; pages: number[]; url: string }[]>([]), [previewIndex, setPreviewIndex] = useState(0);
  useEffect(() => { setParts([]); setPreviewIndex(0); }, [groups]);
  useEffect(() => {
    let cancelled = false;
    readPdfSource(url).then(pdf => {
      if (cancelled) return;
      const pages = pdf.getPageCount();
      if (pages < 2) throw new Error('The PDF must contain at least two pages.');
      const name = filename.replace(/\.pdf$/i, '');
      setCount(pages); setGroups([{ name: `${name}-1`, pages: '1' }, { name: `${name}-2`, pages: pages === 2 ? '2' : `2-${pages}` }]);
    }).catch(cause => { if (!cancelled) setError(cause instanceof Error ? cause.message : 'The original PDF could not be loaded.'); });
    return () => { cancelled = true; };
  }, [url, filename]);
  const close = () => { if (!pending.current) onClose(); };
  const submit = async () => {
    if (pending.current || !parts.length) return;
    try {
      validatePdfPageGroups(groups, count);
      pending.current = true; setBusy(true); setError('');
      await onSplit(groups, requestId.current);
      onClose();
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Could not split the PDF. No pages have been removed.'); }
    finally { pending.current = false; setBusy(false); }
  };
  const preview = async () => {
    if (pending.current) return;
    pending.current = true; setBusy(true); setError('');
    try { setParts(await splitPdfSource(url, groups)); setPreviewIndex(0); }
    catch (cause) { setError(cause instanceof Error ? cause.message : 'Could not create preview.'); }
    finally { pending.current = false; setBusy(false); }
  };
  return createPortal(<div className="fixed inset-0 z-[5400] flex items-center justify-center bg-[#10233A]/30 p-4 font-montserrat">
    <section role="dialog" aria-modal="true" aria-labelledby={titleId} aria-busy={busy} className="flex h-[88vh] w-full max-w-[1120px] flex-col overflow-hidden rounded-xl border border-[#D3E1EC] bg-white shadow-xl">
      <header className="flex items-center gap-3 border-b border-[#E5EDF9] px-5 py-4"><Scissors size={20} className="text-[#007EA7]" /><h2 id={titleId} className="flex-1 text-lg font-semibold text-[#10233A]">{uiText('Split documents')}</h2><button type="button" aria-label={uiText('Close')} disabled={busy} onClick={close}><X size={20} /></button></header>
      <div className="flex min-h-0 flex-1 flex-col overflow-y-auto md:grid md:grid-cols-[minmax(0,1fr)_380px] md:overflow-hidden">
        <div className="h-[300px] shrink-0 overflow-hidden border-b border-[#E5EDF9] md:h-full md:min-h-0 md:border-b-0 md:border-r"><DocumentFileViewer url={parts[previewIndex]?.url || url} filename={parts[previewIndex]?.name || filename} kind="pdf" embedded /></div>
        <div className="space-y-4 p-5 md:overflow-y-auto">
          <p className="text-xs leading-5 text-[#7288A3]">{uiText('Assign every page exactly once. Each group becomes a separate PDF in Uploaded documents for OCR processing. The original file is retained.')}</p>
          {count > 0 && <p className="text-xs font-semibold text-[#10233A]">{uiText('Pages')}: {count}</p>}
          {groups.map((group, index) => <fieldset key={index} disabled={busy} className="space-y-2 rounded-lg border border-[#D3E1EC] bg-[#F8FBFD] p-3">
            <legend className="px-1 text-xs font-semibold text-[#10233A]">{uiText('Document')} {index + 1}</legend>{groups.length > 2 && <button type="button" aria-label={`${uiText('Remove group')} ${index + 1}`} onClick={() => setGroups(values => values.filter((_, i) => i !== index))} className="float-right"><X size={16} /></button>}
            <label className="block text-xs text-[#7288A3]">{uiText('File name')}<input value={group.name} maxLength={120} onChange={event => setGroups(values => values.map((value, i) => i === index ? { ...value, name: event.target.value } : value))} className="mt-1 w-full rounded-md border border-[#D3E1EC] bg-white px-2 py-2 text-[#10233A]" /></label>
            <label className="block text-xs text-[#7288A3]">{uiText('Pages')}<input value={group.pages} placeholder="1-2, 4" onChange={event => setGroups(values => values.map((value, i) => i === index ? { ...value, pages: event.target.value } : value))} className="mt-1 w-full rounded-md border border-[#D3E1EC] bg-white px-2 py-2 text-[#10233A]" /></label>
          </fieldset>)}
          <button type="button" disabled={busy || !count || groups.length >= count} onClick={() => setGroups(values => [...values, { name: `${filename.replace(/\.pdf$/i, '')}-${values.length + 1}`, pages: '' }])} className="flex items-center gap-2 text-xs font-semibold text-[#007EA7] disabled:opacity-50"><Plus size={16} />{uiText('Add document')}</button>
          <button type="button" disabled={busy || !count} onClick={() => void preview()} className="rounded-md border border-[#D3E1EC] px-3 py-2 text-xs font-semibold text-[#007EA7] disabled:opacity-50">{uiText('Preview structure')}</button>
          {parts.length > 0 && <section className="space-y-2"><h3 className="text-xs font-semibold">{uiText('Future document structure')}</h3>{parts.map((part, index) => <button type="button" key={part.name} onClick={() => setPreviewIndex(index)} className={`block w-full rounded-md border p-2 text-left text-xs ${previewIndex === index ? 'border-[#007EA7] bg-[#EAF4F8]' : 'border-[#D3E1EC]'}`}>{part.name} · {uiText('Pages')}: {part.pages.join(', ')}</button>)}</section>}
          {error && <p role="alert" className="rounded-md bg-[#FFF0F0] p-3 text-xs leading-5 text-[#B42318]">{uiText(error)}</p>}
        </div>
      </div>
      <footer className="flex justify-end gap-3 border-t border-[#E5EDF9] px-5 py-4"><button type="button" disabled={busy} onClick={close} className="rounded-lg border border-[#D3E1EC] px-4 py-2 text-sm font-semibold text-[#7288A3]">{uiText('Cancel')}</button><button type="button" disabled={busy || !parts.length} onClick={() => void submit()} className="rounded-lg bg-[#007EA7] px-4 py-2 text-sm font-semibold text-white disabled:opacity-50">{uiText(busy ? 'Saving…' : 'Split and next file')}</button></footer>
    </section>
  </div>, document.body);
}
