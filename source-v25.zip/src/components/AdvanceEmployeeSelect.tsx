import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { loadCompanyAdvanceEmployees } from '../lib/companyAdvanceEmployees';
import { advanceEmployeeName } from '../lib/invoiceAdvanceEmployee';
import { SETTINGS_DATA_CHANGED_EVENT } from '../lib/linkedSettingsData';
import { translateUi as t } from '../i18n/language';
import SearchableSelect, { type SearchableSelectOption } from './SearchableSelect';

export default function AdvanceEmployeeSelect({ companyId, value, label, onChange, disabled = false, className }: {
  companyId: string; value: string; label?: string; onChange: (value: string) => void; disabled?: boolean; className?: string;
}) {
  const [options, setOptions] = useState<SearchableSelectOption[]>([]);
  const [error, setError] = useState('');
  useEffect(() => {
    let active = true, request = 0;
    const refresh = async () => {
      const current = ++request;
      try {
        const result = await supabase.from('companies').select('*').eq('id', companyId);
        const company = result.data?.[0];
        if (result.error || !company) throw new Error('Could not load company employees.');
        const users = loadCompanyAdvanceEmployees({ id: String(company.id), name: String(company.name) });
        if (active && current === request) { setOptions(users.map(user => ({ value: user.id, label: advanceEmployeeName(user), description: user.email }))); setError(''); }
      } catch { if (active && current === request) { setOptions([]); setError('Could not load company employees.'); } }
    };
    void refresh();
    window.addEventListener(SETTINGS_DATA_CHANGED_EVENT, refresh); window.addEventListener('storage', refresh);
    return () => { active = false; window.removeEventListener(SETTINGS_DATA_CHANGED_EVENT, refresh); window.removeEventListener('storage', refresh); };
  }, [companyId]);
  const choices = [{ value: '', label: '—' }, ...options];
  if (value && !options.some(option => option.value === value)) choices.push({ value, label: label || value, disabled: true } as SearchableSelectOption);
  return <div className="min-w-0"><SearchableSelect ariaLabel={t('Advance employee')} value={value} options={choices} onChange={onChange}
    disabled={disabled || Boolean(error)} placeholder={t('Select employee')} portalMenu menuClassName="!z-[5600]"
    className={className || "h-9 w-full min-w-0 rounded-md border border-[#D3E1EC] bg-white px-3 pr-8 font-montserrat text-[12px] text-[#10233A]"} />
    {error && <p role="alert" className="mt-1 text-[11px] text-[#B42318]">{t(error)}</p>}</div>;
}
