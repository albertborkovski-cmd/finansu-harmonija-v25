import { Building2, RefreshCw } from 'lucide-react';
import { translateUi as t, useLanguage } from '../i18n/language';
import { companySaasUsage, SAAS_PRICING, SAAS_PRODUCTS, type CompanySaasPlan } from '../lib/companySaas';
import { contractTierRange, discountedDocumentPrice, hasProgressiveDocumentPricing, type ContractPlan } from '../lib/contractPricing';
import { PageActionButton } from './PageHeader';

/** Same read-only plan and usage presentation in administration and the profile. */
export default function SaasPlanUsageCard({ name, settings, plan, planName, selectedTierId, usage, loading = false, error = '', onRefresh, accountScope = false }: {
  name: string; settings: CompanySaasPlan; plan?: ContractPlan; planName?: string; selectedTierId?: string;
  usage: ReturnType<typeof companySaasUsage>; loading?: boolean; error?: string;
  onRefresh: () => void; accountScope?: boolean;
}) {
  const language = useLanguage();
  const format = (value: number, digits = 1) => new Intl.NumberFormat(language, { maximumFractionDigits: digits }).format(value);
  const progressive = plan && hasProgressiveDocumentPricing(plan);
  const selectedTier = progressive ? plan.tiers.find(tier => tier.id === selectedTierId) : undefined;
  const prices = progressive ? plan.tiers.map(discountedDocumentPrice) : [];
  const price = progressive ? `${format(Math.min(...prices), 4)}–${format(Math.max(...prices), 4)} ct` : `${format(Number(settings.kaina), 6)} EUR`;
  const ready = !loading && !error;
  return <section className="min-w-0 rounded-lg border border-[#D3E1EC] bg-[#F8FAFC] p-5" aria-label={t('Plan usage')}>
    <div className="mb-5 flex items-center gap-3 border-b border-[#E3ECF3] pb-4"><Building2 size={21} className="shrink-0 text-[#7288A3]" /><div className="min-w-0"><h3 className="truncate text-[18px] font-semibold">{name}</h3>{planName && <p className="mt-1 text-[12px] text-[#7288A3]">{t(planName)}</p>}</div></div>
    <dl className="grid grid-cols-1 gap-x-6 gap-y-5 sm:grid-cols-2">
      {[
        ['Product', t(SAAS_PRODUCTS.find(item => item.value === settings.produktas)?.label || '')],
        ['Pricing model', t(SAAS_PRICING.find(item => item.value === settings.kainodara)?.label || '')],
        [settings.periodas === 'month' ? 'Monthly limit' : 'Yearly limit', `${format(Number(settings.kiekis), 0)} ${t('documents')}`],
        [progressive ? 'Document price' : settings.kainodara === 'docs' ? 'Per document' : settings.kainodara === 'users' ? 'Per active user' : 'Per company / period', price],
      ].map(([label, value]) => <div key={label}><dt className="text-[12px] text-[#7288A3]">{t(label)}</dt><dd className="mt-1 text-[16px] font-semibold leading-6">{value}</dd></div>)}
    </dl>
    {selectedTier && <p className="mt-4 rounded-md bg-[#E5EDF9] px-3 py-2 text-[12px] text-[#007EA7]"><strong className="font-semibold">{t('Selected document range')}: </strong>{contractTierRange(selectedTier)} {t('documents')} · {format(discountedDocumentPrice(selectedTier), 4)} ct / {t('document')}</p>}
    <div className="mt-5 border-t border-[#E3ECF3] pt-4" aria-busy={loading}>
      <div className="flex items-center justify-between gap-3"><h4 className="text-[14px] font-semibold">{t('Document usage')}</h4><PageActionButton iconOnly icon={<RefreshCw size={16} className={`shrink-0 ${loading ? 'animate-spin' : ''}`} />} disabled={loading} onClick={onRefresh}>{t('Refresh SaaS usage')}</PageActionButton></div>
      <p className="mt-2 text-[12px] text-[#7288A3]">{usage.from} – {usage.to}</p>
      <div role="progressbar" aria-label={t('SaaS document usage')} aria-valuemin={0} aria-valuemax={100} aria-valuenow={ready ? usage.progress : undefined} aria-valuetext={ready ? `${format(usage.used)} / ${format(Number(settings.kiekis))} ${t('documents')}` : t('Usage unavailable')} className="mt-4 h-2 overflow-hidden rounded-full bg-[#E3ECF3]"><div className={`h-full rounded-full ${usage.exceeded ? 'bg-[#D08A1D]' : 'bg-[#007EA7]'}`} style={{ width: `${ready ? usage.progress : 0}%` }} /></div>
      <div className="mt-2 flex items-center justify-between text-[12px]"><span className="text-[#7288A3]">{t('Used')}: {ready ? format(usage.used, 0) : '—'}</span><strong className="font-semibold tabular-nums">{ready ? `${format(usage.percentage ?? 0)}%` : '—'}</strong></div>
      <dl className="mt-4 grid grid-cols-2 gap-4 border-t border-[#E3ECF3] pt-4">{[['Remaining', usage.remaining], ['Over the limit', usage.exceeded]].map(([label, value]) => <div key={String(label)}><dt className="text-[12px] text-[#7288A3]">{t(String(label))}</dt><dd className="mt-1 text-[20px] font-semibold tabular-nums">{ready && value !== null ? format(Number(value), 0) : '—'}</dd></div>)}</dl>
      <p className="mt-4 text-[11px] leading-5 text-[#7288A3]">{t(accountScope ? 'Usage includes OCR documents available to this account during the current period.' : 'Based on this company’s documents received during the current period.')}</p>
      {error && <p role="alert" className="mt-2 text-[12px] text-[#B42318]">{t(error)}</p>}
    </div>
  </section>;
}
