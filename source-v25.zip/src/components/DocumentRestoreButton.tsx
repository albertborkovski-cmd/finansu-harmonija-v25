import { useRef, useState } from 'react';
import { Loader2, RotateCcw } from 'lucide-react';
import { translateUi as uiText } from '../i18n/language';
import { documentRestoreBlocker } from '../lib/documentRowActions';
import { restoreDeletedDocument, type DbDocument } from '../lib/supabase';

export default function DocumentRestoreButton({ document, allowed, onRestored, onError }: {
  document: Pick<DbDocument, 'id' | 'company_id' | 'document_deletion' | 'number' | 'file_case'>;
  allowed: boolean;
  onRestored: (document: DbDocument) => void;
  onError: (message: string) => void;
}) {
  const saving = useRef(false);
  const [busy, setBusy] = useState(false);
  const blocker = documentRestoreBlocker(document, allowed);
  const restore = async () => {
    if (blocker || saving.current || !document.company_id) return;
    saving.current = true;
    setBusy(true);
    onError('');
    try {
      const restored = await restoreDeletedDocument(document.id, document.company_id, JSON.stringify(document.document_deletion));
      onRestored(restored);
    } catch (error) {
      onError(uiText(error instanceof Error ? error.message : 'The document could not be restored.'));
    } finally {
      saving.current = false;
      setBusy(false);
    }
  };
  return <button type="button" data-button-family="row-restore" data-document-context-action="restore"
    aria-label={`${uiText('Restore document')}: ${document.number || document.file_case || document.id}`}
    title={uiText(blocker || (busy ? 'Restoring…' : 'Restore previous status'))}
    disabled={Boolean(blocker) || busy} aria-busy={busy}
    onClick={event => { event.stopPropagation(); void restore(); }}
    className="flex h-7 w-7 shrink-0 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] transition-colors enabled:hover:border-[#007EA7] enabled:hover:text-[#007EA7] disabled:cursor-not-allowed disabled:opacity-40">
    {busy ? <Loader2 size={14} className="animate-spin" aria-hidden="true" /> : <RotateCcw size={14} aria-hidden="true" />}
  </button>;
}
