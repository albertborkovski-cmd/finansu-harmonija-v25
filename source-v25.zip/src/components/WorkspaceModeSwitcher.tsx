import { PanelsTopLeft } from 'lucide-react';
import { WORKSPACE_MODES, normalizeWorkspaceMode, type WorkspaceMode } from '../lib/workspaceMode';
import { translateUi as uiText } from '../i18n/language';
import SearchableSelect from './SearchableSelect';

export default function WorkspaceModeSwitcher({ value, onChange }: { value: WorkspaceMode; onChange: (value: WorkspaceMode) => void }) {
  return <div data-workspace-mode-switcher className="fixed right-[164px] top-2 z-40 flex h-9 w-[min(252px,calc(100vw-180px))] items-center rounded-md bg-white font-montserrat shadow-sm">
    <PanelsTopLeft aria-hidden="true" size={16} className="pointer-events-none absolute left-2.5 z-10 text-[#7288A3]" />
    <SearchableSelect value={value} options={WORKSPACE_MODES.map(option => ({ ...option }))}
      onChange={next => onChange(normalizeWorkspaceMode(next))} ariaLabel={uiText('Workspace mode')}
      className="h-9 w-full truncate rounded-md border border-[#D3E1EC] bg-white pl-9 pr-8 font-montserrat text-[12px] font-semibold text-[#7288A3] hover:border-[#A1B6C6] hover:text-[#007EA7]" portalMenu />
  </div>;
}
