import { useCallback, useEffect, useRef, useState } from 'react';
import { MessageSquare, Plus } from 'lucide-react';
import { translateUi as t, useLanguage } from '../i18n/language';
import { loadDocumentConversationData, createDocumentConversation, validateDocumentConversationSend } from '../lib/documentChat';
import { canUseIssueConversation } from '../lib/documentIssueAccess';
import { chatWorkerRecipients } from '../lib/newChat';
import { canEditMenu } from '../lib/accessControl';
import GlJournalDialog from './GlJournalDialog';
import ChatsView from './ChatsView';
import DocumentIssueConversation from './DocumentIssueConversation';
import SearchableSelect from './SearchableSelect';
import { PageActionButton } from './PageHeader';

/** One document identity across Worker, TeamLead, issues and the OCR register. */
export default function DocumentChatDialog({ documentId, companyId, side = 'accountant', initialIssueId, onClose }: {
  documentId: string; companyId: string; side?: 'worker' | 'accountant'; initialIssueId?: string; onClose: () => void;
}) {
  return <GlJournalDialog title="Document conversation" onClose={onClose} wide overlayZIndex={6000}>
    <DocumentConversationPanel documentId={documentId} companyId={companyId} side={side} initialIssueId={initialIssueId} />
  </GlJournalDialog>;
}

export function DocumentConversationPanel({ documentId, companyId, side = 'accountant', initialIssueId, active = true, fillHeight = false }: {
  documentId: string; companyId: string; side?: 'worker' | 'accountant'; initialIssueId?: string; active?: boolean; fillHeight?: boolean;
}) {
  const lt = useLanguage() === 'lt';
  const [data, setData] = useState<Awaited<ReturnType<typeof loadDocumentConversationData>> | null>(null);
  const [selected, setSelected] = useState(initialIssueId ? `issue:${initialIssueId}` : '');
  const version = useRef(0);
  const [recipient, setRecipient] = useState('');
  const [creating, setCreating] = useState(false);
  const [newConversation, setNewConversation] = useState(false);
  const [error, setError] = useState('');
  const load = useCallback(async () => {
    const currentVersion = ++version.current;
    try {
      const next = await loadDocumentConversationData(documentId, companyId);
      if (currentVersion !== version.current) return;
      setData(current => {
        next.contexts = next.contexts.map(context => current?.contexts.find(previous => JSON.stringify(previous) === JSON.stringify(context)) || context);
        return next;
      });
      setError('');
      setSelected(current => current || (next.document.digitization_issues?.length && canUseIssueConversation(next.company, side)
        ? `issue:${next.document.digitization_issues.at(-1)!.id}` : next.contexts[0]?.storageKey || ''));
    } catch (reason) { if (currentVersion === version.current) { setData(null); setError(reason instanceof Error ? reason.message : 'Unable to load conversation.'); } }
  }, [documentId, companyId, side]);
  useEffect(() => {
    void load();
    const refresh = () => { void load(); };
    for (const name of ['document-issues-changed', 'chat-conversations-updated', 'focus', 'storage']) window.addEventListener(name, refresh);
    return () => {
      ++version.current;
      for (const name of ['document-issues-changed', 'chat-conversations-updated', 'focus', 'storage']) window.removeEventListener(name, refresh);
    };
  }, [load]);
  const issues = data && canUseIssueConversation(data.company, side) ? data.document.digitization_issues || [] : [];
  const issue = issues.find(item => `issue:${item.id}` === selected);
  const context = data?.contexts.find(item => item.storageKey === selected);
  const options = [...issues.map((item, index) => ({ value: `issue:${item.id}`, label: `${t('Reported issue')} ${index + 1} · ${item.message.slice(0, 70)}` })),
    ...(data?.contexts || []).map(item => ({ value: item.storageKey, label: item.createdByEmail?.toLowerCase() === data?.session.email.toLowerCase() ? item.recipientName || item.subject || t('Chat') : item.createdByName || item.subject || t('Chat') }))];
  const create = async () => {
    setCreating(true); setError('');
    try { const created = await createDocumentConversation(documentId, companyId, recipient); await load(); setSelected(created.storageKey); setNewConversation(false); }
    catch (reason) { setError(reason instanceof Error ? reason.message : 'Unable to start conversation.'); }
    finally { setCreating(false); }
  };
  return <div className={`flex min-h-0 min-w-0 flex-col gap-3 font-montserrat ${fillHeight ? 'flex-1' : ''}`}>
      {data && <p className="break-words text-xs text-[#7288A3]">{data.company.name} · {data.document.number || data.document.file_case}</p>}
      {error && <p role="alert" className="text-sm text-[#D64545]">{t(error)}</p>}
      {!data && !error && <p role="status">{t('Loading…')}</p>}
      {data && <><div className="flex flex-wrap items-center gap-3">
        {!!options.length && <div className="min-w-[200px] flex-1"><SearchableSelect ariaLabel={lt ? 'Dokumento pokalbių istorija' : 'Document conversation history'} value={selected} options={options} onChange={value => { setSelected(value); setNewConversation(false); }} portalMenu /></div>}
        {!initialIssueId && <PageActionButton icon={<Plus size={15} />} disabled={!canEditMenu(data.session, 'messages')} onClick={() => setNewConversation(value => !value)}>{t('New conversation')}</PageActionButton>}
      </div>
      {!initialIssueId && (newConversation || !options.length) && <div className="flex flex-wrap items-end gap-3 rounded-lg border border-[#D3E1EC] bg-[#F8FDFF] p-4"><div className="min-w-[220px] flex-1"><label className="mb-2 block text-xs font-medium">{t('Talk to')}</label><SearchableSelect ariaLabel={t('Talk to')} value={recipient} options={[{ value: 'fh-ai', label: 'FH AI' }, ...chatWorkerRecipients(data.company, data.session.email).map(person => ({ value: person.id, label: `${person.name} · ${t('Worker')}` }))]} onChange={setRecipient} portalMenu /></div><PageActionButton icon={<MessageSquare size={15}/>} disabled={!recipient || creating || !canEditMenu(data.session, 'messages')} onClick={() => void create()}>{t('Open conversation')}</PageActionButton></div>}
      {!newConversation && issue && <DocumentIssueConversation key={issue.id} documentId={documentId} companyId={companyId} issueId={issue.id} side={side} active={active} fillHeight={fillHeight} />}
      {!newConversation && context && <ChatsView key={context.storageKey} embedded fillHeight={fillHeight} active={active} currentUserName={data.session.fullName} conversation={context} preserveConversationMetadata ocrOnly
        beforeSend={() => validateDocumentConversationSend(documentId, companyId, context.storageKey)} />}
      </>}
    </div>;
}
