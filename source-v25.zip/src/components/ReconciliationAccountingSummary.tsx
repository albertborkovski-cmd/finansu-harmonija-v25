import { translateUi as t } from '../i18n/language';
import type { ReconciliationBatch } from '../lib/reconciliation';
import { reconciliationJournalNumber } from '../lib/reconciliationJournal';
import { PageActionButton } from './PageHeader';
import { BookOpen } from 'lucide-react';

export default function ReconciliationAccountingSummary({ batch, batchIndex, onOpenJournal, onDocument }: {
  batch: ReconciliationBatch; batchIndex: number; onOpenJournal?: (batchId: string) => void; onDocument: (id: string) => void;
}) {
  if (!batch.accounting) return <p className="text-[12px] text-[#7288A3]">{t('Historical reconciliation · no GL transfer was recorded.')}</p>;
  const hasPosting = batch.accounting.allocations.some(row => row.fundingAccount !== row.invoiceAccount);
  return <section className="space-y-3">
    <div className="flex items-center justify-between gap-3"><h3 className="text-[14px] font-semibold">{t('Related GL entries')}</h3>{hasPosting && onOpenJournal && <PageActionButton icon={<BookOpen size={14} />} onClick={() => onOpenJournal(batch.id)}>{t('Open GL journal')}</PageActionButton>}</div>
    {batch.accounting.allocations.map((row, index) => {
      const allocation = batch.allocations[index]; const different = row.fundingAccount !== row.invoiceAccount;
      return <div key={index} className="overflow-hidden rounded-lg border border-[#D3E1EC]">
        <div className="flex flex-wrap items-center gap-2 bg-[#F8FDFF] px-3 py-2 text-[12px]">
          <button type="button" className="text-[#007EA7] hover:underline" onClick={() => onDocument(allocation.fundingId)}>{row.fundingNumber}</button><span>↔</span><button type="button" className="text-[#007EA7] hover:underline" onClick={() => onDocument(allocation.invoiceId)}>{row.invoiceNumber}</button>
          <span className="ml-auto font-medium tabular-nums">{(allocation.amountMinor / 100).toFixed(2)} {row.currency}</span>
        </div>
        {different ? <div className="space-y-2 px-3 py-2 text-[12px]">
          <p className="font-medium">{reconciliationJournalNumber(batchIndex, index)} · {t('Debit')} {row.fundingSide === 'Credit' ? row.fundingAccount : row.invoiceAccount} / {t('Credit')} {row.fundingSide === 'Debit' ? row.fundingAccount : row.invoiceAccount}</p>
          {batch.reversedAt && <p className="text-[#7288A3]">{reconciliationJournalNumber(batchIndex, index, true)} · {t('Reconciliation reversal')} · {batch.reversedBy || batch.actor}</p>}
        </div> : <p className="px-3 py-2 text-[12px] text-[#7288A3]">{row.fundingAccount} · {t('Same GL account · balances reconciled, no additional GL entry.')}</p>}
      </div>;
    })}
  </section>;
}
