import { useEffect, useId, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { ArrowDown, ArrowUp, Combine, Search, X } from 'lucide-react';
import { translateUi as uiText } from '../i18n/language';
import { loadOcrMergeCandidates } from '../lib/supabase';
import { filterPdfMergeSources, mergePdfSources, readPdfSource, type PdfMergePage, type PdfMergeSource } from '../lib/ocrPdfSplit';
import DocumentFileViewer from './DocumentFileViewer';

export default function OcrPdfMergeDialog({ documentId, companyId, onClose, onMerge }: {
  documentId: string; companyId: string; onClose: () => void;
  onMerge: (sources: PdfMergeSource[], pages: PdfMergePage[], filename: string, requestId: string) => Promise<void>;
}) {
  const titleId = useId(), requestId = useRef(crypto.randomUUID()), pending = useRef(false);
  const [candidates, setCandidates] = useState<PdfMergeSource[]>([]), [selected, setSelected] = useState<string[]>([documentId]);
  const [pages, setPages] = useState<PdfMergePage[]>([]), [filename, setFilename] = useState('Merged-document');
  const [search, setSearch] = useState('');
  const [preview, setPreview] = useState(''), [error, setError] = useState(''), [busy, setBusy] = useState(false), [loading, setLoading] = useState(true);
  useEffect(() => {
    let cancelled = false;
    loadOcrMergeCandidates(documentId, companyId).then(value => { if (!cancelled) setCandidates(value); })
      .catch(cause => { if (!cancelled) setError(cause instanceof Error ? cause.message : 'Unable to load documents.'); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [documentId, companyId]);
  const close = () => { if (!pending.current) onClose(); };
  const selectedSources = candidates.filter(source => selected.includes(source.id));
  const visibleCandidates = filterPdfMergeSources(candidates, search);
  const prepare = async () => {
    if (pending.current || selectedSources.length < 2) return;
    pending.current = true; setBusy(true); setError('');
    try {
      const next = (await Promise.all(selectedSources.map(async source => {
        const pdf = await readPdfSource(source.url);
        return Array.from({ length: pdf.getPageCount() }, (_, index) => ({ documentId: source.id, page: index + 1 }));
      }))).flat();
      setPages(next); setPreview('');
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'The original PDF could not be loaded.'); }
    finally { pending.current = false; setBusy(false); }
  };
  const renderPreview = async () => {
    if (pending.current) return;
    pending.current = true; setBusy(true); setError('');
    try { setPreview(await mergePdfSources(selectedSources, pages)); }
    catch (cause) { setError(cause instanceof Error ? cause.message : 'Could not create preview.'); }
    finally { pending.current = false; setBusy(false); }
  };
  const move = (index: number, offset: number) => {
    setPages(current => { const next = [...current]; [next[index], next[index + offset]] = [next[index + offset], next[index]]; return next; });
    setPreview('');
  };
  const submit = async () => {
    if (pending.current || !preview) return;
    pending.current = true; setBusy(true); setError('');
    try { await onMerge(selectedSources, pages, filename, requestId.current); onClose(); }
    catch (cause) { setError(cause instanceof Error ? cause.message : 'Could not merge documents. Originals have not been removed.'); }
    finally { pending.current = false; setBusy(false); }
  };
  return createPortal(<div className="fixed inset-0 z-[5400] flex items-center justify-center bg-[#10233A]/30 p-4 font-montserrat">
    <section role="dialog" aria-modal="true" aria-labelledby={titleId} aria-busy={busy} className="flex h-[88vh] w-full max-w-[1120px] flex-col overflow-hidden rounded-xl border border-[#D3E1EC] bg-white shadow-xl">
      <header className="flex items-center gap-3 border-b border-[#E5EDF9] px-5 py-4"><Combine size={20} className="text-[#007EA7]" /><h2 id={titleId} className="flex-1 text-lg font-semibold text-[#10233A]">{uiText('Merge documents')}</h2><button type="button" aria-label={uiText('Close')} disabled={busy} onClick={close}><X size={20} /></button></header>
      <div className="flex min-h-0 flex-1 flex-col overflow-y-auto md:grid md:grid-cols-[minmax(0,1fr)_420px] md:overflow-hidden">
        <div className="h-[300px] shrink-0 overflow-hidden border-b border-[#E5EDF9] md:h-full md:min-h-0 md:border-b-0 md:border-r">{preview ? <DocumentFileViewer url={preview} filename={`${filename}.pdf`} kind="pdf" embedded /> : <div className="flex h-full items-center justify-center p-6 text-center text-sm text-[#7288A3]">{uiText('Choose documents, set the page order and preview the merged PDF.')}</div>}</div>
        <div className="space-y-4 p-5 text-xs text-[#10233A] md:overflow-y-auto">
          <label className="block font-medium">{uiText('Search documents')}
            <span className="relative mt-1.5 block">
              <Search size={16} aria-hidden="true" className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[#7288A3]" />
              <input type="search" value={search} disabled={busy || loading} onChange={event => setSearch(event.target.value)}
                placeholder={uiText('File name or document number')} aria-label={uiText('Search documents')}
                className="h-10 w-full rounded-lg border border-[#D3E1EC] bg-white pl-9 pr-3 text-[12px] font-normal text-[#10233A] outline-none focus:border-[#007EA7]" />
            </span>
          </label>
          <p className="leading-5 text-[#7288A3]">{uiText('Only PDF tasks assigned to the same worker in this organization can be merged. Original files remain in Uploaded documents.')}</p>
          <fieldset disabled={busy || loading} className="space-y-2"><legend className="mb-2 font-semibold">{uiText('Select documents')}</legend>
            {visibleCandidates.map(source => <label key={source.id} className="flex items-start gap-2 rounded-md border border-[#E5EDF9] p-2"><input type="checkbox" checked={selected.includes(source.id)} disabled={source.id === documentId} onChange={event => { setSelected(current => event.target.checked ? [...current, source.id] : current.filter(id => id !== source.id)); setPages([]); setPreview(''); }} className="h-4 w-4 shrink-0 accent-[#007EA7]" /><span className="break-all">{source.name}</span></label>)}
          </fieldset>
          {!loading && candidates.length > 0 && visibleCandidates.length === 0 && <p role="status" className="text-[#7288A3]">{uiText('No documents match your search.')}</p>}
          {!loading && candidates.length < 2 && <p>{uiText('No other assigned PDF documents are available to merge.')}</p>}
          <button type="button" disabled={busy || selectedSources.length < 2} onClick={() => void prepare()} className="rounded-md border border-[#D3E1EC] px-3 py-2 font-semibold text-[#007EA7] disabled:opacity-50">{uiText('Prepare page order')}</button>
          {pages.length > 0 && <>
            <label className="block">{uiText('File name')}<input value={filename} disabled={busy} maxLength={120} onChange={event => setFilename(event.target.value)} className="mt-1 w-full rounded-md border border-[#D3E1EC] p-2" /></label>
            <h3 className="font-semibold">{uiText('Future document structure')}</h3>
            <ol className="space-y-1">{pages.map((page, index) => <li key={`${page.documentId}:${page.page}`} className="flex items-center gap-2 rounded-md bg-[#F4F8FC] p-2"><span className="min-w-0 flex-1 break-words">{index + 1}. {candidates.find(source => source.id === page.documentId)?.name} · {uiText('Page')} {page.page}</span><button type="button" aria-label={`${uiText('Move page up')} ${index + 1}`} disabled={busy || index === 0} onClick={() => move(index, -1)} className="disabled:opacity-30"><ArrowUp size={16} /></button><button type="button" aria-label={`${uiText('Move page down')} ${index + 1}`} disabled={busy || index === pages.length - 1} onClick={() => move(index, 1)} className="disabled:opacity-30"><ArrowDown size={16} /></button></li>)}</ol>
            <button type="button" disabled={busy} onClick={() => void renderPreview()} className="rounded-md border border-[#D3E1EC] px-3 py-2 font-semibold text-[#007EA7]">{uiText('Preview PDF')}</button>
          </>}
          {error && <p role="alert" className="rounded-md bg-[#FFF0F0] p-3 leading-5 text-[#B42318]">{uiText(error)}</p>}
        </div>
      </div>
      <footer className="flex justify-end gap-3 border-t border-[#E5EDF9] px-5 py-4"><button type="button" disabled={busy} onClick={close} className="rounded-lg border border-[#D3E1EC] px-4 py-2 text-sm font-semibold text-[#7288A3]">{uiText('Cancel')}</button><button type="button" disabled={busy || !preview || !filename.trim()} onClick={() => void submit()} className="rounded-lg bg-[#007EA7] px-4 py-2 text-sm font-semibold text-white disabled:opacity-50">{uiText(busy ? 'Saving…' : 'Merge and next file')}</button></footer>
    </section>
  </div>, document.body);
}
