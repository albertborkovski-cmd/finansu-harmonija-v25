import { useMemo, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, ClipboardPaste, Loader2, Save } from 'lucide-react';
import { translateUi as t } from '../i18n/language';
import type { Company } from '../lib/supabase';
import { COUNTERPARTY_FIELDS, COUNTERPARTY_LABELS, counterpartyDraftErrors, counterpartyIbans, emptyCounterpartyDraft, parseCounterpartyPaste, type CounterpartyDraft } from '../lib/companyCounterpartyImport';
import { saveCompanyCounterparties } from '../lib/saveCompanyCounterparties';
import { updateCompanyCounterparty } from '../lib/companyCounterpartyActions';
import { PageActionButton } from './PageHeader';
import OrganizationSettingsHelpLink from './OrganizationSettingsHelpLink';

const inputClass = 'h-[42px] w-full min-w-0 rounded-lg border border-[#D3E1EC] bg-white px-3 font-montserrat text-[14px] font-normal leading-5 text-[#10233A] outline-none focus:border-[#007EA7] focus:ring-1 focus:ring-[#007EA7]/20 disabled:bg-[#F5F8FB]';
const labelClass = 'flex min-w-0 flex-col gap-2 text-[14px] font-semibold leading-5 text-[#10233A]';
const pageSize = 20;
export default function CompanyCounterpartyEditor({ companyId, existing, mode, canEdit, editingCompany, onCancel, onSaved }: {
  companyId: string; existing: Company[]; mode: 'manual' | 'excel'; canEdit: boolean; editingCompany?: Company; onCancel: () => void; onSaved: (count: number) => void;
}) {
  const [rows, setRows] = useState<CounterpartyDraft[]>(() => editingCompany ? [{ accountingCode: editingCompany.accounting_system_code || '', companyCode: editingCompany.company_code || '', vatCode: editingCompany.vat_code || '', name: editingCompany.name, ibans: counterpartyIbans(editingCompany).join('; ') }] : mode === 'manual' ? [emptyCounterpartyDraft()] : []);
  const [email, setEmail] = useState(editingCompany?.email || ''), [phone, setPhone] = useState(editingCompany?.phone || '');
  const [text, setText] = useState(''), [parseError, setParseError] = useState(''), [saveError, setSaveError] = useState('');
  const [busy, setBusy] = useState(false), [page, setPage] = useState(0);
  const pending = useRef(false);
  const errors = useMemo(() => counterpartyDraftErrors(rows, existing.filter(row => row.id !== editingCompany?.id)), [rows, existing, editingCompany]);
  const invalidCount = errors.filter(row => row.length).length;
  const pageCount = Math.max(1, Math.ceil(rows.length / pageSize));
  const update = (index: number, field: keyof CounterpartyDraft, value: string) => {
    setRows(previous => previous.map((row, current) => current === index ? { ...row, [field]: value } : row)); setSaveError('');
  };
  const paste = (value: string) => {
    setText(value); setPage(0); setSaveError('');
    try { setRows(parseCounterpartyPaste(value)); setParseError(''); }
    catch (error) { setRows([]); setParseError(error instanceof Error ? error.message : 'Could not read the pasted companies.'); }
  };
  const save = async () => {
    if (pending.current || !canEdit || parseError || invalidCount || !rows.length) return;
    pending.current = true; setBusy(true); setSaveError('');
    try {
      if (editingCompany) { await updateCompanyCounterparty(companyId, editingCompany, rows[0], { email, phone }); onSaved(1); }
      else onSaved(await saveCompanyCounterparties(companyId, rows));
    }
    catch (error) { setSaveError(error instanceof Error ? error.message : 'Could not save the companies.'); }
    finally { pending.current = false; setBusy(false); }
  };
  const heading = editingCompany ? 'Edit counterparty' : mode === 'manual' ? 'Add company' : 'Import companies from Excel';
  return <section className="flex h-full min-h-0 flex-col gap-4 font-montserrat" aria-label={t(heading)}>
    <header className="flex min-h-8 shrink-0 items-center gap-3">
      <PageActionButton iconOnly className="shrink-0" ariaLabel={t('Back to counterparties')} icon={<ChevronLeft size={16} className="shrink-0" />} disabled={busy} onClick={onCancel}>{t('Back')}</PageActionButton>
      <h3 className="text-[16px] font-semibold leading-6 text-[#10233A]">{t(heading)}</h3>
      <OrganizationSettingsHelpLink section="counterparties" topic={mode === 'excel' ? 'excel' : 'overview'} label={heading} />
    </header>
    <div className="min-h-0 flex-1 space-y-4 overflow-auto pr-2 [scrollbar-gutter:stable]">
      <fieldset disabled={busy || !canEdit} className="min-w-0 space-y-5 rounded-lg border border-[#D3E1EC] bg-white p-5">
        {mode === 'manual' ? <div className="grid grid-cols-1 gap-x-6 gap-y-5 md:grid-cols-2">
          {COUNTERPARTY_FIELDS.map((field, index) => <label key={field} className={`${labelClass} ${field === 'ibans' ? 'md:col-span-2' : ''}`}>
            <span className="flex items-center gap-1.5">{t(COUNTERPARTY_LABELS[index])}{field === 'name' && <span className="text-[#B42318]"> *</span>}<OrganizationSettingsHelpLink section="counterparties" topic={field} label={COUNTERPARTY_LABELS[index]} /></span>
            <input autoFocus={index === 0} required={field === 'name'} aria-label={t(COUNTERPARTY_LABELS[index])} className={inputClass} value={rows[0][field]} maxLength={field === 'ibans' ? 2000 : 500} onChange={event => update(0, field, event.target.value)} />
            {field === 'ibans' && <span className="text-[12px] font-normal text-[#7288A3]">{t('Separate IBANs with commas or semicolons.')}</span>}
          </label>)}
          {editingCompany && <>
            <label className={labelClass}><span className="flex items-center gap-1.5">{t('Email')}<OrganizationSettingsHelpLink section="counterparties" topic="email" label="Email" /></span><input aria-label={t('Email')} type="email" className={inputClass} value={email} onChange={event => setEmail(event.target.value)} /></label>
            <label className={labelClass}><span className="flex items-center gap-1.5">{t('Phone')}<OrganizationSettingsHelpLink section="counterparties" topic="phone" label="Phone" /></span><input aria-label={t('Phone')} type="tel" className={inputClass} value={phone} onChange={event => setPhone(event.target.value)} /></label>
          </>}
          {COUNTERPARTY_FIELDS.some(field => rows[0][field]) && errors[0].length > 0 && <p role="alert" className="text-[12px] text-[#B42318] md:col-span-2">{errors[0].map(message => t(message)).join(' ')}</p>}
        </div> : <>
          <div className="rounded-lg border border-[#D3E1EC] bg-[#F7FBFD] p-3 text-[12px] leading-5 text-[#7288A3]">
            <p>{t('Copy companies from Excel or enter several manually. Separate columns with TAB, IBANs with a comma or semicolon, and each company with a new line.')}</p>
            <p className="mt-2 font-medium text-[#10233A]">{t('Column order: accounting system code, company code, VAT code, name, IBAN.')}</p>
          </div>
          <label className={labelClass}>
            <span>{t('Paste companies from Excel')}</span>
            <textarea autoFocus rows={4} spellCheck={false} aria-label={t('Paste companies from Excel')} value={text} onChange={event => paste(event.target.value)}
              onKeyDown={event => { if (event.key === 'Tab' && !event.shiftKey && !event.ctrlKey && !event.metaKey && !event.altKey) { event.preventDefault(); const input = event.currentTarget, start = input.selectionStart, end = input.selectionEnd; paste(text.slice(0, start) + '\t' + text.slice(end)); requestAnimationFrame(() => input.setSelectionRange(start + 1, start + 1)); } }}
              placeholder={'001\t123456789\tLT123456789\tUAB Pavyzdys\tLT121000011101001000'}
              className={`${inputClass} h-[112px] resize-y py-2 leading-5`} />
            <span className="text-[12px] font-normal text-[#7288A3]">{t('TAB inserts a column separator. Shift + TAB moves focus out of the field.')}</span>
          </label>
          {parseError && <p role="alert" className="text-[12px] text-[#B42318]">{t(parseError)}</p>}
          {rows.length > 0 && <div className="space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2 text-[12px]"><h4 className="font-semibold">{t('Import preview')} · {rows.length}</h4>
              <span role="status" className={invalidCount ? 'text-[#B42318]' : 'text-[#7288A3]'}>{invalidCount ? `${t('Rows to correct')}: ${invalidCount}` : t('Ready to import')}</span></div>
            <div className="max-h-[310px] overflow-auto rounded-lg border border-[#D3E1EC]">
              <table className="w-full min-w-[850px] border-collapse text-left text-[12px]"><thead className="sticky top-0 z-10 bg-[#F2F6FA] text-[#7288A3]"><tr>
                <th className="px-3 py-2">#</th>{COUNTERPARTY_LABELS.map(label => <th key={label} className="px-3 py-2">{t(label)}</th>)}
              </tr></thead><tbody>{rows.slice(page * pageSize, (page + 1) * pageSize).map((row, offset) => {
                const index = page * pageSize + offset;
                return <tr key={index} className={`border-t border-[#E5EDF9] ${errors[index].length ? 'bg-[#FFF9F5]' : 'bg-white'}`}>
                  <td className="px-3 py-2 align-top text-[#7288A3]">{index + 1}</td>
                  {COUNTERPARTY_FIELDS.map((field, fieldIndex) => <td key={field} className="min-w-[150px] px-2 py-1.5 align-top">
                    <input className={`${inputClass} !h-9`} aria-label={`${t(COUNTERPARTY_LABELS[fieldIndex])} ${index + 1}`} aria-invalid={errors[index].length > 0} value={row[field]} onChange={event => update(index, field, event.target.value)} />
                    {field === 'name' && errors[index].length > 0 && <p className="mt-1 text-[10px] leading-4 text-[#B42318]">{errors[index].map(message => t(message)).join(' ')}</p>}
                  </td>)}
                </tr>;
              })}</tbody></table>
            </div>
            {pageCount > 1 && <div className="flex items-center justify-end gap-2 text-[12px] text-[#7288A3]">
              <PageActionButton iconOnly ariaLabel={t('Previous page')} icon={<ChevronLeft size={15} />} disabled={page === 0 || busy} onClick={() => setPage(value => value - 1)}>{t('Previous')}</PageActionButton>
              <span>{page + 1} / {pageCount}</span>
              <PageActionButton iconOnly ariaLabel={t('Next page')} icon={<ChevronRight size={15} />} disabled={page + 1 >= pageCount || busy} onClick={() => setPage(value => value + 1)}>{t('Next')}</PageActionButton>
            </div>}
          </div>}
        </>}
      </fieldset>
      {saveError && <p role="alert" className="rounded-lg border border-[#E8D3AC] bg-[#FFF9EE] px-3 py-2 text-[12px] text-[#926317]">{t(saveError)}</p>}
    </div>
    <footer className="flex min-h-[60px] shrink-0 items-center justify-end gap-2 border-t border-[#D3E1EC] pt-4">
      <PageActionButton disabled={busy} onClick={onCancel}>{t('Cancel')}</PageActionButton>
      <PageActionButton disabled={busy || !canEdit || !rows.length || Boolean(parseError) || invalidCount > 0} onClick={() => void save()}
        icon={busy ? <Loader2 size={15} className="animate-spin" /> : mode === 'excel' ? <ClipboardPaste size={15} /> : <Save size={15} />}>{t(busy ? 'Saving…' : mode === 'excel' ? 'Import' : 'Save')}</PageActionButton>
    </footer>
  </section>;
}
