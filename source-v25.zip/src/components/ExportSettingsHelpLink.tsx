import { HelpCircle } from 'lucide-react';
import { translateUi as t } from '../i18n/language';
import { exportHelpHref } from '../lib/exportSettingsHelp';

export default function ExportSettingsHelpLink({ format, topic = 'overview', label = 'Help', withText = false }: { format: string; topic?: string; label?: string; withText?: boolean }) {
  return <a href={exportHelpHref(format, topic)} target="_blank" rel="noopener noreferrer" aria-label={`${t('Help')}: ${t(label)} · ${t('Opens in a new tab')}`} data-tooltip={`${t('Help')}: ${t(label)}`}
    className="inline-flex shrink-0 items-center justify-center gap-1.5 rounded text-[#007EA7] hover:text-[#005F80] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#007EA7]">
    <HelpCircle size={15} aria-hidden="true" />{withText && <span className="text-[12px] font-medium">{t(label)}</span>}
  </a>;
}
