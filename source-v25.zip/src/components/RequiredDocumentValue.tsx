import { AlertCircle } from 'lucide-react';
import { translateUi as t } from '../i18n/language';
export default function RequiredDocumentValue({ label, field }: { label: string; field?: string }) {
  const message = `${label}: ${t('Required by organization settings. Fill in this field.')}`;
  return <span role="img" data-accounting-required={field} aria-label={message} data-tooltip={message}
    className="absolute left-2 top-1/2 z-[1] flex h-4 w-4 -translate-y-1/2 items-center justify-center text-[#D64545]">
    <AlertCircle size={16} strokeWidth={2.5} aria-hidden="true" />
  </span>;
}
