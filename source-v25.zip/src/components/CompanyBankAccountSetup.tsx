import { translateStatus as statusText } from '../i18n/language';
import { translateUi as uiText } from '../i18n/language';
import { useEffect, useId, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { ExternalLink, Link2, X } from 'lucide-react';
import type { Company } from '../lib/supabase';
import { isInactiveRecord } from '../lib/recordLifecycle';
import { BANK_CONNECTION_CHANGED, bankAccountConnectionStatus, canManageCompanyBankSetup, readBankConnectionPreference, saveBankConnectionPreference, type BankSetupAccount } from '../lib/companyBankSetup';
import { loadCompanyGeneralLedgerAccountHierarchy } from './GeneralLedgerView';
import SearchableSelect from './SearchableSelect';
import { PageActionButton } from './PageHeader';
import { CancelButton, SaveButton } from './ScopedActionButtons';

type Props = { company: Company; account: BankSetupAccount & { connectionStatus?: string }; onGlChange: (value: string) => void; creatingCompany?: boolean; saving?: boolean };
const control = 'h-10 w-full rounded-lg border border-[#D3E1EC] bg-white px-3 font-montserrat text-[13px] text-[#10233A] outline-none focus:border-[#007EA7]';
export default function CompanyBankAccountSetup({ company, account, onGlChange, creatingCompany = false, saving = false }: Props) {
  const [open, setOpen] = useState(false), [provider, setProvider] = useState(''), [busy, setBusy] = useState(false), [error, setError] = useState(''), [message, setMessage] = useState('');
  const [setupRequired, setSetupRequired] = useState(false);
  const [glAccounts, setGlAccounts] = useState(() => loadCompanyGeneralLedgerAccountHierarchy(company.id, company.general_ledger));
  const titleId = useId(), root = useRef<HTMLDivElement>(null), closeButton = useRef<HTMLButtonElement>(null), pending = useRef(false), dropdownEscape = useRef(false);
  const canManage = canManageCompanyBankSetup(company);
  const disabled = saving || isInactiveRecord(account) || (!creatingCompany && !canManage);
  const options = [{ value: '', label: 'Not assigned' }, ...glAccounts.map(row => ({ value: row.code, label: `${row.code} · ${row.name}` }))];
  if (account.glAccount && !options.some(option => option.value === account.glAccount)) options.push({ value: account.glAccount, label: `${account.glAccount} · Unavailable account` });
  const status = bankAccountConnectionStatus(account);
  useEffect(() => {
    const refresh = () => {
      setGlAccounts(loadCompanyGeneralLedgerAccountHierarchy(company.id, company.general_ledger));
      try { const saved = readBankConnectionPreference(company.id, { id: account.id, iban: account.iban }); setProvider(saved?.provider || ''); setSetupRequired(Boolean(saved)); setError(''); }
      catch (cause) { setError(cause instanceof Error ? cause.message : 'Bank settings could not be read.'); }
    };
    refresh();
    window.addEventListener(BANK_CONNECTION_CHANGED, refresh); window.addEventListener('organization-reference-updated', refresh); window.addEventListener('storage', refresh);
    return () => { window.removeEventListener(BANK_CONNECTION_CHANGED, refresh); window.removeEventListener('organization-reference-updated', refresh); window.removeEventListener('storage', refresh); };
  }, [company.id, company.general_ledger, account.id, account.iban]);
  useEffect(() => {
    if (!open) return;
    const previous = document.activeElement as HTMLElement | null;
    const remember = (event: KeyboardEvent) => { if (event.key === 'Escape') dropdownEscape.current = Boolean(root.current?.querySelector('[role="combobox"][aria-expanded="true"]')); };
    window.addEventListener('keydown', remember, true); closeButton.current?.focus();
    return () => { window.removeEventListener('keydown', remember, true); previous?.focus(); };
  }, [open]);
  const close = () => { if (!pending.current) setOpen(false); };
  const connect = async () => {
    if (pending.current) return;
    pending.current = true; setBusy(true); setError(''); setMessage('');
    try {
      await saveBankConnectionPreference(company.id, account, provider);
      setSetupRequired(true);
      setMessage('Provider selection saved. The bank integration is not configured yet, so no bank authorization was started.');
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Bank connection could not be started.'); }
    finally { pending.current = false; setBusy(false); }
  };
  return <>
    <div className="mt-4 grid grid-cols-1 items-end gap-4 border-t border-[#D3E1EC] pt-4 md:grid-cols-2">
      <div className="min-w-0 space-y-1.5"><span className="font-montserrat text-[12px] font-semibold text-[#10233A]">{uiText("Bank GL account")}</span>
        <SearchableSelect ariaLabel={`Bank GL account ${account.iban || account.id}`} value={account.glAccount || ''} options={options} onChange={onGlChange} disabled={disabled} portalMenu className={`${control} pr-9`} />
      </div>
      <div className="flex min-h-10 flex-wrap items-center gap-3"><span className="mr-auto font-montserrat text-[12px] text-[#7288A3]">{uiText("Connection status")}<span className={`ml-2 inline-flex rounded-full px-2.5 py-1 text-[11px] font-semibold ${status === 'Connected' ? 'bg-[#E4F4EF] text-[#21866A]' : status === 'Connection error' ? 'bg-[#FFF0F0] text-[#B42318]' : 'bg-[#E5EDF9] text-[#7288A3]'}`}>{statusText(status)}</span>
        {setupRequired && <span className="mt-1 block text-[11px] text-[#926317]">{uiText("Provider setup required")}</span>}</span>
        <PageActionButton icon={<Link2 size={14} />} disabled={disabled || creatingCompany || !account.iban.trim()} onClick={() => { setMessage(''); setError(''); setOpen(true); }}>{uiText("Connect bank")}</PageActionButton>
      </div>
    </div>
    {!open && error && <p role="alert" className="mt-2 text-[12px] text-[#B42318]">{error}</p>}
    {open && createPortal(<div className="fixed inset-0 z-[5400] flex items-center justify-center bg-[#10233A]/30 p-4 font-montserrat" onClick={event => { event.stopPropagation(); if (event.target === event.currentTarget) close(); }} onKeyDown={event => {
      event.stopPropagation();
      if (event.key === 'Escape') { if (!dropdownEscape.current) { event.preventDefault(); close(); } }
      if (event.key === 'Tab' && !document.querySelector('[role="listbox"]')) {
        const controls = [...root.current!.querySelectorAll<HTMLElement>('button:not(:disabled), input:not(:disabled), [tabindex="0"]')].filter(node => node.getClientRects().length);
        const first = controls[0], last = controls.at(-1);
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
      }
    }}><div ref={root} role="dialog" aria-modal="true" aria-labelledby={titleId} className="w-full max-w-[540px] rounded-xl border border-[#D3E1EC] bg-white shadow-xl">
      <header className="flex items-center justify-between gap-4 border-b border-[#D3E1EC] px-5 py-4"><h2 id={titleId} className="text-[20px] font-semibold text-[#10233A]">{uiText("Connect bank")}</h2><button ref={closeButton} type="button" aria-label={uiText("Close bank connection")} disabled={busy} onClick={close} className="rounded-md p-1 text-[#7288A3] hover:bg-[#F2F5F9]"><X size={20} /></button></header>
      <div className="space-y-5 p-5">
        <label className="block space-y-2 text-[12px] font-medium text-[#7288A3]"><span>{uiText("Bank account")}</span><input aria-label={uiText("Bank account to connect")} readOnly value={`${account.bank || 'Bank'} · ${account.iban}`} className={`${control} !bg-[#F2F5F9]`} /></label>
        <div className="space-y-2 text-[12px] font-medium text-[#7288A3]"><span>{uiText("Bank / Gateway provider")}</span><SearchableSelect ariaLabel={uiText("Bank / Gateway provider")} value={provider} options={[
          { value: 'bank', label: account.bank || 'Direct bank connection', description: 'Bank integration is not configured' },
          { value: 'gateway', label: 'Open banking gateway', description: 'Gateway integration is not configured' },
        ]} onChange={setProvider} disabled={busy} portalMenu menuClassName="!z-[5500]" className={`${control} pr-9`} /></div>
        <p className="text-[12px] leading-5 text-[#7288A3]">{uiText("Authorization takes place on the bank or provider website. FH does not ask for your bank login or password. Provider integration is not configured yet.")}</p>
        {error && <p role="alert" className="rounded-md bg-[#FFF0F0] p-3 text-[12px] text-[#B42318]">{error}</p>}
        {message && <p role="status" className="rounded-md bg-[#FFF4DC] p-3 text-[12px] text-[#926317]">{message}</p>}
      </div>
      <footer className="flex flex-wrap justify-end gap-3 border-t border-[#D3E1EC] px-5 py-4"><CancelButton onClick={close} /><SaveButton disabled={busy || !provider} onClick={() => void connect()} className="gap-2"><ExternalLink size={16} />{busy ? uiText('Preparing…') : uiText('Continue to bank')}</SaveButton></footer>
    </div></div>, document.body)}
  </>;
}
