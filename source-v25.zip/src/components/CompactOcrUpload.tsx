import { useId, useRef, useState } from 'react';
import { Copy, Info, Upload } from 'lucide-react';
import { translateUi as uiText } from '../i18n/language';
import { uploadDocumentsForOcr } from '../lib/ocrDocumentUpload';
import { GLOBAL_OCR_ADDITIONAL_INFORMATION_SCOPE } from '../lib/ocrAdditionalInformation';
import { canAccessUnassignedDocuments } from '../lib/documentEditAccess';
import OcrAdditionalInformation from './OcrAdditionalInformation';
import { useDropdownDismiss } from './useDropdownDismiss';

export default function CompactOcrUpload({ documentCount, onUploaded }: { documentCount: number; onUploaded: () => Promise<void> }) {
  const input = useRef<HTMLInputElement>(null), helpRef = useRef<HTMLDivElement>(null), busyRef = useRef(false);
  const helpId = useId();
  const [busy, setBusy] = useState(false), [dragging, setDragging] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false), [feedback, setFeedback] = useState('');
  const allowed = canAccessUnassignedDocuments(true);
  useDropdownDismiss(helpOpen, helpRef, () => setHelpOpen(false));
  const upload = async (files: File[]) => {
    if (!files.length || busyRef.current || !canAccessUnassignedDocuments(true)) return;
    busyRef.current = true; setBusy(true); setFeedback('');
    try {
      const ids = await uploadDocumentsForOcr(files, { documentCount });
      setFeedback(`${uiText('Submitted for OCR processing')}: ${ids.length}`);
    } catch (error) { setFeedback(uiText(error instanceof Error ? error.message : 'Document upload failed.')); }
    finally {
      try { await onUploaded(); }
      catch { setFeedback(current => `${current} ${uiText('Refresh the list to see the latest changes.')}`); }
      finally { busyRef.current = false; setBusy(false); }
    }
  };
  return <section data-table-workspace-overview data-compact-ocr-upload className="rounded-xl border border-[#D3E1EC] bg-white px-4 py-3 font-montserrat">
    {allowed && <OcrAdditionalInformation companyId={GLOBAL_OCR_ADDITIONAL_INFORMATION_SCOPE} companyName={uiText('All organizations')} />}
    <div className="mb-2 flex flex-wrap items-center justify-between gap-x-5 gap-y-1.5">
      <h2 className="text-[14px] font-semibold text-[#10233A]">{uiText('Uploading documents')}</h2>
      <div className="flex min-w-0 items-center gap-2 text-[11px] text-[#7288A3]">
        <span>{uiText('Or email documents to:')}</span>
        <a className="text-[#007EA7] underline" href="mailto:demo@demo.lt">demo@demo.lt</a>
        <button type="button" aria-label={uiText('Copy document upload email')} className="flex h-6 w-6 items-center justify-center rounded text-[#7288A3] hover:bg-[#E5EDF9] hover:text-[#007EA7]" onClick={() => void navigator.clipboard.writeText('demo@demo.lt').catch(() => setFeedback(uiText('Could not copy email address.')))}><Copy size={14} /></button>
        <div ref={helpRef} className="relative">
          <button type="button" aria-label={uiText('About uploading documents')} aria-expanded={helpOpen} aria-controls={helpId} onClick={() => setHelpOpen(value => !value)} className="flex h-6 w-6 items-center justify-center rounded text-[#007EA7] hover:bg-[#E5EDF9]"><Info size={18} /></button>
          {helpOpen && <div id={helpId} role="dialog" aria-label={uiText('Uploading documents information')} className="absolute right-0 top-8 z-50 w-[340px] max-w-[calc(100vw-48px)] rounded-lg border border-[#D3E1EC] bg-white p-4 text-[12px] leading-[18px] shadow-[0_8px_24px_rgba(16,35,58,0.14)]">
            <p className="font-medium text-[#10233A]">{uiText('Upload one or multiple documents by drag & drop or by selecting files.')}</p>
            <p className="mt-2">{uiText('Documents for different organizations can be uploaded together – the system will identify and assign them during processing.')}</p>
            <p className="mt-2">{uiText('After upload, documents are sent for processing and their status can be followed in Uploaded documents.')}</p>
            <p className="mt-2 font-medium text-[#10233A]">{uiText('Press Alt + P (Option ⌥ + P on Mac) outside a text field to open ADDINFO before uploading.')}</p>
          </div>}
        </div>
      </div>
    </div>
    <div onDragOver={event => { event.preventDefault(); if (allowed && !busy) setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={event => { event.preventDefault(); setDragging(false); void upload(Array.from(event.dataTransfer.files)); }} className={`flex min-h-[62px] flex-wrap items-center justify-center gap-x-3 gap-y-1 rounded-lg border border-dashed px-3 py-2 ${dragging ? 'border-[#007EA7] bg-[#E5EDF9]' : 'border-[#AFC3D2] bg-[#F2F8FB]'}`}>
      <Upload size={22} className="shrink-0 text-[#7288A3]" />
      <p className="text-[12px] text-[#7288A3]">{busy ? uiText('Submitting documents for OCR processing…') : <>{uiText('Drag & drop files here or')} <button type="button" disabled={!allowed} onClick={() => input.current?.click()} className="font-semibold text-[#007EA7] underline disabled:opacity-40">{uiText('browse files')}</button></>}</p>
      <span className="text-[10px] text-[#7288A3]">PDF, JPG, PNG, TIF · 50 MB</span>
    </div>
    {feedback && <p role="status" className="mt-2 text-[11px] text-[#007EA7]">{feedback}</p>}
    <input ref={input} type="file" multiple accept=".pdf,.jpg,.jpeg,.png,.tif,.tiff" disabled={!allowed || busy} aria-label={uiText('Upload documents for OCR processing')} className="hidden" onChange={event => { void upload(Array.from(event.target.files || [])); event.target.value = ''; }} />
  </section>;
}
