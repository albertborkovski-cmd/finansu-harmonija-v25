import type { BalanceParty, BalanceStatement } from '../lib/balanceConfirmation';
import { balancePortalUrl } from '../lib/balanceConfirmation';

export const balanceMoney = (minor: number, currency: string) => `${(minor / 100).toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${currency}`;
export function BalancePartyCard({ party, label }: { party: BalanceParty; label: string }) {
  return <div className="min-w-0 rounded-lg border border-[#D3E1EC] bg-white p-4"><p className="text-xs text-[#7288A3]">{label}</p><p className="mt-2 text-sm font-semibold">{party.name}</p><p className="mt-2 break-words text-xs leading-5 text-[#536B85]">{[party.code, party.vatCode].filter(Boolean).join(' · ') || '—'}<br />{party.address || '—'}<br />{party.email || '—'}</p></div>;
}
export function BalanceLedgerTable({ statement }: { statement: BalanceStatement }) {
  const lt = statement.language === 'LT', amount = (value: number) => (value / 100).toLocaleString(lt ? 'lt-LT' : 'en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return <div className="overflow-x-auto rounded-lg border border-[#D3E1EC]"><table className="w-full min-w-[610px] border-collapse text-xs" aria-label={lt ? 'Skolų suderinimo detalizacija' : 'Balance reconciliation details'}>
    <thead className="bg-[#F1F6FA] text-[#536B85]"><tr>{(lt ? ['Data', 'Dokumento Nr.', 'Aprašymas', 'Debetas', 'Kreditas', 'Likutis'] : ['Date', 'Document No.', 'Description', 'Debit', 'Credit', 'Balance']).map((label, i) => <th key={label} className={`px-3 py-3 font-medium ${i > 2 ? 'text-right' : 'text-left'}`}>{label}{i > 2 && <span className="ml-1">{statement.currency}</span>}</th>)}</tr></thead>
    <tbody><tr className="border-t border-[#E5EDF9] bg-[#F8FBFD]"><td colSpan={5} className="px-3 py-3 font-medium">{lt ? 'Pradinis likutis' : 'Opening balance'} ({statement.from})</td><td className="px-3 py-3 text-right font-semibold tabular-nums">{amount(statement.opening)}</td></tr>
      {statement.lines.map(line => <tr key={line.id} className="border-t border-[#E5EDF9]"><td className="whitespace-nowrap px-3 py-3">{line.date}</td><td className="px-3 py-3">{line.document}</td><td className="px-3 py-3">{line.description}</td>{[line.debit, line.credit, line.balance].map((value, index) => <td key={index} className="px-3 py-3 text-right tabular-nums">{amount(value)}</td>)}</tr>)}
      {!statement.lines.length && <tr><td colSpan={6} className="p-4 text-[#7288A3]">{lt ? 'Pasirinktu laikotarpiu operacijų nėra.' : 'No transactions in the selected period.'}</td></tr>}
    </tbody><tfoot className="border-t border-[#D3E1EC] bg-[#EAF4F8]"><tr><td colSpan={5} className="px-3 py-3 font-semibold">{lt ? 'Galutinis likutis' : 'Closing balance'} ({statement.to})</td><td className="px-3 py-3 text-right font-semibold tabular-nums text-[#007EA7]">{amount(statement.closing)}</td></tr></tfoot>
  </table></div>;
}
export default function BalanceStatementDocument({ statement, signatures = true }: { statement: BalanceStatement; signatures?: boolean }) {
  const lt = statement.language === 'LT';
  return <article className="balance-statement space-y-5 bg-white font-montserrat text-[#10233A]">
    <header className="flex flex-wrap items-start justify-between gap-4 border-b border-[#D3E1EC] pb-4"><div><p className="text-xs font-semibold tracking-wide text-[#007EA7]">FINANSŲ HARMONIJA</p><h2 className="mt-2 text-xl font-semibold">{lt ? 'Tarpusavio skolų suderinimo aktas' : 'Balance confirmation statement'}</h2></div><p className="text-xs text-[#7288A3]">{lt ? 'Suderinimo data' : 'Confirmation date'}<br /><strong className="mt-1 block text-sm text-[#10233A]">{statement.date}</strong></p></header>
    <div className="grid gap-4 sm:grid-cols-2"><BalancePartyCard party={statement.sender} label={lt ? 'Mūsų įmonė' : 'Our company (your counterparty)'} /><BalancePartyCard party={statement.recipient} label={lt ? 'Jūsų įmonė' : 'Your company'} /></div>
    <div className="flex flex-wrap justify-between gap-4 rounded-lg bg-[#F1F6FA] p-4"><div><p className="text-xs text-[#7288A3]">{lt ? 'Suderinimo laikotarpis' : 'Confirmation period'}</p><p className="mt-1 text-sm font-semibold">{statement.from} — {statement.to}</p></div><div><p className="text-xs text-[#7288A3]">{lt ? 'Neapmokėtas likutis' : 'Outstanding balance'}</p><p className="mt-1 text-lg font-semibold text-[#007EA7]">{balanceMoney(statement.closing, statement.currency)}</p></div></div>
    <p className="text-xs text-[#7288A3]">{lt ? 'Likutis mūsų įmonės požiūriu: teigiamas – gautinas, neigiamas – mokėtinas.' : 'Balance from our company’s perspective: positive = receivable, negative = payable.'}</p>
    <BalanceLedgerTable statement={statement} />
    {signatures && <div className="grid grid-cols-2 gap-10 pt-5 text-xs text-[#7288A3]">{[statement.sender.name, statement.recipient.name].map((name, i) => <div key={i}><p className="font-medium text-[#10233A]">{name}</p><div className="mt-10 border-b border-[#A1B6C6]" /><p className="mt-2">{lt ? 'Vardas, pavardė, pareigos, parašas ir data' : 'Name, position, signature and date'}</p></div>)}</div>}
    <p className="break-all text-xs leading-5 text-[#536B85]">{lt ? 'Trūkstamus dokumentus pateikite čia:' : 'Upload missing documents:'}<br /><a className="text-[#007EA7] underline" href={balancePortalUrl(statement.id, true)} target="_blank" rel="noreferrer">{balancePortalUrl(statement.id, true)}</a></p>
  </article>;
}
