import { HelpCircle } from 'lucide-react';
import { translateUi as t } from '../i18n/language';

/** Lightweight contextual link; the article catalog is loaded only in the help tab. */
export default function HelpArticleLink({ category = 'system', article, label }: { category?: string; article: string; label: string }) {
  return <a href={`./#help?${new URLSearchParams({ category, article })}`} target="_blank" rel="noopener noreferrer"
    aria-label={`${t('Help')}: ${t(label)} · ${t('Opens in a new tab')}`} data-tooltip={`${t('Help')}: ${t(label)}`}
    onClick={event => event.stopPropagation()}
    className="inline-flex h-5 w-5 shrink-0 items-center justify-center rounded text-[#7288A3] hover:text-[#007EA7] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#007EA7]">
    <HelpCircle size={15} aria-hidden="true" />
  </a>;
}
