import { translateUi as uiText } from '../i18n/language';
import { useEffect, useId, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';
import { cancelDocumentApproval, createCorrectiveDocument, deleteUnconfirmedDocument, supabase, type Company, type DbDocument } from '../lib/supabase';
import { canEditCompanyDocuments, canViewCompanyDocuments } from '../lib/documentEditAccess';
import { cancelDocumentApprovalBlocker } from '../lib/documentApproval';
import { documentActionRights } from '../lib/documentRowActionAccess';
import { documentActionSnapshot, documentCorrectionKind, documentNumericValue, documentRowAction } from '../lib/documentRowActions';
import { accountingToday, stornoPeriodError, type StornoDocument, type StornoPeriodPolicy } from '../lib/documentStorno';
import { loadStornoPeriodPolicy } from '../lib/documentStornoAccess';
import ScheduleDatePicker from './ScheduleDatePicker';
import { SaveButton } from './ScopedActionButtons';

const buttonClass = 'inline-flex h-8 items-center justify-center rounded-md border-2 border-[#D3E1EC] bg-white px-3 text-[12px] font-semibold text-[#7288A3] hover:border-[#007EA7] hover:text-[#007EA7] disabled:cursor-not-allowed disabled:opacity-40';
const inputClass = 'h-10 w-full rounded-lg border border-[#D3E1EC] bg-white px-3 text-[12px] outline-none focus:border-[#007EA7]';

/** Contextual row action; Storno itself reuses DocumentStornoDialog instead. */
export default function DocumentRowActionDialog({ documentId, companyId, mode, onClose, onDeleted, onCreated, onUpdated, retainedInList = false }: {
  documentId: string; companyId: string; mode: 'delete' | 'correction' | 'cancel-approval'; onClose: () => void;
  onDeleted: (id: string) => void; onCreated: (document: DbDocument) => void; onUpdated: (document: DbDocument) => void;
  retainedInList?: boolean;
}) {
  const titleId = useId();
  const root = useRef<HTMLDivElement>(null);
  const saving = useRef(false);
  const [source, setSource] = useState<StornoDocument | null>(null);
  const [company, setCompany] = useState<Company | null>(null);
  const [blocker, setBlocker] = useState('');
  const [policy, setPolicy] = useState<StornoPeriodPolicy | null>(null);
  const [number, setNumber] = useState('');
  const [date, setDate] = useState(accountingToday);
  const [reason, setReason] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    let current = true;
    void Promise.all([
      supabase.from('documents').select('*').eq('id', documentId).eq('company_id', companyId),
      supabase.from('companies').select('*').eq('id', companyId),
      mode === 'cancel-approval' ? supabase.from('documents').select('id').eq('company_id', companyId).eq('correction_of_document_id', documentId) : Promise.resolve({ data: [], error: null }),
    ]).then(([documents, companies, corrections]) => {
      if (!current) return;
      if (documents.error || companies.error || corrections.error) throw new Error('The document could not be verified. Refresh before continuing.');
      const document = documents.data?.find(item => item.id === documentId && item.company_id === companyId) as StornoDocument | undefined;
      const organization = companies.data?.[0] as unknown as Company | undefined;
      if (!document || !organization || !canViewCompanyDocuments(organization)) throw new Error('The document is unavailable or you no longer have access.');
      const action = documentRowAction(document, documentActionRights(organization));
      setBlocker(mode === 'cancel-approval' ? cancelDocumentApprovalBlocker(document, {
        allowed: canEditCompanyDocuments(organization), today: accountingToday(), period: loadStornoPeriodPolicy(companyId),
        hasCorrections: Boolean(corrections.data?.length),
      }) : action.kind !== mode ? 'The document state changed. Close this action and refresh the list.' : action.disabledReason);
      setSource(document); setCompany(organization);
      if (mode === 'correction') setPolicy(loadStornoPeriodPolicy(companyId));
    }).catch(value => { if (current) setError(value instanceof Error ? value.message : 'The document could not be loaded.'); });
    return () => { current = false; };
  }, [documentId, companyId, mode]);
  useEffect(() => {
    const previous = window.document.activeElement as HTMLElement | null;
    root.current?.focus();
    return () => { if (previous?.isConnected) previous.focus({ preventScroll: true }); };
  }, []);
  const correction = source ? documentCorrectionKind(source) : 'Credit note';
  const title = mode === 'cancel-approval' ? 'Cancel approval' : mode === 'delete' ? 'Delete document' : `Create ${correction.toLowerCase()}`;
  const periodError = mode === 'correction' && source && policy ? stornoPeriodError(date, String(source.document_date || date), accountingToday(), policy) : '';
  const perform = async () => {
    if (!source || blocker || saving.current) return;
    saving.current = true; setBusy(true); setError('');
    try {
      if (mode === 'delete') {
        await deleteUnconfirmedDocument(documentId, companyId, documentActionSnapshot(source));
        onDeleted(documentId);
      } else if (mode === 'cancel-approval') {
        const document = await cancelDocumentApproval(documentId, companyId, { expectedSnapshot: documentActionSnapshot(source), reason });
        onUpdated(document);
      } else {
        const document = await createCorrectiveDocument(documentId, companyId, { expectedSnapshot: documentActionSnapshot(source), number, date, reason });
        onCreated(document);
      }
      onClose();
    } catch (value) { setError(value instanceof Error ? value.message : 'The action could not be saved.'); }
    finally { saving.current = false; setBusy(false); }
  };
  return createPortal(<div className="fixed inset-0 z-[5100] flex items-center justify-center bg-[#10233A]/35 p-4" onMouseDown={event => { if (event.target === event.currentTarget && !busy) onClose(); }}>
    <div ref={root} tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby={titleId} className="flex max-h-[92vh] w-full max-w-[640px] flex-col rounded-xl border border-[#D3E1EC] bg-white font-montserrat text-[12px] text-[#10233A] shadow-xl outline-none" onKeyDown={event => {
      if (event.key === 'Escape') {
        event.stopPropagation();
        const calendar = root.current?.querySelector<HTMLButtonElement>('button[aria-haspopup="dialog"][aria-expanded="true"]');
        if (calendar) { calendar.click(); calendar.focus(); return; }
        if (!busy) onClose();
      }
      if (event.key === 'Tab') {
        const nodes = [...root.current!.querySelectorAll<HTMLElement>('button:not(:disabled), input:not(:disabled), textarea:not(:disabled), [tabindex="0"]')].filter(node => node.getClientRects().length);
        if (event.shiftKey && (window.document.activeElement === nodes[0] || window.document.activeElement === root.current)) { event.preventDefault(); nodes.at(-1)?.focus(); }
        else if (!event.shiftKey && (window.document.activeElement === nodes.at(-1) || window.document.activeElement === root.current)) { event.preventDefault(); nodes[0]?.focus(); }
      }
    }}>
      <header className="flex items-start justify-between gap-3 border-b border-[#D3E1EC] px-6 py-4"><div><h2 id={titleId} className="text-[18px] font-semibold">{uiText(title)}</h2><p className="mt-1 text-[#7288A3]">{company?.name} · {String(source?.number || documentId)}</p></div><button type="button" className={`${buttonClass} !w-8 !px-0`} aria-label={uiText("Close document action")} disabled={busy} onClick={onClose}><X size={16} /></button></header>
      <div className="space-y-4 overflow-y-auto p-6">
        {error && <p role="alert" className="rounded-lg border border-[#F4C7C7] bg-[#FFF0F0] p-3 text-[#B42318]">{error}</p>}
        {!source && !error && <p role="status">{uiText("Loading document…")}</p>}
        {source && <>
          <dl className="grid grid-cols-2 gap-4 rounded-lg border border-[#D3E1EC] p-4"><div><dt className="text-[#7288A3]">{uiText("Original document")}</dt><dd className="mt-1 font-semibold">{String(source.number || '—')}</dd></div><div><dt className="text-[#7288A3]">{uiText("Counterparty")}</dt><dd className="mt-1">{String(source.client_counterparty || '—')}</dd></div><div><dt className="text-[#7288A3]">{uiText("Document type")}</dt><dd className="mt-1">{String(source.document_type || '—')}</dd></div><div><dt className="text-[#7288A3]">{uiText("Total amount")}</dt><dd className="mt-1">{String(source.total_amount || '—')} {String(source.currency || '')}</dd></div></dl>
          {blocker && <p role="status" className="rounded-lg border border-[#EEB648] bg-[#FFF4DC] p-3 text-[#926317]">{blocker}</p>}
          {mode === 'delete' ? <p>{uiText(retainedInList
            ? 'Delete this unapproved document? It will remain visible as an inactive, struck-through record. Use Restore in the same row to return it to its previous status. Its data and action history will be retained.'
            : "Are you sure you want to delete this unapproved document? This action cannot be undone.")}</p> : mode === 'cancel-approval' ? <>
            <p>{uiText("Cancel approval and return this document to Draft for correction?")}</p>
            <div className="rounded-lg bg-[#F0F5FA] p-3"><p className="font-semibold">{String(source.status || source.accounting_note_status)}{uiText(" → Draft")}</p><p className="mt-1 text-[#7288A3]">{uiText("Document data and action history will be kept. No accounting entries will be reversed.")}</p></div>
            <div><label htmlFor={`${titleId}-reason`} className="mb-2 block font-medium">{uiText("Reason (optional)")}</label><textarea id={`${titleId}-reason`} value={reason} onChange={event => setReason(event.target.value)} maxLength={2000} rows={3} disabled={busy || Boolean(blocker)} className={`${inputClass} !h-auto py-3`} /></div>
          </> : <>
            <fieldset disabled={busy || Boolean(blocker)} className="grid gap-4 sm:grid-cols-2">
              <div><label htmlFor={`${titleId}-number`} className="mb-2 block font-medium">{uiText("Document number *")}</label><input id={`${titleId}-number`} value={number} maxLength={100} onChange={event => setNumber(event.target.value)} className={inputClass} /></div>
              <div><label className="mb-2 block font-medium">{uiText("Correction date *")}</label><ScheduleDatePicker value={date} onChange={setDate} ariaLabel={uiText("Correction date")} placeholder={uiText("YYYY-MM-DD")} /></div>
              <div className="sm:col-span-2"><label htmlFor={`${titleId}-reason`} className="mb-2 block font-medium">{uiText("Reason *")}</label><textarea id={`${titleId}-reason`} value={reason} onChange={event => setReason(event.target.value)} maxLength={2000} rows={3} className={`${inputClass} !h-auto py-3`} /></div>
            </fieldset>
            {periodError && <p role="alert" className="text-[#B42318]">{periodError}</p>}
            <div className="rounded-lg bg-[#F0F5FA] p-3"><p className="font-semibold">{correction} · {(-documentNumericValue(source.total_amount)).toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {String(source.currency || '')}</p><p className="mt-1 text-[#7288A3]">{uiText("A linked draft will open for editing. The original document and its GL entries stay unchanged. No accounting transfer is performed.")}</p></div>
          </>}
        </>}
      </div>
      <footer className="flex justify-end gap-3 border-t border-[#D3E1EC] px-6 py-3"><button type="button" className={buttonClass} disabled={busy} onClick={onClose}>{uiText("Cancel")}</button><SaveButton className="!h-8 !text-[12px]" disabled={!source || busy || Boolean(blocker) || (mode === 'correction' && (!policy || Boolean(periodError) || !number.trim() || !reason.trim()))} onClick={() => void perform()}>{busy ? mode === 'delete' ? uiText('Deleting…') : uiText('Saving…') : mode === 'cancel-approval' ? uiText('Cancel approval') : mode === 'delete' ? uiText('Delete') : `Create ${correction.toLowerCase()}`}</SaveButton></footer>
    </div>
  </div>, window.document.body);
}
