import { useState } from 'react';
import type { AppSession } from '../lib/accessControl';
import type { DbDocument } from '../lib/supabase';
import type { InvoiceChatContext } from './invoices/invoiceChat';
import { useOcrInbox } from '../hooks/useOcrInbox';
import { translateUi as uiText } from '../i18n/language';
import ChatsView from './ChatsView';
import DocumentIssueConversation from './DocumentIssueConversation';
import { PageHeader, PageActionButton } from './PageHeader';
import { SystemBreadcrumb } from './SystemNavigation';
import OcrSearchField from './OcrSearchField';

export default function OcrChatsView({ session, currentUserName, conversation, initialIssue, ocrOnly, onOpenDocument }: {
  session: AppSession; currentUserName: string; conversation?: InvoiceChatContext | null; ocrOnly: boolean;
  initialIssue?: { documentId: string; issueId: string } | null; onOpenDocument: (document: DbDocument) => void;
}) {
  const inbox = useOcrInbox(session);
  const [showIssues, setShowIssues] = useState(Boolean(initialIssue));
  const [selected, setSelected] = useState(initialIssue || null);
  const [query, setQuery] = useState('');
  if (!showIssues) return <ChatsView currentUserName={currentUserName} conversation={conversation} ocrOnly={ocrOnly}
    onOpenDocument={onOpenDocument} onOpenIssues={() => setShowIssues(true)} />;
  const rows = inbox.conversations.filter(row => `${row.company.name} ${row.document.number} ${row.document.file_case} ${row.issue.message}`.toLowerCase().includes(query.toLowerCase()));
  const opened = inbox.conversations.find(row => row.document.id === selected?.documentId && row.issue.id === selected?.issueId);
  return <section className="flex h-screen min-h-0 flex-col gap-3 bg-white px-4 py-8 font-montserrat sm:px-8 lg:px-[72px]">
    <PageHeader title={uiText('Chats')} actions={<PageActionButton onClick={() => setShowIssues(false)}>{uiText('All conversations')}</PageActionButton>} />
    <SystemBreadcrumb items={['Chats', 'Document issue conversations']} />
    <div className="grid min-h-0 flex-1 grid-cols-[minmax(220px,320px)_minmax(0,1fr)] overflow-hidden rounded-xl border border-[#D3E1EC]">
      <aside className="flex min-h-0 flex-col border-r border-[#E5EDF9] bg-[#FCFDFE]">
        <div className="border-b border-[#E5EDF9] p-3"><OcrSearchField ariaLabel={uiText('Search conversations')} value={query} onChange={setQuery} /></div>
        <div className="min-h-0 flex-1 overflow-y-auto p-2">{rows.map(row => <button key={`${row.document.id}:${row.issue.id}`} type="button"
          onClick={() => setSelected({ documentId: row.document.id, issueId: row.issue.id })} aria-pressed={opened === row}
          className={`mb-1 flex w-full flex-col gap-1 rounded-lg p-3 text-left text-[12px] ${opened?.issue.id === row.issue.id ? 'bg-[#E5EDF9]' : 'hover:bg-[#F0F7FA]'}`}>
          <span className="flex w-full items-center gap-2 font-semibold text-[#10233A]"><span className="min-w-0 flex-1 truncate">{row.document.number || row.document.file_case}</span>{row.unread > 0 && <span className="rounded-full bg-[#007EA7] px-1.5 text-[10px] text-white">{row.unread}</span>}</span>
          <span className="text-[#7288A3]">{row.company.name}</span><span className="line-clamp-2 text-[#7288A3]">{row.issue.message}</span>
        </button>)}{!rows.length && <p className="p-3 text-[12px] text-[#7288A3]">{uiText('No issue conversations.')}</p>}</div>
      </aside>
      <div className="min-h-0 min-w-0 overflow-y-auto p-4">{opened ? <>
        <div className="mb-3 flex items-center justify-between gap-3"><h2 className="text-[14px] font-semibold text-[#10233A]">{opened.document.number || opened.document.file_case}</h2><PageActionButton onClick={() => onOpenDocument(opened.document)}>{uiText('Open document')}</PageActionButton></div>
        <DocumentIssueConversation key={`${opened.document.id}:${opened.issue.id}`} documentId={opened.document.id} companyId={opened.company.id} issueId={opened.issue.id} side={opened.side} />
      </> : <p className="p-6 text-center text-[12px] text-[#7288A3]">{uiText('Select a conversation')}</p>}</div>
    </div>
  </section>;
}
