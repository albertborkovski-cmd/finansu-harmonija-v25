import { useEffect, useRef, useState } from 'react';
import { Pencil, Play, Plus, Power, Save, X } from 'lucide-react';
import { translateUi as t } from '../i18n/language';
import { PageHeader, PageActionButton } from './PageHeader';
import OcrBreadcrumb from './OcrBreadcrumb';
import OcrSearchField from './OcrSearchField';
import SearchableSelect from './SearchableSelect';
import HorizontalTableScrollbar from './HorizontalTableScrollbar';
import TablePagination from './TablePagination';
import { TABLE_BATCH_SIZE } from '../lib/tablePaging';
import HelpArticleLink from './HelpArticleLink';
import { loadOrganizationReferenceRecords } from './OrganizationReferenceValuesView';
import { documentTypeCatalogOptions } from '../lib/documentTypeCatalog';
import { ocrRoutingTypeCodes } from '../lib/ocrApprovalRouting';
import { loadOcrFieldValidationRules, OCR_FIELD_VALIDATION_CHANGED_EVENT } from '../lib/ocrFieldValidation';
import { automationDocumentFields, automationRuleValueError, automationRulesForDocumentTypes, evaluateConfiguredAutomationRules } from '../lib/ocrAutomationDocument';
import { supabase, ensureOcrFormExamples, type Company } from '../lib/supabase';
import { canAccessAssignedOrganization } from '../lib/linkedSettingsData';
import { AUTH_SESSION_KEY } from '../lib/currentUser';
import { parseSession } from '../lib/accessControl';
import { automationPermissions, automationRuleVisible, canEditAutomationRule, loadAutomationStore, saveAutomationRule, setAutomationRuleEnabled,
  evaluateAutomationRules, OCR_AUTOMATION_CHANGED, type AutomationRule } from '../lib/ocrAutomationRules';

const controlClass = 'h-10 w-full min-w-0 rounded-lg border border-[#D3E1EC] bg-white px-3 text-[13px] text-[#10233A] outline-none focus:border-[#007EA7]';
const actionLabels = { assign: 'Assign value', required: 'Require a value', equals: 'Validate expected value' };
const ruleColumns = [
  { key: 'name', label: 'Rule name', width: 240 },
  { key: 'type', label: 'Document type', width: 210 },
  { key: 'organization', label: 'Organization', width: 180 },
  { key: 'field', label: 'Target field', width: 180 },
  { key: 'condition', label: 'Condition', width: 240 },
  { key: 'action', label: 'Action', width: 220 },
  { key: 'status', label: 'Status', width: 110 },
];
const ruleGrid = `${ruleColumns.map(column => `${column.width}px`).join(' ')} minmax(80px, 1fr)`;
const ruleTableWidth = ruleColumns.reduce((width, column) => width + column.width, 80);
const rowActionClass = 'flex h-7 w-7 shrink-0 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] transition-colors hover:border-[#007EA7] hover:text-[#007EA7] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#007EA7] focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-40';
const ruleText = (value: string, className = '') => <span data-tooltip={value} className={`block truncate ${className}`}>{value}</span>;
const initialRule = (): AutomationRule => ({ id: crypto.randomUUID(), name: '', documentType: '', organizationId: '', fieldKey: '',
  conditionText: '', match: 'contains', action: 'assign', value: '', enabled: true, overwrite: false, updatedAt: '' });

export default function OcrDocumentRulesView() {
  const [store, setStore] = useState(loadAutomationStore);
  const [catalog, setCatalog] = useState(() => loadOrganizationReferenceRecords('Document type'));
  const [companies, setCompanies] = useState<Company[]>([]);
  const [draft, setDraft] = useState<AutomationRule | null>(null);
  const [baseline, setBaseline] = useState('');
  const [query, setQuery] = useState('');
  const [notice, setNotice] = useState('');
  const [, setRevision] = useState(0);
  const [testText, setTestText] = useState('');
  const [testValue, setTestValue] = useState('');
  const [testOrganization, setTestOrganization] = useState('');
  const [result, setResult] = useState<ReturnType<typeof evaluateAutomationRules> | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const permissions = automationPermissions();
  const editable = permissions.edit && (!draft || canEditAutomationRule(draft));
  const typeOptions = documentTypeCatalogOptions(catalog).map(option => ({ ...option, label: t(option.label) }));
  const currentRules = automationRulesForDocumentTypes(store.rules, catalog);
  const typeCodes = ocrRoutingTypeCodes({ document_type: draft?.documentType }, catalog);
  // Only document-level fields: party and line values retain their independent scopes.
  const fields = draft ? automationDocumentFields(loadOcrFieldValidationRules({ documentTypes: typeCodes })) : [];
  const targetField = fields.find(field => field.key === draft?.fieldKey);
  const resultOptions = targetField?.key === 'documentPurpose' ? ['Purchase', 'Sale']
    : targetField?.inputType === 'boolean' ? ['true', 'false'] : targetField?.inputType === 'select' ? targetField.options : undefined;
  const labelFor = (rule: AutomationRule) => loadOcrFieldValidationRules({ documentTypes: ocrRoutingTypeCodes({ document_type: rule.documentType }, catalog) }).find(field => field.key === rule.fieldKey)?.label || rule.fieldKey;

  useEffect(() => {
    let mounted = true;
    const refresh = () => {
      setStore(loadAutomationStore()); setCatalog(loadOrganizationReferenceRecords('Document type')); setRevision(value => value + 1);
      void supabase.from('companies').select('*').then(({ data, error }) => {
        if (!mounted) return;
        if (error) { setNotice('Organizations could not be loaded.'); return; }
        const session = parseSession(localStorage.getItem(AUTH_SESSION_KEY));
        setCompanies(session ? ((data || []) as unknown as Company[]).filter(company => canAccessAssignedOrganization(company, session)) : []);
      });
    };
    const events = [OCR_AUTOMATION_CHANGED, OCR_FIELD_VALIDATION_CHANGED_EVENT, 'organization-reference-updated', 'finansu-harmonija:settings-data-changed', 'storage'];
    events.forEach(event => window.addEventListener(event, refresh)); refresh();
    void ensureOcrFormExamples('automation').catch(() => { if (mounted) setNotice('The test document could not be prepared. Existing documents are unchanged.'); });
    void ensureOcrFormExamples('automation-workflow').catch(() => { if (mounted) setNotice('The test document could not be prepared. Existing documents are unchanged.'); });
    return () => { mounted = false; events.forEach(event => window.removeEventListener(event, refresh)); };
  }, []);
  const close = () => {
    if (draft && JSON.stringify(draft) !== baseline && !window.confirm(t('Discard unsaved rule changes?'))) return;
    setDraft(null); setResult(null); setNotice('');
  };
  const edit = (rule: AutomationRule) => {
    const documentType = automationRulesForDocumentTypes([rule], catalog)[0]?.documentType || rule.documentType;
    const next = { ...rule, documentType };
    setDraft(next); setBaseline(JSON.stringify(next)); setResult(null); setNotice('');
    setTestText(''); setTestValue(''); setTestOrganization(rule.organizationId);
  };
  const update = (patch: Partial<AutomationRule>) => { setDraft(current => current ? { ...current, ...patch } : current); setResult(null); };
  const save = () => {
    if (!draft) return;
    if (!typeOptions.some(type => type.value === draft.documentType) || !fields.some(field => field.key === draft.fieldKey)) { setNotice('Choose an active document type and a configured field.'); return; }
    if (draft.organizationId && !companies.some(company => company.id === draft.organizationId)) { setNotice('Choose an accessible organization.'); return; }
    const valueError = automationRuleValueError(draft, fields);
    if (valueError) { setNotice(valueError); return; }
    try { saveAutomationRule(draft); setStore(loadAutomationStore(true)); setDraft(null); setResult(null); setNotice('Rule saved. Previously completed documents are unchanged.'); }
    catch (error) { setNotice(error instanceof Error ? error.message : 'The rule could not be saved.'); }
  };
  const example = () => {
    const documentType = typeOptions.find(option => option.value === 'FH_TEST_AUTOMATION')?.value
      || typeOptions.find(option => /vat.invoice/i.test(option.value + ' ' + option.label))?.value || typeOptions[0]?.value || '';
    const rule = { ...initialRule(), name: 'TEST · str.42 → PVM1', documentType, organizationId: permissions.global ? '' : companies[0]?.id || '', fieldKey: 'vatClassifier', conditionText: 'str.42', value: 'PVM1', enabled: false };
    edit(rule); setTestText('TESTINĖ SĄSKAITA\nPaslaugos. Taikoma str.42 nuostata.');
  };
  const test = () => {
    if (!draft || !fields.some(field => field.key === draft.fieldKey) || !draft.conditionText.trim()) { setNotice('Choose a field and enter the condition text.'); return; }
    const valueError = automationRuleValueError(draft, fields);
    if (valueError) { setNotice(valueError); return; }
    setNotice('');
    setResult(evaluateConfiguredAutomationRules([...currentRules.filter(rule => rule.id !== draft.id), { ...draft, enabled: true }], {
      documentTypeCodes: typeCodes, organizationId: testOrganization, text: testText,
      values: Object.fromEntries(fields.map(field => [field.key, field.key === draft.fieldKey ? testValue : ''])),
    }, fields));
  };
  const rows = store.rules.filter(automationRuleVisible).filter(rule => [rule.name, rule.conditionText, rule.value, rule.documentType, labelFor(rule), companies.find(company => company.id === rule.organizationId)?.name].join(' ').toLocaleLowerCase().includes(query.toLocaleLowerCase()));
  return <div className="ocr-document-rules flex h-dvh min-h-0 min-w-0 flex-col gap-4 overflow-hidden bg-white px-4 py-8 font-montserrat text-[#10233A] sm:px-8 sm:py-10 lg:px-[56px]">
    <PageHeader title={t('Document validation & training')} afterTitle={<HelpArticleLink category="ocr-workflow" article="document-rules" label="Document validation & training" />} />
    <OcrBreadcrumb items={['Document validation & training', draft && 'Rule']} />
    {draft && <div className="flex shrink-0 flex-wrap items-center justify-end gap-2">
      <PageActionButton icon={<X size={16} />} onClick={close}>{t('Cancel')}</PageActionButton>
      <PageActionButton icon={<Save size={16} />} disabled={!editable} onClick={save}>{t('Save')}</PageActionButton>
    </div>}
    {notice && <div role="status" className="rounded-lg border border-[#D3E1EC] bg-[#F2F8FC] px-4 py-3 text-[13px]">{t(notice)}</div>}
    {draft ? <div className="min-h-0 flex-1 overflow-y-auto pb-6">
      <p className="mb-4 text-[13px] leading-6 text-[#7288A3]">{t('Choose the scope, condition and result. Test the rule before enabling it. Manual confirmations are preserved.')}</p>
      <fieldset disabled={!editable} className="grid min-w-0 gap-4 rounded-xl border border-[#D3E1EC] p-5 md:grid-cols-2">
        <legend className="px-2 text-[14px] font-semibold">{t('Rule configuration')}</legend>
        <label className="space-y-2 text-[12px] font-medium"><span>{t('Rule name')} *</span><input aria-label={t('Rule name')} className={controlClass} value={draft.name} onChange={event => update({ name: event.target.value })} /></label>
        <div className="space-y-2 text-[12px] font-medium"><div>{t('Document type')} *</div><SearchableSelect ariaLabel={t('Document type')} value={draft.documentType} options={typeOptions} onChange={documentType => update({ documentType, fieldKey: '' })} portalMenu className={`${controlClass} pr-9`} /></div>
        <div className="space-y-2 text-[12px] font-medium"><div>{t('Organization (optional)')}</div><SearchableSelect ariaLabel={t('Organization (optional)')} value={draft.organizationId} options={[...(permissions.global || !draft.organizationId ? [{ value: '', label: t('All organizations') }] : []), ...companies.map(company => ({ value: company.id, label: company.name }))]} onChange={organizationId => { update({ organizationId }); setTestOrganization(organizationId); }} portalMenu className={`${controlClass} pr-9`} /></div>
        <div className="space-y-2 text-[12px] font-medium"><div>{t('Target field')} *</div><SearchableSelect ariaLabel={t('Target field')} value={draft.fieldKey} options={fields.map(field => ({ value: field.key, label: t(field.label) }))} disabled={!draft.documentType} onChange={fieldKey => update({ fieldKey })} portalMenu className={`${controlClass} pr-9`} /></div>
        <div className="space-y-2 text-[12px] font-medium"><div>{t('Condition')}</div><SearchableSelect ariaLabel={t('Condition')} value={draft.match} options={[{ value: 'contains', label: t('Document text contains') }, { value: 'equals', label: t('Document text equals') }]} onChange={match => update({ match: match as AutomationRule['match'] })} portalMenu className={`${controlClass} pr-9`} /></div>
        <label className="space-y-2 text-[12px] font-medium"><span>{t('Recognized text to match')} *</span><input aria-label={t('Recognized text to match')} className={controlClass} placeholder="str.42" value={draft.conditionText} onChange={event => update({ conditionText: event.target.value })} /></label>
        <div className="space-y-2 text-[12px] font-medium"><div>{t('Action')}</div><SearchableSelect ariaLabel={t('Action')} value={draft.action} options={Object.entries(actionLabels).map(([value, label]) => ({ value, label: t(label) }))} onChange={action => update({ action: action as AutomationRule['action'] })} portalMenu className={`${controlClass} pr-9`} /></div>
        {draft.action !== 'required' && <div className="space-y-2 text-[12px] font-medium"><div>{t('Result / expected value')} *</div>{resultOptions
          ? <SearchableSelect ariaLabel={t('Result / expected value')} value={draft.value} options={resultOptions.map(value => ({ value, label: t(value) }))} onChange={value => update({ value })} portalMenu className={`${controlClass} pr-9`} />
          : <input aria-label={t('Result / expected value')} className={controlClass} type={targetField?.inputType === 'date' ? 'date' : 'text'} inputMode={targetField?.inputType === 'number' ? 'decimal' : undefined} placeholder={targetField?.key === 'vatClassifier' ? 'PVM1' : undefined} value={draft.value} onChange={event => update({ value: event.target.value })} />}</div>}
        <div className="flex flex-wrap items-center gap-x-8 gap-y-3 text-[12px] md:col-span-2">
          <label className="flex items-center gap-2"><input type="checkbox" className="h-4 w-4 accent-[#007EA7]" checked={draft.enabled} onChange={event => update({ enabled: event.target.checked })} />{t('Rule enabled')}</label>
          {draft.action === 'assign' && <label className="flex items-center gap-2"><input type="checkbox" className="h-4 w-4 accent-[#007EA7]" checked={draft.overwrite} onChange={event => update({ overwrite: event.target.checked })} />{t('Replace OCR value (not manual confirmation)')}</label>}
        </div>
      </fieldset>
      <section className="mt-5 rounded-xl border border-[#D3E1EC] bg-[#F8FBFD] p-5">
        <div className="mb-4 flex items-center justify-between gap-3"><h2 className="text-[14px] font-semibold">{t('Test without changing documents')}</h2><PageActionButton icon={<Play size={15} />} onClick={test}>{t('Test rule')}</PageActionButton></div>
        <div className="grid gap-4 md:grid-cols-2">
          <label className="space-y-2 text-[12px] font-medium md:row-span-2"><span>{t('Test document text')}</span><textarea aria-label={t('Test document text')} rows={6} className={`${controlClass} !h-auto py-3`} value={testText} onChange={event => { setTestText(event.target.value); setResult(null); }} /></label>
          <div className="space-y-2 text-[12px] font-medium"><div>{t('Test organization')}</div><SearchableSelect ariaLabel={t('Test organization')} value={testOrganization} options={[{ value: '', label: t('No organization') }, ...companies.map(company => ({ value: company.id, label: company.name }))]} onChange={value => { setTestOrganization(value); setResult(null); }} portalMenu className={`${controlClass} pr-9`} /></div>
          <label className="space-y-2 text-[12px] font-medium"><span>{t('Current field value')}</span><input aria-label={t('Current field value')} className={controlClass} value={testValue} onChange={event => { setTestValue(event.target.value); setResult(null); }} /></label>
        </div>
        <p className="mt-3 text-[12px] leading-5 text-[#7288A3]">{t('The preview includes enabled saved rules and this draft. It does not save the rule or modify documents. A disabled draft is tested as enabled.')}</p>
        {result && <div role="status" className="mt-4 space-y-2 rounded-lg border border-[#D3E1EC] bg-white p-4 text-[13px]">
          <p className="font-semibold">{t(result.matchedRuleIds.includes(draft.id) ? 'Condition matched' : 'Condition did not match')}</p>
          <p>{t('Result / expected value')}: <strong>{result.values[draft.fieldKey] || '—'}</strong></p>
          {result.warnings.map((warning, index) => <p key={`${warning.ruleId}:${index}`} className="text-[#B42318]">{t(fields.find(field => field.key === warning.fieldKey)?.label || warning.fieldKey)}: {warning.message.startsWith('Expected value: ') ? `${t('Expected value')}: ${warning.message.slice(16)}` : t(warning.message)}</p>)}
        </div>}
      </section>
    </div> : <>
      <p data-table-workspace-overview className="shrink-0 text-[12px] leading-[18px] text-[#7288A3]">{t('Rules use recognized document text. Organization-specific rules take precedence. Completed documents are not changed.')}</p>
      <div className="flex shrink-0 flex-wrap items-center justify-between gap-3">
        <div className="min-w-0 flex-1"><OcrSearchField ariaLabel={t('Search rules')} value={query} onChange={setQuery} /></div>
        <div className="flex shrink-0 items-center gap-2">
          <PageActionButton onClick={example}>{t('Test example')}</PageActionButton>
          <PageActionButton icon={<Plus size={16} />} disabled={!editable} onClick={() => edit({ ...initialRule(), organizationId: permissions.global ? '' : companies[0]?.id || '' })}>{t('Create new')}</PageActionButton>
          <div data-table-workspace-tools className="ml-2 flex h-7 shrink-0 items-center gap-4" />
        </div>
      </div>
      <div ref={scrollRef} aria-label={t('Document validation & training')} className="min-h-0 flex-1 overflow-auto overscroll-contain scrollbar-hide">
        <div role="table" aria-label={t('Rules')} style={{ minWidth: ruleTableWidth }}>
          <div role="row" style={{ gridTemplateColumns: ruleGrid }} className="system-table-header-row mb-1 grid h-10 items-center border-b border-[#D3E1EC] bg-white text-[12px] font-medium">
            {ruleColumns.map((column, index) => <div role="columnheader" key={column.key} className={`min-w-0 px-3 ${index ? 'border-l border-[#D3E1EC]' : ''}`}>{ruleText(t(column.label))}</div>)}
            <div role="columnheader" className="system-table-row-actions px-2"><span className="sr-only">{t('Actions')}</span></div>
          </div>
          {rows.map((rule, index) => <div role="row" key={rule.id} data-record-inactive={!rule.enabled || undefined} style={{ gridTemplateColumns: ruleGrid }} className={`mb-0.5 grid min-h-[56px] items-center rounded-md text-[12px] leading-[18px] ${index % 2 === 0 ? 'bg-[#F8FDFF]' : 'bg-white'} hover:bg-[#E7F4F9]`}>
            <div role="cell" className="min-w-0 px-3 py-1.5">{ruleText(rule.name)}</div>
            <div role="cell" className="min-w-0 px-3 py-1.5">{ruleText(typeOptions.find(type => type.value === currentRules.find(current => current.id === rule.id)?.documentType)?.label || rule.documentType)}</div>
            <div role="cell" className="min-w-0 px-3 py-1.5">{ruleText(companies.find(company => company.id === rule.organizationId)?.name || (rule.organizationId ? rule.organizationId : t('All organizations')))}</div>
            <div role="cell" className="min-w-0 px-3 py-1.5">{ruleText(t(labelFor(rule)))}</div>
            <div role="cell" className="min-w-0 px-3 py-1.5">{ruleText(t(rule.match === 'contains' ? 'Document text contains' : 'Document text equals'), 'text-[11px] text-[#7288A3]')}{ruleText(rule.conditionText)}</div>
            <div role="cell" className="min-w-0 px-3 py-1.5">{ruleText(t(actionLabels[rule.action]))}{rule.action !== 'required' && ruleText(rule.value, 'text-[#7288A3]')}</div>
            <div role="cell" className="min-w-0 px-3 py-1.5"><span className="inline-flex items-center gap-2"><span aria-hidden="true" className={`h-1.5 w-1.5 shrink-0 rounded-full ${rule.enabled ? 'bg-[#2E9A74]' : 'bg-[#A1B6C6]'}`} />{t(rule.enabled ? 'Active' : 'Inactive')}</span></div>
            <div role="cell" className="system-table-row-actions flex items-center justify-end gap-2 px-2">
              <button type="button" className={rowActionClass} aria-label={`${t('Edit')}: ${rule.name}`} onClick={() => edit(rule)}><Pencil size={14} aria-hidden="true" /></button>
              <button type="button" className={rowActionClass} disabled={!canEditAutomationRule(rule)} aria-label={`${t(rule.enabled ? 'Disable rule' : 'Enable rule')}: ${rule.name}`} onClick={() => { try { setAutomationRuleEnabled(rule.id, !rule.enabled); setStore(loadAutomationStore(true)); } catch (error) { setNotice(error instanceof Error ? error.message : 'The rule could not be saved.'); } }}><Power size={14} aria-hidden="true" /></button>
            </div>
          </div>)}
        </div>
        {!rows.length && <div className="py-16 text-center text-[13px] text-[#7288A3]">{t(query ? 'No rules match your search.' : 'No rules yet. Create a rule or open the test example.')}</div>}
      </div>
      <HorizontalTableScrollbar scrollRef={scrollRef} />
      <TablePagination currentPage={Math.max(1, Math.ceil(rows.length / TABLE_BATCH_SIZE))} totalPages={Math.max(1, Math.ceil(rows.length / TABLE_BATCH_SIZE))} itemCount={rows.length} onPageChange={() => {}} scrollRef={scrollRef} />
    </>}
  </div>;
}
