import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ChevronLeft, ClipboardPaste, Pencil, Plus, Trash2 } from 'lucide-react';
import { translateUi as t } from '../i18n/language';
import { supabase, type Company } from '../lib/supabase';
import { canEditCompanySettings } from '../lib/documentEditAccess';
import { ADDITIONAL_CODE_SECTIONS, parseOrganizationCodes, saveOrganizationCodes, organizationCodeLinked, type AdditionalCodeSection, type OrganizationCode } from '../lib/organizationAdditionalCodes';
import { parseExpenseCodePaste, expenseCodeRowErrors, EXPENSE_CODE_TYPES, type ExpenseCodeType, type ExpenseCodeDraft } from '../lib/companyExpenseImport';
import { loadCompanyGeneralLedgerRegister, importCompanyExpenseCodes, updateCompanyExpenseCodes, type LedgerAccount } from './GeneralLedgerView';
import { isInactiveRecord } from '../lib/recordLifecycle';
import { PageActionButton } from './PageHeader';
import SearchableSelect from './SearchableSelect';
import OcrSearchField from './OcrSearchField';
import HorizontalTableScrollbar from './HorizontalTableScrollbar';
import GlJournalDialog from './GlJournalDialog';
import { RowDeleteButton } from './DeleteButtons';
import OrganizationSettingsHelpLink from './OrganizationSettingsHelpLink';

type CodeRow = OrganizationCode & { expenseType?: ExpenseCodeType; alternativeCodes?: string[] };
const empty = (): ExpenseCodeDraft => ({ code: '', name: '', alternativeCodes: '' });
const inputClass = 'h-10 w-full rounded-md border border-[#D3E1EC] bg-white px-3 text-[13px] text-[#10233A] outline-none focus:border-[#007EA7]';

export default function OrganizationAdditionalCodes({ companyId, section, onUpdated, onClose }: {
  companyId: string; section: AdditionalCodeSection | 'expenses'; onUpdated: (company: Company) => void; onClose: () => void;
}) {
  const info = ADDITIONAL_CODE_SECTIONS.find(item => item.key === section);
  const label = info?.label || 'Expenses';
  const expense = section === 'expenses';
  const [company, setCompany] = useState<Company>();
  const [rows, setRows] = useState<CodeRow[]>([]), [search, setSearch] = useState('');
  const [mode, setMode] = useState<'new' | 'edit' | 'excel' | null>(null), [original, setOriginal] = useState<CodeRow>();
  const [draft, setDraft] = useState<ExpenseCodeDraft>(empty), [text, setText] = useState(''), [type, setType] = useState<ExpenseCodeType>('Code');
  const [error, setError] = useState(''), [busy, setBusy] = useState(false), [loading, setLoading] = useState(true);
  const [removing, setRemoving] = useState<string[] | null>(null);
  const scroll = useRef<HTMLDivElement>(null);
  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const result = await supabase.from('companies').select('*').eq('id', companyId);
      const current = result.data?.[0] as unknown as Company | undefined;
      if (result.error || !current) throw new Error('Could not load organization settings.');
      setCompany(current);
      setRows(expense ? loadCompanyGeneralLedgerRegister(companyId, current.general_ledger) : parseOrganizationCodes(current[info!.field]).items);
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Unable to save.'); }
    finally { setLoading(false); }
  }, [companyId, expense, info]);
  useEffect(() => { void refresh(); }, [refresh]);
  const allowed = Boolean(company && canEditCompanySettings(company) && !isInactiveRecord(company));
  const parsed = useMemo(() => {
    try { return { rows: mode === 'excel' ? parseExpenseCodePaste(text) : [draft], error: '' }; }
    catch (cause) { return { rows: [], error: cause instanceof Error ? cause.message : 'Could not read the pasted codes.' }; }
  }, [mode, text, draft]);
  const errors = expenseCodeRowErrors(parsed.rows, rows.filter(row => row.id !== original?.id));
  const invalid = Boolean(parsed.error || !parsed.rows.length || errors.some(row => row.length));
  const filtered = useMemo(() => rows.filter(row => `${row.code} ${row.name}`.toLocaleLowerCase().includes(search.trim().toLocaleLowerCase())).sort((a, b) => a.code.localeCompare(b.code, undefined, { numeric: true })), [rows, search]);
  const edit = (next: 'new' | 'edit' | 'excel', row?: CodeRow) => {
    setMode(next); setOriginal(row); setDraft(row ? { code: row.code, name: row.name, alternativeCodes: row.alternativeCodes?.join(', ') || '' } : empty()); setText(''); setType(row?.expenseType || 'Code'); setError('');
  };
  const save = async () => {
    if (!company || !allowed || busy || invalid) return;
    setBusy(true); setError('');
    try {
      if (expense) {
        if (mode === 'edit' && original) await updateCompanyExpenseCodes(companyId, { original: original as LedgerAccount, edit: { ...original, ...draft, expenseType: type, alternativeCodes: draft.alternativeCodes.split(/[,;]/).map(value => value.trim()).filter(Boolean) } as LedgerAccount });
        else await importCompanyExpenseCodes(companyId, company.general_ledger || '', parsed.rows, type);
      } else {
        const result = await saveOrganizationCodes(companyId, section as AdditionalCodeSection, mode === 'edit' && original ? { type: 'edit', original, row: draft } : { type: 'add', rows: parsed.rows });
        onUpdated(result.company);
      }
      setMode(null); setOriginal(undefined); await refresh();
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Unable to save.'); }
    finally { setBusy(false); }
  };
  const remove = async () => {
    if (!removing || !allowed || busy) return;
    setBusy(true); setError('');
    try {
      if (expense) await updateCompanyExpenseCodes(companyId, { removeIds: removing });
      else { const result = await saveOrganizationCodes(companyId, section as AdditionalCodeSection, { type: 'remove', ids: removing }); onUpdated(result.company); }
      setRemoving(null); await refresh();
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Unable to save.'); }
    finally { setBusy(false); }
  };
  return <section className="flex h-full min-h-0 min-w-0 flex-col gap-4 font-montserrat" aria-label={t(label)}>
    <header className="flex min-h-8 shrink-0 flex-wrap items-center justify-between gap-3">
      <div className="flex items-center gap-2">{mode && <PageActionButton iconOnly icon={<ChevronLeft size={16} />} ariaLabel={t('Back')} disabled={busy} onClick={() => { setMode(null); setError(''); }}>{t('Back')}</PageActionButton>}<h3 className="text-[16px] font-semibold text-[#10233A]">{t(mode === 'excel' ? 'Import from Excel' : mode === 'new' ? 'New code' : mode === 'edit' ? 'Edit code' : label)}</h3><OrganizationSettingsHelpLink section={section} topic={mode === 'excel' ? 'excel' : 'overview'} label={label} /></div>
      {!mode && <div className="ml-auto flex flex-wrap justify-end gap-2"><PageActionButton disabled={!allowed || loading} icon={<Plus size={15} />} onClick={() => edit('new')}>{t('New code')}</PageActionButton><PageActionButton disabled={!allowed || loading} icon={<ClipboardPaste size={15} />} onClick={() => edit('excel')}>{t('Import from Excel')}</PageActionButton><PageActionButton disabled={!allowed || loading || !rows.some(row => row.active)} icon={<Trash2 size={15} />} onClick={() => { setError(''); setRemoving(rows.map(row => row.id)); }}>{t('Clear all')}</PageActionButton></div>}
    </header>
    {mode ? <div className="min-h-0 flex-1 space-y-4 overflow-y-auto pr-2 [scrollbar-gutter:stable]">
      {mode === 'excel' ? <><p className="text-[12px] leading-5 text-[#7288A3]">{t('Column A: Code. Column B: Name or description. Copy both columns and paste here.')}</p><label className="block space-y-2 text-[12px] text-[#7288A3]"><span className="inline-flex items-center gap-1.5">{t('Paste codes from Excel')}<OrganizationSettingsHelpLink section={section} topic="excel" label="Import from Excel" /></span><textarea aria-label={t('Paste codes from Excel')} value={text} onChange={event => setText(event.target.value)} disabled={busy} className={`${inputClass} h-28 resize-y py-2`} /></label></>
        : <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">{(['code', 'name'] as const).map(key => <label key={key} className="space-y-2 text-[12px] font-medium text-[#7288A3]"><span className="inline-flex items-center gap-1.5">{t(key === 'code' ? 'Code' : 'Name')} *<OrganizationSettingsHelpLink section={section} topic={key} label={key === 'code' ? 'Code' : 'Name'} /></span><input required aria-label={t(key === 'code' ? 'Code' : 'Name')} disabled={busy} value={draft[key]} maxLength={key === 'code' ? 100 : 1000} className={inputClass} onChange={event => setDraft(previous => ({ ...previous, [key]: event.target.value }))} /></label>)}</div>}
      {expense && <div className="grid grid-cols-1 gap-4 sm:grid-cols-2"><div className="space-y-2"><p className="flex items-center gap-1.5 text-[12px] font-medium text-[#7288A3]">{t('Type')}<OrganizationSettingsHelpLink section={section} topic="type" label="Type" /></p><SearchableSelect value={type} options={EXPENSE_CODE_TYPES.map(value => ({ value, label: t(value) }))} ariaLabel={t('Type')} onChange={value => setType(value as ExpenseCodeType)} portalMenu disabled={busy} className={inputClass} /></div>{mode !== 'excel' && <label className="space-y-2 text-[12px] font-medium text-[#7288A3]"><span className="inline-flex items-center gap-1.5">{t('Alternative codes')}<OrganizationSettingsHelpLink section={section} topic="alternativeCodes" label="Alternative codes" /></span><input aria-label={t('Alternative codes')} className={inputClass} value={draft.alternativeCodes} onChange={event => setDraft(previous => ({ ...previous, alternativeCodes: event.target.value }))} disabled={busy} /></label>}</div>}
      {parsed.error && <p role="alert" className="text-[12px] text-[#B42318]">{t(parsed.error)}</p>}
      {mode === 'excel' && parsed.rows.length > 0 && <div className="max-h-[360px] overflow-auto rounded-lg border border-[#D3E1EC]"><table className="w-full text-left text-[12px]"><thead className="sticky top-0 bg-[#F2F6FA]"><tr><th className="px-3 py-2"><span className="inline-flex items-center gap-1">{t('Code')}<OrganizationSettingsHelpLink section={section} topic="code" label="Code" /></span></th><th className="px-3 py-2"><span className="inline-flex items-center gap-1">{t('Name')}<OrganizationSettingsHelpLink section={section} topic="name" label="Name" /></span></th></tr></thead><tbody>{parsed.rows.map((row, index) => <tr key={index} className="border-t border-[#E5EDF9]"><td className="px-3 py-2">{row.code}{errors[index].map(message => <p key={message} className="text-[#B42318]">{t(message)}</p>)}</td><td className="px-3 py-2">{row.name}</td></tr>)}</tbody></table></div>}
      {mode !== 'excel' && (draft.code || draft.name) && errors[0]?.length > 0 && <p role="alert" className="text-[12px] text-[#B42318]">{errors[0].map(message => t(message)).join(' ')}</p>}
    </div> : <>
      <OcrSearchField value={search} onChange={setSearch} ariaLabel={t('Search codes')} />
      <div ref={scroll} className="min-h-0 flex-1 overflow-auto [scrollbar-gutter:stable]"><table className="w-full min-w-[520px] border-separate border-spacing-x-0 border-spacing-y-0.5 text-left text-[12px]">
        <thead className="sticky top-0 z-10 bg-white"><tr><th className="w-[24%] px-3 py-3 font-medium"><span className="inline-flex items-center gap-1">{t('Code')}<OrganizationSettingsHelpLink section={section} topic="code" label="Code" /></span></th><th className="px-3 py-3 font-medium"><span className="inline-flex items-center gap-1">{t('Name')}<OrganizationSettingsHelpLink section={section} topic="name" label="Name" /></span></th>{expense && <th className="px-3 py-3 font-medium"><span className="inline-flex items-center gap-1">{t('Type')}<OrganizationSettingsHelpLink section={section} topic="type" label="Type" /></span></th>}<th className="system-table-row-actions min-w-[88px] px-3 py-3"><span className="sr-only">{t('Actions')}</span></th></tr></thead>
        <tbody>{filtered.map((row, index) => <tr key={row.id} data-record-inactive={!row.active || undefined} className={`h-10 ${index % 2 === 0 ? 'bg-[#F8FDFF]' : 'bg-white'} hover:bg-[#E7F4F9]`}><td className="rounded-l-lg px-3 py-2">{row.code}</td><td className="px-3 py-2">{row.name || '—'}</td>{expense && <td className="px-3 py-2">{row.expenseType ? t(row.expenseType) : '—'}</td>}<td className="system-table-row-actions rounded-r-lg px-3 py-1.5"><div className="flex items-center justify-end gap-1.5"><button type="button" aria-label={`${t('Edit')}: ${row.code}`} title={t('Edit')} disabled={!allowed || busy} onClick={() => edit('edit', row)} className="flex h-7 w-7 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] hover:border-[#007EA7] hover:text-[#007EA7] disabled:opacity-40"><Pencil size={14} /></button><RowDeleteButton label={`${t('Delete')}: ${row.code}`} disabled={!allowed || busy} inactive={!row.active} linked={!expense && organizationCodeLinked(companyId, row)} onDelete={() => { setError(''); setRemoving([row.id]); }} /></div></td></tr>)}</tbody>
      </table>{!filtered.length && <p className="p-8 text-center text-[12px] text-[#7288A3]">{t(loading ? 'Loading…' : 'No matching records.')}</p>}</div>
      <HorizontalTableScrollbar scrollRef={scroll} fixed={false} expandable={false} />
    </>}
    {error && <p role="alert" className="text-[12px] text-[#B42318]">{t(error)}</p>}
    <footer className="flex min-h-[60px] shrink-0 items-center justify-end gap-2 border-t border-[#D3E1EC] pt-4"><PageActionButton disabled={busy} onClick={() => mode ? setMode(null) : onClose()}>{t(mode ? 'Cancel' : 'Close')}</PageActionButton>{mode && <PageActionButton disabled={busy || !allowed || invalid} onClick={() => void save()}>{t(busy ? 'Saving…' : mode === 'excel' ? 'Import' : 'Save changes')}</PageActionButton>}</footer>
    {removing && <GlJournalDialog title={removing.length > 1 ? 'Clear all' : 'Delete'} onClose={() => { if (!busy) setRemoving(null); }} overlayZIndex={280} footer={<><PageActionButton disabled={busy} onClick={() => setRemoving(null)}>{t('Cancel')}</PageActionButton><PageActionButton disabled={busy} onClick={() => void remove()}>{t('Confirm')}</PageActionButton></>}><p className="text-[13px] leading-6">{t('Unused codes will be deleted. Codes already used in documents will remain inactive with their history preserved.')}</p>{error && <p role="alert" className="mt-3 text-[12px] text-[#B42318]">{t(error)}</p>}</GlJournalDialog>}
  </section>;
}
