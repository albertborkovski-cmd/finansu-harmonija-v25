import type { ReactNode } from 'react';
import { translateUi as t, useLanguage } from '../i18n/language';
import { SAAS_PRODUCTS, SAAS_PRICING, SAAS_PERIODS, SAAS_OVERAGE, SAAS_MODULES, type CompanySaasPlan } from '../lib/companySaas';
import { contractDocumentPricing, contractPlanSaas, type ContractPlan, type DocumentPricing } from '../lib/contractPricing';
import SearchableSelect from './SearchableSelect';
import MultiSelectField from './MultiSelectField';

const DOCUMENT_PRICING_OPTIONS = [{ value: 'progressive', label: 'Progressive pricing tiers' }, { value: 'flat', label: 'Fixed price per document' }] as const;
const inputClass = 'h-[42px] w-full min-w-0 rounded-lg border border-[#D3E1EC] bg-white px-[14px] font-montserrat text-[14px] font-medium leading-5 text-[#10233A] outline-none focus:border-[#007EA7]';
const translated = (options: readonly { value: string; label: string }[]) => options.map(item => ({ ...item, label: t(item.label) }));
const priceLabel = (value: CompanySaasPlan) => value.kainodara === 'docs' ? 'Price per document (EUR)' : value.kainodara === 'users' ? 'Price per active user (EUR)' : 'Company fee per period (EUR)';
function Field({ label, children }: { label: string; children: ReactNode }) {
  return <div className="flex min-w-0 flex-col gap-2"><span className="text-[14px] font-semibold leading-5">{t(label)}</span>{children}</div>;
}

/** Uses the same option registries and FH controls as the company SaaS card. */
export function ContractPlanOptionsFields({ value, documentPricing, onChange, onPricingChange }: { value: CompanySaasPlan; documentPricing: DocumentPricing; onChange: (value: CompanySaasPlan) => void; onPricingChange: (value: DocumentPricing) => void }) {
  const patch = (next: Partial<CompanySaasPlan>) => onChange({ ...value, ...next });
  return <div className="grid min-w-0 grid-cols-1 gap-4 sm:grid-cols-2">
    <Field label="Product"><SearchableSelect ariaLabel={t('SaaS product')} value={value.produktas} options={translated(SAAS_PRODUCTS)} onChange={next => patch({ produktas: next as CompanySaasPlan['produktas'] })} portalMenu /></Field>
    <Field label="Pricing model"><SearchableSelect ariaLabel={t('SaaS pricing model')} value={value.kainodara} options={translated(SAAS_PRICING)} onChange={next => patch({ kainodara: next as CompanySaasPlan['kainodara'] })} portalMenu /></Field>
    <label className="flex min-w-0 flex-col gap-2 text-[14px] font-semibold leading-5">{t('Document limit')}<input aria-label={t('SaaS document limit')} inputMode="numeric" value={value.kiekis} onChange={event => patch({ kiekis: event.target.value.trim() })} className={inputClass} /></label>
    <Field label="Period"><SearchableSelect ariaLabel={t('SaaS period')} value={value.periodas} options={translated(SAAS_PERIODS)} onChange={next => patch({ periodas: next as CompanySaasPlan['periodas'] })} portalMenu /></Field>
    {value.kainodara === 'docs' && <Field label="Document pricing"><SearchableSelect ariaLabel={t('Document pricing')} value={documentPricing} options={translated(DOCUMENT_PRICING_OPTIONS)} onChange={next => onPricingChange(next as DocumentPricing)} portalMenu /></Field>}
    {value.kainodara !== 'docs' || documentPricing === 'flat' ? <label className="flex min-w-0 flex-col gap-2 text-[14px] font-semibold leading-5">{t(priceLabel(value))}<input aria-label={t('SaaS price (EUR)')} inputMode="decimal" value={value.kaina} onChange={event => patch({ kaina: event.target.value.replace(',', '.').trim() })} className={inputClass} /></label> : null}
    <Field label="Overage policy"><SearchableSelect ariaLabel={t('SaaS overage policy')} value={value.virsijimas} options={translated(SAAS_OVERAGE)} onChange={next => patch({ virsijimas: next as CompanySaasPlan['virsijimas'] })} portalMenu /></Field>
    <div className="sm:col-span-2"><MultiSelectField label={t('Modules')} options={SAAS_MODULES.map(item => t(item.label))} value={SAAS_MODULES.filter(item => value.moduliai.includes(item.value)).map(item => t(item.label))} onChange={values => patch({ moduliai: SAAS_MODULES.filter(item => values.includes(t(item.label))).map(item => item.value) })} portalMenu /></div>
    {value.kainodara === 'docs' && documentPricing === 'progressive' && <p className="sm:col-span-2 text-[12px] leading-5 text-[#7288A3]">{t('Document prices and discounts are set in the pricing tiers below. No flat document price is applied.')}</p>}
  </div>;
}

export function ContractPlanOptionsSummary({ plan, showModules = true }: { plan: ContractPlan; showModules?: boolean }) {
  const language = useLanguage(), value = contractPlanSaas(plan);
  const label = (options: readonly { value: string; label: string }[], selected: string) => t(options.find(option => option.value === selected)?.label || '—');
  const format = (number: number) => new Intl.NumberFormat(language, { maximumFractionDigits: 6 }).format(number);
  const progressive = value.kainodara === 'docs' && contractDocumentPricing(plan) === 'progressive';
  return <div className="mb-5 rounded-lg border border-[#D3E1EC] bg-[#F8FDFF] p-4">
    <dl className="grid grid-cols-1 gap-x-6 gap-y-4 sm:grid-cols-2 lg:grid-cols-3">{[
      ['Product', label(SAAS_PRODUCTS, value.produktas)], ['Pricing model', label(SAAS_PRICING, value.kainodara)],
      ['Document limit', format(Number(value.kiekis))], ['Period', label(SAAS_PERIODS, value.periodas)],
      ['Overage policy', label(SAAS_OVERAGE, value.virsijimas)],
      [progressive ? 'Document pricing' : priceLabel(value), progressive ? t('Progressive pricing tiers') : `${format(Number(value.kaina))} EUR`],
    ].map(([name, text]) => <div key={name} className="min-w-0"><dt className="text-[12px] text-[#7288A3]">{t(name)}</dt><dd className="mt-1 text-[14px] font-semibold leading-5">{text}</dd></div>)}</dl>
    {showModules && <div className="mt-4 border-t border-[#D3E1EC] pt-3"><p className="mb-2 text-[12px] text-[#7288A3]">{t('Modules')}</p><div className="flex flex-wrap gap-2">{value.moduliai.length ? SAAS_MODULES.filter(item => value.moduliai.includes(item.value)).map(item => <span key={item.value} className="rounded-md border border-[#D3E1EC] bg-white px-2.5 py-1 text-[12px]">{t(item.label)}</span>) : <span className="text-[12px] text-[#7288A3]">{t('No modules selected')}</span>}</div></div>}
  </div>;
}
