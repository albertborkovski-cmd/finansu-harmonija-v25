import { useEffect, useId, useLayoutEffect, useRef, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { FileText, Info, X } from 'lucide-react';
import { translateStatus as statusText, translateUi as uiText } from '../i18n/language';
import type { DbDocument } from '../lib/supabase';
import { ocrDocumentStatusPresentation } from '../lib/ocrDocumentStatusPresentation';
import { ocrStatusLabel } from '../lib/ocrStatuses';
import { uploadedDocumentSource } from '../lib/uploadedDocumentSource';
import { uploadedDocumentTimestamp } from '../lib/uploadedDocuments';

export function OcrDocumentStatusCell({ status, description, color, documentName, onOpen, action, panelId, expanded }: {
  status: string; description: string; color: string; documentName: string; onOpen: () => void; action?: ReactNode;
  panelId?: string; expanded?: boolean;
}) {
  const label = ocrStatusLabel(status, statusText);
  return <div className="flex min-w-0 flex-col items-stretch gap-1">
    <button type="button" aria-haspopup={panelId ? undefined : 'dialog'} aria-controls={panelId} aria-expanded={panelId ? expanded : undefined} aria-label={`${uiText('Status')}: ${label} · ${documentName}`}
      title={panelId ? undefined : description ? uiText(description) : label}
      onClick={event => { event.stopPropagation(); onOpen(); }}
      className="block min-w-0 flex-1 rounded text-left font-montserrat focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#007EA7]">
      <span className="flex min-w-0 items-center gap-1.5 text-[12px] font-normal leading-[18px] text-[#10233A]">
        <span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ backgroundColor: color }} />
        <span className="min-w-0 truncate">{label}</span>
      </span>
      {!panelId && description && <span data-ocr-status-description className="mt-0.5 block truncate pl-3 text-[10px] font-normal leading-[14px] text-[#7288A3]">{uiText(description)}</span>}
    </button>
    {panelId && description && <span data-ocr-status-description className="block truncate pl-3 font-montserrat text-[10px] font-normal leading-[14px] text-[#7288A3]">{uiText(description)}</span>}
    {action && <div className="pl-3">{action}</div>}
  </div>;
}

export function OcrDocumentStatusPanel({ document, organizationName, descriptions, displayGroup = false, displayDetail = false, onClose, footer, relatedAction, docked = false, id }: {
  document: DbDocument; organizationName?: string; descriptions: Record<string, string>; displayGroup?: boolean; displayDetail?: boolean;
  onClose: () => void; footer?: ReactNode; relatedAction?: ReactNode;
  docked?: boolean; id?: string;
}) {
  const titleId = useId();
  const panelRef = useRef<HTMLElement>(null);
  const closeRef = useRef(onClose); closeRef.current = onClose;
  const presentation = ocrDocumentStatusPresentation(document, descriptions);
  const displayedStatus = displayGroup ? presentation.registerStatus : displayDetail ? presentation.detail : presentation.status;
  const source = uploadedDocumentSource(document, uiText);
  const timestamp = uploadedDocumentTimestamp(document);
  const uploaded = timestamp ? new Date(timestamp).toLocaleDateString('lt-LT') : document.receive_date || '—';

  useLayoutEffect(() => {
    if (!docked || !panelRef.current) return;
    const panel = panelRef.current;
    const fit = () => {
      if (panel.closest('[data-table-workspace-expanded]')) { panel.style.removeProperty('--status-panel-height'); return; }
      panel.style.setProperty('--status-panel-height', `${Math.max(180, Math.min(620, window.innerHeight - panel.getBoundingClientRect().top - 56))}px`);
    };
    fit();
    window.addEventListener('resize', fit);
    window.addEventListener('scroll', fit, true);
    return () => { window.removeEventListener('resize', fit); window.removeEventListener('scroll', fit, true); };
  }, [docked]);

  useEffect(() => {
    // A docked information region is part of the workspace, not a modal:
    // do not lock scrolling, trap focus, or dismiss it on outside click/Escape.
    if (docked) return;
    const previous = window.document.activeElement instanceof HTMLElement ? window.document.activeElement : null;
    const overflow = window.document.body.style.overflow;
    window.document.body.style.overflow = 'hidden';
    panelRef.current?.focus();
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') { event.preventDefault(); event.stopImmediatePropagation(); closeRef.current(); return; }
      if (event.key !== 'Tab') return;
      const controls = Array.from(panelRef.current?.querySelectorAll<HTMLElement>('button:not(:disabled), a[href], [tabindex="0"]') || []).filter(control => control.getClientRects().length);
      const first = controls[0], last = controls[controls.length - 1];
      if (event.shiftKey && (window.document.activeElement === first || window.document.activeElement === panelRef.current)) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && (window.document.activeElement === last || window.document.activeElement === panelRef.current)) { event.preventDefault(); first?.focus(); }
    };
    window.addEventListener('keydown', onKey, true);
    return () => {
      window.removeEventListener('keydown', onKey, true);
      window.document.body.style.overflow = overflow;
      if (previous?.isConnected) previous.focus({ preventScroll: true });
    };
  }, [docked]);

  const panel = <aside ref={panelRef} id={id} data-ocr-status-docked={docked || undefined}
      role={docked ? 'region' : 'dialog'} aria-modal={docked ? undefined : true} aria-labelledby={titleId} tabIndex={docked ? undefined : -1}
      onClick={event => event.stopPropagation()}
      className={docked
        ? 'uploaded-document-status-info flex min-h-0 min-w-0 flex-col overflow-hidden rounded-lg border border-[#D3E1EC] bg-white font-montserrat'
        : 'absolute bottom-0 right-0 top-0 flex w-[390px] max-w-[calc(100vw-24px)] flex-col border-l border-[#D3E1EC] bg-white font-montserrat shadow-[-12px_0_32px_rgba(16,35,58,0.12)] outline-none'}>
      <header className={`flex shrink-0 items-center justify-between gap-2 border-b border-[#E5EDF9] ${docked ? 'min-h-10 bg-[#F4F8FC] px-3 py-1.5' : 'px-6 py-5'}`}>
        <h2 id={titleId} className={`${docked ? 'text-[12px] leading-[18px]' : 'text-[18px]'} font-semibold text-[#10233A]`}>{uiText('Document status details')}</h2>
        <button type="button" aria-label={uiText(docked ? 'Hide document status details' : 'Close document details')} title={uiText(docked ? 'Hide document status details' : 'Close document details')} onClick={onClose}
          aria-controls={docked ? id : undefined} aria-expanded={docked ? true : undefined}
          className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md text-[#007EA7] hover:bg-[#E5EDF9] focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#007EA7]">{docked ? <Info size={18} aria-hidden="true" /> : <X size={20} />}</button>
      </header>
      <div className={`min-h-0 flex-1 overflow-y-auto ${docked ? 'p-3' : 'px-6 py-5'}`}>
        <div className="mb-3 flex min-w-0 items-start gap-2 text-[#7288A3]">
          <FileText size={16} className="mt-px shrink-0" aria-hidden="true" />
          <span className="min-w-0 break-words text-[12px] font-medium leading-[18px] text-[#10233A]">{document.file_case || document.number || document.id}</span>
        </div>
        <section className="mb-3 border-l-2 bg-[#F8FBFD] px-3 py-2.5" style={{ borderLeftColor: presentation.color }} aria-label={uiText('Status')}>
          <div className="flex items-start gap-1.5 text-[12px] font-semibold leading-[18px] text-[#10233A]">
            <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full" style={{ backgroundColor: presentation.color }} />
            {ocrStatusLabel(displayedStatus, statusText)}
          </div>
          {presentation.detail !== displayedStatus && <p className="mt-1 pl-3.5 text-[11px] text-[#7288A3]">{ocrStatusLabel(presentation.detail, statusText)}</p>}
          {presentation.description && <p className="mt-1.5 whitespace-pre-wrap break-words text-[11px] font-normal leading-[17px] text-[#7288A3]">{uiText(presentation.description)}</p>}
          {relatedAction && <div className="mt-2">{relatedAction}</div>}
        </section>
        {document.ocr_worker_handoff && ['Rejected', 'Escalated'].includes(document.status) && <section className="mb-3 rounded-lg border border-[#E5EDF9] p-3 text-[11px] leading-[17px]">
          <h3 className="font-semibold text-[#10233A]">{uiText(document.status === 'Rejected' ? 'Return reason' : 'Escalation reason')}</h3>
          <p className="mt-1 text-[#10233A]">{uiText(document.ocr_worker_handoff.reason)}</p>
          {document.ocr_worker_handoff.comment && <p className="mt-2 whitespace-pre-wrap break-words text-[#7288A3]">{document.ocr_worker_handoff.comment}</p>}
          <p className="mt-2 text-[#7288A3]">{document.ocr_worker_handoff.actor} · {new Date(document.ocr_worker_handoff.at).toLocaleString()}</p>
        </section>}
        {document.ocr_split && <section className="mb-3 rounded-lg border border-[#E5EDF9] p-3 text-[11px] leading-[17px] text-[#10233A]">
          <h3 className="font-semibold">{uiText('Created documents')}</h3>
          {document.ocr_split.children.map(child => <p key={child.id} className="mt-1 break-words">{child.name} · {uiText('Pages')}: {child.pages.join(', ')}</p>)}
        </section>}
        {document.ocr_split_parent && <p className="mb-3 text-[11px] text-[#7288A3]">{uiText('Original pages')}: {document.ocr_split_parent.pages.join(', ')}</p>}
        {document.ocr_merge && <p className="mb-3 break-words text-[11px] text-[#7288A3]">{uiText('Merged document')}: {document.ocr_merge.childId}</p>}
        <dl className="divide-y divide-[#E5EDF9]">
          {[
            ['Organization', organizationName || uiText('Organization not identified')],
            ['Source', uiText(source.type)], ['Source details', source.detail], ['Uploaded', uploaded],
          ].map(([label, value]) => <div key={label} className="grid grid-cols-[80px_minmax(0,1fr)] items-start gap-2 py-2 first:pt-0 last:pb-0">
            <dt className="text-[10px] font-medium leading-[18px] text-[#7288A3]">{uiText(label)}</dt>
            <dd className="min-w-0 whitespace-pre-wrap break-words text-[11px] font-normal leading-[18px] text-[#10233A]">{value || '—'}</dd>
          </div>)}
        </dl>
      </div>
      {footer && <footer className={`flex shrink-0 flex-wrap items-center justify-end gap-2 border-t border-[#E5EDF9] ${docked ? 'px-3 py-2.5' : 'px-6 py-5'}`}>{footer}</footer>}
    </aside>;
  if (docked) return panel;
  return createPortal(<div data-ocr-status-panel className="fixed inset-0 z-[240] bg-[#10233A]/10" onClick={event => { event.stopPropagation(); onClose(); }}>
    {panel}
  </div>, window.document.body);
}
