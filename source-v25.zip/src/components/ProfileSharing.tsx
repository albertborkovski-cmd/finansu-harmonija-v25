import { useCallback, useEffect, useState } from 'react';
import { Copy, Eye, EyeOff, Info, RefreshCw, Search } from 'lucide-react';
import { translateUi as t, useLanguage } from '../i18n/language';
import { supabase, type Company, type DbDocument } from '../lib/supabase';
import { canAccessUnassignedDocuments, canViewCompanyDocuments } from '../lib/documentEditAccess';
import { loadDirectoryCounterparties } from '../lib/organizationDirectory';
import { buildProfileSharingEntries, createProfileSharingPreview, type SharingEntry, type SharingPreview } from '../lib/profileSharing';
import { toggleFilteredSelection } from '../lib/tableSelection';
import { PageActionButton } from './PageHeader';
import GlJournalDialog from './GlJournalDialog';

const inputClass = 'h-[42px] w-full min-w-0 rounded-lg border border-[#D3E1EC] bg-white px-3.5 font-montserrat text-[14px] text-[#10233A] outline-none focus:border-[#007EA7]';
const checkboxClass = 'h-[18px] w-[18px] shrink-0 rounded-[6px] accent-[#007EA7]';

async function readSharingEntries() {
  const [companyResult, documentResult] = await Promise.all([
    supabase.from('companies').select('*'), supabase.from('documents').select('*', { includeDeleted: true }),
  ]);
  if (companyResult.error || documentResult.error) throw new Error('Could not load sharing data.');
  const companies = ((companyResult.data || []) as unknown as Company[]).filter(canViewCompanyDocuments);
  const includeUnassigned = canAccessUnassignedDocuments();
  return buildProfileSharingEntries(companies, loadDirectoryCounterparties(companies, includeUnassigned), (documentResult.data || []) as unknown as DbDocument[], includeUnassigned);
}

/** Frontend preview only. The key is component state, never storage, logs or a request. */
export default function ProfileSharing() {
  const language = useLanguage();
  const [entries, setEntries] = useState<SharingEntry[]>([]);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(() => new Set());
  const [apiKey, setApiKey] = useState(''), [showKey, setShowKey] = useState(false);
  const [query, setQuery] = useState(''), [error, setError] = useState('');
  const [loading, setLoading] = useState(true), [preparing, setPreparing] = useState(false);
  const [refresh, setRefresh] = useState(0), [preview, setPreview] = useState<SharingPreview | null>(null);
  useEffect(() => {
    let active = true;
    setLoading(true); setError('');
    void readSharingEntries().then(rows => { if (active) setEntries(rows); })
      .catch(reason => { if (active) { setEntries([]); setError(reason instanceof Error ? reason.message : 'Could not load sharing data.'); } })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [refresh]);
  const closePreview = useCallback(() => setPreview(null), []);
  const filtered = entries.filter(entry => `${t(entry.name)} ${entry.code}`.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase()));
  const filteredIds = filtered.map(entry => entry.id);
  const allSelected = filtered.length > 0 && filteredIds.every(id => selectedIds.has(id));
  const partiallySelected = !allSelected && filteredIds.some(id => selectedIds.has(id));
  const format = (count: number) => new Intl.NumberFormat(language).format(count);
  const prepare = async () => {
    if (loading || preparing) return;
    setPreparing(true); setError('');
    try {
      // Re-check current company permissions before producing the preview.
      const current = await readSharingEntries();
      const result = createProfileSharingPreview(current, selectedIds, apiKey);
      setEntries(current); setPreview(result); setApiKey(''); setShowKey(false);
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Could not prepare copy preview.'); }
    finally { setPreparing(false); }
  };
  return <section className="flex min-w-0 flex-col gap-5 font-montserrat text-[#10233A]">
    <div><h2 className="text-[20px] font-semibold leading-7">{t('Copy data to another account')}</h2>
      <p className="mt-1 text-[13px] leading-5 text-[#7288A3]">{t('Select counterparties to prepare their data for another Finansų harmonija account.')}</p></div>
    <section className="rounded-lg border border-[#D3E1EC] bg-white">
      <h3 className="rounded-t-lg border-b border-[#E5EDF9] bg-[#F4F8FC] px-5 py-3 text-[14px] font-semibold">{t('1. Destination account')}</h3>
      <div className="space-y-2 p-5"><label htmlFor="profile-sharing-key" className="block text-[14px] font-semibold">{t('Destination account API key')} *</label>
        <div className="relative max-w-[720px]"><input id="profile-sharing-key" type={showKey ? 'text' : 'password'} autoComplete="off" spellCheck={false} maxLength={4096} value={apiKey} onChange={event => { setApiKey(event.target.value); setError(''); }} placeholder={t('Enter API key')} className={`${inputClass} pr-12`} disabled={preparing} />
          <button type="button" aria-label={t(showKey ? 'Hide API key' : 'Show API key')} title={t(showKey ? 'Hide API key' : 'Show API key')} aria-pressed={showKey} disabled={preparing} onClick={() => setShowKey(current => !current)} className="absolute inset-y-0 right-0 flex w-11 items-center justify-center text-[#7288A3] hover:text-[#007EA7]">{showKey ? <EyeOff size={17} /> : <Eye size={17} />}</button></div>
        <p className="text-[12px] leading-5 text-[#7288A3]">{t('Use the API key from the destination account. The key is not saved or transmitted in this preview.')}</p>
      </div>
    </section>
    <section className="min-w-0 rounded-lg border border-[#D3E1EC] bg-white">
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-t-lg border-b border-[#E5EDF9] bg-[#F4F8FC] px-5 py-3"><h3 className="text-[14px] font-semibold">{t('2. Select counterparties')}</h3><PageActionButton icon={<RefreshCw size={15} />} iconOnly disabled={loading || preparing} onClick={() => setRefresh(value => value + 1)}>{t('Refresh')}</PageActionButton></div>
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#E5EDF9] px-5 py-3"><label className="relative w-full max-w-[420px]"><Search size={16} className="absolute left-3.5 top-3.5 text-[#7288A3]" /><input aria-label={t('Search counterparties')} placeholder={t('Search counterparties')} value={query} onChange={event => setQuery(event.target.value)} className={`${inputClass} pl-10`} /></label>
        <label className="flex min-h-9 cursor-pointer items-center gap-2.5 text-[13px]"><input type="checkbox" checked={allSelected} ref={element => { if (element) element.indeterminate = partiallySelected; }} disabled={!filtered.length || loading || preparing} onChange={() => setSelectedIds(current => toggleFilteredSelection(current, filteredIds))} className={checkboxClass} />{t('Select all filtered counterparties')}</label></div>
      <div className="max-h-[320px] overflow-y-auto" aria-busy={loading}>
        {loading ? <p className="p-6 text-center text-[13px] text-[#7288A3]">{t('Loading…')}</p> : filtered.length ? filtered.map(entry => <label key={entry.id} className={`flex min-h-[48px] cursor-pointer items-center gap-3 border-b border-[#E5EDF9] px-5 py-2.5 last:border-0 ${selectedIds.has(entry.id) ? 'bg-[#E5EDF9]' : 'bg-white hover:bg-[#F8FDFF]'}`}>
          <input type="checkbox" aria-label={`${t('Select counterparty')}: ${t(entry.name)}`} checked={selectedIds.has(entry.id)} disabled={preparing} onChange={() => setSelectedIds(current => { const next = new Set(current); if (next.has(entry.id)) next.delete(entry.id); else next.add(entry.id); return next; })} className={checkboxClass} />
          <span className="min-w-0 flex-1 text-[14px] font-medium leading-5">{t(entry.name)}{entry.code && <span className="ml-2 text-[12px] font-normal text-[#7288A3]">{entry.code}</span>}</span>
          <span className="min-w-[44px] shrink-0 rounded bg-[#F4F8FC] px-2 py-1 text-right text-[12px] tabular-nums text-[#536B86]" title={t('Documents')}>({format(entry.documentIds.length)})</span>
        </label>) : <p className="p-6 text-center text-[13px] text-[#7288A3]">{t('No counterparties found.')}</p>}
      </div>
      <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[#E5EDF9] px-5 py-4"><p className="text-[12px] text-[#7288A3]">{t('Selected counterparties')}: <strong className="font-semibold tabular-nums">{format(selectedIds.size)}</strong></p><PageActionButton icon={<Copy size={16} />} disabled={loading || preparing || !apiKey.trim() || !selectedIds.size} onClick={() => void prepare()}>{t(preparing ? 'Preparing preview…' : 'Copy data')}</PageActionButton></div>
    </section>
    <p className="text-[12px] leading-5 text-[#7288A3]">{t('The preview includes selected company settings, additional columns and related OCR documents. No data is moved or deleted.')}</p>
    {error && <p role="alert" className="text-[13px] text-[#B42318]">{t(error)}</p>}
    {preview && <GlJournalDialog title="Copy preview" onClose={closePreview} footer={<PageActionButton onClick={closePreview}>{t('Close')}</PageActionButton>}>
      <div className="flex items-start gap-3 rounded-lg border border-[#D3E1EC] bg-[#F8FDFF] p-4"><Info size={18} className="mt-0.5 shrink-0 text-[#007EA7]" /><p className="text-[13px] leading-5">{t('Preview only. No data has been sent and the destination API key has not been validated. Copying will require a connected account API.')}</p></div>
      <div className="mt-4 max-h-[300px] overflow-auto rounded-lg border border-[#D3E1EC]"><table className="w-full text-left text-[12px]"><thead className="sticky top-0 bg-[#F4F8FC] text-[#7288A3]"><tr><th className="px-3 py-2.5 font-semibold">{t('Counterparty')}</th><th className="px-3 py-2.5 text-right font-semibold">{t('Documents')}</th><th className="px-3 py-2.5 font-semibold">{t('Status')}</th></tr></thead><tbody>{preview.entries.map(entry => <tr key={entry.id} className="border-t border-[#E5EDF9]"><td className="px-3 py-3">{t(entry.name)}</td><td className="px-3 py-3 text-right tabular-nums">{format(entry.documentCount)}</td><td className="px-3 py-3"><span className="rounded bg-[#E5EDF9] px-2 py-1 text-[#007EA7]">{t('Not sent')}</span></td></tr>)}</tbody></table></div>
      <p className="mt-4 text-[13px]">{t('Unique documents')}: <strong>{format(preview.documentCount)}</strong></p>
      <p className="mt-2 text-[12px] leading-5 text-[#7288A3]">{t('Documents linked to several selected counterparties are counted once in the total.')}</p>
    </GlJournalDialog>}
  </section>;
}
