import { translateUi as uiText } from '../i18n/language';
import { useLayoutEffect, useState, type ReactNode, type RefObject } from 'react';
import { createPortal } from 'react-dom';
import { dropdownPosition } from '../lib/dropdownPosition';

/** Keeps existing system menus outside clipped table/toolbar scroll containers. */
export default function DropdownPortal({ anchorRef, menuRef, children, width = 280, height = 360, zIndex = 1100, role, ariaLabel, id, align = 'start', onKeyDown }: {
  anchorRef: RefObject<HTMLElement | null>;
  menuRef: RefObject<HTMLDivElement>;
  children: ReactNode;
  width?: number;
  height?: number;
  /** A portal in document dialogs must sit above its owning dialog, not just the page. */
  zIndex?: number;
  role?: 'listbox' | 'dialog' | 'menu';
  ariaLabel?: string;
  id?: string;
  align?: 'start' | 'end';
  onKeyDown?: React.KeyboardEventHandler<HTMLDivElement>;
}) {
  const [position, setPosition] = useState<ReturnType<typeof dropdownPosition> | null>(null);
  useLayoutEffect(() => {
    const update = () => {
      const rect = anchorRef.current?.getBoundingClientRect();
      if (!rect || rect.bottom < 0 || rect.top > window.innerHeight) { setPosition(null); return; }
      const next = dropdownPosition(rect, { width: window.innerWidth, height: window.innerHeight }, width, height);
      setPosition(align === 'end' ? { ...next, left: Math.max(8, Math.min(rect.right - next.width, window.innerWidth - next.width - 8)) } : next);
    };
    update();
    window.addEventListener('resize', update);
    window.addEventListener('scroll', update, true);
    const observer = new ResizeObserver(update);
    if (anchorRef.current) observer.observe(anchorRef.current);
    return () => { window.removeEventListener('resize', update); window.removeEventListener('scroll', update, true); observer.disconnect(); };
  }, [anchorRef, width, height, align]);
  return createPortal(<div ref={menuRef} role={role} aria-label={uiText(ariaLabel)} id={id}
    data-system-dropdown-portal="true" onKeyDown={onKeyDown} onClick={event => event.stopPropagation()}
    style={{ ...position, zIndex, visibility: position ? 'visible' : 'hidden' }}
    className="fixed flex min-h-0 flex-col overflow-hidden rounded-lg border border-[#D3E1EC] bg-white p-1.5 shadow-[0_8px_24px_rgba(16,35,58,0.14)]">
    {children}
  </div>, document.body);
}
