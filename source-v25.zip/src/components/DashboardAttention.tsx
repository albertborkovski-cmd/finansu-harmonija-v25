import { translateUi as uiText } from '../i18n/language';
import { AlertCircle, Bell, Info } from "lucide-react";
import { useState } from 'react';
import type { AttentionNotification, NotificationTab } from "../lib/notifications";
import NotificationRelativeTime from './NotificationRelativeTime';

export default function DashboardAttention({ rows, onOpen, onOpenRecord }: {
  rows: AttentionNotification[];
  onOpen: (tab?: NotificationTab, query?: string) => void;
  onOpenRecord?: (row: AttentionNotification) => Promise<void>;
}) {
  const [opening, setOpening] = useState(''), [error, setError] = useState('');
  const open = async (row: AttentionNotification) => {
    if (opening) return;
    if (!onOpenRecord) { onOpen(row.category, row.name); return; }
    setOpening(row.id); setError('');
    try { await onOpenRecord(row); } catch (cause) { setError(cause instanceof Error ? cause.message : 'Unable to open notification.'); }
    finally { setOpening(''); }
  };
  const sorted = [...rows].sort((a, b) => {
    const rank = (row: AttentionNotification) => 'severity' in row && row.severity === 'Critical' ? 0 : 'severity' in row && row.severity === 'Warning' ? 1 : 2;
    return rank(a) - rank(b) || (Date.parse(b.createdAt || '') || 0) - (Date.parse(a.createdAt || '') || 0);
  });
  return (
    <section data-dashboard-notifications aria-labelledby="dashboard-attention-heading" className="col-span-full w-full min-w-0 overflow-hidden rounded-lg border border-[#D3E1EC] bg-white">
      <div className="flex min-h-12 items-center justify-between gap-4 border-b border-[#E1EBF2] px-5 py-3">
        <div className="flex min-w-0 items-center gap-3">
          <h2 id="dashboard-attention-heading" className="font-montserrat text-[14px] font-semibold leading-5 text-[#10233A]">{uiText("Notifications")}</h2>
          <span aria-label={`${uiText('Active notifications')}: ${rows.length}`} className="flex h-5 min-w-5 shrink-0 items-center justify-center rounded-full bg-[#E34242] px-1.5 font-montserrat text-[11px] font-semibold leading-5 text-white">{rows.length}</span>
        </div>
        <button type="button" onClick={() => onOpen('notifications')} className="shrink-0 font-montserrat text-[12px] font-semibold text-[#007EA7] hover:text-[#006B8E]">{uiText("View all")}</button>
      </div>
      {rows.length === 0 ? (
        <p className="px-5 py-8 text-center font-montserrat text-[12px] leading-[18px] text-[#7288A3]">{uiText("No notifications or reminders need your attention.")}</p>
      ) : (
        <ul className="max-h-[320px] overflow-y-auto divide-y divide-[#E1EBF2]">
          {sorted.slice(0, 5).map(row => {
            const severity = 'severity' in row ? row.severity : 'Info';
            const Icon = row.category === "reminders" ? Bell : severity === 'Info' ? Info : AlertCircle;
            const color = severity === 'Critical' ? 'bg-[#FFF0F1] text-[#C43E48]' : severity === 'Warning' ? 'bg-[#FFF7E1] text-[#A66B00]' : 'bg-[#E6F2F6] text-[#007EA7]';
            return (
              <li key={`${row.category}:${row.id}`} className="grid min-h-12 grid-cols-[32px_minmax(0,1fr)_auto] items-center gap-x-4 gap-y-1 px-5 py-2 md:grid-cols-[32px_minmax(140px,1fr)_minmax(0,2fr)_auto]">
                <span role="img" aria-label={uiText(severity || 'Info')} data-tooltip={uiText(severity || 'Info')} className={`flex h-8 w-8 items-center justify-center rounded-full ${color}`}><Icon size={16} aria-hidden="true" /></span>
                <div className="min-w-0 font-montserrat text-[12px] leading-[18px]">
                  <p className="truncate font-medium text-[#10233A]" data-tooltip={uiText(row.name)}>{uiText(row.name)}</p>
                  <p className="text-[11px] font-normal text-[#7288A3]">{row.organizationName || '—'} · <NotificationRelativeTime row={row} /></p>
                </div>
                <p data-tooltip={row.message} className="col-start-2 row-start-2 min-w-0 truncate font-montserrat text-[12px] font-normal leading-[18px] text-[#7288A3] md:col-start-3 md:row-start-1">{row.message}</p>
                <button type="button" disabled={Boolean(opening)} onClick={() => void open(row)} aria-label={`Open ${row.name}`} className="col-start-3 row-start-1 inline-flex h-8 min-w-[76px] items-center justify-center rounded border-2 border-[#D3E1EC] bg-white px-3 font-montserrat text-[12px] font-semibold text-[#7288A3] transition-colors hover:border-[#007EA7] hover:text-[#007EA7] disabled:opacity-50 md:col-start-4">{uiText("Open")}</button>
              </li>
            );
          })}
        </ul>
      )}
      {error && <p role="alert" className="px-5 py-2 text-[12px] text-[#B42318]">{uiText(error)}</p>}
    </section>
  );
}
