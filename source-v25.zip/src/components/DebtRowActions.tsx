import { useRef, useState } from 'react';
import { Bell, CreditCard, ExternalLink, MoreVertical } from 'lucide-react';
import { translateUi as uiText } from '../i18n/language';
import type { DebtRow } from '../lib/companyRelatedObjectData';
import { debtActionState, type DebtAction } from '../lib/debtActions';
import DropdownPortal from './DropdownPortal';
import { useDropdownDismiss } from './useDropdownDismiss';

export default function DebtRowActions({ row, rights, onDocument, onAction }: { row: DebtRow; rights: { send: boolean; payment: boolean }; onDocument?: () => void; onAction: (action: DebtAction) => void }) {
  const [open, setOpen] = useState(false), anchor = useRef<HTMLButtonElement>(null), menu = useRef<HTMLDivElement>(null);
  useDropdownDismiss(open, anchor, () => setOpen(false), menu);
  const actions = debtActionState('All', [row], rights);
  const options = [
    ...(onDocument ? [{ label: 'Open document', icon: ExternalLink, run: onDocument }] : []),
    ...(actions.reminder.enabled ? [{ label: 'Send reminder', icon: Bell, run: () => onAction('reminder') }] : []),
    ...(actions.payment.enabled ? [{ label: 'Create payment', icon: CreditCard, run: () => onAction('payment') }] : []),
  ];
  if (!options.length) return null;
  return <><button ref={anchor} type="button" aria-label={`${uiText('Actions')} · ${row.documentReference}`} aria-haspopup="menu" aria-expanded={open} onClick={() => setOpen(value => !value)} className="flex h-7 w-7 shrink-0 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] hover:border-[#007EA7] hover:text-[#007EA7]"><MoreVertical size={14} /></button>{open && <DropdownPortal anchorRef={anchor} menuRef={menu} role="menu" ariaLabel={uiText('Actions')} width={220} height={options.length * 40 + 12} align="end" onKeyDown={e => { if (e.key === 'Escape') { setOpen(false); anchor.current?.focus(); } }}><div className="space-y-1">{options.map(({ label, icon: Icon, run }) => <button type="button" role="menuitem" key={label} onClick={() => { setOpen(false); run(); }} className="flex w-full items-center gap-2 rounded-md px-3 py-2.5 text-left font-montserrat text-xs font-medium text-[#10233A] hover:bg-[#E5EDF9] hover:text-[#007EA7]"><Icon size={16} />{uiText(label)}</button>)}</div></DropdownPortal>}</>;
}
