import { useCallback, useEffect, useMemo, useState } from 'react';
import { Calculator, Eye, Pencil, Play, Plus, Power, Printer } from 'lucide-react';
import { supabase, type Company, type DbDocument } from '../lib/supabase';
import { ASSET_SECTIONS, assetBalance, assetMoney, assetToday, assetUsed, blankAsset, depreciationPreview, newAssetStore, type AssetCommand, type AssetGroup, type AssetInventory, type AssetSection, type AssetStore, type FixedAsset } from '../lib/fixedAssets';
import { ASSETS_CHANGED, assetPermissions, assetPurchaseDocuments, initializeAssetExamples, loadAssets, updateAssets } from '../lib/fixedAssetStore';
import { translateUi as t, useLanguage } from '../i18n/language';
import CompanyBreadcrumb from './CompanyBreadcrumb';
import { PageActionButton, PageHeader } from './PageHeader';
import WarehouseTable, { type WarehouseTableRow } from './WarehouseTable';
import type { ColConfig } from './ColumnSettingsPanel';
import GlJournalDialog from './GlJournalDialog';
import { CancelButton, SaveButton } from './ScopedActionButtons';
import { RowDeleteButton } from './DeleteButtons';
import { CashField as Field, CashRowAction as RowAction, cashInput as input } from './cash/CashControls';
import CashPrintPreview from './cash/CashPrintPreview';
import type { CashPrintReport } from '../lib/cashPrint';
import { AssetCardEditor, AssetGroupEditor, AssetInventoryEditor, AssetOperationEditor } from './assets/AssetEditors';

const col = (key: string, label: string, width = 155, visible = true): ColConfig => ({ key, label, width, visible });
const registerColumns = [col('number', 'Inventory No.', 145), col('name', 'Asset name', 235), col('group', 'Asset group', 175), col('acquisitionDate', 'Acquisition date', 140), col('commissioned', 'Commissioning date', 145), col('cost', 'Gross carrying amount', 170), col('depreciation', 'Accumulated depreciation', 180), col('book', 'Book value', 140), col('currency', 'Currency', 85), col('status', 'Status', 115), col('method', 'Depreciation method', 190, false), col('residual', 'Residual value', 135, false), col('location', 'Location', 160, false), col('department', 'Department', 150, false), col('quantity', 'Quantity', 100, false)];
const depreciationColumns = [col('number', 'Inventory No.', 145), col('name', 'Asset name', 220), col('method', 'Depreciation method', 185), col('book', 'Book value', 130), col('residual', 'Residual value', 130), col('units', 'Production units', 150), col('amount', 'Monthly depreciation', 170), col('expected', 'Next depreciation month', 180), col('reason', 'Calculation result', 320)];
const groupColumns = [col('code', 'Code', 110), col('name', 'Name', 220), col('assetAccount', 'Asset GL account', 170), col('depreciationAccount', 'Accumulated depreciation account', 220), col('expenseAccount', 'Depreciation expense account', 210), col('lifeMonths', 'Useful life (months)', 150), col('method', 'Depreciation method', 190), col('status', 'Status', 120)];
const operationColumns = [col('date', 'Date', 110), col('number', 'Document No.', 155), col('assetNumber', 'Inventory No.', 150), col('assetName', 'Asset name', 220), col('kind', 'Operation type', 180), col('costChange', 'Cost change', 130), col('depreciationChange', 'Depreciation change', 160), col('accounts', 'GL accounts', 200), col('reason', 'Reason', 250), col('by', 'Created by', 200)];
const inventoryColumns = [col('number', 'Inventory No.', 170), col('date', 'Date', 130), col('count', 'Assets', 120), col('difference', 'Quantity difference', 160), col('status', 'Status', 130)];
type Editor = { type: 'asset'; record: FixedAsset; readOnly: boolean; revision: number } | { type: 'group'; record: AssetGroup; revision: number } | { type: 'operation'; record: FixedAsset; revision: number } | { type: 'inventory'; record: AssetInventory; revision: number };

export default function CompanyFixedAssetsView({ company, section }: { company: Company; section: AssetSection }) {
  const language = useLanguage();
  const [store, setStore] = useState<AssetStore>(() => newAssetStore(company.id, company.base_currency || 'EUR'));
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [loadError, setLoadError] = useState(''), [error, setError] = useState(''), [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false), [editor, setEditor] = useState<Editor | null>(null);
  const [confirmation, setConfirmation] = useState<{ command: AssetCommand; title: string; description: string; revision: number } | null>(null);
  const [month, setMonth] = useState(() => { const d = new Date(); return new Date(Date.UTC(d.getFullYear(), d.getMonth(), 0)).toISOString().slice(0, 7); });
  const [asOf, setAsOf] = useState(assetToday), [units, setUnits] = useState<Record<string, number>>({});
  const [documents, setDocuments] = useState<DbDocument[]>([]), [report, setReport] = useState<CashPrintReport | null>(null);
  const permissions = assetPermissions(company), title = ASSET_SECTIONS.find(s => s.id === section)!.label;
  const refresh = useCallback(() => { try { setStore(loadAssets(company)); setLoadError(''); } catch (cause) { setLoadError((cause as Error).message); } }, [company]);
  useEffect(() => { refresh(); window.addEventListener(ASSETS_CHANGED, refresh); window.addEventListener('storage', refresh); return () => { window.removeEventListener(ASSETS_CHANGED, refresh); window.removeEventListener('storage', refresh); }; }, [refresh]);
  useEffect(() => { let cancelled = false; void initializeAssetExamples(company).then(() => { if (!cancelled) refresh(); }).catch(cause => { if (!cancelled) setError((cause as Error).message); }); return () => { cancelled = true; }; }, [company, refresh]);
  useEffect(() => { if (!permissions.view) return; let cancelled = false; void supabase.from('documents').select('*').eq('company_id', company.id).then(result => { if (!cancelled && !result.error) setDocuments(assetPurchaseDocuments((result.data || []) as unknown as DbDocument[], company)); }); return () => { cancelled = true; }; }, [company, permissions.view]);
  const save = async (command: AssetCommand, revision = editor?.revision ?? store.revision) => {
    if (busy) return; setBusy(true); setError(''); setMessage('');
    try { setStore(await updateAssets(company, revision, command)); setEditor(null); setConfirmation(null); setMessage('Changes saved.'); }
    catch (cause) { setError((cause as Error).message); }
    finally { setBusy(false); }
  };
  const open = (value: Editor) => { setEditor(value); setError(''); setMessage(''); };
  const newGroup = () => open({ type: 'group', revision: store.revision, record: { id: crypto.randomUUID(), code: '', name: '', assetAccount: '', depreciationAccount: '', expenseAccount: '', lifeMonths: 60, method: 'Straight-line', inactive: false } });
  const newInventory = () => {
    const date = assetToday();
    open({ type: 'inventory', revision: store.revision, record: { id: crypto.randomUUID(), number: `INV-FA-${String(store.inventories.length + 1).padStart(4, '0')}`, date, locked: false, lines: store.assets.filter(a => { const b = assetBalance(store, a, date); return b.start && !b.disposed; }).map(a => ({ assetId: a.id, number: a.number, name: a.name, bookQuantity: a.quantity, actualQuantity: a.quantity, bookValue: assetBalance(store, a, date).book, note: '' })) } });
  };
  const remove = (collection: 'assets' | 'groups', id: string) => {
    const record = store[collection].find(r => r.id === id)!;
    const used = collection === 'assets' ? assetUsed(store, id) : store.assets.some(a => a.groupId === id);
    setError(''); setConfirmation({ command: { type: record.inactive ? 'restore' : 'remove', collection, id }, title: record.inactive ? 'Reactivate record' : used ? 'Deactivate record' : 'Delete record', description: record.inactive ? 'The record will become active again.' : 'Unused records are deleted. Referenced records remain in the register as inactive.', revision: store.revision });
  };
  const previews = useMemo(() => store.assets.map(a => depreciationPreview(store, a, month, units[a.id] || 0)), [store, month, units]);
  const rows: WarehouseTableRow[] = useMemo(() => {
    const label = (value: string) => t(value, language);
    if (section === 'groups') return store.groups.map(g => ({ ...g, name: label(g.name), method: label(g.method), status: label(g.inactive ? 'Inactive' : 'Active') }));
    if (section === 'inventory') return store.inventories.map(i => ({ id: i.id, number: i.number, date: i.date, count: i.lines.length, difference: Number(i.lines.reduce((n, l) => n + l.actualQuantity - l.bookQuantity, 0).toFixed(3)), status: label(i.locked ? 'Locked' : 'Draft') }));
    if (section === 'operations') return store.operations.map(o => ({ id: o.id, date: o.date, number: o.number, assetNumber: o.assetNumber, assetName: o.assetName, kind: label(o.kind), costChange: o.costChange / 100, depreciationChange: o.depreciationChange / 100, accounts: [...new Set(o.lines.map(l => l.account))].join(' / '), reason: o.reason, by: o.by }));
    return store.assets.filter(a => section !== 'register' || !asOf || a.acquisitionDate <= asOf).map(a => { const b = assetBalance(store, a, section === 'register' ? asOf : undefined), p = previews.find(p => p.assetId === a.id)!; return { id: a.id, inactive: a.inactive, number: a.number, name: a.name, group: store.groups.find(g => g.id === a.groupId)?.name || '—', acquisitionDate: a.acquisitionDate, commissioned: b.start?.date || '—', cost: b.cost / 100, depreciation: b.depreciation / 100, book: b.book / 100, currency: store.currency, status: label(b.status), method: label(a.method), residual: a.residual / 100, location: a.location, department: a.department, quantity: a.quantity, units: units[a.id] || 0, amount: p.amount / 100, expected: p.expected || '—', reason: label(p.reason || 'Ready to calculate') }; });
  }, [store, section, asOf, previews, units, language]);
  const print = (asset?: FixedAsset) => {
    const list = asset ? [asset] : store.assets.filter(a => a.acquisitionDate <= asOf && (!selected.size || selected.has(a.id)));
    setReport({ title: asset ? 'Fixed asset card' : 'Asset register', company: company.name, details: [['As of', asOf], ['Currency', store.currency]], columns: ['Inventory No.', 'Asset name', 'Gross carrying amount', 'Accumulated depreciation', 'Book value', 'Status'], rows: list.map(a => { const b = assetBalance(store, a, asOf); return [a.number, a.name, assetMoney(b.cost), assetMoney(b.depreciation), assetMoney(b.book), t(b.status)]; }), footer: asset ? store.operations.filter(o => o.assetId === asset.id && o.date <= asOf).map(o => `${o.date} · ${o.number} · ${t(o.kind)} · ${o.reason} · ${o.by}`).join('\n') : '' });
  };
  const printOperation = (id: string) => { const o = store.operations.find(o => o.id === id)!; setReport({ title: t(o.kind), company: company.name, details: [['Document No.', o.number], ['Date', o.date], ['Asset name', `${o.assetNumber} · ${o.assetName}`], ['Reason', o.reason], ['Created by', o.by], ['Currency', store.currency]], columns: ['GL account', 'Debit', 'Credit'], rows: o.lines.map(l => [l.account, assetMoney(l.debit), assetMoney(l.credit)]), footer: '' }); };
  if (!permissions.view) return <p role="alert" className="p-9">{t('You do not have access to fixed assets.')}</p>;
  const editable = permissions.edit && !loadError && !busy;
  const create = permissions.create && !loadError && !busy;
  const columns = section === 'groups' ? groupColumns : section === 'depreciation' ? depreciationColumns : section === 'inventory' ? inventoryColumns : section === 'operations' ? operationColumns : registerColumns;
  const common = { company, store, busy, error, onClose: () => { if (!busy) setEditor(null); }, onSave: (c: AssetCommand) => void save(c) };
  return <div className="h-full min-h-0 min-w-0 px-[clamp(24px,5vw,72px)] py-8 font-montserrat text-[#10233A]">
    <div className="mx-auto flex h-full min-h-0 w-full max-w-[1384px] flex-col gap-4">
    <CompanyBreadcrumb companyName={company.name} items={['Fixed assets', title]} />
    <PageHeader title={title} actions={<>
      {(section === 'register' || section === 'groups') && <PageActionButton icon={<Plus size={15} />} disabled={!create} onClick={newGroup}>New asset group</PageActionButton>}
      {section === 'register' && <PageActionButton icon={<Plus size={15} />} disabled={!create || !store.groups.some(g => !g.inactive)} onClick={() => open({ type: 'asset', record: blankAsset(crypto.randomUUID(), store.groups.find(g => !g.inactive)), readOnly: false, revision: store.revision })}>New asset</PageActionButton>}
      {section === 'inventory' && <PageActionButton icon={<Plus size={15} />} disabled={!create} onClick={newInventory}>New inventory</PageActionButton>}
    </>} />
    {loadError && <p role="alert" className="text-[13px] text-red-700">{t(loadError)}</p>}
    {!editor && !confirmation && error && <p role="alert" className="text-[13px] text-red-700">{t(error)}</p>}
    {message && <p role="status" className="text-[12px] text-[#007EA7]">{t(message)}</p>}
    {section === 'register' && !store.groups.length && <p className="text-[13px] text-[#7288A3]">{t('Create an asset group with GL accounts, then add an asset card.')}</p>}
    {section === 'depreciation' && <div className="flex shrink-0 flex-wrap items-end gap-3 rounded-lg border border-[#D3E1EC] bg-[#F8FDFF] p-3">
      <div className="w-44"><Field label="Depreciation month"><input className={input} type="month" value={month} onChange={e => setMonth(e.target.value)} /></Field></div>
      <PageActionButton icon={<Calculator size={15} />} disabled={!create || !selected.size} onClick={() => { setError(''); const ids = [...selected].filter(id => previews.some(p => p.assetId === id)); const invalid = previews.find(p => ids.includes(p.assetId) && (p.reason || p.amount === 0)); if (invalid) { setError(invalid.reason || 'The asset is fully depreciated.'); return; } setConfirmation({ title: 'Post depreciation', description: `${ids.length} · ${assetMoney(previews.filter(p => ids.includes(p.assetId)).reduce((n, p) => n + p.amount, 0))} ${store.currency}`, command: { type: 'depreciate', month, assetIds: ids, units }, revision: store.revision }); }}>Calculate selected assets</PageActionButton><p className="pb-1 text-[12px] text-[#7288A3]">{t('Review the amounts before posting. Each asset is calculated once per month.')}</p>
    </div>}
    <WarehouseTable key={section} scope={`fixed-assets:${company.id}:${section}`} title={title} rows={rows} defaults={columns} selected={selected} onSelectedChange={setSelected} showSelectionSummary={false} onRefresh={refresh} actionColumnWidth={180}
      onPrint={section === 'register' ? () => print() : undefined} printLabel={section === 'register' ? 'Print asset register' : undefined}
      toolbar={section === 'register' ? <label className="flex h-8 shrink-0 items-center gap-2 text-[12px] font-medium text-[#7288A3]"><span>{t('As of')}</span><input aria-label={t('As of')} className={`${input} !h-8 !w-[148px] !text-[12px]`} type="date" value={asOf} onChange={e => setAsOf(e.target.value)} /></label> : undefined}
      renderCell={(row, key) => {
        if (key === 'number') return <button type="button" className="truncate text-[#007EA7] hover:underline" onClick={() => { if (section === 'operations') printOperation(row.id); else if (section === 'inventory') open({ type: 'inventory', record: { ...store.inventories.find(i => i.id === row.id)!, locked: true }, revision: store.revision }); else if (section !== 'groups') open({ type: 'asset', record: store.assets.find(a => a.id === row.id)!, readOnly: true, revision: store.revision }); }}>{row[key]}</button>;
        if (key === 'units' && section === 'depreciation') return store.assets.find(a => a.id === row.id)?.method === 'Units of production' ? <input aria-label={`${t('Production units')} ${row.number}`} className={`${input} !h-8`} type="number" min="0" value={units[row.id] || 0} disabled={!editable} onClick={e => e.stopPropagation()} onChange={e => setUnits({ ...units, [row.id]: Number(e.target.value) })} /> : <span>—</span>;
        if (['cost', 'depreciation', 'book', 'residual', 'amount', 'costChange', 'depreciationChange'].includes(key)) return <span className="tabular-nums">{Number(row[key]).toFixed(2)}</span>;
        if (key === 'status') return <span className={`rounded-md px-2 py-1 text-[11px] font-medium ${row.inactive ? 'bg-[#F1F3F6] text-[#7288A3]' : 'bg-[#E6F2F6] text-[#007EA7]'}`}>{row[key]}</span>;
        return <span title={t(String(row[key] ?? ''))}>{typeof row[key] === 'string' ? t(row[key]) : row[key] ?? '—'}</span>;
      }} actions={row => <div className="flex shrink-0 items-center justify-end gap-1">
        {section === 'register' || section === 'depreciation' ? <>
          <RowAction label="View asset" onClick={() => open({ type: 'asset', record: store.assets.find(a => a.id === row.id)!, readOnly: true, revision: store.revision })}><Eye size={14} /></RowAction>
          <RowAction label="Edit asset" disabled={!editable || row.inactive} onClick={() => open({ type: 'asset', record: store.assets.find(a => a.id === row.id)!, readOnly: false, revision: store.revision })}><Pencil size={14} /></RowAction>
          <RowAction label="Asset operation" disabled={!create || row.inactive || assetBalance(store, store.assets.find(a => a.id === row.id)!).disposed} onClick={() => open({ type: 'operation', record: store.assets.find(a => a.id === row.id)!, revision: store.revision })}><Play size={14} /></RowAction>
          <RowAction label="Print asset card" onClick={() => print(store.assets.find(a => a.id === row.id))}><Printer size={14} /></RowAction>
          {row.inactive ? <RowAction label="Reactivate" disabled={!editable} onClick={() => remove('assets', row.id)}><Power size={14} /></RowAction> : <RowDeleteButton linked={assetUsed(store, row.id)} label={t('Delete record')} disabled={!editable || !permissions.delete} onDelete={() => remove('assets', row.id)} />}
        </> : section === 'groups' ? <>
          <RowAction label="Edit" disabled={!editable} onClick={() => open({ type: 'group', record: store.groups.find(g => g.id === row.id)!, revision: store.revision })}><Pencil size={14} /></RowAction>
          {row.inactive ? <RowAction label="Reactivate" disabled={!editable} onClick={() => remove('groups', row.id)}><Power size={14} /></RowAction> : <RowDeleteButton linked={store.assets.some(a => a.groupId === row.id)} label={t('Delete record')} disabled={!editable || !permissions.delete} onDelete={() => remove('groups', row.id)} />}
        </> : section === 'operations' ? <RowAction label="View operation" onClick={() => printOperation(row.id)}><Eye size={14} /></RowAction> : <>
          <RowAction label="View inventory" onClick={() => open({ type: 'inventory', record: { ...store.inventories.find(i => i.id === row.id)!, locked: true }, revision: store.revision })}><Eye size={14} /></RowAction>
          <RowAction label="Edit inventory" disabled={!editable || store.inventories.find(i => i.id === row.id)?.locked} onClick={() => open({ type: 'inventory', record: store.inventories.find(i => i.id === row.id)!, revision: store.revision })}><Pencil size={14} /></RowAction>
          <RowAction label="Print inventory" onClick={() => { const i = store.inventories.find(i => i.id === row.id)!; setReport({ title: 'Asset inventory', company: company.name, details: [['Inventory No.', i.number], ['Date', i.date]], columns: ['Inventory No.', 'Asset name', 'Book quantity', 'Actual quantity', 'Difference', 'Notes'], rows: i.lines.map(l => [l.number, l.name, String(l.bookQuantity), String(l.actualQuantity), String(l.actualQuantity - l.bookQuantity), l.note]), footer: '' }); }}><Printer size={14} /></RowAction>
        </>}
      </div>} />
    {editor?.type === 'asset' && <AssetCardEditor {...common} record={editor.record} documents={documents} readOnly={editor.readOnly} />}
    {editor?.type === 'group' && <AssetGroupEditor {...common} record={editor.record} />}
    {editor?.type === 'operation' && <AssetOperationEditor {...common} record={editor.record} />}
    {editor?.type === 'inventory' && <AssetInventoryEditor {...common} record={editor.record} />}
    {confirmation && <GlJournalDialog title={confirmation.title} onClose={() => !busy && setConfirmation(null)} footer={<><CancelButton onClick={() => setConfirmation(null)}>{t('Cancel')}</CancelButton><SaveButton disabled={busy} onClick={() => void save(confirmation.command, confirmation.revision)}>{t('Confirm')}</SaveButton></>}><p className="text-[13px]">{t(confirmation.description)}</p>{error && <p role="alert" className="mt-3 text-[13px] text-red-700">{t(error)}</p>}</GlJournalDialog>}
    {report && <CashPrintPreview report={report} onClose={() => setReport(null)} />}
    </div>
  </div>;
}
