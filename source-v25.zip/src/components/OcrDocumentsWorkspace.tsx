import { translateUi as uiText } from '../i18n/language';
import { useMemo, useState, type ReactNode } from "react";
import { Check, Settings, Building2, Star } from "lucide-react";
import { NO_BUYER_FILTER } from '../lib/documentOrganizationAssignment';
import type { Company } from "../lib/supabase";
import { PageHeader } from "./PageHeader";
import OcrBreadcrumb from "./OcrBreadcrumb";
import OcrSearchField from "./OcrSearchField";

export default function OcrDocumentsWorkspace({
  title,
  organizations,
  selectedIds,
  onOrganizationsChange,
  singleOrganization = false,
  embedded = false,
  children,
}: {
  title: string;
  organizations: Company[];
  selectedIds: string[];
  onOrganizationsChange: (ids: string[]) => void;
  singleOrganization?: boolean;
  embedded?: boolean;
  children: ReactNode;
}) {
  return (
    <div className={`ocr-documents-workspace flex min-w-0 flex-col bg-white font-montserrat text-[#10233A] ${embedded ? "min-h-full gap-4" : "h-dvh min-h-0 gap-4 overflow-hidden px-4 py-10 sm:px-8 lg:px-[56px]"}`}>
      {!embedded && <PageHeader title={uiText(title)} />}
      {!embedded && <OcrBreadcrumb items={["All documents", title]} />}
      <div className="flex min-h-0 flex-1 flex-col items-stretch gap-4 lg:flex-row">
        {!embedded && (
          <OrganizationSidebar
            organizations={organizations}
            selectedIds={selectedIds}
            onChange={onOrganizationsChange}
            singleOrganization={singleOrganization}
          />
        )}
        <div className="flex min-h-0 min-w-0 flex-1 flex-col gap-3">
          {children}
        </div>
      </div>
    </div>
  );
}

export function OrganizationSidebar({
  organizations,
  selectedIds,
  onChange,
  singleOrganization = false,
  singleOrAll = false,
  allOrganizationsSelected = false,
  onOpenSettings,
  canOpenSettings,
  includeNoBuyer = false,
  noBuyerCount = 0,
  clientIds,
  headerActions,
  integrated = false,
}: {
  organizations: Company[];
  selectedIds: string[];
  onChange: (ids: string[]) => void;
  singleOrganization?: boolean;
  singleOrAll?: boolean;
  allOrganizationsSelected?: boolean;
  onOpenSettings?: (organization: Company) => void;
  canOpenSettings?: (organization: Company) => boolean;
  includeNoBuyer?: boolean;
  noBuyerCount?: number;
  clientIds?: ReadonlySet<string>;
  headerActions?: ReactNode;
  integrated?: boolean;
}) {
  const [organizationQuery, setOrganizationQuery] = useState("");
  const [clientsOnly, setClientsOnly] = useState(false);
  const selectedSet = useMemo(() => new Set(selectedIds), [selectedIds]);
  const selectedCount = organizations.filter(organization => selectedSet.has(organization.id)).length;
  const visibleOrganizations = useMemo(() => {
    const normalizedQuery = organizationQuery.trim().toLocaleLowerCase();
    return organizations.filter((organization) =>
      (!clientIds || !clientsOnly || clientIds.has(organization.id))
      && (!normalizedQuery || `${organization.name} ${organization.company_code || ''}`.toLocaleLowerCase().includes(normalizedQuery)),
    );
  }, [organizationQuery, organizations, clientIds, clientsOnly]);
  const showNoBuyer = includeNoBuyer && !clientsOnly && (!organizationQuery.trim() || `${uiText('No buyer')} No buyer`.toLocaleLowerCase().includes(organizationQuery.trim().toLocaleLowerCase()));
  const displayedIds = [...visibleOrganizations.map(organization => organization.id), ...(showNoBuyer ? [NO_BUYER_FILTER] : [])];
  const allSelected = singleOrAll ? allOrganizationsSelected : displayedIds.length > 0 && displayedIds.every(id => selectedSet.has(id));

  const toggleOrganization = (id: string) => {
    if (singleOrganization || singleOrAll) {
      onChange([id]);
      return;
    }
    const next = selectedIds.includes(id)
      ? selectedIds.filter((selectedId) => selectedId !== id)
      : [...selectedIds, id];
    onChange(next);
  };

  return (
    <aside className={integrated
      ? 'row-start-2 flex max-h-[240px] min-h-0 w-full flex-col overflow-hidden border-b border-[#E5EDF9] bg-white pb-3 lg:col-start-1 lg:max-h-none lg:self-stretch lg:border-b-0 lg:border-r lg:pb-0 lg:pr-3'
      : 'flex max-h-[240px] w-full flex-shrink-0 flex-col self-start overflow-hidden rounded-lg border border-[#D3E1EC] bg-white lg:max-h-full lg:w-[224px]'}>
      <div className={integrated ? 'shrink-0 pb-3' : 'shrink-0 border-b border-[#E5EDF9] px-4 pb-3 pt-4'}>
        <div className="flex min-h-7 items-center justify-between gap-2">
          <h2 className="font-montserrat text-[14px] font-semibold text-[#10233A]">{uiText("Organizations")}</h2>
          <div className="flex items-center gap-1.5">
          {clientIds && <button type="button" aria-label={uiText('Show organization clients only')} title={uiText('Show organization clients only')}
            aria-pressed={clientsOnly} onClick={() => setClientsOnly(value => !value)}
            className={`flex h-7 w-7 shrink-0 items-center justify-center rounded border transition-colors ${clientsOnly ? 'border-[#007EA7] bg-[#E5EDF9] text-[#007EA7]' : 'border-[#D3E1EC] bg-white text-[#7288A3] hover:border-[#007EA7] hover:text-[#007EA7]'}`}>
            <Star size={15} fill={clientsOnly ? 'currentColor' : 'none'} />
          </button>}
          {headerActions}
          {!headerActions && <span className="flex h-6 min-w-10 items-center justify-center rounded-full bg-[#E7F4F9] px-2 font-montserrat text-[11px] font-semibold text-[#007EA7]">
            {selectedCount}/{organizations.length}
          </span>}
          </div>
        </div>
        {!integrated && <p className="mt-1 font-montserrat text-[11px] font-medium leading-[16px] text-[#7288A3]">
          {singleOrganization || singleOrAll ? uiText("Choose an organization to display") : uiText("Choose which organizations to display")}
        </p>}
        <OcrSearchField
          ariaLabel={uiText("Search organizations")}
          value={organizationQuery}
          onChange={setOrganizationQuery}
          className="mt-3 !w-full !min-w-0 !max-w-full"
        />
      </div>
      <div className="flex min-h-0 flex-col p-2">
        {!singleOrganization && <>
        <button
          type="button"
          aria-pressed={allSelected}
          data-static-selection
          onClick={() => onChange(singleOrAll ? [] : allSelected ? selectedIds.filter(id => !displayedIds.includes(id)) : [...new Set([...selectedIds, ...displayedIds])])}
          className={`flex min-h-10 w-full shrink-0 items-center gap-3 rounded-lg px-2.5 py-2 text-left transition-colors ${allSelected ? "bg-[#E7F4F9]" : "hover:bg-[#F2F7FC]"}`}
        >
          {!singleOrAll && <SelectorCheck checked={allSelected} />}
          <span className="min-w-0 flex-1 font-montserrat text-[12px] font-semibold text-[#10233A]">{uiText(singleOrAll ? 'All organizations' : clientIds ? 'Select all shown' : 'All organizations')}</span>
          <span className="font-montserrat text-[11px] font-medium text-[#7288A3]">
            {visibleOrganizations.length}
          </span>
        </button>
        <div className="mx-2 my-2 h-px shrink-0 bg-[#E5EDF9]" />
        </>}
        <div className="min-h-0 max-h-[calc(100dvh-250px)] overflow-y-auto overscroll-y-contain pr-0.5">
          <div className="flex flex-col gap-0.5">
            {showNoBuyer && (
              <button type="button" aria-pressed={selectedSet.has(NO_BUYER_FILTER) && !(singleOrAll && allSelected)} data-static-selection
                onClick={() => onChange([NO_BUYER_FILTER])}
                title={uiText('Documents without an organization')}
                className={`flex h-11 min-w-0 items-center gap-2 rounded-md border px-2.5 text-left transition-colors ${selectedSet.has(NO_BUYER_FILTER) && !(singleOrAll && allSelected) ? 'border-[#D5E5EF] bg-[#F0F7FB]' : 'border-transparent bg-white hover:bg-[#F7F9FC]'}`}>
                {!singleOrAll && <SelectorCheck checked={selectedSet.has(NO_BUYER_FILTER)} />}
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded border border-[#DCE7EF] bg-white text-[#7288A3]"><Building2 size={14} /></span>
                <span className="min-w-0 flex-1 truncate font-montserrat text-[12px] font-medium text-[#10233A]">{uiText('No buyer')}</span>
                <span className="font-montserrat text-[11px] text-[#7288A3]">{noBuyerCount}</span>
              </button>
            )}
            {visibleOrganizations.map((organization) => {
              const checked = selectedSet.has(organization.id) && !(singleOrAll && allSelected);
              const initials = organization.name
                .trim()
                .split(/\s+/)
                .slice(0, 2)
                .map((part) => part.charAt(0).toLocaleUpperCase())
                .join("");
              return (
                <div key={organization.id} data-organization-selected={checked}
                  className={`flex h-11 min-w-0 items-center rounded-md border px-1 transition-colors ${checked ? 'border-[#D5E5EF] bg-[#F0F7FB]' : 'border-transparent bg-white hover:bg-[#F7F9FC]'}`}>
                <button
                  type="button"
                  aria-pressed={checked}
                  data-static-selection
                  onClick={() => toggleOrganization(organization.id)}
                  className="flex h-full min-w-0 flex-1 items-center gap-2 rounded px-1.5 text-left focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#007EA7]"
                >
                  {!singleOrAll && <SelectorCheck checked={checked} />}
                  <span className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded border border-[#DCE7EF] bg-white font-montserrat text-[9px] font-semibold text-[#7288A3]">
                    {clientIds ? (clientIds.has(organization.id)
                      ? <Star size={14} fill="currentColor" className="text-[#007EA7]" aria-label={uiText('Organization client')} />
                      : <Building2 size={14} />) : initials || "—"}
                  </span>
                  <span title={organization.name} className="min-w-0 flex-1 truncate font-montserrat text-[12px] font-medium text-[#10233A]">
                    {organization.name}
                  </span>
                </button>
                {onOpenSettings && <button
                  type="button"
                  aria-label={`${uiText(clientIds ? 'Organization settings' : 'Documents & digitization setup')} · ${organization.name}`}
                  title={`${uiText(clientIds ? 'Organization settings' : 'Documents & digitization setup')} · ${organization.name}`}
                  disabled={canOpenSettings ? !canOpenSettings(organization) : false}
                  onClick={() => onOpenSettings(organization)}
                  className="flex h-7 w-7 shrink-0 items-center justify-center rounded border border-transparent text-[#7288A3] transition-colors hover:border-[#B8D7E5] hover:bg-white hover:text-[#007EA7] focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#007EA7] disabled:cursor-not-allowed disabled:text-[#B4B6B8]"
                ><Settings size={15} /></button>}
                </div>
              );
            })}
            {visibleOrganizations.length === 0 && !showNoBuyer && (
              <div className="px-3 py-6 text-center font-montserrat text-[11px] font-medium text-[#7288A3]">{uiText("No organizations found")}</div>
            )}
          </div>
        </div>
      </div>
    </aside>
  );
}

function SelectorCheck({ checked }: { checked: boolean }) {
  return (
    <span className={`flex h-[18px] w-[18px] flex-shrink-0 items-center justify-center rounded-[6px] border ${checked ? "border-[#007EA7] bg-[#007EA7]" : "border-[#A1B6C6] bg-white"}`}>
      {checked && <Check size={12} strokeWidth={2.5} className="text-white" />}
    </span>
  );
}


