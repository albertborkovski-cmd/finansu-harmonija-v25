import ClientPlanSelection from './ClientPlanSelection';
import SaasPlansPricing from './SaasPlansPricing';

/** The profile is selection-only, even for an administrator's own account. */
export default function ContractPricingPanel(props: { selectedPlanId: string; currentPlanId?: string; selectedTierId?: string; onSelectPlan: (id: string) => void; onSelectTier?: (id: string) => void; administration?: boolean }) {
  return props.administration
    ? <SaasPlansPricing selectedPlanId={props.selectedPlanId} onSelectPlan={props.onSelectPlan} />
    : <ClientPlanSelection selectedPlanId={props.selectedPlanId} currentPlanId={props.currentPlanId || ''} selectedTierId={props.selectedTierId} onSelectPlan={props.onSelectPlan} onSelectTier={props.onSelectTier} />;
}
