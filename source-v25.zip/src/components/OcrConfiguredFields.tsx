import { useId, useState, type Dispatch, type ReactNode, type SetStateAction } from 'react';
import { AlertCircle, Building2, ChevronDown, Plus, Trash2 } from 'lucide-react';
import { translateUi as uiText } from '../i18n/language';
import type { WorkspaceTask } from './WorkspaceView';
import type { DbDocument } from '../lib/supabase';
import type { OcrFieldValidationRule } from '../lib/ocrFieldValidation';
import { configuredOcrParties, ocrFormGroups, ocrRulePartyId, ocrSavedPartyId, ocrPartyRoleLabel } from '../lib/ocrFormSchema';
import { ocrEditorValue, updateOcrEditorValue, type OcrFieldScope } from '../lib/ocrFormValues';
import { hasOcrValue, isRequiredOcrPartyField, ocrDocumentPartyPurpose } from '../lib/ocrRequiredFields';
import SearchableSelect from './SearchableSelect';
import { ocrEditorRulesForIntegration } from '../lib/ocrAccountingFields';
import { OCR_FIELD_IMPORTANCE } from '../lib/ocrFieldImportance';

export type OcrConfiguredControl = {
  rule: OcrFieldValidationRule; scope: OcrFieldScope; value: string; required: boolean; onChange: (value: string) => void;
  compact?: boolean;
};
export function OcrConfiguredInput({ rule, value, required, onChange, readOnly, compact }: OcrConfiguredControl & { readOnly: boolean }) {
  const id = useId(), invalid = required && !hasOcrValue(value);
  const classes = `min-w-0 w-full border ${compact ? 'rounded px-2' : 'rounded-lg px-3'} text-[12px] outline-none focus:border-[#007EA7] ${invalid ? 'border-[#E65050] bg-[#FFF0F0]' : 'border-[#D3E1EC] bg-white'}`;
  return <div className={compact ? 'ocr-party-control' : 'space-y-1.5 text-[12px] font-medium text-[#10233A]'}>
    <label htmlFor={id}>{uiText(rule.label)}{required && <span className="ml-1 text-[#D64545]">*</span>}</label>
    {rule.inputType === 'select' || rule.inputType === 'boolean' ? <SearchableSelect ariaLabel={uiText(rule.label)} value={value}
      options={rule.inputType === 'boolean' ? [{ value: 'true', label: uiText('Yes') }, { value: 'false', label: uiText('No') }] : rule.options || []}
      onChange={onChange} disabled={readOnly} placeholder="—" portalMenu className={`${compact ? 'h-8' : 'h-10'} pr-9 ${classes}`} />
      : rule.inputType === 'textarea' ? <textarea id={id} aria-label={uiText(rule.label)} aria-invalid={invalid} value={value} rows={compact ? 2 : 3}
        readOnly={readOnly} onChange={event => onChange(event.target.value)} className={`resize-y py-2 ${classes}`} />
      : <input id={id} aria-label={uiText(rule.label)} aria-invalid={invalid} value={value} readOnly={readOnly}
        type={rule.inputType === 'date' || rule.inputType === 'email' ? rule.inputType : 'text'} inputMode={rule.inputType === 'number' ? 'decimal' : undefined}
        onChange={event => onChange(event.target.value)} className={`${compact ? 'h-8' : 'h-10'} ${classes}`} />}
  </div>;
}

export default function OcrConfiguredFields({ rules, draft, document, setDraft, readOnly, renderControl, exportFormat, onSelectControl }: {
  rules: readonly OcrFieldValidationRule[]; draft: WorkspaceTask; document?: Partial<DbDocument>;
  setDraft: Dispatch<SetStateAction<WorkspaceTask>>; readOnly: boolean;
  renderControl: (control: OcrConfiguredControl) => ReactNode;
  exportFormat?: string;
  onSelectControl?: (control: OcrConfiguredControl) => void;
}) {
  const [closedGroups, setClosedGroups] = useState<Set<string>>(() => new Set(['calculated']));
  const groups = ocrFormGroups(ocrEditorRulesForIntegration(rules, exportFormat));
  const partyRules = groups.flatMap(group => group.id === 'parties' ? group.fields : []);
  const purpose = ocrDocumentPartyPurpose(document);
  const parties = configuredOcrParties(partyRules, draft.ocrParties || document?.ocr_parties, draft.id, purpose);
  const control = (rule: OcrFieldValidationRule, scope: OcrFieldScope = {}) => {
    const compact = Boolean(scope.party);
    const props: OcrConfiguredControl = { rule, scope, compact, value: ocrEditorValue(draft, document, rule, scope), required: isRequiredOcrPartyField(rule, purpose),
      onChange: value => setDraft(current => updateOcrEditorValue(current, rule, value, scope, parties, rules, document)) };
    const importance = OCR_FIELD_IMPORTANCE[rule.level];
    const missing = props.required && !hasOcrValue(props.value);
    return <div key={rule.key} data-ocr-field={rule.key} data-ocr-field-label={rule.label} data-ocr-validation={missing ? 'missing' : undefined}
      role={compact ? 'group' : undefined} aria-label={compact ? `${uiText(rule.label)}. ${uiText('Field importance')}: ${uiText(importance.label)}` : undefined}
      className={compact ? 'ocr-party-field relative rounded-sm border-l-[3px] pl-2' : 'rounded-sm border-l-[3px] pl-2.5'} style={{ borderLeftColor: importance.color }}
      onFocusCapture={() => { if (!readOnly) onSelectControl?.(props); }} onClick={() => { if (!readOnly) onSelectControl?.(props); }}>
      {compact ? <span data-ocr-importance={rule.level} role="img" aria-label={`${uiText('Field importance')}: ${uiText(importance.label)}`}
        data-tooltip={`${uiText('Field importance')}: ${uiText(importance.label)}`} className="absolute -left-1.5 inset-y-0 w-2" /> : <div className="mb-1.5 flex items-center gap-1.5 text-[10px] font-medium text-[#7288A3]" data-ocr-importance={rule.level}>
        <span>{uiText('Field importance')}:</span>
        <span className="inline-flex items-center gap-1 rounded px-1.5 py-0.5" style={{ color: importance.color, backgroundColor: importance.background }}>
          <span aria-hidden="true" className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: importance.color }} />{uiText(importance.label)}
        </span>
      </div>}
      {renderControl(props) ?? <OcrConfiguredInput {...props} readOnly={readOnly} />}
      {missing && <p className="mt-1.5 flex items-center gap-1.5 text-[11px] text-[#B42318]" data-ocr-validation-message>
        <AlertCircle size={14} aria-hidden="true" className="shrink-0" />{uiText('Required field is empty.')}
      </p>}
    </div>;
  };
  return <div className="space-y-3" data-ocr-configured-form>
    {groups.map(group => <details key={group.id} open={!closedGroups.has(group.id)} onToggle={event => {
      const open = event.currentTarget.open;
      setClosedGroups(current => {
        if (current.has(group.id) === !open) return current;
        const next = new Set(current); if (open) next.delete(group.id); else next.add(group.id); return next;
      });
    }} className="group/section rounded-lg border border-[#D3E1EC] bg-white" data-ocr-field-group={group.id}>
      <summary className="flex cursor-pointer list-none items-center justify-between gap-3 rounded-lg bg-[#F2F8FC] px-4 py-3 text-[13px] font-semibold text-[#10233A] outline-none focus-visible:ring-2 focus-visible:ring-[#007EA7] [&::-webkit-details-marker]:hidden">
        {uiText(group.id === 'calculated' ? 'Accounting fields (ADDINFO)' : group.label)}<ChevronDown size={17} aria-hidden="true" className="shrink-0 text-[#7288A3] transition-transform group-open/section:rotate-180" />
      </summary>
      <div className={group.id === 'parties' ? 'ocr-parties-container p-3' : 'space-y-3 p-3'} data-ocr-accounting-fields={group.id === 'calculated' || undefined}>
        {group.id === 'parties' ? <div className="ocr-parties-grid">{parties.map(party => {
          const role = ocrSavedPartyId(party), sameRole = parties.filter(item => ocrSavedPartyId(item) === role);
          const primary = sameRole[0].id === party.id;
          const fields = group.fields.filter(rule => ocrRulePartyId(rule) === role);
          const label = uiText(ocrPartyRoleLabel(party.role, purpose));
          return <section key={party.id} aria-label={label} className="ocr-party-card min-w-0 overflow-hidden rounded-lg border border-[#D3E1EC] bg-white">
            <div className="flex min-h-9 items-center justify-between gap-2 border-b border-[#D3E1EC] bg-[#F2F7FC] px-3 py-2">
              <h3 className="flex min-w-0 items-center gap-2 text-[12px] font-semibold text-[#10233A]"><Building2 size={15} aria-hidden="true" className="shrink-0 text-[#7288A3]" />{label}{sameRole.length > 1 ? ` ${sameRole.indexOf(party) + 1}` : ''}</h3>
              {!readOnly && !primary && <button type="button" aria-label={`${uiText('Remove party')}: ${label} ${sameRole.indexOf(party) + 1}`} onClick={() => setDraft(current => ({ ...current, ocrParties: (current.ocrParties || []).filter(item => item.id !== party.id) }))} className="rounded p-1.5 text-[#7288A3] hover:bg-[#FFF0F0] hover:text-[#D92D20]"><Trash2 size={15} /></button>}
            </div>
            <div className="ocr-party-fields p-2.5">{fields.map(rule => control(rule, { party, primary, purpose }))}</div>
          </section>;
        })}</div> : group.id === 'lines' ? <>
          {!readOnly && <div className="flex justify-end"><button type="button" onClick={() => setDraft(current => ({ ...current, products: [...current.products,
            { id: crypto.randomUUID(), name: '', description: '', quantity: '', price: '', ocrValues: {} }] }))} className="flex items-center gap-1.5 rounded border border-[#D3E1EC] px-3 py-1.5 text-[12px] font-semibold text-[#007EA7]"><Plus size={15} />{uiText('Add line')}</button></div>}
          {draft.products.length === 0 && <p className="text-[12px] text-[#7288A3]">{uiText('No document lines are available.')}</p>}
          {draft.products.map((line, index) => <section key={line.id} aria-label={`${uiText('Line item')} ${index + 1}`} className="space-y-3 rounded-lg border border-[#E5EDF9] p-3">
            <div className="flex items-center justify-between"><h3 className="text-[12px] font-semibold text-[#10233A]">{uiText('Line item')} {index + 1}</h3>
              {!readOnly && <button type="button" aria-label={`${uiText('Remove line')} ${index + 1}`} onClick={() => setDraft(current => ({ ...current, products: current.products.filter(item => item.id !== line.id) }))} className="rounded p-1.5 text-[#7288A3] hover:bg-[#FFF0F0] hover:text-[#D92D20]"><Trash2 size={15} /></button>}
            </div>{group.fields.map(rule => control(rule, { line }))}
          </section>)}
        </> : group.fields.map(rule => control(rule))}
      </div>
    </details>)}
  </div>;
}
