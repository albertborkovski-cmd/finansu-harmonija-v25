import { translateUi as uiText } from '../i18n/language';
import { useEffect, useId, useRef, useState, type FormEvent } from 'react';
import { createPortal } from 'react-dom';
import { CornerUpLeft, Send, X } from 'lucide-react';
import { SaveButton } from './ScopedActionButtons';
import SearchableSelect from './SearchableSelect';
import { ESCALATION_REASONS, RETURN_DOCUMENT_REASONS, validateWorkerHandoff, type WorkerHandoffAction, type WorkerHandoffInput } from '../lib/ocrWorkerHandoff';

export default function SendToTeamLeadDialog({ documentName, action = 'escalate', onClose, onSend }: {
  documentName: string; action?: WorkerHandoffAction; onClose: () => void; onSend: (values: WorkerHandoffInput) => Promise<void>;
}) {
  const titleId = useId(), commentId = useId(), helpId = useId();
  const root = useRef<HTMLDivElement>(null), pending = useRef(false);
  const [reason, setReason] = useState(''), [comment, setComment] = useState('');
  const [error, setError] = useState(''), [busy, setBusy] = useState(false);
  const returning = action === 'return';
  const commentRequired = reason === 'Other';
  const title = returning ? 'Return document' : 'Send to team lead';
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    root.current?.querySelector<HTMLInputElement>('[role="combobox"]')?.focus();
    return () => { if (previous?.isConnected) previous.focus(); };
  }, []);
  const close = () => { if (!pending.current) onClose(); };
  const submit = async (event: FormEvent) => {
    event.preventDefault(); event.stopPropagation();
    if (pending.current) return;
    try {
      const values = validateWorkerHandoff(action, { reason, comment });
      pending.current = true; setBusy(true); setError('');
      await onSend(values);
      onClose();
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Could not save the document. Please try again.'); }
    finally { pending.current = false; setBusy(false); }
  };
  return createPortal(<div className="fixed inset-0 z-[5400] flex items-center justify-center bg-[#10233A]/30 p-4 font-montserrat" onMouseDown={event => {
    event.stopPropagation(); if (event.target === event.currentTarget) close();
  }} onKeyDown={event => {
    if (event.defaultPrevented) return;
    event.stopPropagation();
    if (event.key === 'Escape') { event.preventDefault(); close(); }
  }}>
    <div ref={root} role="dialog" aria-modal="true" aria-labelledby={titleId} aria-busy={busy} className="flex max-h-[90vh] w-full max-w-[620px] flex-col overflow-hidden rounded-xl border border-[#D3E1EC] bg-white shadow-xl">
      <header className="flex items-start gap-3 border-b border-[#E5EDF9] px-6 py-4">
        <span className="rounded-lg bg-[#EAF4F8] p-2.5 text-[#007EA7]">{returning ? <CornerUpLeft size={21} /> : <Send size={21} />}</span>
        <div className="min-w-0 flex-1"><h2 id={titleId} className="text-[18px] font-semibold text-[#10233A]">{uiText(title)}</h2><p className="mt-1 truncate text-[12px] text-[#7288A3]">{documentName}</p></div>
        <button type="button" aria-label={uiText('Close')} disabled={busy} onClick={close} className="rounded-md p-1 text-[#7288A3] hover:bg-[#F2F5F9] disabled:opacity-50"><X size={19} /></button>
      </header>
      <form onSubmit={event => void submit(event)} className="flex min-h-0 flex-col">
        <div className="space-y-4 overflow-y-auto px-6 py-5">
          <p id={helpId} className="rounded-lg bg-[#F4F8FC] px-3 py-2.5 text-[12px] leading-5 text-[#7288A3]">{uiText(returning
            ? 'The document will return to Uploaded documents as Rejected in Needs attention. Your corrections will be saved.'
            : 'The document will move to TeamLead → Escalated documents as Escalated. Your corrections will be saved.')}</p>
          <div><p className="mb-1.5 text-[12px] font-medium text-[#7288A3]">{uiText('Reason')} <span className="text-[#D92D20]">*</span></p>
            <SearchableSelect ariaLabel={uiText('Reason')} value={reason} disabled={busy} onChange={value => { setReason(value); setError(''); }} options={[...(returning ? RETURN_DOCUMENT_REASONS : ESCALATION_REASONS)]} localizeOptions placeholder={uiText('Select a reason')} />
          </div>
          <div><label htmlFor={commentId} className="mb-1.5 block text-[12px] font-medium text-[#7288A3]">{uiText(commentRequired ? 'Comment' : 'Comment (optional)')}{commentRequired && <span className="text-[#D92D20]"> *</span>}</label>
            <textarea id={commentId} required={commentRequired} aria-describedby={helpId} disabled={busy} rows={5} maxLength={5000} value={comment} onChange={event => { setComment(event.target.value); setError(''); }} placeholder={uiText('Add details that will help the recipient…')} className="w-full resize-y rounded-lg border border-[#D3E1EC] bg-white px-3 py-2.5 text-[13px] leading-5 text-[#10233A] outline-none focus:border-[#007EA7] focus:ring-2 focus:ring-[#007EA7]/10" />
          </div>
          {error && <p role="alert" className="rounded-md bg-[#FFF0F0] p-3 text-[12px] text-[#B42318]">{uiText(error)}</p>}
        </div>
        <footer className="flex flex-wrap justify-end gap-3 border-t border-[#E5EDF9] px-6 py-4">
          <button type="button" disabled={busy} onClick={close} className="rounded-lg border border-[#D3E1EC] px-4 py-2 text-[13px] font-semibold text-[#7288A3] disabled:opacity-50">{uiText('Cancel')}</button>
          <SaveButton type="submit" disabled={busy || !reason || commentRequired && !comment.trim()}>{uiText(busy ? 'Saving…' : returning ? 'Return and next file' : 'Send and next file')}</SaveButton>
        </footer>
      </form>
    </div>
  </div>, document.body);
}
