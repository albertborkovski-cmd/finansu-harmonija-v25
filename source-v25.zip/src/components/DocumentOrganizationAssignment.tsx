import { useRef, useState } from 'react';
import { Plus, Scissors, Upload } from 'lucide-react';
import { translateUi as uiText } from '../i18n/language';
import { assignDocumentOrganization, type Company, type DbDocument } from '../lib/supabase';
import { documentOrganizationSnapshot } from '../lib/documentOrganizationAssignment';
import { uploadedDocumentSource } from '../lib/uploadedDocumentSource';
import { uploadedDocumentTimestamp as uploadedTimestamp } from '../lib/uploadedDocuments';
import SearchableSelect from './SearchableSelect';
import { HeaderBackButton } from './SystemNavigation';
import { SaveButton } from './ScopedActionButtons';
import { PageActionButton } from './PageHeader';
import HorizontalTableScrollbar from './HorizontalTableScrollbar';
function displayUploadedDate(document: DbDocument) {
  const timestamp = uploadedTimestamp(document);
  if (!timestamp) return document.receive_date || '—';
  const date = new Date(timestamp);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function sourceValue(document: DbDocument) {
  return uploadedDocumentSource(document, uiText).detail;
}

function AssignmentField({ label, value }: { label: string; value?: string }) {
  return (
    <div className="flex min-w-0 flex-col gap-2">
      <span className="font-montserrat text-[14px] font-semibold leading-5 text-[#10233A]">{uiText(label)}</span>
      <div className="flex h-[42px] min-w-0 items-center rounded-lg border border-[#D3E1EC] bg-[#F7F7F7] px-[14px] font-montserrat text-[14px] font-medium leading-5 text-[#828588]">
        <span className="truncate" title={value || undefined}>{value || '—'}</span>
      </div>
    </div>
  );
}


export default function DocumentOrganizationAssignment({ document: selectedDocument, organizations, onAssigned, onClose }: {
 document: DbDocument; organizations: Company[]; onAssigned: (document: DbDocument) => void; onClose: () => void;
}) {
 const [selectedOrganizationId, setSelectedOrganizationId] = useState('');
 const [assignmentLineMode, setAssignmentLineMode] = useState<'summary' | 'quantity'>(selectedDocument.summary_line_items?.length ? 'summary' : 'quantity');
 const [saving, setSaving] = useState(false), [error, setError] = useState('');
 const pending = useRef(false), tableScrollRef = useRef<HTMLDivElement>(null);
 const snapshot = useRef(documentOrganizationSnapshot(selectedDocument as unknown as Record<string, unknown>));
 const close = () => { if (!pending.current) onClose(); };
 async function assignOrganization() {
  if (!selectedOrganizationId || pending.current) return;
  pending.current = true; setSaving(true); setError('');
  try { onAssigned(await assignDocumentOrganization(selectedDocument.id, selectedOrganizationId, snapshot.current)); }
  catch (reason) { setError(reason instanceof Error ? reason.message : 'Unable to save the document.'); }
  finally { pending.current = false; setSaving(false); }
 }
    const selectedOrganization = organizations.find((organization) => organization.id === selectedOrganizationId);
    const purpose = (selectedDocument.document_purpose || '').trim().toLowerCase();
    const isPurchase = purpose === 'purchase' || (purpose !== 'sale' && /purchase|expense|pirk/i.test(`${selectedDocument.type} ${selectedDocument.document_type}`));
    const counterpartyName = selectedDocument.client_counterparty === 'Organization pending identification'
      ? '—'
      : selectedDocument.client_counterparty || '—';
    let counterpartyCode = '';
    try {
      const stored = JSON.parse(window.localStorage.getItem('finansu-harmonija:v7:settings:counterparties') || '[]') as Company[];
      if (Array.isArray(stored)) counterpartyCode = stored.find((party) => party.id === selectedDocument.counterparty_id || party.name.trim().toLowerCase() === counterpartyName.trim().toLowerCase())?.company_code || '';
    } catch { /* Missing optional directory data leaves the code empty. */ }
    const selectedAssignmentLines = assignmentLineMode === 'summary'
      ? selectedDocument.summary_line_items
      : selectedDocument.line_items;
    const assignmentLines = selectedAssignmentLines?.length
      ? selectedAssignmentLines
      : assignmentLineMode === 'summary' && selectedDocument.line_items?.length
        ? selectedDocument.line_items
        : assignmentLineMode === 'quantity' && selectedDocument.summary_line_items?.length
          ? selectedDocument.summary_line_items
        : [{
            id: 'empty-line', unit: '—', qty: '—', price: selectedDocument.amount_without_vat || '—',
            subtotal: selectedDocument.amount_without_vat || '—', vat: selectedDocument.vat || '—',
            vatPct: selectedDocument.vat_percent || '—', total: selectedDocument.total_amount || '—',
            productGroup: '—', department: selectedDocument.department_code || '—',
            object: selectedDocument.object_project || '—', series: selectedDocument.series || '—',
            center: selectedDocument.cost_center || '—', expense: selectedDocument.expense_account || '—',
            vatClass: selectedDocument.vat_classifier || '—', barcode: '', product: '', code: '', discount: '',
          }];
    return (
      <div role="dialog" aria-modal="true" aria-label={uiText("Assign organization")} data-document-form="organization-assignment" className="fixed inset-0 z-50 flex flex-col overflow-hidden bg-white">
        <div className="flex min-h-0 flex-1 flex-row overflow-y-auto">
          <section className="sticky left-0 top-0 flex h-screen w-[28%] min-w-[260px] max-w-[400px] flex-shrink-0 items-center justify-center border-r border-[#D3E1EC] bg-[#F8FDFF]">
            <div className="h-full w-full">
              {selectedDocument.image_url && (selectedDocument.image_url.startsWith('data:image/') || /\.(png|jpe?g|gif|webp|tiff?)($|\?)/i.test(selectedDocument.image_url)) ? (
                <img src={selectedDocument.image_url} alt="Uploaded document" className="h-full w-full bg-white object-contain object-top" />
              ) : selectedDocument.image_url ? (
                <object data={selectedDocument.image_url} type="application/pdf" aria-label={uiText("Uploaded document")} className="h-full w-full bg-white">
                  <div className="flex h-full items-center justify-center bg-white px-8 text-center font-montserrat text-[14px] text-[#7288A3]">{uiText("PDF preview is not available in this browser.")}</div>
                </object>
              ) : (
                <div className="flex h-full items-center justify-center px-4">
                  <div className="flex w-full max-w-[304px] flex-col items-center gap-4 rounded-lg border-2 border-dashed border-[#D3E1EC] bg-white px-4 py-8 text-center">
                    <div className="flex h-14 w-14 flex-shrink-0 items-center justify-center rounded-full bg-[#F0F7FA]"><Upload size={28} className="text-[#007EA7]" /></div>
                    <span className="w-full whitespace-nowrap text-center font-montserrat text-[16px] font-semibold leading-6 text-[#10233A]">{uiText("Uploaded document")}</span>
                    <span className="w-full min-w-0 text-center font-montserrat text-[13px] font-medium leading-5 text-[#7288A3] [overflow-wrap:anywhere]" title={selectedDocument.file_case || selectedDocument.number || selectedDocument.id}>{selectedDocument.file_case || selectedDocument.number || selectedDocument.id}</span>
                  </div>
                </div>
              )}
            </div>
          </section>

          <section className="flex min-w-0 flex-1 flex-col overflow-hidden">
              <header className="flex flex-shrink-0 flex-wrap items-center justify-between gap-3 px-6 py-6">
                <div className="flex min-w-0 items-center gap-2">
                  <HeaderBackButton onClick={close} label={uiText("Back")} />
                  <h1 className="truncate font-montserrat text-[18px] font-semibold leading-[26px] text-[#10233A]">{uiText("Assign organization")} · {selectedDocument.file_case || selectedDocument.number || selectedDocument.id}</h1>
                </div>
                <div className="flex flex-shrink-0 items-center gap-2">
                  <PageActionButton onClick={close} disabled={saving}>{uiText('Cancel')}</PageActionButton>
                  <SaveButton disabled={!selectedOrganization || saving} onClick={() => void assignOrganization()} className="!h-8 !min-h-8 !rounded-md !px-3 !text-[14px] !leading-5">{uiText("Assign organization")}</SaveButton>
                </div>
              </header>

            <div className="min-h-0 min-w-0 flex-1 overflow-x-hidden overflow-y-auto scrollbar-hide">
            <div className="flex min-h-full w-full min-w-0 flex-col gap-6 px-6 pb-6">
{error && <p role="alert" className="text-[12px] text-[#B42318]">{uiText(error)}</p>}
              <div className="grid min-w-0 grid-cols-[repeat(auto-fit,minmax(180px,1fr))] gap-x-4 gap-y-4 rounded-lg border border-[#D3E1EC] p-4">
                <div className="contents">
                  <div className="flex min-w-0 flex-col gap-2">
                    <span className="font-montserrat text-[14px] font-semibold leading-5 text-[#10233A]">{uiText("Organization")}</span>
                    <SearchableSelect
                      ariaLabel={uiText("Organization")}
                      value={selectedOrganizationId}
                      disabled={saving}
                      portalMenu
                      onChange={setSelectedOrganizationId}
                      placeholder={uiText("Select organization")}
                      options={organizations.map((organization) => ({
                        value: organization.id,
                        label: organization.name,
                        description: `${uiText("Company code")}: ${organization.company_code || '—'}`,
                      }))}
                      selectionIndicator="checkbox"
                      menuClassName="!z-[5200] w-[360px] max-w-[calc(100vw-48px)]"
                      emptyMessage={uiText("No organizations found.")}
                    />
                  </div>
                  <AssignmentField label={isPurchase ? uiText('Seller') : uiText('Buyer')} value={counterpartyName} />
                  <AssignmentField label={uiText("Counterparty code")} value={counterpartyCode} />
                  <AssignmentField label={uiText("Accountable person")} value={selectedDocument.accountable_responsible} />
                </div>

                {[
                  [['Invoice date', selectedDocument.invoice_contract_date || selectedDocument.document_date || '—'], ['Operation date', selectedDocument.operation_date || '—']],
                  [['Due date', selectedDocument.due_end_date || '—']],
                  [['Document Number', selectedDocument.number || '—'], ['Order No.', selectedDocument.order_no || '—']],
                  [['Amount', selectedDocument.amount_without_vat || '—'], ['Total Amount', selectedDocument.total_amount || '—']],
                  [['VAT', selectedDocument.vat || '—'], ['Currency', selectedDocument.currency || '—']],
                ].map((fieldGroup, groupIndex) => (
                  <div key={groupIndex} className="contents">
                    {fieldGroup.map(([label, value]) => <AssignmentField key={label} label={uiText(label)} value={value} />)}
                  </div>
                ))}


              </div>

              <section className="flex w-full min-w-0 flex-col gap-2">
                <div className="flex items-center justify-start gap-3">
                  <div className="inline-flex rounded-md bg-[#EEF4F7] p-0.5">
                    <button type="button" onClick={() => setAssignmentLineMode('summary')} className={`h-7 rounded px-3 font-montserrat text-[11px] font-semibold transition-colors ${assignmentLineMode === 'summary' ? 'bg-white text-[#007EA7] shadow-[0_1px_3px_rgba(16,35,58,0.12)]' : 'text-[#7288A3] hover:text-[#10233A]'}`}>{uiText("Summary")} ({selectedDocument.summary_line_items?.length || 0})</button>
                    <button type="button" onClick={() => setAssignmentLineMode('quantity')} className={`h-7 rounded px-3 font-montserrat text-[11px] font-semibold transition-colors ${assignmentLineMode === 'quantity' ? 'bg-white text-[#007EA7] shadow-[0_1px_3px_rgba(16,35,58,0.12)]' : 'text-[#7288A3] hover:text-[#10233A]'}`}>{uiText("Quantity")} ({selectedDocument.line_items?.length || 0})</button>
                  </div>
                  <button type="button" disabled aria-label={uiText("Split")} className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-md border border-[#D3E1EC] bg-white text-[#D3E1EC]"><Scissors size={14} strokeWidth={1.8} /></button>
                  <button type="button" disabled aria-label={uiText("Add line")} className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-md border border-[#D3E1EC] bg-white text-[#D3E1EC]"><Plus size={14} strokeWidth={1.8} /></button>
                </div>
                <h2 className="border-b border-[#D3E1EC] pb-2 font-montserrat text-[12px] font-semibold text-[#10233A]">{uiText("Document lines")}</h2>
                <div ref={tableScrollRef} className="w-full min-w-0 overflow-x-auto scrollbar-hide">
                <div className="flex w-max min-w-full flex-col">
                  <div className="flex flex-row items-center gap-[2px] p-[5px]">
                    <div className="w-[18px] flex-shrink-0" />
                    <div className="w-6 flex-shrink-0" />
                    {[['Unit',110],['Quantity',80],['Price',90],['Amount',90],['VAT',80],['VAT %',70],['Total Amount',110],['Product group',130],['Department',100],['Object',90],['Series',80],['Center',90],['GL account',110],['VAT Classifier',110]].map(([label, width], index) => <div key={String(label)} className="flex-shrink-0 px-2 font-montserrat text-[12px] font-medium text-[#7288A3]" style={{ width: Number(width) }}>{uiText(label)}{index < 7 ? <span className="ml-0.5 text-[#D64545]">*</span> : null}</div>)}
                  </div>
                  {assignmentLines.map((line, lineIndex) => (
                    <div key={line.id} className={`flex flex-row items-center gap-[2px] rounded-lg p-[5px] ${lineIndex % 2 === 0 ? 'bg-[#F8FDFF]' : 'bg-white'}`}>
                      <div className="flex w-[18px] flex-shrink-0 items-center justify-center font-montserrat text-[12px] font-medium text-[#A1B6C6]">{lineIndex + 1}</div>
                      <div className="w-6 flex-shrink-0" />
                      {[[line.unit,110],[line.qty,80],[line.price,90],[line.subtotal,90],[line.vat,80],[line.vatPct,70],[line.total,110],[line.productGroup,130],[line.department,100],[line.object,90],[line.series,80],[line.center,90],[line.expense,110],[line.vatClass,110]].map(([value, width], index) => <div key={`${line.id}-${index}`} className={`flex h-[26px] flex-shrink-0 items-center rounded border border-[#D3E1EC] px-2 font-montserrat text-[12px] font-medium leading-[18px] bg-[#F7F7F7] text-[#828588]`} style={{ width: Number(width) }}><span className="truncate" title={String(value || '')}>{String(value || '—')}</span></div>)}
                    </div>
                  ))}
                </div>
                </div>
                <HorizontalTableScrollbar scrollRef={tableScrollRef} className="py-2" expandable={false} />
              </section>

              <section aria-label={uiText("Activity history")} className="flex w-full min-w-0 flex-col gap-4 overflow-x-auto pb-2">
                <div className="flex items-center gap-3 pl-3 font-montserrat text-[12px] font-medium leading-[18px] text-[#7288A3]">
                  <span className="w-[158px] text-[#10233A]">{uiText("Date")}</span><span className="h-5 w-px bg-[#D3E1EC]" /><span className="w-[120px]">{uiText("User")}</span><span className="h-5 w-px bg-[#D3E1EC]" /><span className="w-[136px]">{uiText("Action")}</span><span className="h-5 w-px bg-[#D3E1EC]" /><span>{uiText("Details")}</span>
                </div>
                <div className="flex h-9 items-center rounded-lg bg-[#F8FDFF] font-montserrat text-[12px] font-normal leading-[18px] text-[#10233A]">
                  <span className="w-[180px] flex-shrink-0 px-3">{displayUploadedDate(selectedDocument)}</span><div className="flex flex-1 items-center gap-6 px-3"><span className="w-[120px] truncate" title={sourceValue(selectedDocument)}>{sourceValue(selectedDocument)}</span><span className="w-[136px] truncate" title={uiText("Organization identification")}>{uiText("Organization identification")}</span><span>{uiText("Organization assignment is required.")}</span></div>
                </div>
              </section>
            </div>
            </div>
          </section>
        </div>
      </div>
    );
}
