import { ExternalLink } from 'lucide-react';

export function HelpScreenshot({ file, caption, lt }: { file: string; caption: string; lt: boolean }) {
  const src = `${import.meta.env.BASE_URL}help/${file}`;
  return <figure className="my-5 overflow-hidden rounded-lg border border-[#D3E1EC] bg-[#F5F8FB]">
    <a href={src} target="_blank" rel="noopener noreferrer" aria-label={`${caption} · ${lt ? 'Atidaryti didesnį vaizdą' : 'Open larger image'}`}><img src={src} alt={caption} loading="lazy" className="h-auto w-full" /></a>
    <figcaption className="flex items-center justify-between gap-3 px-4 py-3 text-[11px] leading-5 text-[#526B86]"><span>{caption}</span><ExternalLink size={14} className="shrink-0" aria-hidden="true" /></figcaption>
  </figure>;
}
