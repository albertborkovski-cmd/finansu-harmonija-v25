import { translateUi as uiText } from '../i18n/language';
import { isHandwrittenDocument, ocrHandwriting, type HandwritingSource } from '../lib/ocrHandwriting';
import DocumentWarningIndicator from './DocumentWarningIndicator';

export default function HandwrittenDocumentBadge({ document }: { document?: HandwritingSource | null }) {
  return <>
    {isHandwrittenDocument(document) && <span data-ocr-handwritten={ocrHandwriting(document)} className="inline-flex shrink-0"><DocumentWarningIndicator message={uiText('Handwritten')} /></span>}
    {document?.ocr_multiple_documents === true && <span data-ocr-multiple-documents className="inline-flex shrink-0"><DocumentWarningIndicator message={uiText('Multiple documents suspected')} /></span>}
  </>;
}
