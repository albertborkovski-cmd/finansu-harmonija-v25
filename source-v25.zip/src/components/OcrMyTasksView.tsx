import { translateUi as uiText } from '../i18n/language';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { supabase, ensureOcrMyTaskExamples, ensureOcrHandwritingExamples, ensureOcrRecognitionExamples, ensureOcrWorkflowExamples, ensureOcrFormExamples, routeCompletedOcrResults, type Company, type DbDocument } from '../lib/supabase';
import { canEditMenu, canViewMenu } from '../lib/accessControl';
import { canReviewDocumentIssues, documentIssueSession } from '../lib/documentIssueAccess';
import { canEditCompanyDocuments } from '../lib/documentEditAccess';
import { canAccessAssignedOrganization } from '../lib/linkedSettingsData';
import { findSavedReviewDocumentTask, OCR_REVIEW_DOCUMENT_TASK_KEYS } from '../lib/ocrReviewDocuments';
import { myOcrTasks, assignedOcrDocumentIds, requireAssignedOcrTask, ocrTaskTab, type OcrTaskTab, type MyOcrTask } from '../lib/ocrMyTasks';
import { OCR_DOCUMENT_WORK_LOG_KEY, type OcrDocumentWorkLog } from './ocrDocumentWorkTimeStore';
import { WorkspaceDocumentEditor, type WorkspaceTask } from './WorkspaceView';
import { ProcessedDocumentsTable, type ReviewDocumentReference } from './OcrProcessedDocumentsView';
import { PageHeader } from './PageHeader';
import OcrBreadcrumb from './OcrBreadcrumb';
import { belongsToWorker } from '../lib/ocrWorkerHandoff';
import { sortOcrTaskQueue, ocrTaskPriority, ocrTaskWaitingSince } from '../lib/ocrTaskPriority';

const WORKSPACE_TASKS_KEY = 'finansu-harmonija:v12:workspace:review-document-tasks';
const readCollection = <T,>(key: string, forWrite = false): Record<string, T> => {
  try {
    const value = JSON.parse(localStorage.getItem(key) || '{}');
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('Invalid task collection');
    return value;
  } catch {
    if (forWrite) throw new Error('Unable to read the saved tasks. No existing work has been overwritten.');
    return {};
  }
};

export default function OcrMyTasksView() {
  const [rows, setRows] = useState<MyOcrTask[]>([]);
  const [activeTab, setActiveTab] = useState<OcrTaskTab>('Pending');
  const [editing, setEditing] = useState<MyOcrTask | null>(null);
  const [documentQueue, setDocumentQueue] = useState<ReviewDocumentReference[]>([]);
  const [documentIndex, setDocumentIndex] = useState(-1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const opening = useRef(false);
  const load = useCallback(async () => {
    try {
      await ensureOcrMyTaskExamples();
      await ensureOcrHandwritingExamples();
      await ensureOcrRecognitionExamples();
      await ensureOcrWorkflowExamples();
      await ensureOcrFormExamples();
      await ensureOcrFormExamples('parties');
      await ensureOcrFormExamples('accounting');
      await ensureOcrFormExamples('tabs');
      await ensureOcrFormExamples('quality');
      await ensureOcrFormExamples('automation-workflow');
      await routeCompletedOcrResults();
      const [docs, organizations] = await Promise.all([supabase.from('documents').select('*'), supabase.from('companies').select('*')]);
      if (docs.error || organizations.error) throw new Error(docs.error?.message || organizations.error?.message);
      const session = documentIssueSession();
      if (!session || !canViewMenu(session, 'ocr-workspace-my-tasks')) { setRows([]); return []; }
      const allowed = (organizations.data as unknown as Company[] ?? []).filter(company => canAccessAssignedOrganization(company, session));
      const names = new Map(allowed.map(company => [company.id, company.name]));
      const documents = (docs.data as unknown as DbDocument[] ?? []).filter(document => names.has(document.company_id ?? ''));
      const collections = OCR_REVIEW_DOCUMENT_TASK_KEYS.map(key => readCollection<WorkspaceTask>(key));
      const tasks = new Map(documents.flatMap(document => {
        const task = findSavedReviewDocumentTask({ id: document.id, companyId: document.company_id }, collections);
        return task ? [[document.id, task] as const] : [];
      }));
      const workLog = readCollection<OcrDocumentWorkLog[string]>(OCR_DOCUMENT_WORK_LOG_KEY);
      const next = myOcrTasks(documents, names, session.email, tasks, workLog, {
        documents: canViewMenu(session, 'ocr-workspace') || canViewMenu(session, 'ocr-review-approve-documents'),
        issues: canReviewDocumentIssues(),
      }, true);
      setRows(next); setError('');
      return next;
    } catch (reason) { setRows([]); setError(reason instanceof Error ? reason.message : 'Unable to load your tasks.'); return []; }
    finally { setLoading(false); }
  }, []);
  useEffect(() => {
    void load();
    const refresh = () => { void load(); };
    const events = ['storage', 'finansu-harmonija:persistent-state-changed', 'finansu-harmonija:data-changed', 'finansu-harmonija:settings-data-changed', 'document-issues-changed'];
    events.forEach(event => window.addEventListener(event, refresh));
    return () => events.forEach(event => window.removeEventListener(event, refresh));
  }, [load]);
  const tabs: OcrTaskTab[] = ['Pending', 'In progress', 'Completed'];
  const documentIds = useMemo(() => assignedOcrDocumentIds(rows.filter(row => ocrTaskTab(row) === activeTab)), [rows, activeTab]);
  const requireEditAccess = async (task: MyOcrTask) => {
    const session = documentIssueSession();
    if (!session || !canViewMenu(session, 'ocr-workspace-my-tasks')) throw new Error('You no longer have access to My tasks.');
    if (task.issue) {
      const result = await supabase.from('companies').select('*').eq('id', task.document.company_id);
      const company = (result.data as unknown as Company[] | null)?.[0];
      if (result.error || !company || !canAccessAssignedOrganization(company, session) || !canReviewDocumentIssues() || !canEditCompanyDocuments(company))
        throw new Error('You no longer have Edit access to this task.');
    } else if (!canEditMenu(session, 'ocr-workspace') && !canEditMenu(session, 'ocr-review-approve-documents')) {
      throw new Error('You no longer have Edit access to this task.');
    }
  };
  const open = async (document: ReviewDocumentReference, index: number, queue: ReviewDocumentReference[]) => {
    if (opening.current) return;
    opening.current = true;
    try {
      const current = requireAssignedOcrTask(await load(), document);
      if (ocrTaskTab(current) !== 'Completed') await requireEditAccess(current);
      setDocumentQueue(queue); setDocumentIndex(index); setEditing(current);
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Unable to open task.'); }
    finally { opening.current = false; }
  };
  const close = () => { setEditing(null); setDocumentQueue([]); setDocumentIndex(-1); void load(); };
  const openNextFile = async () => {
    const currentTasks = await load();
    const email = editing?.savedTask?.assignedToEmail || editing?.cells.assignedToEmail || documentIssueSession()?.email || '';
    const candidates = sortOcrTaskQueue(currentTasks.filter(task => ocrTaskTab(task) !== 'Completed' && task.document.id !== editing?.document.id && belongsToWorker(task, email))
      .map(task => ({ ...task, priority: ocrTaskPriority(task.savedTask?.priority), waitingSince: ocrTaskWaitingSince(task.document, task.savedTask) })));
    for (const task of candidates) {
      try { await requireEditAccess(task); }
      catch { continue; }
      const queue = candidates.map(item => ({ id: item.document.id, companyId: item.document.company_id, name: item.document.file_case || item.document.number }));
      setDocumentQueue(queue); setDocumentIndex(candidates.indexOf(task)); setEditing(task); return;
    }
    close();
  };
  if (editing) return <WorkspaceDocumentEditor key={editing.document.id}
    readOnly={ocrTaskTab(editing) === 'Completed'}
    documentName={editing.document.file_case || editing.document.number} documentId={editing.document.id} companyId={editing.document.company_id}
    savedTask={editing.savedTask} filePosition={documentIndex + 1} fileTotal={documentQueue.length} onBack={close}
    reportedIssueId={editing.issue?.id} onIssueFixed={close}
    onSave={task => {
      const tasks = readCollection<WorkspaceTask>(WORKSPACE_TASKS_KEY, true);
      localStorage.setItem(WORKSPACE_TASKS_KEY, JSON.stringify({ ...tasks, [editing.document.id]: task }));
      window.dispatchEvent(new CustomEvent('finansu-harmonija:persistent-state-changed', { detail: { storageKey: WORKSPACE_TASKS_KEY } }));
    }}
    onNextFile={openNextFile} />;
  return <div className="relative flex min-h-full min-w-0 flex-col gap-8 bg-white px-4 py-14 sm:px-8 lg:px-[72px]">
    <PageHeader title={uiText("My tasks")} />
    <OcrBreadcrumb items={['Workspace', 'My tasks']} />
    {error && <p role="alert" className="rounded-lg bg-[#FFF0F0] px-3 py-2 text-sm text-[#B42318]">{error}</p>}
    <div role="tablist" aria-label={uiText('Task status')} className="flex min-w-0 gap-5 border-b border-[#D3E1EC]">
      {tabs.map((tab, index) => <button key={tab} type="button" role="tab" aria-selected={activeTab === tab}
        tabIndex={activeTab === tab ? 0 : -1} onClick={() => setActiveTab(tab)}
        onKeyDown={event => {
          const next = event.key === 'ArrowRight' ? (index + 1) % tabs.length : event.key === 'ArrowLeft' ? (index + tabs.length - 1) % tabs.length : event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length - 1 : -1;
          if (next < 0) return;
          event.preventDefault(); setActiveTab(tabs[next]);
          (event.currentTarget.parentElement?.children[next] as HTMLButtonElement)?.focus();
        }}
        className={`border-b-2 px-1 py-3 font-montserrat text-[13px] font-semibold ${activeTab === tab ? 'border-[#007EA7] text-[#007EA7]' : 'border-transparent text-[#7288A3] hover:text-[#007EA7]'}`}>
        {uiText(tab)}<span className="ml-2 text-[11px] tabular-nums">{rows.filter(row => ocrTaskTab(row) === tab).length}</span>
      </button>)}
    </div>
    <ProcessedDocumentsTable embedded showAllDocuments processingQueue documentIds={documentIds}
      taskStatusOverride={activeTab}
      onRefreshDocuments={load}
      onEditDocument={activeTab === 'Completed' ? undefined : (document, index, queue) => void open(document, index, queue)}
      onViewDocument={activeTab === 'Completed' ? (document, index, queue) => void open(document, index, queue) : undefined}
      emptyMessage={loading ? uiText('Loading your tasks…') : uiText('No tasks in this status.')} />
  </div>;
}
