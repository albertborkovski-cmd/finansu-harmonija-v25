import { useCallback, useEffect, useRef, useState } from 'react';
import { AlertTriangle } from 'lucide-react';
import { translateUi as uiText } from '../i18n/language';
import { documentWasApproved } from '../lib/documentInlineEditing';
import GlJournalDialog from './GlJournalDialog';
import { PageActionButton } from './PageHeader';

export function ApprovedDocumentEditWarning() {
  return <div role="status" className="flex items-start gap-2 rounded-lg border border-[#EEB648] bg-[#FFF4DC] px-4 py-3 font-montserrat text-[12px] leading-5 text-[#926317]">
    <AlertTriangle size={17} className="mt-0.5 shrink-0" />
    <div><p className="font-semibold">{uiText('This document has already been approved.')}</p>
      <p>{uiText('You can edit the document. Changes are recorded in its history; existing GL postings and data already sent to an accounting system are not changed automatically.')}</p></div>
  </div>;
}

/** One confirmation per inline save; cancelling/unmounting performs no write. */
export function useApprovedDocumentEditWarning() {
  const [label, setLabel] = useState<string | null>(null);
  const pending = useRef<((accepted: boolean) => void) | null>(null);
  const finish = useCallback((accepted: boolean) => {
    const resolve = pending.current; pending.current = null;
    setLabel(null); resolve?.(accepted);
  }, []);
  useEffect(() => () => { pending.current?.(false); pending.current = null; }, []);
  const confirm = useCallback((document: Record<string, unknown>) => {
    if (!documentWasApproved(document)) return Promise.resolve(true);
    pending.current?.(false);
    setLabel(String(document.number || document.file_case || document.id || ''));
    return new Promise<boolean>(resolve => { pending.current = resolve; });
  }, []);
  const dialog = label !== null ? <GlJournalDialog title="Edit approved document" subtitle={label} overlayZIndex={6500}
    onClose={() => finish(false)} footer={<><PageActionButton onClick={() => finish(false)}>{uiText('Cancel')}</PageActionButton>
      <PageActionButton onClick={() => finish(true)}>{uiText('Save changes')}</PageActionButton></>}>
    <ApprovedDocumentEditWarning />
  </GlJournalDialog> : null;
  return { confirm, dialog };
}
