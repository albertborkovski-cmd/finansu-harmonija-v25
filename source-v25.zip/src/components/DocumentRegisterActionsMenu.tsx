import { useEffect, useId, useRef, useState } from 'react';
import { AlertCircle, CheckCheck, FileX2, Loader2, MoreHorizontal } from 'lucide-react';
import { translateUi as t } from '../i18n/language';
import DropdownPortal from './DropdownPortal';
import { useDropdownDismiss } from './useDropdownDismiss';

type Props = {
  documentLabel: string;
  disabled: boolean;
  canEdit: boolean;
  excluded: boolean;
  exported: boolean;
  issueBlocksExport: boolean;
  onExportAction: (action: 'exclude' | 'exported') => Promise<void>;
  onReportIssue: () => void;
  onError: (message: string) => void;
};

/** Global OCR document register only; accounting-document actions stay separate. */
export default function DocumentRegisterActionsMenu({ documentLabel, disabled, canEdit, excluded, exported, issueBlocksExport, onExportAction, onReportIssue, onError }: Props) {
  const [open, setOpen] = useState(false), [busy, setBusy] = useState(false);
  const anchor = useRef<HTMLButtonElement>(null), menu = useRef<HTMLDivElement>(null);
  const pending = useRef(false), focusLast = useRef(false), id = useId();
  const close = () => {
    if (menu.current?.contains(document.activeElement)) anchor.current?.focus();
    setOpen(false);
  };
  useDropdownDismiss(open, anchor, close, menu);
  useEffect(() => { if (disabled) setOpen(false); }, [disabled]);
  useEffect(() => {
    if (!open) return;
    const frame = requestAnimationFrame(() => {
      const items = menu.current?.querySelectorAll<HTMLButtonElement>('[role="menuitem"]:not(:disabled)');
      (focusLast.current ? items?.[items.length - 1] : items?.[0])?.focus();
    });
    return () => cancelAnimationFrame(frame);
  }, [open]);
  const run = async (action: 'exclude' | 'exported') => {
    if (pending.current || disabled || !canEdit || (action === 'exclude' ? excluded : exported || issueBlocksExport)) return;
    pending.current = true; setBusy(true); close(); onError('');
    try { await onExportAction(action); }
    catch (cause) { onError(cause instanceof Error ? cause.message : 'Could not update the document export mark.'); }
    finally { pending.current = false; setBusy(false); }
  };
  const rowClass = 'flex min-h-9 w-full items-center gap-2.5 rounded-md px-3 py-2 text-left text-[12px] font-medium leading-[18px] text-[#10233A] hover:bg-[#E5EDF9] focus:bg-[#E5EDF9] focus:outline-none disabled:cursor-not-allowed disabled:text-[#A1B6C6]';
  return <>
    <button ref={anchor} type="button" title={t('More actions')} aria-label={`${t('More actions')}: ${documentLabel}`} aria-haspopup="menu" aria-expanded={open} aria-controls={open ? id : undefined}
      disabled={disabled || busy} data-document-register-actions="true"
      onClick={event => { event.stopPropagation(); focusLast.current = false; setOpen(value => !value); }}
      onKeyDown={event => {
        if (['ArrowDown', 'ArrowUp'].includes(event.key)) { event.preventDefault(); focusLast.current = event.key === 'ArrowUp'; setOpen(true); }
      }}
      className="flex h-7 w-7 shrink-0 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] transition-colors hover:border-[#007EA7] hover:text-[#007EA7] disabled:cursor-not-allowed disabled:opacity-40">
      {busy ? <Loader2 size={14} className="animate-spin" /> : <MoreHorizontal size={16} />}
    </button>
    {open && <DropdownPortal anchorRef={anchor} menuRef={menu} role="menu" ariaLabel={t('Document actions')} id={id} align="end" width={296} height={164} zIndex={5300}
      onKeyDown={event => {
        if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); close(); return; }
        if (event.key === 'Tab') { setOpen(false); return; }
        if (!['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) return;
        event.preventDefault();
        const items = [...(menu.current?.querySelectorAll<HTMLButtonElement>('[role="menuitem"]:not(:disabled)') || [])];
        if (!items.length) return;
        const current = items.indexOf(document.activeElement as HTMLButtonElement);
        const next = event.key === 'Home' ? 0 : event.key === 'End' ? items.length - 1 : (current + (event.key === 'ArrowUp' ? -1 : 1) + items.length) % items.length;
        items[next]?.focus();
      }}>
      <div className="min-h-0 overflow-y-auto font-montserrat">
        <button type="button" role="menuitem" className={rowClass} disabled={!canEdit || excluded} onClick={() => void run('exclude')}><FileX2 size={16} className="shrink-0 text-[#7288A3]" />{t('Exclude document from export')}</button>
        <span className="block" title={issueBlocksExport ? t('Resolve the reported digitization issue before marking this document as exported.') : undefined}>
          <button type="button" role="menuitem" className={rowClass} disabled={!canEdit || exported || issueBlocksExport} onClick={() => void run('exported')}><CheckCheck size={16} className="shrink-0 text-[#7288A3]" />{t('Mark as exported')}</button>
        </span>
        <button type="button" role="menuitem" className={rowClass} onClick={() => { close(); onReportIssue(); }}><AlertCircle size={16} className="shrink-0 text-[#7288A3]" />{t('Report issue')}</button>
      </div>
    </DropdownPortal>}
  </>;
}
