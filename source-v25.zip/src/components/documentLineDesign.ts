/** Compact form-row geometry shared by Documents → Edit and Create invoice.
 * These are form rows, not register-table headings with resize separators. */
export const documentLineRowClass = 'flex flex-row items-center gap-[2px] rounded-lg p-[5px]';
export const documentLineHeaderClass = 'flex flex-row items-center gap-[2px] p-[5px]';
export const documentLineInputClass = 'h-[26px] min-w-0 rounded border border-[#D3E1EC] bg-white px-2 py-1 font-montserrat text-[12px] font-medium leading-[18px] text-[#10233A] outline-none transition-colors focus:border-[#007EA7]';
export type DocumentLineColumn = { key: string; label: string; w: number; required?: boolean };
export const documentSummaryColumns: DocumentLineColumn[] = [
  { key: 'unit', label: 'Unit', w: 110, required: true },
  { key: 'qty', label: 'Quantity', w: 80, required: true },
  { key: 'price', label: 'Price', w: 90, required: true },
  { key: 'subtotal', label: 'Amount', w: 90, required: true },
  { key: 'vat', label: 'VAT', w: 80, required: true },
  { key: 'vatPct', label: 'VAT %', w: 70, required: true },
  { key: 'total', label: 'Total Amount', w: 110, required: true },
  { key: 'productGroup', label: 'Product group', w: 130 },
  { key: 'department', label: 'Department', w: 100 },
  { key: 'object', label: 'Object', w: 90 },
  { key: 'series', label: 'Series', w: 80 },
  { key: 'center', label: 'Center', w: 90 },
  { key: 'expense', label: 'GL account', w: 110 },
  { key: 'vatClass', label: 'VAT Classifier', w: 110 },
];
export const documentQuantityColumns: DocumentLineColumn[] = [
  { key: 'barcode', label: 'Barcode', w: 100 },
  { key: 'systemId', label: 'System ID', w: 110 },
  { key: 'product', label: 'Product', w: 140, required: true },
  { key: 'productGroup', label: 'Product group', w: 130 },
  { key: 'unit', label: 'Unit of measure', w: 110, required: true },
  { key: 'qty', label: 'Quantity', w: 80, required: true },
  { key: 'price', label: 'Price', w: 90, required: true },
  { key: 'subtotal', label: 'Amount', w: 90, required: true },
  { key: 'discount', label: 'Discount', w: 90, required: true },
  { key: 'vat', label: 'VAT', w: 80, required: true },
  { key: 'vatPct', label: 'VAT %', w: 70, required: true },
  { key: 'total', label: 'Total Amount', w: 110, required: true },
  { key: 'code', label: 'Document Number', w: 120 },
  ...documentSummaryColumns.slice(8),
];
