import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { ArrowLeft, ExternalLink, FileText, MailCheck, Printer, Send, X } from 'lucide-react';
import type { Company } from '../lib/supabase';
import type { DebtRow } from '../lib/companyRelatedObjectData';
import { getLanguage, translateUi as uiText } from '../i18n/language';
import { buildBalanceStatements, balancePortalUrl, saveBalancePreview, type BalanceStatement } from '../lib/balanceConfirmation';
import { loadOrganizationCounterparties } from '../lib/organizationReferenceLists';
import { appendOrganizationEmailHistoryBatch, debtEmailTemplates, loadOrganizationEmailTemplates, renderOrganizationEmailTemplate, type OrganizationEmailHistoryEntry } from '../lib/organizationEmail';
import { parseReconciliationState } from '../lib/reconciliation';
import { reconciliationStorageKey } from '../lib/reconciliationJournal';
import SearchableSelect from './SearchableSelect';
import { PageActionButton } from './PageHeader';
import BalanceStatementDocument, { balanceMoney } from './BalanceStatementDocument';

const input = 'h-10 w-full rounded-md border border-[#D3E1EC] bg-white px-3 text-[13px] text-[#10233A] outline-none focus:border-[#007EA7]';
const check = 'h-[18px] w-[18px] shrink-0 accent-[#007EA7]';
function Field({ label, children }: { label: string; children: ReactNode }) { return <label className="flex min-w-0 flex-col gap-1.5 text-xs font-medium text-[#536B85]"><span>{label}</span>{children}</label>; }

export default function BalanceConfirmationDialog({ company, rows, canSend, onClose, onSaved }: { company: Company; rows: DebtRow[]; canSend: () => boolean; onClose: () => void; onSaved: () => void }) {
  const lt = getLanguage() === 'lt', t = (en: string, translated: string) => lt ? translated : en;
  const today = new Date().toLocaleDateString('en-CA');
  const [date, setDate] = useState(today), [from, setFrom] = useState(`${today.slice(0, 4)}-01-01`), [to, setTo] = useState(today);
  const [language, setLanguage] = useState<'LT' | 'EN'>(lt ? 'LT' : 'EN');
  const templates = useMemo(() => debtEmailTemplates(loadOrganizationEmailTemplates(company.id), 'balance-confirmation', language).filter(item => item.language.toUpperCase() === language), [company.id, language]);
  const [templateId, setTemplateId] = useState('');
  const template = templates.find(item => item.id === templateId) || templates[0];
  const [customMessage, setCustomMessage] = useState<string | null>(null);
  const [emails, setEmails] = useState<Record<string, string>>({}), [excluded, setExcluded] = useState<Set<string>>(new Set());
  const [attach, setAttach] = useState(true), [preview, setPreview] = useState<string | null>(null), [error, setError] = useState(''), [busy, setBusy] = useState(false);
  const [tokenPrefix] = useState(() => crypto.randomUUID());
  const dialogRef = useRef<HTMLDivElement>(null);
  const contacts = useMemo(() => loadOrganizationCounterparties(company.id), [company.id]);
  const calculation = useMemo(() => {
    try {
      const raw = localStorage.getItem(reconciliationStorageKey(company.id));
      return { statements: buildBalanceStatements(rows, company, contacts, { date, from, to, language }, raw ? parseReconciliationState(raw, company.id) : null).map((statement, index) => ({ ...statement, id: `${tokenPrefix}-${index}` })), error: '' };
    } catch (cause) { return { statements: [] as BalanceStatement[], error: cause instanceof Error ? cause.message : 'Could not prepare the statements.' }; }
  }, [rows, company, contacts, date, from, to, language, tokenPrefix]);
  const statements = calculation.statements.map(statement => ({ ...statement, recipient: { ...statement.recipient, email: emails[statement.id] ?? statement.recipient.email } }));
  const selected = statements.filter(statement => !excluded.has(statement.id));
  const previewStatement = statements.find(statement => statement.id === preview);
  const message = customMessage ?? `${template?.body || ''}\n\n${language === 'LT' ? 'Patvirtinti arba patikslinti likutį' : 'Balance confirmation link'}: {{balanceConfirmationLink}}\n${language === 'LT' ? 'Įkelti trūkstamus dokumentus' : 'Upload missing documents link'}: {{uploadMissingDocumentsLink}}`;
  useEffect(() => {
    const prior = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    dialogRef.current?.focus();
    const key = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && !event.defaultPrevented && !document.querySelector('[data-system-dropdown-portal]')) { event.preventDefault(); onClose(); }
      if (event.key === 'Tab') {
        const nodes = dialogRef.current?.querySelectorAll<HTMLElement>('button:not(:disabled),input:not(:disabled),textarea,a[href],[tabindex="0"]');
        if (!nodes?.length) return;
        if (event.shiftKey && document.activeElement === nodes[0]) { event.preventDefault(); nodes[nodes.length - 1].focus(); }
        else if (!event.shiftKey && document.activeElement === nodes[nodes.length - 1]) { event.preventDefault(); nodes[0].focus(); }
      }
    };
    document.addEventListener('keydown', key);
    return () => { document.removeEventListener('keydown', key); prior?.focus(); };
  }, [onClose]);
  const openPortal = (statement: BalanceStatement, upload = false) => { try { saveBalancePreview(statement); window.open(balancePortalUrl(statement.id, upload), '_blank', 'noopener,noreferrer'); } catch { setError(t('The preview could not be saved.', 'Nepavyko išsaugoti peržiūros.')); } };
  const send = () => {
    setError('');
    if (!canSend()) { setError(uiText('You do not have permission to send debt messages.')); return; }
    if (!selected.length || calculation.error || !template || !message.trim()) { setError(t('Select recipients and complete the required fields.', 'Pasirinkite gavėjus ir užpildykite privalomus laukus.')); return; }
    if (selected.some(statement => !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(statement.recipient.email.trim()))) { setError(uiText('Enter a valid recipient email.')); return; }
    setBusy(true);
    try {
      const entries = selected.map((statement): OrganizationEmailHistoryEntry => {
        saveBalancePreview(statement);
        const data = { sender: company.name, recipient: statement.recipient.name, reconciliationDate: date, debtBalance: balanceMoney(statement.closing, statement.currency), portalUrl: balancePortalUrl(statement.id), documentReference: rows.filter(row => statement.debtIds.includes(row.id)).map(row => row.documentReference).join(', ') };
        let body = renderOrganizationEmailTemplate(message, data).replaceAll('{{balanceConfirmationLink}}', data.portalUrl).replaceAll('{{uploadMissingDocumentsLink}}', balancePortalUrl(statement.id, true));
        if (!body.includes(data.portalUrl)) body += `\n\nBalance confirmation link: ${data.portalUrl}`;
        if (!body.includes(balancePortalUrl(statement.id, true))) body += `\nUpload missing documents link: ${balancePortalUrl(statement.id, true)}`;
        return { id: statement.id, organizationId: company.id, sentAt: new Date().toISOString(), sender: company.name, senderEmail: company.email, senderDetails: { name: company.name, companyCode: company.company_code, vatCode: company.vat_code, address: company.address }, recipient: statement.recipient.name, recipientEmail: statement.recipient.email.trim(), recipientDetails: { name: statement.recipient.name, companyCode: statement.recipient.code, vatCode: statement.recipient.vatCode, address: statement.recipient.address }, templateName: template.name, language, subject: renderOrganizationEmailTemplate(template.subject, data), body, reconciliationDate: date, debtBalance: data.debtBalance, portalUrl: data.portalUrl, documentReference: data.documentReference, purpose: 'balance-confirmation', relatedDebtIds: statement.debtIds, deliveryStatus: 'saved', balanceStatement: statement, attachBalancePdf: attach };
      });
      appendOrganizationEmailHistoryBatch(entries);
      onSaved();
    } catch { setError(t('Could not save the confirmation. Please try again.', 'Nepavyko išsaugoti suderinimo. Bandykite dar kartą.')); }
    finally { setBusy(false); }
  };
  return createPortal(<div className="balance-dialog-backdrop fixed inset-0 z-[5400] flex items-center justify-center bg-[#10233A]/30 p-3 sm:p-6"><div ref={dialogRef} tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby="balance-dialog-title" className={`balance-dialog flex max-h-[94dvh] w-full flex-col overflow-hidden rounded-xl border border-[#D3E1EC] bg-white font-montserrat text-[#10233A] shadow-xl outline-none ${previewStatement ? 'max-w-[980px]' : 'max-w-[860px]'}`}>
    <header className="balance-no-print flex shrink-0 items-center gap-3 border-b border-[#E5EDF9] px-6 py-4"><span className="rounded-lg bg-[#E5EDF9] p-2.5 text-[#007EA7]"><MailCheck size={21} /></span><div className="min-w-0 flex-1"><h2 id="balance-dialog-title" className="text-lg font-semibold">{previewStatement ? t('PDF preview', 'PDF peržiūra') : uiText('Send balance confirmation')}</h2><p className="mt-1 text-xs text-[#7288A3]">{t('A separate statement for each counterparty and currency.', 'Atskiras aktas kiekvienam kontrahentui ir valiutai.')}</p></div><PageActionButton iconOnly ariaLabel={uiText('Close')} icon={<X size={18} />} onClick={onClose}>{uiText('Close')}</PageActionButton></header>
    <div className="balance-dialog-content min-h-0 overflow-y-auto p-6">
      {previewStatement ? <BalanceStatementDocument statement={previewStatement} /> : <div className="space-y-5">
        <div className="grid gap-4 sm:grid-cols-3"><Field label={`${t('Confirmation date', 'Suderinimo data')} *`}><input type="date" value={date} onChange={e => setDate(e.target.value)} className={input} /></Field><Field label={`${t('Period from', 'Laikotarpis nuo')} *`}><input type="date" value={from} onChange={e => setFrom(e.target.value)} className={input} /></Field><Field label={`${t('Period to', 'Laikotarpis iki')} *`}><input type="date" value={to} onChange={e => setTo(e.target.value)} className={input} /></Field></div>
        <div className="grid gap-4 sm:grid-cols-[180px_1fr]"><Field label={uiText('Language')}><SearchableSelect ariaLabel={uiText('Language')} value={language} onChange={v => { setLanguage(v as 'LT' | 'EN'); setTemplateId(''); setCustomMessage(null); }} options={[{ value: 'LT', label: 'Lietuvių (LT)' }, { value: 'EN', label: 'English (EN)' }]} className={input} /></Field><Field label={uiText('Email template')}><SearchableSelect ariaLabel={uiText('Email template')} value={template?.id || ''} onChange={v => { setTemplateId(v); setCustomMessage(null); }} options={templates.map(item => ({ value: item.id, label: item.name }))} className={input} /></Field></div>
        <Field label={`${uiText('Message')} *`}><textarea rows={8} value={message} onChange={e => setCustomMessage(e.target.value)} className={`${input} !h-auto resize-y py-3 leading-5`} /></Field>
        <div className="flex flex-wrap gap-4 text-xs"><button type="button" disabled={!selected.length} className="text-[#007EA7] underline disabled:text-[#A1B6C6]" onClick={() => openPortal(selected[0])}>{t('Balance confirmation link · Preview', 'Likučio patvirtinimo nuoroda · Peržiūra')} <ExternalLink className="inline" size={12} /></button><button type="button" disabled={!selected.length} className="text-[#007EA7] underline disabled:text-[#A1B6C6]" onClick={() => openPortal(selected[0], true)}>{t('Upload missing documents link', 'Trūkstamų dokumentų įkėlimo nuoroda')}</button></div>
        <section><h3 className="mb-3 text-sm font-semibold">{t('Selected counterparties', 'Pasirinkti kontrahentai')} ({selected.length})</h3><div className="overflow-x-auto rounded-lg border border-[#D3E1EC]"><table className="w-full min-w-[650px] text-xs"><thead className="bg-[#F1F6FA] text-left text-[#536B85]"><tr><th className="p-3"><input type="checkbox" className={check} aria-label={t('Select all counterparties', 'Pasirinkti visus kontrahentus')} checked={statements.length > 0 && selected.length === statements.length} onChange={e => setExcluded(e.target.checked ? new Set() : new Set(statements.map(s => s.id)))} /></th>{[uiText('Counterparty'), uiText('Recipient (email)'), uiText('Outstanding balance'), 'PDF'].map(label => <th className="p-3 font-medium" key={label}>{label}</th>)}</tr></thead><tbody>{statements.map(statement => <tr key={statement.id} className="border-t border-[#E5EDF9]"><td className="p-3"><input type="checkbox" className={check} aria-label={statement.recipient.name} checked={!excluded.has(statement.id)} onChange={() => setExcluded(old => { const next = new Set(old); if (next.has(statement.id)) next.delete(statement.id); else next.add(statement.id); return next; })} /></td><td className="p-3 font-medium">{statement.recipient.name}</td><td className="p-2"><input type="email" aria-label={`${uiText('Recipient (email)')} · ${statement.recipient.name}`} value={statement.recipient.email} onChange={e => setEmails(old => ({ ...old, [statement.id]: e.target.value }))} className={input} /></td><td className="whitespace-nowrap p-3 text-right font-semibold tabular-nums">{balanceMoney(statement.closing, statement.currency)}</td><td className="p-3"><PageActionButton iconOnly icon={<FileText size={16} />} ariaLabel={`${t('Preview PDF', 'Peržiūrėti PDF')} · ${statement.recipient.name}`} onClick={() => { saveBalancePreview(statement); setPreview(statement.id); }}>{t('Preview PDF', 'Peržiūrėti PDF')}</PageActionButton></td></tr>)}</tbody></table></div></section>
        <div className="flex flex-wrap items-center gap-5"><label className="flex items-center gap-2 text-xs"><input type="checkbox" checked={attach} onChange={e => setAttach(e.target.checked)} className={check} />{t('Attach balance confirmation PDF', 'Pridėti skolų suderinimo akto PDF')}</label><button type="button" disabled={!selected.length} className="flex items-center gap-1.5 text-xs font-semibold text-[#007EA7] underline" onClick={() => { saveBalancePreview(selected[0]); setPreview(selected[0].id); }}><FileText size={16} />{t('Preview PDF', 'Peržiūrėti PDF')}</button></div>
        <p className="text-xs leading-5 text-[#7288A3]">{t('Preview: Send saves the prepared messages locally. Email delivery and public links require a connected server.', 'Peržiūra: „Siųsti“ išsaugo paruoštus laiškus vietoje. Laiškų siuntimui ir viešoms nuorodoms reikia prijungto serverio.')}</p>
      </div>}
      {(error || calculation.error) && <p role="alert" className="mt-4 rounded-md bg-[#FFF1F0] p-3 text-xs text-[#B42318]">{uiText(error || calculation.error)}</p>}
    </div>
    <footer className="balance-no-print flex shrink-0 items-center justify-end gap-2 border-t border-[#E5EDF9] px-6 py-4">{previewStatement ? <><PageActionButton icon={<ArrowLeft size={15} />} onClick={() => setPreview(null)}>{uiText('Back')}</PageActionButton><PageActionButton icon={<Printer size={15} />} onClick={() => window.print()}>{t('Print / PDF', 'Spausdinti / PDF')}</PageActionButton></> : <><PageActionButton onClick={onClose}>{uiText('Cancel')}</PageActionButton><PageActionButton icon={<Send size={15} />} disabled={busy || !selected.length || Boolean(calculation.error)} onClick={send}>{uiText('Send')}</PageActionButton></>}</footer>
  </div></div>, document.body);
}
