import { AlertCircle } from 'lucide-react';

/** One fixed icon slot with the shared Profile settings tooltip and accessible cause. */
export default function DocumentWarningIndicator({ message, error = false }: { message: string; error?: boolean }) {
  return <span role="img" tabIndex={0} data-tooltip={message} aria-label={message}
    className="inline-flex h-5 w-5 shrink-0 items-center justify-center rounded focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#007EA7]">
    {error ? <AlertCircle size={17} strokeWidth={2.4} className="text-[#D64545]" aria-hidden="true" />
      : <svg width="18" height="18" viewBox="0 0 20 20" aria-hidden="true"><path d="M8.3 2.8a1.95 1.95 0 0 1 3.4 0l7 12.2a1.95 1.95 0 0 1-1.7 2.9H3a1.95 1.95 0 0 1-1.7-2.9Z" fill="#D99420" /><path d="M10 6.8v4.8" stroke="white" strokeWidth="1.9" strokeLinecap="round" /><circle cx="10" cy="14.4" r="1" fill="white" /></svg>}
  </span>;
}
