import { translateUi as uiText } from '../i18n/language';
import { isHandwrittenDocument, type DocumentStructureDecision, type HandwritingSource } from '../lib/ocrHandwriting';
import DocumentWarningIndicator from './DocumentWarningIndicator';

export default function OcrRecognitionWarnings({ document, decision, onChange, onSave, onNavigate, busy = false }: {
  document?: HandwritingSource; decision?: DocumentStructureDecision;
  onChange?: (choice: 'single' | 'split') => void; onSave?: () => void; busy?: boolean;
  onNavigate?: () => void;
}) {
  const description = (text: string) => onNavigate
    ? <button type="button" onClick={onNavigate} className="rounded-sm text-left underline decoration-dotted underline-offset-2 hover:decoration-solid">{uiText(text)}</button>
    : uiText(text);
  const multiple = document?.ocr_multiple_documents === true;
  if (!multiple && !isHandwrittenDocument(document) && !document?.ocr_poor_quality && !document?.ocr_quality_review_required) return null;
  return <div data-ocr-recognition-warnings className="space-y-3 text-[12px] leading-5">
    {document?.ocr_poor_quality === true && <div className="rounded-md border border-[#F0D58A] bg-[#FFFAEB] px-3 py-2 text-[#9A6700]">
      <p className="flex items-center gap-2 font-semibold"><DocumentWarningIndicator message={uiText('Poor document quality')} />{description('Poor document quality')}</p>
      <p className="mt-1 pl-6">{description('Check readability and compare extracted values with the original. Request a clearer document if needed.')}</p>
    </div>}
    {document?.ocr_quality_review_required === true && <div className="rounded-md border border-[#F0D58A] bg-[#FFFAEB] px-3 py-2 text-[#9A6700]">
      <p className="flex items-center gap-2 font-semibold"><DocumentWarningIndicator message={uiText('Quality review required')} />{description('Quality review required')}</p>
      <p className="mt-1 pl-6">{description('This document is assigned for quality review even when automatic validations find no errors. Review all pages and extracted values before completion.')}</p>
    </div>}
    {isHandwrittenDocument(document) && <p className="flex items-center gap-2 text-[#9A6700]"><DocumentWarningIndicator message={uiText('Handwritten')} />{description('Handwritten document detected')}</p>}
    {multiple && <>
      <p className="flex items-start gap-2 text-[#9A6700]"><DocumentWarningIndicator message={uiText('Multiple documents suspected')} />{description('Multiple documents suspected. Please review all pages.')}</p>
      {onChange && <fieldset disabled={busy} className="flex flex-wrap items-center gap-x-5 gap-y-2">
        <legend className="sr-only">{uiText('Document structure')}</legend>
        {([{ value: 'single', label: 'Single document' }, { value: 'split', label: 'Split documents' }] as const).map(option => <label key={option.value} className="flex cursor-pointer items-center gap-2 text-[#10233A]">
          <input type="radio" name="ocr-document-structure" value={option.value} checked={decision?.choice === option.value} onChange={() => onChange(option.value)} className="h-4 w-4 accent-[#007EA7]" />{uiText(option.label)}
        </label>)}
        {onSave && <button type="button" disabled={!decision || busy} onClick={onSave} className="rounded-md border border-[#D3E1EC] bg-white px-3 py-1.5 font-semibold text-[#007EA7] disabled:opacity-50">{uiText(busy ? 'Saving…' : 'Save decision')}</button>}
      </fieldset>}
      {decision?.choice === 'split' && <p className="text-[#7288A3]">{uiText('Assign PDF pages to separate documents in the splitting window.')}</p>}
      {decision?.choice === 'single' && <p className="text-[#7288A3]">{uiText('Reviewed as a single document. The original OCR warning remains in the history.')}</p>}
    </>}
  </div>;
}
