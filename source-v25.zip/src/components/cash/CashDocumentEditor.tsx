import { translateUi as uiText } from '../../i18n/language';
import { useState } from 'react';
import { Plus, Printer, Trash2 } from 'lucide-react';
import { cashAmount, cashCorrespondences, cashId, cashMinor, cashTotal, type CashDocument, type CashLine, type CashStore } from '../../lib/cash';
import { cashDocumentReport } from '../../lib/cashPrint';
import CashPrintPreview from './CashPrintPreview';
import GlJournalDialog from '../GlJournalDialog';
import SearchableSelect, { type SearchableSelectOption } from '../SearchableSelect';
import { PageActionButton } from '../PageHeader';
import { CashField, CashSection, CashStatus, cashInput } from './CashControls';

export type CashRelatedDocument = { id: string; number: string; label: string; currency: string; counterparty: string };
export default function CashDocumentEditor({ initial, store, companyName, readOnly, glAccounts, counterparties, relatedDocuments, onSave, onClose }: {
  initial: CashDocument; store: CashStore; companyName: string; readOnly: boolean;
  glAccounts: SearchableSelectOption[]; counterparties: string[]; relatedDocuments: CashRelatedDocument[];
  onSave: (document: CashDocument, approve: boolean) => void; onClose: () => void;
}) {
  const [draft, setDraft] = useState(() => structuredClone(initial));
  const [amounts, setAmounts] = useState<Record<string, string>>(() => Object.fromEntries(initial.lines.map(line => [line.id, line.amountMinor ? cashAmount(line.amountMinor) : ''])));
  const [error, setError] = useState('');
  const [manualParty, setManualParty] = useState(false);
  const [printPreview, setPrintPreview] = useState(false);
  const account = store.accounts.find(row => row.id === draft.accountId);
  const isNew = !initial.number;
  const locked = readOnly || initial.status === 'Approved' || initial.inactive;
  const activeAccounts = store.accounts.filter(row => !row.inactive || row.id === draft.accountId).map(row => ({ value: row.id, label: `${row.code} · ${row.name} · ${row.currency}`, disabled: row.inactive }));
  const series = store.series.filter(row => row.kind === draft.kind && (!row.inactive || row.id === draft.seriesId)).map(row => ({ value: row.id, label: row.prefix, disabled: row.inactive }));
  const glOptions = [...glAccounts];
  draft.lines.forEach(line => { if (line.account && !glOptions.some(row => row.value === line.account)) glOptions.push({ value: line.account, label: `${line.account} · Unavailable`, disabled: true }); });
  const set = <K extends keyof CashDocument>(key: K, value: CashDocument[K]) => setDraft(current => ({ ...current, [key]: value }));
  const setLine = (id: string, changes: Partial<CashLine>) => setDraft(current => ({ ...current, lines: current.lines.map(line => line.id === id ? { ...line, ...changes } : line) }));
  const total = draft.lines.reduce((sum, line) => { try { return sum + cashMinor(amounts[line.id] || ''); } catch { return sum; } }, 0);
  const save = (approve: boolean) => {
    try { onSave({ ...draft, lines: draft.lines.map(line => ({ ...line, amountMinor: cashMinor(amounts[line.id] || '') })) }, approve); }
    catch (cause) { setError(cause instanceof Error ? cause.message : 'The document could not be saved.'); }
  };
  const correspondences = initial.status === 'Approved' ? cashCorrespondences(initial) : [];
  if (printPreview) return <CashPrintPreview report={cashDocumentReport(initial, store, companyName)} onClose={() => setPrintPreview(false)} />;
  return <GlJournalDialog wide title={`${locked ? 'View document' : isNew ? 'New document' : 'Edit document'} · ${draft.kind}`} subtitle={`${companyName}${draft.number ? ` · ${draft.number}` : ''}`} onClose={onClose} footer={
    <div role="group" aria-label={uiText("Cash document actions")} className="flex w-full flex-wrap items-center justify-between gap-3">
      {!isNew && <PageActionButton icon={<Printer size={16} />} className="shrink-0" onClick={() => setPrintPreview(true)}>{uiText("Print / PDF")}</PageActionButton>}
      <div className="ml-auto flex flex-wrap items-center justify-end gap-2">
        <PageActionButton className="shrink-0" onClick={onClose}>{locked ? uiText('Close') : uiText('Cancel')}</PageActionButton>
        {!locked && <>
          <PageActionButton className="shrink-0" onClick={() => save(false)}>{uiText("Save draft")}</PageActionButton>
          <PageActionButton className="shrink-0" onClick={() => save(true)}>{uiText("Save & approve")}</PageActionButton>
        </>}
      </div>
    </div>
  }>
    <div className="space-y-4">
      {error && <p role="alert" className="rounded-lg bg-red-50 p-3 text-[12px] text-red-700">{error}</p>}
      <div className="flex flex-wrap items-center justify-between gap-3"><CashStatus status={draft.inactive ? 'Inactive' : draft.status} /><span className="text-[12px] text-[#7288A3]">{draft.kind === 'Money receipt' ? uiText('PPK · Money collected') : draft.kind === 'Cash income order' ? uiText('KPO · Cash received') : uiText('KIO · Cash paid')}</span></div>
      <CashSection title={uiText("1. Document information")}>
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <CashField label={uiText("Cash account *")}><SearchableSelect portalMenu ariaLabel={uiText("Cash account")} className={cashInput} value={draft.accountId} options={activeAccounts} disabled={locked || !!draft.receiptId} onChange={value => set('accountId', value)} /></CashField>
          <CashField label={uiText("Date *")}><input aria-label={uiText("Cash document date")} type="date" className={cashInput} disabled={locked} value={draft.date} onChange={event => set('date', event.target.value)} /></CashField>
          <CashField label={uiText("Series *")}><SearchableSelect portalMenu ariaLabel={uiText("Cash document series")} className={cashInput} value={draft.seriesId} options={series} disabled={locked || !isNew} onChange={value => set('seriesId', value)} /></CashField>
          <CashField label={uiText("Document No.")}><input aria-label={uiText("Cash document number")} className={cashInput} readOnly value={draft.number || 'Assigned when saved'} /></CashField>
          <div className="sm:col-span-2"><CashField label={uiText("Counterparty *")}>{manualParty && !locked ? <input aria-label={uiText("Cash counterparty name")} className={cashInput} value={draft.counterparty} onChange={event => set('counterparty', event.target.value)} /> : <SearchableSelect portalMenu ariaLabel={uiText("Cash counterparty")} className={cashInput} value={draft.counterparty} options={[...new Set([...counterparties, draft.counterparty].filter(Boolean))]} disabled={locked} onChange={value => set('counterparty', value)} />}</CashField>{!locked && <button type="button" onClick={() => setManualParty(value => !value)} className="mt-1 text-[11px] text-[#007EA7] hover:underline">{manualParty ? uiText('Choose from counterparties') : uiText('Enter a person / other counterparty')}</button>}</div>
          <CashField label={uiText("Currency")}><input aria-label={uiText("Cash currency")} className={cashInput} readOnly value={account?.currency || draft.currency || '—'} /></CashField>
          <CashField label={uiText("Cash GL account")}><input aria-label={uiText("Cash GL account")} className={cashInput} readOnly value={account?.glAccount || draft.cashGlAccount || '—'} /></CashField>
          <div className="sm:col-span-2 xl:col-span-4"><CashField label={uiText("Purpose of payment *")}><input aria-label={uiText("Cash purpose of payment")} className={cashInput} disabled={locked} value={draft.purpose} onChange={event => set('purpose', event.target.value)} /></CashField></div>
        </div>
      </CashSection>
      <CashSection title={uiText("2. Accounting allocation")}>
        <div className="max-h-[340px] overflow-auto rounded-lg border border-[#E5EDF9]">
          <table className="w-full min-w-[850px] table-fixed text-left text-[12px]"><thead className="sticky top-0 z-10 bg-[#F3F7FB] text-[#7288A3]"><tr>{[['#', 'w-10'], ['GL account', 'w-[240px]'], ['Description', 'w-[220px]'], ['Related document', 'w-[210px]'], [`Amount ${account?.currency || draft.currency}`, 'w-32'], ['', 'w-10']].map(([label, width]) => <th key={label} className={`px-2 py-3 font-medium ${width}`}>{label || <span className="sr-only">{uiText("Actions")}</span>}</th>)}</tr></thead>
            <tbody>{draft.lines.map((line, index) => <tr key={line.id} className="border-t border-[#E5EDF9]">
              <td className="px-2 text-[#7288A3]">{index + 1}</td>
              <td className="p-2"><SearchableSelect portalMenu ariaLabel={`Correspondence account ${index + 1}`} className={cashInput} value={line.account} options={glOptions.filter(row => row.value !== account?.glAccount)} disabled={locked} onChange={value => setLine(line.id, { account: value })} /></td>
              <td className="p-2"><input aria-label={`Cash line description ${index + 1}`} className={cashInput} value={line.description} disabled={locked} onChange={event => setLine(line.id, { description: event.target.value })} /></td>
              <td className="p-2"><SearchableSelect portalMenu ariaLabel={`Related cash document ${index + 1}`} className={cashInput} value={line.relatedDocumentId} options={[{ value: '', label: '—' }, ...relatedDocuments.filter(row => row.currency === account?.currency || !row.currency).map(row => ({ value: row.id, label: row.label })), ...(!relatedDocuments.some(row => row.id === line.relatedDocumentId) && line.relatedDocumentId ? [{ value: line.relatedDocumentId, label: line.relatedDocumentNumber }] : [])]} disabled={locked} onChange={value => setLine(line.id, { relatedDocumentId: value, relatedDocumentNumber: relatedDocuments.find(row => row.id === value)?.number || '' })} /></td>
              <td className="p-2"><input aria-label={`Cash line amount ${index + 1}`} inputMode="decimal" className={`${cashInput} tabular-nums`} value={amounts[line.id] || ''} disabled={locked} onChange={event => setAmounts(current => ({ ...current, [line.id]: event.target.value }))} /></td>
              <td className="pr-2">{!locked && <button type="button" title={uiText("Remove line")} aria-label={`Remove cash line ${index + 1}`} className="text-[#7288A3] hover:text-red-600" onClick={() => set('lines', draft.lines.filter(row => row.id !== line.id))}><Trash2 size={15} /></button>}</td>
            </tr>)}</tbody>
          </table>
        </div>
        <div className="mt-3 flex items-center justify-between gap-4">{!locked ? <PageActionButton icon={<Plus size={14} />} onClick={() => set('lines', [...draft.lines, { id: cashId(), account: '', description: '', amountMinor: 0, relatedDocumentId: '', relatedDocumentNumber: '' }])}>{uiText("Add line")}</PageActionButton> : <span />}<div className="text-right text-[12px] text-[#7288A3]">{uiText("Total")}<span className="ml-4 text-[18px] font-semibold tabular-nums text-[#007EA7]">{cashAmount(locked ? cashTotal(initial) : total)} {account?.currency || draft.currency}</span></div></div>
        <p className="mt-3 text-[11px] text-[#7288A3]">{uiText("Related documents are references only. Matching is managed in Reconciliation.")}{draft.kind === 'Money receipt' ? uiText(' Create a cash income order to include this receipt in the cash book.') : ''}</p>
      </CashSection>
      {!!correspondences.length && <CashSection title={uiText("3. GL correspondence")}><table className="w-full text-left text-[12px]"><thead><tr>{['GL account', 'Debit', 'Credit'].map(label => <th key={label} className="px-3 py-2 font-medium text-[#7288A3]">{uiText(label)}</th>)}</tr></thead><tbody>{correspondences.map((row, index) => <tr key={index} className="border-t border-[#E5EDF9]"><td className="px-3 py-2">{row.account}</td><td className="px-3 py-2 tabular-nums">{cashAmount(row.debit)}</td><td className="px-3 py-2 tabular-nums">{cashAmount(row.credit)}</td></tr>)}</tbody></table></CashSection>}
      <details className="rounded-xl border border-[#D3E1EC] text-[12px]"><summary className="cursor-pointer bg-[#F3F7FB] px-4 py-3 font-semibold">{uiText("Additional information & history")}</summary><div className="space-y-4 p-4"><CashField label={uiText("Notes")}><textarea aria-label={uiText("Cash document notes")} className={`${cashInput} h-20 py-2`} disabled={locked} value={draft.notes} onChange={event => set('notes', event.target.value)} /></CashField>{draft.receiptId && <p>{uiText("Source receipt: ")}{store.documents.find(row => row.id === draft.receiptId)?.number || '—'}</p>}<div className="grid gap-3 text-[#7288A3] sm:grid-cols-3"><span>{uiText("Cashier: ")}{draft.cashier || uiText('Assigned on approval')}</span><span>{uiText("Accountant: ")}{draft.accountant || uiText('Assigned on approval')}</span><span>{uiText("Created by: ")}{draft.createdBy}</span></div>{store.audit.filter(row => row.recordId === initial.id).map(row => <p key={row.id} className="border-t border-[#E5EDF9] pt-2 text-[11px] text-[#7288A3]">{new Date(row.at).toLocaleString('en-GB')} · {row.action} · {row.actor}</p>)}</div></details>
    </div>
  </GlJournalDialog>;
}
