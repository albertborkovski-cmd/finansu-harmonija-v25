import { translateStatus as statusText } from '../../i18n/language';
import { translateUi as uiText } from '../../i18n/language';
import { useId, type ReactNode } from 'react';
export const cashInput = 'h-10 w-full min-w-0 rounded-lg border border-[#D3E1EC] bg-white px-3 text-[13px] font-medium text-[#10233A] outline-none focus:border-[#007EA7] disabled:bg-[#F6F8FB] disabled:text-[#7288A3]';
export function CashField({ label, children }: { label: string; children: ReactNode }) {
  return <label className="flex min-w-0 flex-col gap-1.5 text-[12px] font-medium text-[#7288A3]"><span>{uiText(label)}</span>{children}</label>;
}
export function CashSection({ title, children }: { title: string; children: ReactNode }) {
  const id = useId();
  return <section aria-labelledby={id} className="overflow-hidden rounded-xl border border-[#D3E1EC]"><h3 id={id} className="bg-[#F3F7FB] px-4 py-3 text-[13px] font-semibold text-[#10233A]">{uiText(title)}</h3><div className="p-4">{children}</div></section>;
}
export function CashRowAction({ label, children, onClick, disabled = false }: { label: string; children: ReactNode; onClick: () => void; disabled?: boolean }) {
  return <button type="button" title={uiText(label)} aria-label={uiText(label)} disabled={disabled} onClick={onClick} className="flex h-7 w-7 shrink-0 items-center justify-center rounded border-2 border-[#D3E1EC] bg-white text-[#7288A3] transition-colors enabled:hover:border-[#007EA7] enabled:hover:text-[#007EA7] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#007EA7] disabled:cursor-not-allowed disabled:opacity-40">{children}</button>;
}
export function CashStatus({ status }: { status: string }) {
  return <span className={`inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-[11px] font-medium ${status === 'Approved' || status === 'Active' ? 'bg-[#E8F5EE] text-[#23744F]' : status === 'Inactive' ? 'bg-[#F1F3F6] text-[#7288A3]' : 'bg-[#E6F2F6] text-[#007EA7]'}`}><span className="h-1.5 w-1.5 rounded-full bg-current" />{statusText(status)}</span>;
}
