import { ArrowLeft, ArrowRight, BookOpen, ChevronRight, ExternalLink, Info } from 'lucide-react';
import { integrationTopic, integrationTopics } from '../lib/integrationHelpTopics';
import { exportHelpHref } from '../lib/exportSettingsHelp';
import { exportFieldHelp, exportHelpFields } from '../lib/exportSettingsHelp';
import { integrationArticle } from '../lib/integrationHelp';
import { CURRENT_INTEGRATION_NOTICE, RIVILE_GUIDE_SOURCES } from '../lib/exportHelpGuide';
import { translateUi as t } from '../i18n/language';
import { integrationHelpHref } from './IntegrationHelpLink';
import { HelpScreenshot } from './HelpMedia';
import { integrationHelpVisuals } from '../lib/helpVisuals';
import type { IntegrationHelpLink as TopicLink } from '../lib/integrationHelpTopics';
import { useHelpContent } from './HelpContentProvider';
import { isHelpVisible } from '../lib/helpContent';

const panel = 'rounded-xl border border-[#D3E1EC] bg-white p-5 sm:p-7 [&_th]:!resize-none [&_th]:after:!hidden';
function RelatedLinks({ links: allLinks, integration, lang }: { links: TopicLink[]; integration: string; lang: 0 | 1 }) {
  const { state } = useHelpContent();
  const links = allLinks.filter(link => isHelpVisible(integrationHelpHref(link.integration || integration, link.topic), state));
  return <ul className="space-y-2">{links.map(link => <li key={`${link.integration || integration}/${link.topic}/${link.section || ''}`}>
    <a href={integrationHelpHref(link.integration || integration, link.topic, link.section)} className="inline-flex items-start gap-2 text-[13px] leading-6 text-[#007EA7] underline decoration-[#A5CADB] underline-offset-4 hover:decoration-[#007EA7] focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#007EA7]">
      <ArrowRight size={14} className="mt-1.5 shrink-0" aria-hidden="true" />{link.label[lang]}
    </a>
  </li>)}</ul>;
}

export default function IntegrationHelpTopics({ integration, topicId, lt }: { integration: string; topicId: string | null; lt: boolean }) {
  const lang = lt ? 1 : 0;
  const { state } = useHelpContent();
  const article = integrationArticle(integration);
  const accounting = article.group === 'accounting';
  const fields = accounting && topicId === 'configuration' ? exportHelpFields(integration, 'overview') : [];
  const topics = integrationTopics(integration).filter(item => isHelpVisible(integrationHelpHref(integration, item.id), state));
  const topic = integrationTopic(integration, topicId);
  const next = topic ? topics[topics.indexOf(topic) + 1] : undefined;
  const visuals = topic ? integrationHelpVisuals(integration, topic.id) : [];
  const providerLinks = [...(article.links || []), ...(integration.startsWith('Rivilė') ? RIVILE_GUIDE_SOURCES.filter(source => integration === 'Rivilė ERP' ? source.title.includes('ERP') : !source.title.includes('ERP')).map(source => ({ label: source.title, url: source.url })) : [])];

  if (!topic) return <section className={panel} aria-labelledby="integration-topics-title">
    <div className="mb-3 flex items-center gap-2 text-[12px] text-[#7288A3]"><BookOpen size={15} />{lt ? 'Integracijos' : 'Integrations'}<ChevronRight size={13} />{article.name[lang]}</div>
    <h2 id="integration-topics-title" className="text-[23px] font-semibold">{article.name[lang]}</h2>
    <p className="mt-2 text-[13px] leading-6 text-[#526B86]">{article.summary[lang]}</p>
    <p className="mt-2 text-[12px] leading-6 text-[#7288A3]">{lt ? 'Pasirinkite temą. Tiekėjo veiksmai ir Finansų harmonijos funkcijos aprašyti atskirai. Pateikti tik patikrinti gavėjo meniu keliai; jų nebuvimas nereiškia, kad naudojamas bendras visų sistemų importas.' : 'Choose a topic. Provider steps and Finansų harmonija capabilities are separate. Only verified receiver menu paths are included; a missing path does not imply a universal import procedure.'}</p>
    <p className="mb-3 mt-6 text-[11px] font-semibold uppercase tracking-wide text-[#7288A3]">{lt ? 'Pagalbos temos' : 'Help topics'} · {topics.length}</p>
    <div className="divide-y divide-[#E5EDF9] overflow-hidden rounded-lg border border-[#D3E1EC]">
      {topics.map((item, index) => <a key={item.id} href={integrationHelpHref(integration, item.id)} className="group flex items-center gap-4 px-4 py-5 transition-colors hover:bg-[#F2F8FB] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-[-2px] focus-visible:outline-[#007EA7]">
        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#EAF4F9] text-[12px] font-semibold text-[#007EA7]">{index + 1}</span>
        <span className="min-w-0 flex-1"><span className="block text-[14px] font-semibold text-[#007EA7]">{item.title[lang]}</span><span className="mt-1 block text-[12px] leading-5 text-[#7288A3]">{item.description[lang]}</span></span>
        <ChevronRight size={18} className="shrink-0 text-[#7288A3] group-hover:text-[#007EA7]" />
      </a>)}
    </div>
    {accounting && <><aside className="mt-5 flex gap-2 text-[12px] leading-6 text-[#7288A3]"><Info size={16} className="mt-1 shrink-0 text-[#007EA7]" /><p>{CURRENT_INTEGRATION_NOTICE[lang]}</p></aside><a className="mt-5 inline-flex items-center gap-2 text-[12px] font-medium text-[#007EA7] underline underline-offset-2" href={exportHelpHref(integration)}>{lt ? 'Eksporto nustatymų laukų paaiškinimai' : 'Export-setting field descriptions'}<ArrowRight size={14} /></a></>}
  </section>;

  return <article className="space-y-5" aria-labelledby="integration-topic-title">
    <header className={panel}>
      <a href={integrationHelpHref(integration)} className="mb-4 inline-flex items-center gap-2 text-[12px] font-medium text-[#007EA7]"><ArrowLeft size={14} />{lt ? `Visos ${article.name[lang]} temos` : `All ${article.name[lang]} topics`}</a>
      <p className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-[#7288A3]">{article.name[lang]} · {topics.indexOf(topic) + 1} / {topics.length}</p>
      <h2 id="integration-topic-title" className="text-[21px] font-semibold leading-8">{topic.title[lang]}</h2>
      <p className="mt-2 text-[13px] leading-6 text-[#526B86]">{topic.description[lang]}</p>
      <nav aria-label={lt ? 'Šiame straipsnyje' : 'In this article'} className="mt-6 border-t border-[#E5EDF9] pt-4">
        <h3 className="mb-3 text-[12px] font-semibold text-[#526B86]">{lt ? 'Šiame straipsnyje' : 'In this article'}</h3>
        <ol className="space-y-2">{topic.sections.map((section, index) => <li key={section.title[0]}><a href={integrationHelpHref(integration, topic.id, index + 1)} className="text-[12px] leading-5 text-[#007EA7] underline decoration-[#BCD7E3] underline-offset-4 hover:decoration-[#007EA7]">{section.title[lang]}</a></li>)}</ol>
      </nav>
    </header>
    {topic.sections.map((section, sectionIndex) => <section id={`help-section-${sectionIndex + 1}`} aria-labelledby={`help-heading-${sectionIndex + 1}`} key={section.title[0]} className={`${panel} scroll-mt-5`}>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2"><h3 id={`help-heading-${sectionIndex + 1}`} className="text-[16px] font-semibold">{section.title[lang]}</h3><span className="rounded-md bg-[#EBF5FA] px-2 py-1 text-[10px] font-semibold text-[#007EA7]">{section.system === 'FH' ? 'Finansų harmonija' : section.system}</span></div>
      {section.paragraphs?.map(paragraph => <p key={paragraph[0]} className="mb-3 text-[13px] leading-6 text-[#526B86]">{paragraph[lang]}</p>)}
      {section.steps && <ol className="space-y-4">{section.steps.map((step, index) => <li key={step[0]} className="flex gap-3"><span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#E5EDF9] text-[11px] font-semibold text-[#007EA7]">{index + 1}</span><p className="text-[13px] leading-6 text-[#526B86]">{step[lang]}</p></li>)}</ol>}
      {section.system === 'FH' && topic.sections.findIndex(item => item.system === 'FH') === sectionIndex && visuals.map(visual => <HelpScreenshot key={visual.file} lt={lt} file={visual.file} caption={visual.caption[lang]} />)}
      {section.table && <div className="mt-4 overflow-x-auto rounded-lg border border-[#D3E1EC]"><table className="w-full text-left text-[12px] leading-6"><thead className="bg-[#F2F7FA]"><tr>{section.table.headers.map(header => <th scope="col" key={header[0]} className="px-4 py-3 font-semibold">{header[lang]}</th>)}</tr></thead><tbody className="divide-y divide-[#E5EDF9]">{section.table.rows.map((row, index) => <tr key={index}>{row.map((cell, cellIndex) => cellIndex === 0 ? <th scope="row" key={cellIndex} className="px-4 py-3 align-top font-medium">{cell[lang]}</th> : <td key={cellIndex} className="px-4 py-3 align-top text-[#526B86]">{cell[lang]}</td>)}</tr>)}</tbody></table></div>}
      {section.example && <aside className="mt-5 rounded-lg border-l-4 border-[#007EA7] bg-[#F1F7FA] p-4"><h4 className="mb-2 text-[13px] font-semibold">{section.example.title[lang]}</h4>{section.example.code && <pre className="my-3 overflow-x-auto rounded-md border border-[#D3E1EC] bg-white p-3 text-[12px]"><code>{section.example.code}</code></pre>}{section.example.paragraphs.map(paragraph => <p key={paragraph[0]} className="mt-2 text-[12px] leading-6 text-[#526B86]">{paragraph[lang]}</p>)}</aside>}
      {Boolean(section.links?.length) && <div className="mt-5 border-t border-[#E5EDF9] pt-4"><p className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-[#7288A3]">{lt ? 'Išsamiau apie šį žingsnį' : 'More about this step'}</p><RelatedLinks links={section.links!} integration={integration} lang={lang} /></div>}
    </section>)}
    {topic.fieldReference && <section className={panel}><h3 className="text-[16px] font-semibold">{lt ? 'Laukai ir jų reikšmės' : 'Fields and their meanings'}</h3><dl className="mt-2 divide-y divide-[#E5EDF9]">{fields.map(field => <div key={field.key} className="py-4"><dt className="text-[13px] font-semibold">{t(field.label)}</dt><dd className="mt-1 text-[13px] leading-6 text-[#526B86]">{exportFieldHelp(field, lt)}</dd></div>)}{article.fields?.map(field => <div key={field.label[0]} className="py-4"><dt className="text-[13px] font-semibold">{field.label[lang]}</dt><dd className="mt-1 text-[13px] leading-6 text-[#526B86]">{field.description[lang]}</dd></div>)}</dl></section>}
    {topic.note && <aside className="flex gap-3 rounded-xl border border-[#D3E1EC] bg-[#EEF6FA] p-5"><Info size={18} className="mt-0.5 shrink-0 text-[#007EA7]" /><div><h3 className="mb-1 text-[13px] font-semibold">{lt ? 'Dabartinė FH funkcija' : 'Current FH capability'}</h3><p className="text-[12px] leading-6 text-[#526B86]">{topic.note[lang]}</p></div></aside>}
    {!visuals.length && topic.screenshot && <section className={panel}><HelpScreenshot lt={lt} file={topic.screenshot.file} caption={topic.screenshot.caption[lang]} /></section>}
    {providerLinks.length > 0 && <section className={panel}><h3 className="mb-3 text-[13px] font-semibold">{lt ? 'Oficiali tiekėjo pagalba' : 'Official provider help'}</h3><div className="flex flex-wrap gap-4">{providerLinks.map(link => <a key={link.url} href={link.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-[12px] text-[#007EA7] underline underline-offset-2">{link.label}<ExternalLink size={12} /></a>)}</div></section>}
    {Boolean(topic.related?.length) && <section className={panel}><h3 className="mb-4 text-[16px] font-semibold">{lt ? 'Susiję paaiškinimai' : 'Related instructions'}</h3><RelatedLinks links={topic.related!} integration={integration} lang={lang} /></section>}
    <footer className="flex flex-wrap items-center justify-between gap-4 rounded-lg border border-[#D3E1EC] bg-white p-4">
      <a href={integrationHelpHref(integration)} className="inline-flex items-center gap-2 text-[12px] font-medium text-[#007EA7]"><ArrowLeft size={14} />{lt ? 'Visos temos' : 'All topics'}</a>
      {next && <a href={integrationHelpHref(integration, next.id)} className="inline-flex items-center gap-2 text-[12px] font-medium text-[#007EA7]">{next.title[lang]}<ArrowRight size={14} /></a>}
    </footer>
  </article>;
}
