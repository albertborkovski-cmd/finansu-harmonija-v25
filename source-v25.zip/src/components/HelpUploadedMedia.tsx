import { useEffect, useState } from 'react';
import { useLanguage } from '../i18n/language';
import { readHelpMedia } from '../lib/helpMediaStore';

export default function HelpUploadedMedia({ source, caption, video }: { source: string; caption: string; video: boolean }) {
  const lt = useLanguage() === 'lt';
  const [media, setMedia] = useState<{ source: string; url: string } | null>(null);
  const [failed, setFailed] = useState('');
  useEffect(() => {
    let active = true, objectUrl = '';
    readHelpMedia(source).then(record => {
      if (!active) return;
      if (!record) { setFailed(source); return; }
      objectUrl = URL.createObjectURL(record.blob);
      setMedia({ source, url: objectUrl });
    }).catch(() => { if (active) setFailed(source); });
    return () => { active = false; if (objectUrl) URL.revokeObjectURL(objectUrl); };
  }, [source]);
  const url = media?.source === source ? media.url : '';
  return <figure className="overflow-hidden rounded-lg border border-[#D3E1EC] bg-white">
    {url ? video ? <video src={url} controls preload="metadata" className="max-h-[620px] w-full" aria-label={caption} />
      : <a href={url} target="_blank" rel="noopener noreferrer"><img src={url} alt={caption} loading="lazy" className="h-auto max-h-[720px] w-full object-contain" /></a>
      : <p className="p-4 text-xs text-[#7288A3]">{failed === source ? (lt ? 'Šis failas nepasiekiamas šios naršyklės saugykloje.' : 'This file is not available in this browser’s storage.') : (lt ? 'Įkeliamas failas…' : 'Loading media…')}</p>}
    {caption && <figcaption className="border-t border-[#E5EDF9] px-4 py-2 text-xs text-[#7288A3]">{caption}</figcaption>}
  </figure>;
}
