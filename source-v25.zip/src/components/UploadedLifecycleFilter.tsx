import { Check } from 'lucide-react';
import { translateStatus as statusText, translateUi as uiText } from '../i18n/language';
import { UPLOADED_LIFECYCLE_FILTERS, toggleUploadedLifecycleFilter, type UploadedLifecycleFilter as Filter } from '../lib/uploadedLifecycleFilters';

export default function UploadedLifecycleFilter({ value, counts, onChange }: {
  value: Filter[]; counts: Partial<Record<Filter, number>>; onChange: (value: Filter[]) => void;
}) {
  return <div role="group" aria-label={uiText('Processing & export')} className="uploaded-lifecycle-filters flex min-w-0 flex-1 flex-wrap items-center gap-1">
    {UPLOADED_LIFECYCLE_FILTERS.map(option => {
      const checked = value.includes(option.value);
      return <button key={option.value} type="button" aria-pressed={checked} data-static-selection="true"
        onClick={() => onChange(toggleUploadedLifecycleFilter(value, option.value))}
        className={`inline-flex h-8 shrink-0 items-center gap-1.5 whitespace-nowrap rounded-md border border-transparent px-2 font-montserrat text-[12px] font-medium leading-[18px] transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#007EA7] ${checked ? 'bg-[#E5EDF9] text-[#007EA7]' : 'bg-[#F4F8FC] text-[#7288A3] hover:bg-[#EAF4F8] hover:text-[#007EA7]'}`}>
        <span aria-hidden="true" className={`flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-[6px] border ${checked ? 'border-[#007EA7] bg-[#007EA7]' : 'border-[#A1B6C6]'}`}>{checked && <Check size={12} strokeWidth={2.5} className="text-white" />}</span>
        <span>{statusText(option.label)}</span><span className={`min-w-5 rounded px-1 text-center text-[10px] leading-[18px] tabular-nums ${checked ? 'bg-white/80 text-[#007EA7]' : 'bg-[#E5EDF9] text-[#7288A3]'}`}>{counts[option.value] || 0}</span>
      </button>;
    })}
  </div>;
}
