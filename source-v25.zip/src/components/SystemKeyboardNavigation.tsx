import { useEffect, useState } from 'react';
import { installKeyboardNavigation } from '../lib/keyboardNavigation';
import { translateUi as t } from '../i18n/language';

/** Mounted once above both workspaces, including lazily loaded screens and portals. */
export default function SystemKeyboardNavigation() {
  const [pendingClose, setPendingClose] = useState<(() => void) | null>(null);
  useEffect(() => installKeyboardNavigation(close => setPendingClose(() => close)), []);
  if (!pendingClose) return null;
  return <div className="fixed inset-0 z-[20000] flex items-center justify-center bg-[#10233A]/30 p-4">
    <section role="alertdialog" aria-modal="true" aria-labelledby="keyboard-discard-title" aria-describedby="keyboard-discard-description" className="w-full max-w-md rounded-xl border border-[#D3E1EC] bg-white p-6 font-montserrat text-[#10233A] shadow-xl">
      <h2 id="keyboard-discard-title" className="text-lg font-semibold">{t('Unsaved changes')}</h2>
      <p id="keyboard-discard-description" className="mt-3 text-sm text-[#7288A3]">{t('You changed fields in this window. Close without saving?')}</p>
      <div className="mt-6 flex flex-wrap justify-end gap-2">
        <button type="button" data-keyboard-dismiss onClick={() => setPendingClose(null)} className="rounded-md border-2 border-[#D3E1EC] px-3 py-2 text-sm font-semibold text-[#7288A3]">{t('Keep editing')}</button>
        <button type="button" onClick={() => { setPendingClose(null); pendingClose(); }} className="rounded-md bg-[#007EA7] px-3 py-2 text-sm font-semibold text-white">{t('Close without saving')}</button>
      </div>
    </section>
  </div>;
}
