import { useEffect, useRef, useState } from 'react';
import { CheckCircle2, FileText, Send, UploadCloud, X } from 'lucide-react';
import { BALANCE_RESPONSES_KEY, loadBalancePreview, saveBalanceFiles, saveBalanceResponse, validateBalanceFiles } from '../lib/balanceConfirmation';
import { markOrganizationEmailResponseReceived } from '../lib/organizationEmail';
import BalanceStatementDocument from './BalanceStatementDocument';
import SearchableSelect from './SearchableSelect';
import { PageActionButton } from './PageHeader';

export default function BalanceConfirmationPortal() {
  const [statement] = useState(() => loadBalancePreview(decodeURIComponent(window.location.pathname.split('/balance-confirmation/')[1] || '')));
  const [language, setLanguage] = useState<'LT' | 'EN'>(statement?.language || 'EN');
  const lt = language === 'LT', t = (en: string, translated: string) => lt ? translated : en;
  const [decision, setDecision] = useState<'confirm' | 'disagree'>('confirm'), [comment, setComment] = useState('');
  const [response, setResponse] = useState(() => { try { return statement ? JSON.parse(localStorage.getItem(BALANCE_RESPONSES_KEY) || '{}')[statement.id] || null : null; } catch { return null; } });
  const [files, setFiles] = useState<File[]>([]), [uploaded, setUploaded] = useState<string[]>([]), [uploading, setUploading] = useState(false), [dragging, setDragging] = useState(false);
  const [error, setError] = useState(''), [uploadError, setUploadError] = useState('');
  const inputRef = useRef<HTMLInputElement>(null), uploadRef = useRef<HTMLElement>(null);
  useEffect(() => { if (window.location.hash === '#upload') uploadRef.current?.scrollIntoView({ block: 'center' }); }, []);
  const chooseFiles = (incoming: File[]) => {
    setUploadError('');
    const next = [...files, ...incoming.filter(file => !files.some(existing => existing.name === file.name && existing.size === file.size && existing.lastModified === file.lastModified))];
    try { validateBalanceFiles(next); setFiles(next); } catch (cause) { setUploadError(cause instanceof Error ? cause.message : 'Invalid files.'); }
  };
  const upload = async () => {
    if (!statement || uploading) return;
    setUploading(true); setUploadError('');
    try { await saveBalanceFiles(statement, files); setUploaded(previous => [...previous, ...files.map(file => file.name)]); setFiles([]); }
    catch { setUploadError(t('Files could not be saved. Please try again.', 'Nepavyko išsaugoti failų. Bandykite dar kartą.')); }
    finally { setUploading(false); }
  };
  const submit = () => {
    if (!statement || response) return;
    setError('');
    try {
      const saved = saveBalanceResponse(statement.id, decision, comment);
      setResponse(saved);
      markOrganizationEmailResponseReceived(statement.id, saved.at, decision === 'confirm' ? 'matches' : 'differs');
    } catch (cause) { setError(cause instanceof Error ? cause.message : t('The response could not be saved.', 'Nepavyko išsaugoti atsakymo.')); }
  };
  if (!statement) return <main className="mx-auto max-w-3xl p-8 font-montserrat text-[#10233A]"><h1 className="text-xl font-semibold">{t('Balance confirmation', 'Likučio suderinimas')}</h1><p className="mt-4">{t('This confirmation link is not available in this browser. Ask the sender for a valid link.', 'Ši suderinimo nuoroda šioje naršyklėje nepasiekiama. Paprašykite siuntėjo galiojančios nuorodos.')}</p></main>;
  return <main className="min-h-screen bg-[#F6F9FC] font-montserrat text-[#10233A]">
    <header className="border-b border-[#D3E1EC] bg-white"><div className="mx-auto flex max-w-[1200px] items-center justify-between gap-4 px-6 py-4"><span className="text-sm font-bold text-[#007EA7]">Finansų harmonija</span><div className="w-[180px]"><SearchableSelect ariaLabel="Language" value={language} onChange={value => setLanguage(value as 'EN' | 'LT')} options={[{ value: 'LT', label: 'Lietuvių (LT)' }, { value: 'EN', label: 'English (EN)' }]} className="h-9 w-full rounded-md border border-[#D3E1EC] bg-white px-3 text-xs" /></div></div></header>
    <div className="mx-auto max-w-[1200px] space-y-6 p-4 sm:p-6">
      <div className="flex items-center gap-3"><span className="rounded-lg bg-[#E5EDF9] p-3 text-[#007EA7]"><FileText size={24} /></span><div><h1 className="text-2xl font-semibold">{t('Balance confirmation', 'Likučio suderinimas')}</h1><p className="mt-1 text-xs text-[#7288A3]">{t('Review the statement, confirm the balance or describe any discrepancy.', 'Peržiūrėkite aktą, patvirtinkite likutį arba nurodykite neatitikimus.')}</p></div></div>
      <div className="rounded-xl border border-[#D3E1EC] bg-white p-5"><BalanceStatementDocument statement={{ ...statement, language }} signatures={false} /></div>
      <div className="grid items-start gap-6 lg:grid-cols-2">
        <section className="rounded-xl border border-[#D3E1EC] bg-white p-5"><h2 className="mb-4 text-sm font-semibold">{t('Your response', 'Jūsų atsakymas')} *</h2>
          {response ? <div role="status" className="flex items-start gap-3 rounded-lg bg-[#EDF8F2] p-4 text-sm text-[#277C60]"><CheckCircle2 size={20} /><div><strong>{response.decision === 'confirm' ? t('Balance confirmed', 'Likutis patvirtintas') : t('Discrepancy recorded', 'Neatitikimas užregistruotas')}</strong><p className="mt-2 whitespace-pre-wrap text-xs">{response.comment}</p><p className="mt-2 text-xs">{new Date(response.at).toLocaleString()}</p></div></div> : <>
            {(['confirm', 'disagree'] as const).map(value => <label key={value} className={`mb-3 flex cursor-pointer items-start gap-3 rounded-lg border p-3 ${decision === value ? 'border-[#007EA7] bg-[#F0F8FC]' : 'border-[#D3E1EC]'}`}><input type="radio" name="balance-response" checked={decision === value} onChange={() => setDecision(value)} className="mt-0.5 h-4 w-4 accent-[#007EA7]" /><span><strong className="text-sm">{value === 'confirm' ? t('Confirm balance', 'Patvirtinti likutį') : t('Disagree', 'Nesutinku')}</strong><span className="mt-1 block text-xs text-[#7288A3]">{value === 'confirm' ? t('The balance matches our accounting records.', 'Likutis sutampa su mūsų apskaitos duomenimis.') : t('The balance differs from our accounting records.', 'Likutis nesutampa su mūsų apskaitos duomenimis.')}</span></span></label>)}
            <label className="mt-4 block text-xs font-medium text-[#536B85]">{t('Comment', 'Komentaras')}{decision === 'disagree' && ' *'}<textarea value={comment} onChange={e => setComment(e.target.value)} maxLength={2000} rows={5} className="mt-2 w-full resize-y rounded-lg border border-[#D3E1EC] p-3 text-sm text-[#10233A] outline-none focus:border-[#007EA7]" /></label><div className="mb-4 text-right text-[11px] text-[#7288A3]">{comment.length} / 2000</div>
            {error && <p role="alert" className="mb-3 text-xs text-[#B42318]">{error}</p>}<div className="flex justify-end"><PageActionButton icon={<Send size={15} />} disabled={decision === 'disagree' && !comment.trim()} onClick={submit}>{t('Submit', 'Pateikti')}</PageActionButton></div>
          </>}
        </section>
        <section id="upload" ref={uploadRef} className="rounded-xl border border-[#D3E1EC] bg-white p-5"><h2 className="text-sm font-semibold">{t('Upload missing documents', 'Įkelti trūkstamus dokumentus')}</h2><p className="mt-2 text-xs leading-5 text-[#7288A3]">{t('Provide missing invoices or other accounting documents. Uploading files does not submit your balance response.', 'Pateikite trūkstamas sąskaitas ar kitus apskaitos dokumentus. Failų įkėlimas nepateikia jūsų atsakymo dėl likučio.')}</p>
          <div onDragOver={e => { e.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={e => { e.preventDefault(); setDragging(false); chooseFiles(Array.from(e.dataTransfer.files)); }} className={`mt-4 flex min-h-[160px] flex-col items-center justify-center gap-3 rounded-lg border border-dashed p-5 text-center ${dragging ? 'border-[#007EA7] bg-[#EAF4F8]' : 'border-[#A1B6C6] bg-[#F8FBFD]'}`}><UploadCloud size={28} className="text-[#7288A3]" /><p className="text-xs">{t('Drag and drop files here, or', 'Nutempkite failus čia arba')} <button type="button" className="font-semibold text-[#007EA7] underline" onClick={() => inputRef.current?.click()}>{t('Select files', 'Pasirinkite failus')}</button></p><p className="text-[11px] text-[#7288A3]">PDF, JPG, PNG, TIFF, DOCX, XLSX · 50 MB</p><input ref={inputRef} type="file" multiple accept=".pdf,.jpg,.jpeg,.png,.tif,.tiff,.docx,.xlsx" className="sr-only" onChange={e => { chooseFiles(Array.from(e.target.files || [])); e.target.value = ''; }} /></div>
          <ul className="mt-3 space-y-2">{files.map((file, index) => <li key={`${file.name}:${index}`} className="flex items-center justify-between gap-3 rounded-md bg-[#F1F6FA] p-2 text-xs"><span className="truncate">{file.name}</span><button type="button" disabled={uploading} aria-label={`${t('Remove', 'Pašalinti')} ${file.name}`} onClick={() => setFiles(old => old.filter((_, i) => i !== index))}><X size={16} /></button></li>)}</ul>
          {uploaded.length > 0 && <div role="status" className="mt-3 text-xs text-[#277C60]">{t('Saved locally:', 'Išsaugota vietoje:')} {uploaded.join(', ')}</div>}{uploadError && <p role="alert" className="mt-3 text-xs text-[#B42318]">{uploadError}</p>}
          <div className="mt-4 flex justify-end"><PageActionButton icon={<UploadCloud size={16} />} disabled={!files.length || uploading} onClick={() => void upload()}>{uploading ? t('Uploading…', 'Įkeliama…') : t('Upload', 'Įkelti')}</PageActionButton></div>
        </section>
      </div>
      <p className="text-center text-xs leading-5 text-[#7288A3]">{t('Frontend preview: responses and file contents are saved only in this browser. External delivery requires the server integration.', 'Sąsajos peržiūra: atsakymai ir failai išsaugomi tik šioje naršyklėje. Išoriniam perdavimui reikalinga serverio integracija.')}</p>
    </div>
  </main>;
}
